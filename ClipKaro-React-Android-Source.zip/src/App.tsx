import { useCallback, useEffect, useState } from 'react';
import { AddMusicView } from './components/AddMusicView';
import { AddVoiceView } from './components/AddVoiceView';
import { CutVideoView } from './components/CutVideoView';
import { HomeView } from './components/HomeView';
import { InGameFloatingButton } from './components/InGameFloatingButton';
import { MyClipsView } from './components/MyClipsView';
import { MyGamesView } from './components/MyGamesView';
import { TopNav } from './components/TopNav';
import { ClipItem, GameItem, SocialPlatform, WorkspaceTab } from './types/clipkaro';
import {
  addCustomGameToDb,
  DEFAULT_GAMES,
  deleteClipFromDb,
  deleteCustomGameFromDb,
  getAllClips,
  getAllGames,
  getStoredCopyrightSafeMode,
  saveClipToDb,
  setStoredCopyrightSafeMode,
} from './utils/mediaStorage';

export default function App() {
  const [activeTab, setActiveTab] = useState<WorkspaceTab>('home');
  const [clips, setClips] = useState<ClipItem[]>([]);
  const [games, setGames] = useState<GameItem[]>(DEFAULT_GAMES);
  const [isLoadingStore, setIsLoadingStore] = useState<boolean>(true);
  const [copyrightSafeMode, setCopyrightSafeMode] = useState<boolean>(() =>
    getStoredCopyrightSafeMode()
  );

  // Cross-view contextual handoffs
  const [cutLinkPrefill, setCutLinkPrefill] = useState<string>('');
  const [cutPlatformPrefill, setCutPlatformPrefill] = useState<
    SocialPlatform | 'upload' | 'studio'
  >('youtube');
  const [cutStreamerPrefill, setCutStreamerPrefill] = useState<string>('');
  const [cutGamePrefill, setCutGamePrefill] = useState<string>('');
  const [clipsGameFilter, setClipsGameFilter] = useState<string>('all');

  // In-Game Floating Button state (demo visible by default in web preview)
  const isWebPreview =
    typeof window !== 'undefined' && window.location.protocol.startsWith('http');
  const [floatingVisible, setFloatingVisible] = useState<boolean>(isWebPreview);
  const [floatingGameName, setFloatingGameName] = useState<string>('BGMI');
  const [isFloatingDemo, setIsFloatingDemo] = useState<boolean>(isWebPreview);

  const refreshStore = useCallback(async () => {
    try {
      const [loadedClips, loadedGames] = await Promise.all([getAllClips(), getAllGames()]);
      setClips(loadedClips);
      setGames(loadedGames);
    } finally {
      setIsLoadingStore(false);
    }
  }, []);

  useEffect(() => {
    refreshStore();
  }, [refreshStore]);

  const handleToggleCopyrightSafeMode = () => {
    setCopyrightSafeMode((prev) => {
      const next = !prev;
      setStoredCopyrightSafeMode(next);
      return next;
    });
  };

  const handleSaveClip = async (clip: ClipItem) => {
    await saveClipToDb(clip);
    const updated = await getAllClips();
    setClips(updated);
  };

  const handleDeleteClip = async (id: string) => {
    await deleteClipFromDb(id);
    const updated = await getAllClips();
    setClips(updated);
  };

  const handleAddGame = async (name: string, genre: string) => {
    const coverPool = DEFAULT_GAMES.map((g) => g.coverUrl);
    const coverUrl = coverPool[games.length % coverPool.length];
    const newGame: GameItem = {
      id: `game-custom-${Date.now()}`,
      name,
      genre,
      coverUrl,
      isCustom: true,
    };
    await addCustomGameToDb(newGame);
    const updatedGames = await getAllGames();
    setGames(updatedGames);
  };

  const handleDeleteCustomGame = async (id: string) => {
    await deleteCustomGameFromDb(id);
    const updatedGames = await getAllGames();
    setGames(updatedGames);
  };

  const handleSendLinkToCut = (
    url: string,
    platform: SocialPlatform,
    suggestedStreamer?: string
  ) => {
    setCutLinkPrefill(url);
    setCutPlatformPrefill(platform);
    setCutStreamerPrefill(suggestedStreamer ?? '');
    setActiveTab('cut');
  };

  const handleViewGameClips = (gameName: string) => {
    setClipsGameFilter(gameName);
    setActiveTab('clips');
  };

  const handleCutClipForGame = (gameName: string) => {
    setCutGamePrefill(gameName);
    setActiveTab('cut');
  };

  return (
    <div className="min-h-screen bg-[#0B0E14] text-slate-100 flex flex-col">
      <TopNav
        activeTab={activeTab}
        onNavigate={(tab) => {
          if (tab === 'clips') setClipsGameFilter('all');
          setActiveTab(tab);
        }}
      />

      <main className="mx-auto w-full max-w-7xl flex-1 px-4 py-6 sm:px-6 sm:py-8">
        {isLoadingStore ? (
          <div className="space-y-4">
            <div className="h-8 w-64 animate-pulse rounded-lg bg-slate-800/70" />
            <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-6">
              {Array.from({ length: 6 }).map((_, idx) => (
                <div key={idx} className="h-28 animate-pulse rounded-xl bg-slate-800/50" />
              ))}
            </div>
            <div className="aspect-video w-full animate-pulse rounded-xl bg-slate-800/40" />
          </div>
        ) : (
          <>
            {activeTab === 'home' && (
              <HomeView
                clipCount={clips.length}
                gameCount={games.length}
                copyrightSafeMode={copyrightSafeMode}
                onToggleCopyrightSafeMode={handleToggleCopyrightSafeMode}
                onNavigate={(tab) => {
                  if (tab === 'clips') setClipsGameFilter('all');
                  setActiveTab(tab);
                }}
                onSendLinkToCut={handleSendLinkToCut}
              />
            )}

            {activeTab === 'cut' && (
              <CutVideoView
                copyrightSafeMode={copyrightSafeMode}
                onToggleCopyrightSafeMode={handleToggleCopyrightSafeMode}
                games={games}
                initialOriginalLink={cutLinkPrefill}
                initialPlatform={cutPlatformPrefill}
                initialStreamerName={cutStreamerPrefill}
                initialGameTag={cutGamePrefill}
                onSaveClip={handleSaveClip}
                onGoToMyClips={() => {
                  setClipsGameFilter('all');
                  setActiveTab('clips');
                }}
              />
            )}

            {activeTab === 'voice' && (
              <AddVoiceView
                clips={clips}
                onSaveClip={handleSaveClip}
                onNavigate={(tab) => setActiveTab(tab)}
              />
            )}

            {activeTab === 'music' && (
              <AddMusicView
                clips={clips}
                copyrightSafeMode={copyrightSafeMode}
                onSaveClip={handleSaveClip}
                onNavigate={(tab) => setActiveTab(tab)}
              />
            )}

            {activeTab === 'clips' && (
              <MyClipsView
                clips={clips}
                games={games}
                initialGameFilter={clipsGameFilter}
                onDeleteClip={handleDeleteClip}
                onSaveClip={handleSaveClip}
                onNavigate={(tab) => setActiveTab(tab)}
              />
            )}

            {activeTab === 'games' && (
              <MyGamesView
                games={games}
                clips={clips}
                onAddGame={handleAddGame}
                onDeleteCustomGame={handleDeleteCustomGame}
                onViewGameClips={handleViewGameClips}
                onCutClipForGame={handleCutClipForGame}
                onSaveClip={handleSaveClip}
                onActivateFloatingButton={(gameName) => {
                  setFloatingGameName(gameName);
                  setIsFloatingDemo(false);
                  setFloatingVisible(true);
                }}
              />
            )}
          </>
        )}
      </main>

      <InGameFloatingButton
        visible={floatingVisible}
        activeGameName={floatingGameName}
        isWebPreviewDemo={isFloatingDemo}
        onSaveClip={handleSaveClip}
        onNavigateToClips={() => {
          setClipsGameFilter('all');
          setActiveTab('clips');
        }}
        onClose={() => setFloatingVisible(false)}
      />
    </div>
  );
}

import { useCallback, useEffect, useState } from 'react';
import { Layers, RefreshCw, ShieldAlert } from 'lucide-react';
import { AddMusicView } from './components/AddMusicView';
import { AddVoiceView } from './components/AddVoiceView';
import { CutVideoView } from './components/CutVideoView';
import { HomeView } from './components/HomeView';
import { InGameFloatingButton } from './components/InGameFloatingButton';
import { MyClipsView } from './components/MyClipsView';
import { MyGamesView } from './components/MyGamesView';
import { TopNav } from './components/TopNav';
import { WelcomePermissionScreen } from './components/WelcomePermissionScreen';
import { ClipItem, GameItem, SocialPlatform, WorkspaceTab } from './types/clipkaro';
import {
  ClipKaroPermissionState,
  getPermissionState,
  requestOverlayPermission,
} from './utils/androidPermissions';
import {
  addCustomGameToDb,
  DEFAULT_GAMES,
  deleteClipFromDb,
  deleteCustomGameFromDb,
  getAllClips,
  getAllGames,
  getStoredCopyrightSafeMode,
  saveClipToDb,
  setStoredCopyrightSafeMode,
} from './utils/mediaStorage';

export default function App() {
  const [activeTab, setActiveTab] = useState<WorkspaceTab>('home');
  const [clips, setClips] = useState<ClipItem[]>([]);
  const [games, setGames] = useState<GameItem[]>(DEFAULT_GAMES);
  const [isLoadingStore, setIsLoadingStore] = useState<boolean>(true);
  const [copyrightSafeMode, setCopyrightSafeMode] = useState<boolean>(() =>
    getStoredCopyrightSafeMode()
  );

  // First-Launch Welcome Permission State (persisted via SharedPreferences on Android)
  const [permissionState, setPermissionState] = useState<ClipKaroPermissionState>(() =>
    getPermissionState()
  );
  const [showOverlayBlockedModal, setShowOverlayBlockedModal] = useState<boolean>(false);
  const [overlayBlockedRetryShown, setOverlayBlockedRetryShown] = useState<boolean>(false);
  const [awaitingOverlayFromGames, setAwaitingOverlayFromGames] = useState<boolean>(false);

  // Cross-view contextual handoffs
  const [cutLinkPrefill, setCutLinkPrefill] = useState<string>('');
  const [cutPlatformPrefill, setCutPlatformPrefill] = useState<
    SocialPlatform | 'upload' | 'studio'
  >('youtube');
  const [cutStreamerPrefill, setCutStreamerPrefill] = useState<string>('');
  const [cutGamePrefill, setCutGamePrefill] = useState<string>('');
  const [clipsGameFilter, setClipsGameFilter] = useState<string>('all');

  // In-Game Floating Button state (demo visible by default in web preview)
  const isWebPreview =
    typeof window !== 'undefined' && window.location.protocol.startsWith('http');
  const [floatingVisible, setFloatingVisible] = useState<boolean>(isWebPreview);
  const [floatingGameName, setFloatingGameName] = useState<string>('BGMI');
  const [isFloatingDemo, setIsFloatingDemo] = useState<boolean>(isWebPreview);

  const syncPermissionState = useCallback(() => {
    const latest = getPermissionState();
    setPermissionState(latest);
    return latest;
  }, []);

  useEffect(() => {
    const handleSync = () => {
      const latest = syncPermissionState();
      if (awaitingOverlayFromGames) {
        setAwaitingOverlayFromGames(false);
        if (latest.overlay) {
          setShowOverlayBlockedModal(false);
          setOverlayBlockedRetryShown(false);
          setActiveTab('games');
        } else {
          setOverlayBlockedRetryShown(true);
        }
      }
    };

    const handleVisibility = () => {
      if (document.visibilityState === 'visible') {
        handleSync();
      }
    };

    window.addEventListener('clipkaro-permissions-updated', handleSync);
    window.addEventListener('focus', handleSync);
    document.addEventListener('visibilitychange', handleVisibility);
    return () => {
      window.removeEventListener('clipkaro-permissions-updated', handleSync);
      window.removeEventListener('focus', handleSync);
      document.removeEventListener('visibilitychange', handleVisibility);
    };
  }, [awaitingOverlayFromGames, syncPermissionState]);

  const navigateWithGuard = useCallback(
    (tab: WorkspaceTab) => {
      if (tab === 'games') {
        const latest = syncPermissionState();
        if (!latest.overlay) {
          setShowOverlayBlockedModal(true);
          return;
        }
      }
      if (tab === 'clips') setClipsGameFilter('all');
      setActiveTab(tab);
    },
    [syncPermissionState]
  );

  const refreshStore = useCallback(async () => {
    try {
      const [loadedClips, loadedGames] = await Promise.all([getAllClips(), getAllGames()]);
      setClips(loadedClips);
      setGames(loadedGames);
    } finally {
      setIsLoadingStore(false);
    }
  }, []);

  useEffect(() => {
    refreshStore();
  }, [refreshStore]);

  const handleToggleCopyrightSafeMode = () => {
    setCopyrightSafeMode((prev) => {
      const next = !prev;
      setStoredCopyrightSafeMode(next);
      return next;
    });
  };

  const handleSaveClip = async (clip: ClipItem) => {
    await saveClipToDb(clip);
    const updated = await getAllClips();
    setClips(updated);
  };

  const handleDeleteClip = async (id: string) => {
    await deleteClipFromDb(id);
    const updated = await getAllClips();
    setClips(updated);
  };

  const handleAddGame = async (name: string, genre: string) => {
    const coverPool = DEFAULT_GAMES.map((g) => g.coverUrl);
    const coverUrl = coverPool[games.length % coverPool.length];
    const newGame: GameItem = {
      id: `game-custom-${Date.now()}`,
      name,
      genre,
      coverUrl,
      isCustom: true,
    };
    await addCustomGameToDb(newGame);
    const updatedGames = await getAllGames();
    setGames(updatedGames);
  };

  const handleDeleteCustomGame = async (id: string) => {
    await deleteCustomGameFromDb(id);
    const updatedGames = await getAllGames();
    setGames(updatedGames);
  };

  const handleSendLinkToCut = (
    url: string,
    platform: SocialPlatform,
    suggestedStreamer?: string
  ) => {
    setCutLinkPrefill(url);
    setCutPlatformPrefill(platform);
    setCutStreamerPrefill(suggestedStreamer ?? '');
    setActiveTab('cut');
  };

  const handleViewGameClips = (gameName: string) => {
    setClipsGameFilter(gameName);
    setActiveTab('clips');
  };

  const handleCutClipForGame = (gameName: string) => {
    setCutGamePrefill(gameName);
    setActiveTab('cut');
  };

  const handleRequestOverlayFromGate = () => {
    const { awaitingNativeSettings } = requestOverlayPermission();
    if (awaitingNativeSettings) {
      setAwaitingOverlayFromGames(true);
    } else {
      const latest = syncPermissionState();
      if (latest.overlay) {
        setShowOverlayBlockedModal(false);
        setOverlayBlockedRetryShown(false);
        setActiveTab('games');
      } else {
        setOverlayBlockedRetryShown(true);
      }
    }
  };

  // Show Welcome Permission Screen before Home Screen on first launch
  if (!permissionState.setupDone) {
    return (
      <WelcomePermissionScreen
        permissionState={permissionState}
        onRefreshPermissions={syncPermissionState}
        onComplete={() => {
          syncPermissionState();
          setActiveTab('home');
        }}
      />
    );
  }

  return (
    <div className="min-h-screen bg-[#0B0E14] text-slate-100 flex flex-col">
      <TopNav activeTab={activeTab} onNavigate={navigateWithGuard} />

      <main className="mx-auto w-full max-w-7xl flex-1 px-4 py-6 sm:px-6 sm:py-8">
        {isLoadingStore ? (
          <div className="space-y-4">
            <div className="h-8 w-64 animate-pulse rounded-lg bg-slate-800/70" />
            <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-6">
              {Array.from({ length: 6 }).map((_, idx) => (
                <div key={idx} className="h-28 animate-pulse rounded-xl bg-slate-800/50" />
              ))}
            </div>
            <div className="aspect-video w-full animate-pulse rounded-xl bg-slate-800/40" />
          </div>
        ) : (
          <>
            {activeTab === 'home' && (
              <HomeView
                clipCount={clips.length}
                gameCount={games.length}
                copyrightSafeMode={copyrightSafeMode}
                onToggleCopyrightSafeMode={handleToggleCopyrightSafeMode}
                onNavigate={navigateWithGuard}
                onSendLinkToCut={handleSendLinkToCut}
              />
            )}

            {activeTab === 'cut' && (
              <CutVideoView
                copyrightSafeMode={copyrightSafeMode}
                onToggleCopyrightSafeMode={handleToggleCopyrightSafeMode}
                games={games}
                initialOriginalLink={cutLinkPrefill}
                initialPlatform={cutPlatformPrefill}
                initialStreamerName={cutStreamerPrefill}
                initialGameTag={cutGamePrefill}
                onSaveClip={handleSaveClip}
                onGoToMyClips={() => {
                  setClipsGameFilter('all');
                  setActiveTab('clips');
                }}
              />
            )}

            {activeTab === 'voice' && (
              <AddVoiceView
                clips={clips}
                onSaveClip={handleSaveClip}
                onNavigate={navigateWithGuard}
              />
            )}

            {activeTab === 'music' && (
              <AddMusicView
                clips={clips}
                copyrightSafeMode={copyrightSafeMode}
                onSaveClip={handleSaveClip}
                onNavigate={navigateWithGuard}
              />
            )}

            {activeTab === 'clips' && (
              <MyClipsView
                clips={clips}
                games={games}
                initialGameFilter={clipsGameFilter}
                onDeleteClip={handleDeleteClip}
                onSaveClip={handleSaveClip}
                onNavigate={navigateWithGuard}
              />
            )}

            {activeTab === 'games' && permissionState.overlay && (
              <MyGamesView
                games={games}
                clips={clips}
                onAddGame={handleAddGame}
                onDeleteCustomGame={handleDeleteCustomGame}
                onViewGameClips={handleViewGameClips}
                onCutClipForGame={handleCutClipForGame}
                onSaveClip={handleSaveClip}
                onActivateFloatingButton={(gameName) => {
                  setFloatingGameName(gameName);
                  setIsFloatingDemo(false);
                  setFloatingVisible(true);
                }}
              />
            )}
          </>
        )}
      </main>

      {/* Strict Guard Modal: Do not let user enter My Games without Overlay permission */}
      {showOverlayBlockedModal && (
        <div
          role="dialog"
          aria-modal="true"
          aria-labelledby="overlay-required-title"
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4 backdrop-blur-sm"
        >
          <div className="w-full max-w-md rounded-2xl border border-rose-500/40 bg-[#121722] p-6 shadow-2xl space-y-4">
            <div className="flex items-start gap-3">
              <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-rose-500/15 text-rose-400">
                <Layers className="h-5 w-5" aria-hidden="true" />
              </span>
              <div>
                <h2 id="overlay-required-title" className="font-display text-lg font-bold text-white">
                  Overlay Permission Required
                </h2>
                <p className="mt-0.5 text-xs text-slate-300">
                  Permission Required to show CLIP button in BGMI
                </p>
              </div>
            </div>

            <div className="flex items-start gap-2.5 rounded-xl border border-rose-500/60 bg-rose-950/50 p-3.5 text-xs text-rose-200">
              <ShieldAlert className="h-4 w-4 text-rose-400 shrink-0 mt-0.5" aria-hidden="true" />
              <span className="font-semibold">
                Floating button will not appear in BGMI without this permission
              </span>
            </div>

            <div className="flex flex-col gap-2 sm:flex-row sm:justify-end">
              <button
                type="button"
                onClick={() => {
                  setShowOverlayBlockedModal(false);
                  if (activeTab === 'games') setActiveTab('home');
                }}
                className="rounded-lg border border-slate-700 bg-[#0B0E14] px-4 py-2 text-xs font-semibold text-slate-300 hover:text-white"
              >
                Back to Home
              </button>
              <button
                type="button"
                onClick={handleRequestOverlayFromGate}
                className="inline-flex items-center justify-center gap-1.5 rounded-lg bg-rose-600 px-4 py-2 text-xs font-bold text-white hover:bg-rose-500"
              >
                {overlayBlockedRetryShown ? (
                  <>
                    <RefreshCw className="h-3.5 w-3.5" aria-hidden="true" />
                    <span>Try Again</span>
                  </>
                ) : (
                  <span>Allow Floating Button</span>
                )}
              </button>
            </div>
          </div>
        </div>
      )}

      <InGameFloatingButton
        visible={floatingVisible}
        activeGameName={floatingGameName}
        isWebPreviewDemo={isFloatingDemo}
        onSaveClip={handleSaveClip}
        onNavigateToClips={() => {
          setClipsGameFilter('all');
          setActiveTab('clips');
        }}
        onClose={() => setFloatingVisible(false)}
      />
    </div>
  );
}

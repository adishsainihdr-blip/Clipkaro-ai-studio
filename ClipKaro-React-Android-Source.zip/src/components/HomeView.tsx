import { FormEvent, useMemo, useState } from 'react';
import {
  Scissors,
  Mic,
  Music,
  Film,
  Gamepad2,
  ShieldCheck,
  ShieldAlert,
  ExternalLink,
  ArrowRight,
  Download,
  Globe,
  PlayCircle,
  Smartphone,
} from 'lucide-react';
import { SocialPlatform, WorkspaceTab } from '../types/clipkaro';
import { PLATFORM_PRESETS, parseSocialEmbedUrl } from '../utils/embedUrl';

import { ExportCodeModal } from './ExportCodeModal';

interface HomeViewProps {
  clipCount: number;
  gameCount: number;
  copyrightSafeMode: boolean;
  onToggleCopyrightSafeMode: () => void;
  onNavigate: (tab: WorkspaceTab) => void;
  onSendLinkToCut: (url: string, platform: SocialPlatform, suggestedStreamer?: string) => void;
}

const PLATFORMS: { id: SocialPlatform; label: string }[] = [
  { id: 'youtube', label: 'YouTube' },
  { id: 'instagram', label: 'Instagram' },
  { id: 'facebook', label: 'Facebook' },
];

export function HomeView({
  clipCount,
  gameCount,
  copyrightSafeMode,
  onToggleCopyrightSafeMode,
  onNavigate,
  onSendLinkToCut,
}: HomeViewProps) {
  const [activePlatform, setActivePlatform] = useState<SocialPlatform>('youtube');
  const [urlInput, setUrlInput] = useState<string>(PLATFORM_PRESETS[0].url);
  const [loadedUrl, setLoadedUrl] = useState<string>(PLATFORM_PRESETS[0].url);
  const [suggestedStreamer, setSuggestedStreamer] = useState<string>(PLATFORM_PRESETS[0].creator);
  const [exportModalOpen, setExportModalOpen] = useState<boolean>(false);

  const parsedEmbed = useMemo(
    () => parseSocialEmbedUrl(loadedUrl, activePlatform),
    [loadedUrl, activePlatform]
  );

  const handlePlatformSwitch = (platform: SocialPlatform) => {
    setActivePlatform(platform);
    const firstPreset = PLATFORM_PRESETS.find((p) => p.platform === platform);
    if (firstPreset) {
      setUrlInput(firstPreset.url);
      setLoadedUrl(firstPreset.url);
      setSuggestedStreamer(firstPreset.creator);
    }
  };

  const handleOpenInside = (e: FormEvent) => {
    e.preventDefault();
    if (!urlInput.trim()) return;
    const result = parseSocialEmbedUrl(urlInput, activePlatform);
    setActivePlatform(result.platform);
    setLoadedUrl(urlInput.trim());
    setSuggestedStreamer('');
  };

  const handleSelectPreset = (url: string, platform: SocialPlatform, creator: string) => {
    setActivePlatform(platform);
    setUrlInput(url);
    setLoadedUrl(url);
    setSuggestedStreamer(creator);
  };

  const platformPresets = PLATFORM_PRESETS.filter((p) => p.platform === activePlatform);

  return (
    <div className="space-y-8">
      {/* Page Intro & Workspace Summary */}
      <section className="flex flex-col gap-3 lg:flex-row lg:items-end lg:justify-between">
        <div className="space-y-1.5">
          <h1 className="font-display text-2xl font-bold tracking-tight text-white sm:text-3xl text-balance">
            ClipKaro Creator Studio
          </h1>
          <p className="max-w-2xl text-sm text-slate-400">
            Open YouTube, Instagram, or Facebook videos inside your workspace, trim 10 to 60 second permission clips with streamer credit, and mix voiceovers or copyright-safe music.
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-3 text-xs text-slate-400 tabular-nums">
          <span>{clipCount} clips saved</span>
          <span aria-hidden="true">·</span>
          <span>{gameCount} games tracked</span>
          <span aria-hidden="true">·</span>
          <span className={copyrightSafeMode ? 'text-emerald-400 font-medium' : 'text-amber-400 font-medium'}>
            Copyright-Safe Mode {copyrightSafeMode ? 'ON' : 'OFF'}
          </span>
          <span aria-hidden="true">·</span>
          <button
            type="button"
            onClick={() => setExportModalOpen(true)}
            className="inline-flex items-center gap-1.5 rounded-lg border border-rose-500/40 bg-rose-500/10 px-2.5 py-1 font-semibold text-rose-300 transition-colors hover:bg-rose-500/20 hover:text-white whitespace-nowrap"
          >
            <Download className="h-3.5 w-3.5" aria-hidden="true" />
            <span>Download React + Android Code</span>
          </button>
        </div>
      </section>

      {/* Quick Actions Grid */}
      <section aria-labelledby="quick-actions-heading" className="space-y-3">
        <div className="flex items-center justify-between">
          <h2 id="quick-actions-heading" className="font-display text-base font-semibold text-slate-200">
            Quick Actions
          </h2>
        </div>

        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-6">
          <button
            type="button"
            onClick={() => onNavigate('cut')}
            className="group flex flex-col items-start justify-between gap-3 rounded-xl border border-slate-800 bg-[#121722] p-4 text-left transition-colors hover:border-rose-500/60 hover:bg-[#171E2C] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-rose-500"
          >
            <span className="flex h-10 w-10 items-center justify-center rounded-lg bg-rose-500/15 text-rose-400">
              <Scissors className="h-5 w-5" aria-hidden="true" />
            </span>
            <div>
              <div className="font-display text-sm font-semibold text-white whitespace-nowrap">
                Cut Video
              </div>
              <div className="mt-0.5 text-xs text-slate-400">10–60s permission trim</div>
            </div>
          </button>

          <button
            type="button"
            onClick={() => onNavigate('voice')}
            className="group flex flex-col items-start justify-between gap-3 rounded-xl border border-slate-800 bg-[#121722] p-4 text-left transition-colors hover:border-slate-600 hover:bg-[#171E2C] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-rose-500"
          >
            <span className="flex h-10 w-10 items-center justify-center rounded-lg bg-sky-500/15 text-sky-400">
              <Mic className="h-5 w-5" aria-hidden="true" />
            </span>
            <div>
              <div className="font-display text-sm font-semibold text-white whitespace-nowrap">
                Add Voice
              </div>
              <div className="mt-0.5 text-xs text-slate-400">Mic or audio upload</div>
            </div>
          </button>

          <button
            type="button"
            onClick={() => onNavigate('music')}
            className="group flex flex-col items-start justify-between gap-3 rounded-xl border border-slate-800 bg-[#121722] p-4 text-left transition-colors hover:border-slate-600 hover:bg-[#171E2C] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-rose-500"
          >
            <span className="flex h-10 w-10 items-center justify-center rounded-lg bg-amber-500/15 text-amber-400">
              <Music className="h-5 w-5" aria-hidden="true" />
            </span>
            <div>
              <div className="font-display text-sm font-semibold text-white whitespace-nowrap">
                Add Music
              </div>
              <div className="mt-0.5 text-xs text-slate-400">Royalty-free backing</div>
            </div>
          </button>

          <button
            type="button"
            onClick={() => onNavigate('clips')}
            className="group flex flex-col items-start justify-between gap-3 rounded-xl border border-slate-800 bg-[#121722] p-4 text-left transition-colors hover:border-slate-600 hover:bg-[#171E2C] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-rose-500"
          >
            <span className="flex h-10 w-10 items-center justify-center rounded-lg bg-indigo-500/15 text-indigo-400">
              <Film className="h-5 w-5" aria-hidden="true" />
            </span>
            <div>
              <div className="font-display text-sm font-semibold text-white whitespace-nowrap">
                My Clips
              </div>
              <div className="mt-0.5 text-xs text-slate-400 tabular-nums">
                {clipCount} {clipCount === 1 ? 'clip' : 'clips'} saved
              </div>
            </div>
          </button>

          <button
            type="button"
            onClick={() => onNavigate('games')}
            className="group flex flex-col items-start justify-between gap-3 rounded-xl border border-slate-800 bg-[#121722] p-4 text-left transition-colors hover:border-slate-600 hover:bg-[#171E2C] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-rose-500"
          >
            <span className="flex h-10 w-10 items-center justify-center rounded-lg bg-violet-500/15 text-violet-400">
              <Gamepad2 className="h-5 w-5" aria-hidden="true" />
            </span>
            <div>
              <div className="font-display text-sm font-semibold text-white whitespace-nowrap">
                My Games
              </div>
              <div className="mt-0.5 text-xs text-slate-400 tabular-nums">
                {gameCount} titles & mini-game
              </div>
            </div>
          </button>

          <button
            type="button"
            onClick={() => onNavigate('apps')}
            className="group flex flex-col items-start justify-between gap-3 rounded-xl border border-rose-500/40 bg-[#121722] p-4 text-left transition-colors hover:border-rose-500 hover:bg-[#171E2C] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-rose-500"
          >
            <span className="flex h-10 w-10 items-center justify-center rounded-lg bg-rose-500/15 text-rose-400">
              <Smartphone className="h-5 w-5" aria-hidden="true" />
            </span>
            <div>
              <div className="font-display text-sm font-semibold text-white whitespace-nowrap">
                My Apps
              </div>
              <div className="mt-0.5 text-xs text-slate-400">YT, IG, FB, WA + BGMI</div>
            </div>
          </button>

          <button
            type="button"
            role="switch"
            aria-checked={copyrightSafeMode}
            onClick={onToggleCopyrightSafeMode}
            className={`flex flex-col items-start justify-between gap-3 rounded-xl border p-4 text-left transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-rose-500 sm:col-span-3 lg:col-span-6 ${
              copyrightSafeMode
                ? 'border-emerald-500/40 bg-emerald-950/25 hover:bg-emerald-950/35'
                : 'border-amber-500/40 bg-amber-950/20 hover:bg-amber-950/30'
            }`}
          >
            <div className="flex w-full items-center justify-between gap-3">
              <div className="flex items-center gap-3">
                <span
                  className={`flex h-9 w-9 items-center justify-center rounded-lg ${
                    copyrightSafeMode
                      ? 'bg-emerald-500/20 text-emerald-400'
                      : 'bg-amber-500/20 text-amber-400'
                  }`}
                >
                  {copyrightSafeMode ? (
                    <ShieldCheck className="h-5 w-5" aria-hidden="true" />
                  ) : (
                    <ShieldAlert className="h-5 w-5" aria-hidden="true" />
                  )}
                </span>
                <div>
                  <div className="font-display text-sm font-semibold text-white">
                    Copyright-Safe Mode {copyrightSafeMode ? 'ON' : 'OFF'}
                  </div>
                  <div className="text-xs text-slate-300">
                    {copyrightSafeMode ? 'Attribution & safe audio active' : 'Tap to re-enable safety'}
                  </div>
                </div>
              </div>
              <span className="text-xs font-bold uppercase tracking-wider text-slate-300">
                {copyrightSafeMode ? 'Enabled' : 'Disabled'}
              </span>
            </div>
          </button>
        </div>
      </section>

      {/* Open Inside Viewer */}
      <section
        aria-labelledby="open-inside-heading"
        className="rounded-xl border border-slate-800 bg-[#121722] p-5 sm:p-6 space-y-5"
      >
        <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
          <div>
            <h2 id="open-inside-heading" className="font-display text-lg font-bold text-white">
              Open Inside Viewer
            </h2>
            <p className="mt-0.5 text-sm text-slate-400">
              Preview YouTube, Instagram, or Facebook links directly inside ClipKaro before cutting.
            </p>
          </div>

          {/* Platform Switcher */}
          <div
            role="tablist"
            aria-label="Social Platform"
            className="inline-flex items-center gap-1 rounded-lg border border-slate-800 bg-[#0B0E14] p-1 self-start"
          >
            {PLATFORMS.map((plat) => {
              const selected = activePlatform === plat.id;
              return (
                <button
                  key={plat.id}
                  type="button"
                  role="tab"
                  aria-selected={selected}
                  onClick={() => handlePlatformSwitch(plat.id)}
                  className={`rounded-md px-4 py-1.5 text-xs font-semibold transition-colors whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-rose-500 ${
                    selected
                      ? 'bg-rose-600 text-white'
                      : 'text-slate-400 hover:text-slate-100'
                  }`}
                >
                  {plat.label}
                </button>
              );
            })}
          </div>
        </div>

        {/* URL Input + Action Controls */}
        <form onSubmit={handleOpenInside} className="flex flex-col gap-3 sm:flex-row">
          <div className="relative flex-1">
            <Globe
              className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-500"
              aria-hidden="true"
            />
            <input
              type="url"
              value={urlInput}
              onChange={(e) => setUrlInput(e.target.value)}
              placeholder={`Paste ${
                activePlatform === 'youtube'
                  ? 'YouTube watch, Shorts, or live'
                  : activePlatform === 'instagram'
                    ? 'Instagram Reel or Post'
                    : 'Facebook Video'
              } URL...`}
              aria-label="Video URL to open inside viewer"
              className="w-full rounded-lg border border-slate-700/80 bg-[#0B0E14] py-2.5 pl-10 pr-4 text-sm text-white placeholder:text-slate-500 focus:border-rose-500 focus:outline-none"
            />
          </div>
          <div className="flex items-center gap-2.5 shrink-0">
            <button
              type="submit"
              className="inline-flex items-center gap-2 rounded-lg border border-slate-700 bg-slate-800 px-4 py-2.5 text-sm font-semibold text-white transition-colors hover:bg-slate-700 whitespace-nowrap shrink-0"
            >
              <PlayCircle className="h-4 w-4" aria-hidden="true" />
              <span>Open Inside</span>
            </button>
            <button
              type="button"
              onClick={() =>
                onSendLinkToCut(
                  parsedEmbed.originalUrl || urlInput,
                  parsedEmbed.platform,
                  suggestedStreamer
                )
              }
              className="inline-flex items-center gap-2 rounded-lg bg-rose-600 px-4 py-2.5 text-sm font-semibold text-white transition-colors hover:bg-rose-500 whitespace-nowrap shrink-0"
            >
              <span>Cut This Link</span>
              <ArrowRight className="h-4 w-4" aria-hidden="true" />
            </button>
          </div>
        </form>

        {/* Quick Presets for Active Platform */}
        <div className="flex flex-wrap items-center gap-2 text-xs">
          <span className="text-slate-400">Quick examples:</span>
          {platformPresets.map((preset) => (
            <button
              key={preset.id}
              type="button"
              onClick={() => handleSelectPreset(preset.url, preset.platform, preset.creator)}
              className={`rounded-md border px-2.5 py-1 transition-colors whitespace-nowrap shrink-0 ${
                loadedUrl === preset.url
                  ? 'border-rose-500/60 bg-rose-500/10 text-rose-300'
                  : 'border-slate-800 bg-[#0B0E14] text-slate-300 hover:border-slate-700 hover:text-white'
              }`}
            >
              {preset.label}
            </button>
          ))}
        </div>

        {/* Viewer Frame */}
        <div className="overflow-hidden rounded-xl border border-slate-800 bg-[#07090D]">
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-800/80 px-4 py-2.5 text-xs text-slate-400">
            <div className="flex items-center gap-2 truncate">
              <span className="font-semibold text-slate-200 capitalize">{parsedEmbed.platform}</span>
              <span aria-hidden="true">·</span>
              <span className="truncate">{parsedEmbed.displayLabel}</span>
            </div>
            {parsedEmbed.originalUrl && (
              <a
                href={parsedEmbed.originalUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1.5 text-slate-300 hover:text-white whitespace-nowrap shrink-0"
              >
                <span>Open source link</span>
                <ExternalLink className="h-3.5 w-3.5" aria-hidden="true" />
              </a>
            )}
          </div>

          {parsedEmbed.embedUrl ? (
            <div className="relative aspect-video w-full bg-black">
              <iframe
                key={parsedEmbed.embedUrl}
                src={parsedEmbed.embedUrl}
                title={parsedEmbed.displayLabel}
                className="h-full w-full border-0"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                allowFullScreen
                referrerPolicy="strict-origin-when-cross-origin"
              />
            </div>
          ) : (
            <div className="flex aspect-video w-full flex-col items-center justify-center gap-3 p-6 text-center">
              <Globe className="h-9 w-9 text-slate-500" aria-hidden="true" />
              <div className="max-w-md space-y-1">
                <p className="text-sm font-medium text-slate-200">{parsedEmbed.displayLabel}</p>
                <p className="text-xs text-slate-400">
                  {parsedEmbed.hint ||
                    'Paste a direct YouTube, Instagram Reel/Post, or Facebook Video URL above to open it inside the player.'}
                </p>
              </div>
              <button
                type="button"
                onClick={() => onNavigate('cut')}
                className="mt-1 rounded-lg bg-slate-800 px-4 py-2 text-xs font-semibold text-white hover:bg-slate-700"
              >
                Upload or Record Video in Cut Video
              </button>
            </div>
          )}

          {parsedEmbed.hint && parsedEmbed.embedUrl && (
            <div className="border-t border-slate-800/80 bg-[#0B0E14] px-4 py-2.5 text-xs text-slate-400">
              {parsedEmbed.hint}
            </div>
          )}
        </div>
      </section>

      <ExportCodeModal isOpen={exportModalOpen} onClose={() => setExportModalOpen(false)} />
    </div>
  );
}

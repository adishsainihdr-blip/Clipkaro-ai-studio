import { useEffect, useMemo, useRef, useState } from 'react';
import {
  CheckCircle2,
  Download,
  ExternalLink,
  Eye,
  EyeOff,
  Film,
  Flame,
  FolderSync,
  HardDrive,
  Image as ImageIcon,
  Mic,
  Music,
  Play,
  Scissors,
  Search,
  Share2,
  ShieldCheck,
  SlidersHorizontal,
  Sparkles,
  Star,
  Trash2,
  Wand2,
  X,
} from 'lucide-react';
import { ClipItem, GameItem, WorkspaceTab } from '../types/clipkaro';
import {
  formatSeconds,
  generateRoyaltyFreeWavBlob,
  generateSampleStreamVideoBlob,
  ROYALTY_FREE_TRACKS,
} from '../utils/mediaGenerators';
import { shareClipToPlatform, ShareTargetPlatform } from '../utils/androidPermissions';
import {
  calculateClipsStorageBytes,
  findExpiredClips,
  formatStorageBytes,
} from '../utils/mediaStorage';
import {
  combineCssFilters,
  EFFECT_MODES,
  FILTER_PRESETS,
  getAspectContainerClass,
  getSpeedAtTime,
} from '../utils/videoEditorPresets';
import { AiAutoEditAnalysis, runAiAutoEdit } from '../utils/aiAutoEditor';
import {
  calculateViralScore,
  prepareExportVideoBlobWithViralScore,
} from '../utils/viralScore';
import { AiAutoEditModal } from './AiAutoEditModal';
import { ClipEditorModal, EditorTab } from './ClipEditorModal';
import { ViralScoreExportDialog } from './ViralScoreExportDialog';

interface MyClipsViewProps {
  clips: ClipItem[];
  games: GameItem[];
  initialGameFilter?: string;
  initialPlayClipId?: string | null;
  onClearInitialPlayClip?: () => void;
  isNativeAndroid?: boolean;
  autoDelete7Days?: boolean;
  keepBestClips?: boolean;
  showViralScoreInApp?: boolean;
  onToggleShowViralScoreInApp?: () => void;
  onToggleClipHideScore?: (clip: ClipItem) => Promise<void>;
  onToggleAutoDelete7Days?: () => void | Promise<void>;
  onToggleKeepBestClips?: () => void;
  onRunSmartCleanupNow?: () => Promise<number>;
  onToggleFavouriteClip?: (clip: ClipItem) => Promise<void>;
  onSyncClipKaroFolder?: () => Promise<number>;
  onDeleteClip: (id: string) => Promise<void>;
  onSaveClip: (clip: ClipItem) => Promise<void>;
  onNavigate: (tab: WorkspaceTab) => void;
}

type ClipFilterMode = 'all' | 'favourites' | 'permission' | 'voice' | 'music';
type ClipSortMode = 'newest' | 'viral';

export function MyClipsView({
  clips,
  games,
  initialGameFilter = 'all',
  initialPlayClipId,
  onClearInitialPlayClip,
  isNativeAndroid = false,
  autoDelete7Days = false,
  keepBestClips = true,
  showViralScoreInApp = true,
  onToggleShowViralScoreInApp,
  onToggleClipHideScore,
  onToggleAutoDelete7Days,
  onToggleKeepBestClips,
  onRunSmartCleanupNow,
  onToggleFavouriteClip,
  onSyncClipKaroFolder,
  onDeleteClip,
  onSaveClip,
  onNavigate,
}: MyClipsViewProps) {
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [gameFilter, setGameFilter] = useState<string>(initialGameFilter);
  const [filterMode, setFilterMode] = useState<ClipFilterMode>('all');
  const [sortMode, setSortMode] = useState<ClipSortMode>('newest');

  // Active Player Modal State
  const [playingClip, setPlayingClip] = useState<ClipItem | null>(null);
  const [editingClip, setEditingClip] = useState<ClipItem | null>(null);
  const [editorInitialTab, setEditorInitialTab] = useState<EditorTab>('trim');
  const [shareNotice, setShareNotice] = useState<string | null>(null);
  const [activeVideoUrl, setActiveVideoUrl] = useState<string | null>(null);
  const [activeVoiceUrl, setActiveVoiceUrl] = useState<string | null>(null);
  const [activeMusicUrl, setActiveMusicUrl] = useState<string | null>(null);
  const [activeProofUrl, setActiveProofUrl] = useState<string | null>(null);

  // Viral Score Share/Export Prompt & Per-Clip Long-Press State
  const [pendingExportAction, setPendingExportAction] = useState<{
    clip: ClipItem;
    kind: 'share' | 'download';
    platform?: ShareTargetPlatform;
  } | null>(null);
  const [isExportingViralChoice, setIsExportingViralChoice] = useState<boolean>(false);
  const [longPressClip, setLongPressClip] = useState<ClipItem | null>(null);
  const longPressTimerRef = useRef<number | null>(null);
  const longPressStartPosRef = useRef<{ x: number; y: number } | null>(null);

  // AI Auto Edit State
  const [aiEditingClipId, setAiEditingClipId] = useState<string | null>(null);
  const [aiStatusText, setAiStatusText] = useState<string>('');
  const [aiComparisonState, setAiComparisonState] = useState<{
    originalClip: ClipItem;
    analysis: AiAutoEditAnalysis;
  } | null>(null);

  // Delete & Folder Sync State
  const [clipPendingDelete, setClipPendingDelete] = useState<ClipItem | null>(null);
  const [isDeleting, setIsDeleting] = useState<boolean>(false);
  const [isSyncingFolder, setIsSyncingFolder] = useState<boolean>(false);

  // Quick sample creation in My Clips
  const [isCreatingSample, setIsCreatingSample] = useState<boolean>(false);
  const [samplePct, setSamplePct] = useState<number>(0);

  const playerVideoRef = useRef<HTMLVideoElement | null>(null);
  const playerVoiceRef = useRef<HTMLAudioElement | null>(null);
  const playerMusicRef = useRef<HTMLAudioElement | null>(null);

  useEffect(() => {
    setGameFilter(initialGameFilter || 'all');
  }, [initialGameFilter]);

  useEffect(() => {
    if (!initialPlayClipId) return;
    const match = clips.find((c) => c.id === initialPlayClipId);
    if (match) {
      setPlayingClip(match);
      onClearInitialPlayClip?.();
    }
  }, [clips, initialPlayClipId, onClearInitialPlayClip]);

  const totalStorageLabel = useMemo(
    () => formatStorageBytes(calculateClipsStorageBytes(clips)),
    [clips]
  );

  const expiredClipsCount = useMemo(
    () => findExpiredClips(clips, keepBestClips).length,
    [clips, keepBestClips]
  );

  const favouriteClipsCount = useMemo(
    () => clips.filter((c) => c.isFavourite).length,
    [clips]
  );

  // Create and revoke object URLs whenever playingClip changes
  useEffect(() => {
    if (!playingClip) {
      setActiveVideoUrl(null);
      setActiveVoiceUrl(null);
      setActiveMusicUrl(null);
      setActiveProofUrl(null);
      return;
    }

    const vUrl = URL.createObjectURL(playingClip.videoBlob);
    const voUrl = playingClip.voiceBlob ? URL.createObjectURL(playingClip.voiceBlob) : null;
    const muUrl = playingClip.musicBlob ? URL.createObjectURL(playingClip.musicBlob) : null;
    const prUrl =
      playingClip.permission.proofBlob &&
      playingClip.permission.proofMimeType?.startsWith('image/')
        ? URL.createObjectURL(playingClip.permission.proofBlob)
        : null;

    setActiveVideoUrl(vUrl);
    setActiveVoiceUrl(voUrl);
    setActiveMusicUrl(muUrl);
    setActiveProofUrl(prUrl);

    return () => {
      URL.revokeObjectURL(vUrl);
      if (voUrl) URL.revokeObjectURL(voUrl);
      if (muUrl) URL.revokeObjectURL(muUrl);
      if (prUrl) URL.revokeObjectURL(prUrl);
    };
  }, [playingClip]);

  // Sync audio track volumes when player mounts
  useEffect(() => {
    if (!playingClip) return;
    if (playerVideoRef.current) {
      playerVideoRef.current.volume = playingClip.originalVolume ?? 1;
    }
    if (playerVoiceRef.current) {
      playerVoiceRef.current.volume = playingClip.voiceVolume ?? 1;
    }
    if (playerMusicRef.current) {
      playerMusicRef.current.volume = playingClip.musicVolume ?? 0.45;
    }
  }, [playingClip, activeVideoUrl, activeVoiceUrl, activeMusicUrl]);

  const filteredClips = useMemo(() => {
    const matched = clips.filter((clip) => {
      const q = searchQuery.trim().toLowerCase();
      if (q) {
        const matchesTitle = clip.title.toLowerCase().includes(q);
        const matchesCredit = clip.permission.creditText.toLowerCase().includes(q);
        const matchesGame = clip.gameTag.toLowerCase().includes(q);
        if (!matchesTitle && !matchesCredit && !matchesGame) return false;
      }
      if (gameFilter !== 'all' && clip.gameTag !== gameFilter) return false;
      if (filterMode === 'favourites' && !clip.isFavourite) return false;
      if (filterMode === 'permission' && !clip.permission.hasPermission) return false;
      if (filterMode === 'voice' && !clip.voiceBlob) return false;
      if (filterMode === 'music' && !clip.musicBlob) return false;
      return true;
    });

    if (sortMode === 'viral') {
      return [...matched].sort((a, b) => {
        const diff = calculateViralScore(b).score - calculateViralScore(a).score;
        return diff !== 0 ? diff : b.createdAt - a.createdAt;
      });
    }
    return matched;
  }, [clips, searchQuery, gameFilter, filterMode, sortMode]);

  const handlePlayerLoadedMetadata = () => {
    const vEl = playerVideoRef.current;
    if (!vEl || !playingClip) return;
    if (playingClip.trimStart > 0 && playingClip.trimStart < vEl.duration) {
      vEl.currentTime = playingClip.trimStart;
    }
    vEl.play().catch(() => undefined);
  };

  const handlePlayerPlay = () => {
    const vEl = playerVideoRef.current;
    if (!vEl || !playingClip) return;
    const offset = Math.max(0, vEl.currentTime - playingClip.trimStart);
    vEl.playbackRate = getSpeedAtTime(playingClip.speedSegments, offset);
    if (playerVoiceRef.current) {
      playerVoiceRef.current.currentTime = Math.min(
        offset,
        playerVoiceRef.current.duration || offset
      );
      playerVoiceRef.current.play().catch(() => undefined);
    }
    if (playerMusicRef.current) {
      playerMusicRef.current.currentTime =
        playerMusicRef.current.duration > 0 ? offset % playerMusicRef.current.duration : 0;
      playerMusicRef.current.play().catch(() => undefined);
    }
  };

  const handlePlayerPause = () => {
    playerVoiceRef.current?.pause();
    playerMusicRef.current?.pause();
  };

  const handlePlayerTimeUpdate = () => {
    const vEl = playerVideoRef.current;
    if (!vEl || !playingClip) return;
    const offset = Math.max(0, vEl.currentTime - playingClip.trimStart);
    const segSpeed = getSpeedAtTime(playingClip.speedSegments, offset);
    if (Math.abs(vEl.playbackRate - segSpeed) > 0.01) {
      vEl.playbackRate = segSpeed;
    }
    if (playingClip.trimEnd > playingClip.trimStart && vEl.currentTime >= playingClip.trimEnd) {
      vEl.pause();
      vEl.currentTime = playingClip.trimStart;
      playerVoiceRef.current?.pause();
      playerMusicRef.current?.pause();
    }
  };

  const handleConfirmDelete = async () => {
    if (!clipPendingDelete) return;
    setIsDeleting(true);
    try {
      await onDeleteClip(clipPendingDelete.id);
      if (playingClip?.id === clipPendingDelete.id) {
        setPlayingClip(null);
      }
      setClipPendingDelete(null);
    } finally {
      setIsDeleting(false);
    }
  };

  const handleCreateDemoClip = async () => {
    setIsCreatingSample(true);
    setSamplePct(0);
    try {
      const blob = await generateSampleStreamVideoBlob({
        durationSec: 10,
        title: 'Clutch Arena Highlight',
        creditLine: 'Credit: @AlexPlays',
        onProgress: setSamplePct,
      });
      const sampleClip: ClipItem = {
        id: `clip-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
        title: 'Clutch Arena Highlight',
        platform: 'youtube',
        gameTag: games[0]?.name || 'Valorant & Tactical FPS',
        durationSec: 10,
        trimStart: 0,
        trimEnd: 10,
        createdAt: Date.now(),
        copyrightSafe: true,
        permission: {
          hasPermission: true,
          streamerName: 'AlexPlays',
          originalVideoLink: 'https://www.youtube.com/watch?v=aqz-KE-bpKQ',
          creditText: 'Credit: @AlexPlays',
        },
        videoBlob: blob,
        videoMimeType: blob.type || 'video/webm',
        voiceVolume: 1,
        musicVolume: 0.45,
        originalVolume: 1,
      };
      await onSaveClip(sampleClip);
    } finally {
      setIsCreatingSample(false);
    }
  };

  const handleRequestShareClip = (clip: ClipItem, platform: ShareTargetPlatform) => {
    setPendingExportAction({ clip, kind: 'share', platform });
  };

  const handleRequestDownloadClip = (clip: ClipItem) => {
    setPendingExportAction({ clip, kind: 'download' });
  };

  const handleConfirmExportViralChoice = async (includeScoreOnVideo: boolean) => {
    if (!pendingExportAction) return;
    setIsExportingViralChoice(true);
    try {
      const { clip, kind, platform } = pendingExportAction;
      const prepared = await prepareExportVideoBlobWithViralScore(clip, includeScoreOnVideo);

      if (kind === 'share' && platform) {
        const captionBase = clip.autoCaption || 'What a Headshot!';
        const msg = await shareClipToPlatform({
          platform,
          title: clip.title,
          gameTag: clip.gameTag,
          autoCaption:
            includeScoreOnVideo && prepared.scoreBadgeText
              ? `${captionBase} (${prepared.scoreBadgeText})`
              : captionBase,
          videoBlob: prepared.blob,
          videoMimeType: prepared.mimeType,
          nativeUri: prepared.nativeUri,
        });
        setShareNotice(includeScoreOnVideo ? `${msg} (With Viral Score)` : `${msg} (Clean Video)`);
      } else {
        const ext = prepared.mimeType.includes('mp4') ? 'mp4' : 'webm';
        const url = URL.createObjectURL(prepared.blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `${clip.title.replace(/[^a-z0-9_-]/gi, '_')}${
          includeScoreOnVideo ? '_Scored' : ''
        }.${ext}`;
        document.body.appendChild(a);
        a.click();
        a.remove();
        setTimeout(() => URL.revokeObjectURL(url), 2500);
        setShareNotice(
          includeScoreOnVideo
            ? 'Exported video with Viral Score badge!'
            : 'Saved clean video without Viral Score!'
        );
      }
      setPendingExportAction(null);
    } finally {
      setIsExportingViralChoice(false);
    }
  };

  const clearCardLongPress = () => {
    if (longPressTimerRef.current !== null) {
      window.clearTimeout(longPressTimerRef.current);
      longPressTimerRef.current = null;
    }
    longPressStartPosRef.current = null;
  };

  const handleOneTapTrendingMusicAndCaption = async (clip: ClipItem) => {
    const trendingTrack = ROYALTY_FREE_TRACKS[0];
    const musicBlob = generateRoyaltyFreeWavBlob(trendingTrack.id);
    const updated: ClipItem = {
      ...clip,
      musicBlob,
      musicName: trendingTrack.title,
      musicVolume: 0.45,
      originalVolume: 0.85,
      autoCaption: clip.autoCaption?.trim() || 'What a Headshot!',
    };
    await onSaveClip(updated);
    if (playingClip?.id === clip.id) {
      setPlayingClip(updated);
    }
    setShareNotice('Applied Trending Music + "What a Headshot!" caption in 1 tap!');
  };

  const handleRunAiAutoEdit = async (clip: ClipItem) => {
    if (aiEditingClipId) return;
    setAiEditingClipId(clip.id);
    setAiStatusText('AI analyzing clip…');
    try {
      const analysis = await runAiAutoEdit(clip, (stage) => {
        setAiStatusText(stage);
      });
      setAiComparisonState({ originalClip: clip, analysis });
    } catch {
      setShareNotice('AI Auto Edit could not process this clip. Try Edit Clip manually.');
    } finally {
      setAiEditingClipId(null);
      setAiStatusText('');
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <h1 className="font-display text-2xl font-bold tracking-tight text-white">My Clips</h1>
          <p className="mt-1 text-sm text-slate-400">
            Play saved video files with synced voiceovers, background music, and streamer attribution, or remove unwanted clips.
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2.5">
          {isNativeAndroid && onSyncClipKaroFolder && (
            <button
              type="button"
              disabled={isSyncingFolder}
              onClick={async () => {
                setIsSyncingFolder(true);
                try {
                  await onSyncClipKaroFolder();
                } finally {
                  setIsSyncingFolder(false);
                }
              }}
              className="inline-flex items-center gap-2 rounded-lg border border-slate-700 bg-[#121722] px-3.5 py-2 text-xs font-semibold text-slate-200 hover:border-slate-500 hover:text-white disabled:opacity-60 whitespace-nowrap shrink-0"
            >
              <FolderSync className="h-3.5 w-3.5 text-emerald-400" aria-hidden="true" />
              <span>{isSyncingFolder ? 'Syncing…' : 'Sync ClipKaro Folder'}</span>
            </button>
          )}
          <button
            type="button"
            disabled={isCreatingSample}
            onClick={handleCreateDemoClip}
            className="inline-flex items-center gap-2 rounded-lg border border-slate-700 bg-[#121722] px-3.5 py-2 text-xs font-semibold text-slate-200 hover:border-slate-500 hover:text-white disabled:opacity-60 whitespace-nowrap shrink-0"
          >
            <Sparkles className="h-3.5 w-3.5 text-rose-400" aria-hidden="true" />
            <span>
              {isCreatingSample ? `Creating Demo (${samplePct}%)` : 'Create 10s Sample Clip'}
            </span>
          </button>
          <button
            type="button"
            onClick={() => onNavigate('cut')}
            className="inline-flex items-center gap-2 rounded-lg bg-rose-600 px-4 py-2 text-xs font-semibold text-white hover:bg-rose-500 whitespace-nowrap shrink-0"
          >
            <Scissors className="h-3.5 w-3.5" aria-hidden="true" />
            <span>Cut New Clip</span>
          </button>
        </div>
      </div>

      {/* Smart Storage Card */}
      <section
        aria-label="Smart Storage"
        className="flex flex-col gap-3 rounded-xl border border-slate-800 bg-[#121722] p-4 sm:flex-row sm:items-center sm:justify-between"
      >
        <div className="flex items-center gap-3">
          <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-amber-500/15 text-amber-400">
            <HardDrive className="h-5 w-5" aria-hidden="true" />
          </span>
          <div>
            <div className="flex flex-wrap items-center gap-2">
              <span className="font-display text-sm font-bold text-white">Smart Storage:</span>
              <span className="font-mono text-sm font-bold text-amber-300 tabular-nums">
                {totalStorageLabel}
              </span>
              <span className="text-xs text-slate-400 tabular-nums">
                ({clips.length} clips · {favouriteClipsCount} Best kept)
              </span>
            </div>
            <p className="text-xs text-slate-400">
              Auto-clean clips older than 7 days while protecting clips marked Favourite / Best.
            </p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            role="switch"
            aria-checked={autoDelete7Days}
            onClick={() => void onToggleAutoDelete7Days?.()}
            className={`rounded-lg border px-3 py-1.5 text-xs font-bold transition-colors ${
              autoDelete7Days
                ? 'border-rose-500/60 bg-rose-600/20 text-rose-200'
                : 'border-slate-700 bg-[#0B0E14] text-slate-300 hover:border-slate-500'
            }`}
          >
            Auto delete &gt; 7 days: {autoDelete7Days ? 'ON' : 'OFF'}
          </button>

          <button
            type="button"
            role="switch"
            aria-checked={keepBestClips}
            onClick={() => onToggleKeepBestClips?.()}
            className={`rounded-lg border px-3 py-1.5 text-xs font-bold transition-colors ${
              keepBestClips
                ? 'border-amber-500/60 bg-amber-500/20 text-amber-200'
                : 'border-slate-700 bg-[#0B0E14] text-slate-300 hover:border-slate-500'
            }`}
          >
            Keep Best Clips: {keepBestClips ? 'ON' : 'OFF'}
          </button>

          {onToggleShowViralScoreInApp && (
            <button
              type="button"
              role="switch"
              aria-checked={showViralScoreInApp}
              onClick={onToggleShowViralScoreInApp}
              className={`rounded-lg border px-3 py-1.5 text-xs font-bold transition-colors ${
                showViralScoreInApp
                  ? 'border-emerald-500/60 bg-emerald-500/20 text-emerald-200'
                  : 'border-slate-700 bg-[#0B0E14] text-slate-300 hover:border-slate-500'
              }`}
            >
              Show Viral Score in App: {showViralScoreInApp ? 'ON' : 'OFF'}
            </button>
          )}

          {expiredClipsCount > 0 && onRunSmartCleanupNow && (
            <button
              type="button"
              onClick={async () => {
                const removed = await onRunSmartCleanupNow();
                if (removed > 0) {
                  setShareNotice(`Smart Storage cleaned ${removed} clip(s) older than 7 days.`);
                }
              }}
              className="rounded-lg bg-rose-600 px-3 py-1.5 text-xs font-bold text-white hover:bg-rose-500"
            >
              Clean {expiredClipsCount} Old
            </button>
          )}
        </div>
      </section>

      {/* Filters */}
      <div className="flex flex-col gap-3 rounded-xl border border-slate-800 bg-[#121722] p-4 lg:flex-row lg:items-center lg:justify-between">
        <div className="flex flex-1 flex-col gap-3 sm:flex-row">
          <div className="relative flex-1">
            <Search
              className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-500"
              aria-hidden="true"
            />
            <input
              type="search"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search by title, @streamer, or game..."
              aria-label="Search clips"
              className="w-full rounded-lg border border-slate-700/80 bg-[#0B0E14] py-2 pl-9 pr-3 text-sm text-white placeholder:text-slate-500 focus:border-rose-500 focus:outline-none"
            />
          </div>

          <select
            value={gameFilter}
            onChange={(e) => setGameFilter(e.target.value)}
            aria-label="Filter by game"
            className="rounded-lg border border-slate-700/80 bg-[#0B0E14] px-3 py-2 text-sm text-white focus:border-rose-500 focus:outline-none"
          >
            <option value="all">All Games &amp; Apps</option>
            {games.map((g) => (
              <option key={g.id} value={g.name}>
                {g.name}
              </option>
            ))}
            <option value="YouTube">YouTube</option>
            <option value="Instagram">Instagram</option>
            <option value="Facebook">Facebook</option>
            <option value="WhatsApp">WhatsApp</option>
            <option value="Just Chatting & IRL">Just Chatting & IRL</option>
          </select>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <div className="flex items-center gap-1 overflow-x-auto rounded-lg border border-slate-800 bg-[#0B0E14] p-1">
            {(
              [
                { id: 'all', label: 'All' },
                { id: 'favourites', label: 'Best / Fav' },
                { id: 'permission', label: 'Permission Verified' },
                { id: 'voice', label: 'With Voice' },
                { id: 'music', label: 'With Music' },
              ] as { id: ClipFilterMode; label: string }[]
            ).map((tab) => (
              <button
                key={tab.id}
                type="button"
                onClick={() => setFilterMode(tab.id)}
                className={`rounded-md px-3 py-1.5 text-xs font-medium whitespace-nowrap shrink-0 transition-colors ${
                  filterMode === tab.id
                    ? 'bg-slate-800 text-white'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>

          <button
            type="button"
            onClick={() => setSortMode((prev) => (prev === 'viral' ? 'newest' : 'viral'))}
            className={`inline-flex items-center gap-1.5 rounded-lg border px-3 py-2 text-xs font-bold whitespace-nowrap shrink-0 transition-colors ${
              sortMode === 'viral'
                ? 'border-amber-400/70 bg-amber-500/20 text-amber-200'
                : 'border-slate-700 bg-[#0B0E14] text-slate-300 hover:border-slate-500'
            }`}
          >
            <Flame className="h-3.5 w-3.5 text-amber-400" aria-hidden="true" />
            <span>
              {sortMode === 'viral' ? 'Sorted: Viral Score (Highest First)' : 'Sort: Viral Score'}
            </span>
          </button>
        </div>
      </div>

      {shareNotice && (
        <div className="flex items-center justify-between gap-3 rounded-xl border border-emerald-500/40 bg-emerald-950/30 px-4 py-2.5 text-xs font-semibold text-emerald-200">
          <div className="flex items-center gap-2 min-w-0">
            <CheckCircle2 className="h-4 w-4 text-emerald-400 shrink-0" aria-hidden="true" />
            <span className="truncate">{shareNotice}</span>
          </div>
          <button
            type="button"
            onClick={() => setShareNotice(null)}
            aria-label="Dismiss notice"
            className="rounded p-1 text-emerald-300 hover:text-white shrink-0"
          >
            <X className="h-3.5 w-3.5" aria-hidden="true" />
          </button>
        </div>
      )}

      {/* Clips Grid or Empty State */}
      {filteredClips.length === 0 ? (
        <div className="flex flex-col items-center justify-center gap-4 rounded-xl border border-slate-800 bg-[#121722] px-6 py-16 text-center">
          <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-slate-800/80 text-slate-400">
            <Film className="h-6 w-6" aria-hidden="true" />
          </div>
          <div className="max-w-md space-y-1">
            <h2 className="font-display text-base font-semibold text-white">
              {clips.length === 0 ? 'No saved clips yet' : 'No clips match your filters'}
            </h2>
            <p className="text-sm text-slate-400">
              {clips.length === 0
                ? 'Cut a video file in Cut Video or generate a 10-second sample clip to test real playback and deletion.'
                : 'Try clearing your search query or switching back to All Games.'}
            </p>
          </div>
          <div className="flex flex-wrap items-center justify-center gap-3 pt-1">
            <button
              type="button"
              onClick={() => onNavigate('cut')}
              className="inline-flex items-center gap-2 rounded-lg bg-rose-600 px-4 py-2.5 text-sm font-semibold text-white hover:bg-rose-500"
            >
              <Scissors className="h-4 w-4" aria-hidden="true" />
              <span>Go to Cut Video</span>
            </button>
            {clips.length === 0 && (
              <button
                type="button"
                disabled={isCreatingSample}
                onClick={handleCreateDemoClip}
                className="inline-flex items-center gap-2 rounded-lg border border-slate-700 bg-slate-800 px-4 py-2.5 text-sm font-semibold text-white hover:bg-slate-700 disabled:opacity-60"
              >
                <Sparkles className="h-4 w-4 text-rose-400" aria-hidden="true" />
                <span>
                  {isCreatingSample ? `Creating (${samplePct}%)` : 'Create 10s Sample Clip'}
                </span>
              </button>
            )}
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {filteredClips.map((clip) => {
            const viral = calculateViralScore(clip);
            const isAiBusy = aiEditingClipId === clip.id;
            const shouldShowViralOnCard = showViralScoreInApp && !clip.hideViralScore;

            return (
              <article
                key={clip.id}
                onPointerDown={(e) => {
                  clearCardLongPress();
                  longPressStartPosRef.current = { x: e.clientX, y: e.clientY };
                  longPressTimerRef.current = window.setTimeout(() => {
                    longPressTimerRef.current = null;
                    setLongPressClip(clip);
                  }, 500);
                }}
                onPointerMove={(e) => {
                  const start = longPressStartPosRef.current;
                  if (!start) return;
                  if (Math.hypot(e.clientX - start.x, e.clientY - start.y) > 10) {
                    clearCardLongPress();
                  }
                }}
                onPointerUp={clearCardLongPress}
                onPointerCancel={clearCardLongPress}
                onContextMenu={(e) => {
                  e.preventDefault();
                  clearCardLongPress();
                  setLongPressClip(clip);
                }}
                className="flex flex-col justify-between overflow-hidden rounded-xl border border-slate-800 bg-[#121722]"
              >
                <div>
                  {/* Thumbnail with duration scrim */}
                  <div className="relative aspect-video w-full bg-[#07090D] overflow-hidden">
                    {clip.thumbnailDataUrl ? (
                      <img
                        src={clip.thumbnailDataUrl}
                        alt={clip.title}
                        style={{ filter: combineCssFilters(clip.filterPreset, clip.effectMode) }}
                        className={`h-full w-full ${
                          clip.fitMode === 'fit' ? 'object-contain' : 'object-cover'
                        }`}
                        referrerPolicy="no-referrer"
                      />
                    ) : (
                      <div className="flex h-full w-full items-center justify-center bg-gradient-to-br from-slate-900 to-slate-800">
                        <Film className="h-9 w-9 text-slate-600" aria-hidden="true" />
                      </div>
                    )}
                    {clip.effectMode === 'cinematic' && (
                      <>
                        <div className="pointer-events-none absolute inset-x-0 top-0 h-[10%] bg-black" />
                        <div className="pointer-events-none absolute inset-x-0 bottom-0 h-[10%] bg-black" />
                      </>
                    )}
                    <div className="pointer-events-none absolute inset-x-0 bottom-0 h-14 bg-gradient-to-t from-black/85 via-black/40 to-transparent" />
                    <button
                      type="button"
                      onClick={() => void onToggleFavouriteClip?.(clip)}
                      title={clip.isFavourite ? 'Marked Best / Keep Forever' : 'Mark as Best / Favourite'}
                      aria-label={clip.isFavourite ? 'Unmark Best clip' : 'Mark as Best clip'}
                      className={`absolute top-2.5 right-2.5 flex h-8 w-8 items-center justify-center rounded-full border backdrop-blur-sm transition-colors ${
                        clip.isFavourite
                          ? 'border-amber-400 bg-amber-500/90 text-slate-950'
                          : 'border-slate-600/80 bg-black/60 text-slate-200 hover:border-amber-400 hover:text-amber-300'
                      }`}
                    >
                      <Star
                        className={`h-4 w-4 ${clip.isFavourite ? 'fill-current' : ''}`}
                        aria-hidden="true"
                      />
                    </button>
                    <span className="absolute bottom-2.5 right-3 font-mono text-xs font-semibold text-white tabular-nums">
                      {formatSeconds(clip.durationSec)}
                    </span>
                  </div>

                  {/* Metadata (Zero-pill discipline: unboxed text with separators) */}
                  <div className="space-y-2 p-4">
                    <div className="flex items-center justify-between gap-2">
                      <h3 className="font-display text-base font-semibold text-white truncate">
                        {clip.title}
                      </h3>
                      {clip.isFavourite && (
                        <span className="text-[11px] font-bold text-amber-300 shrink-0">
                          ★ Best
                        </span>
                      )}
                    </div>

                    {/* Viral Score + Tip (App-only; hidden if Settings OFF or long-pressed Hide Score) */}
                    {shouldShowViralOnCard ? (
                      <div
                        className={`rounded-lg border px-2.5 py-2 ${
                          viral.tier === 'high'
                            ? 'border-emerald-500/40 bg-emerald-950/25'
                            : viral.tier === 'medium'
                              ? 'border-amber-500/40 bg-amber-950/20'
                              : 'border-slate-700/80 bg-[#0B0E14]'
                        }`}
                      >
                        <div className="flex items-center gap-1.5 text-xs font-bold">
                          <Flame
                            className={`h-3.5 w-3.5 shrink-0 ${
                              viral.tier === 'high'
                                ? 'text-emerald-400'
                                : viral.tier === 'medium'
                                  ? 'text-amber-400'
                                  : 'text-slate-400'
                            }`}
                            aria-hidden="true"
                          />
                          <span
                            className={
                              viral.tier === 'high'
                                ? 'text-emerald-200'
                                : viral.tier === 'medium'
                                  ? 'text-amber-200'
                                  : 'text-slate-200'
                            }
                          >
                            {viral.label}
                          </span>
                        </div>
                        <div className="mt-0.5 text-[11px] text-slate-400">
                          Tip: {viral.tip}
                        </div>
                      </div>
                    ) : showViralScoreInApp && clip.hideViralScore ? (
                      <div className="text-[11px] text-slate-500 italic">
                        Score hidden · Long-press clip to Show Score
                      </div>
                    ) : null}

                    <div className="flex flex-wrap items-center gap-x-2 gap-y-1 text-xs text-slate-400 tabular-nums">
                      <span>{clip.durationSec} sec</span>
                      <span aria-hidden="true">·</span>
                      <span className="capitalize">{clip.platform}</span>
                      <span aria-hidden="true">·</span>
                      <span className="truncate max-w-[160px]">{clip.gameTag}</span>
                      {clip.isReaction && (
                        <>
                          <span aria-hidden="true">·</span>
                          <span className="font-semibold text-teal-300">Reaction</span>
                        </>
                      )}
                      {clip.voiceChanger && clip.voiceChanger !== 'normal' && (
                        <>
                          <span aria-hidden="true">·</span>
                          <span className="capitalize text-violet-300">{clip.voiceChanger} Voice</span>
                        </>
                      )}
                      {clip.aspectRatio && clip.aspectRatio !== '16:9' && (
                        <>
                          <span aria-hidden="true">·</span>
                          <span className="font-semibold text-rose-300">{clip.aspectRatio}</span>
                        </>
                      )}
                      {clip.effectMode && clip.effectMode !== 'none' && (
                        <>
                          <span aria-hidden="true">·</span>
                          <span className="text-amber-300">
                            {EFFECT_MODES.find((m) => m.id === clip.effectMode)?.label}
                          </span>
                        </>
                      )}
                      {clip.speedSegments &&
                        clip.speedSegments.some((s) => s.speed !== 1) && (
                          <>
                            <span aria-hidden="true">·</span>
                            <span className="text-sky-300">
                              {clip.speedSegments.length > 1
                                ? 'Split Speed'
                                : `${clip.speedSegments[0].speed}x`}
                            </span>
                          </>
                        )}
                    </div>

                    <div className="text-xs text-slate-300 font-mono truncate">
                      {clip.permission.creditText}
                    </div>

                    <div className="flex flex-wrap items-center gap-x-3 gap-y-1 pt-0.5 text-xs text-slate-400">
                      {clip.permission.hasPermission && (
                        <span className="inline-flex items-center gap-1 text-emerald-400">
                          <ShieldCheck className="h-3.5 w-3.5" aria-hidden="true" />
                          <span>Permission verified</span>
                        </span>
                      )}
                      {clip.voiceBlob && (
                        <span className="inline-flex items-center gap-1 text-sky-400">
                          <Mic className="h-3.5 w-3.5" aria-hidden="true" />
                          <span>Voice</span>
                        </span>
                      )}
                      {clip.musicBlob && (
                        <span className="inline-flex items-center gap-1 text-amber-400">
                          <Music className="h-3.5 w-3.5" aria-hidden="true" />
                          <span>Music</span>
                        </span>
                      )}
                    </div>
                  </div>
                </div>

                {/* AI Auto Edit 1-Tap Action Strip */}
                <div className="border-t border-slate-800/80 bg-[#0F1520] px-4 py-2">
                  <button
                    type="button"
                    disabled={Boolean(aiEditingClipId)}
                    onClick={() => void handleRunAiAutoEdit(clip)}
                    className="inline-flex w-full items-center justify-center gap-2 rounded-lg border border-amber-500/50 bg-gradient-to-r from-amber-500/20 via-rose-500/20 to-violet-500/20 px-3 py-2 text-xs font-bold text-amber-200 transition-colors hover:border-amber-400 hover:text-white disabled:opacity-60"
                  >
                    <Wand2 className="h-3.5 w-3.5 text-amber-400" aria-hidden="true" />
                    <span>
                      {isAiBusy
                        ? aiStatusText || 'AI Auto Editing…'
                        : 'AI Auto Edit (Best 15s + Music + Cinematic)'}
                    </span>
                  </button>
                </div>

                {/* 1-Tap Share Bar (#BGMI #ClipKaro) */}
                <div className="flex items-center justify-between gap-1.5 border-t border-slate-800/80 bg-[#0B0E14]/60 px-4 py-2">
                  <span className="inline-flex items-center gap-1 text-[10px] font-semibold text-slate-400 shrink-0">
                    <Share2 className="h-3 w-3 text-rose-400" aria-hidden="true" />
                    <span>Share:</span>
                  </span>
                  <div className="flex items-center gap-1">
                    <button
                      type="button"
                      onClick={() => handleRequestShareClip(clip, 'youtube')}
                      className="rounded bg-red-600/90 px-2 py-1 text-[10px] font-bold text-white hover:bg-red-500"
                    >
                      YT Shorts
                    </button>
                    <button
                      type="button"
                      onClick={() => handleRequestShareClip(clip, 'instagram')}
                      className="rounded bg-fuchsia-600/90 px-2 py-1 text-[10px] font-bold text-white hover:bg-fuchsia-500"
                    >
                      Reels
                    </button>
                    <button
                      type="button"
                      onClick={() => handleRequestShareClip(clip, 'whatsapp')}
                      className="rounded bg-emerald-600/90 px-2 py-1 text-[10px] font-bold text-white hover:bg-emerald-500"
                    >
                      WhatsApp
                    </button>
                  </div>
                </div>

                {/* Card Actions: Play, Thumbnail, Edit & Delete */}
                <div className="flex items-center gap-1.5 border-t border-slate-800/80 px-4 py-3">
                  <button
                    type="button"
                    onClick={() => setPlayingClip(clip)}
                    className="inline-flex flex-1 items-center justify-center gap-1.5 rounded-lg bg-rose-600 px-3 py-2 text-xs font-semibold text-white transition-colors hover:bg-rose-500 whitespace-nowrap"
                  >
                    <Play className="h-3.5 w-3.5 fill-current" aria-hidden="true" />
                    <span>Play</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setEditorInitialTab('thumbnail');
                      setEditingClip(clip);
                    }}
                    title="Thumbnail Maker (1 VS 4 CLUTCH)"
                    className="inline-flex items-center justify-center gap-1 rounded-lg border border-slate-700 bg-[#0B0E14] px-2.5 py-2 text-xs font-semibold text-amber-300 transition-colors hover:border-amber-400 hover:text-amber-200 whitespace-nowrap shrink-0"
                  >
                    <ImageIcon className="h-3.5 w-3.5" aria-hidden="true" />
                    <span>Thumb</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setEditorInitialTab('trim');
                      setEditingClip(clip);
                    }}
                    className="inline-flex items-center justify-center gap-1 rounded-lg border border-slate-700 bg-[#0B0E14] px-2.5 py-2 text-xs font-semibold text-slate-200 transition-colors hover:border-rose-500 hover:text-white whitespace-nowrap shrink-0"
                  >
                    <SlidersHorizontal className="h-3.5 w-3.5" aria-hidden="true" />
                    <span>Edit</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setClipPendingDelete(clip)}
                    aria-label="Delete clip"
                    className="inline-flex items-center justify-center rounded-lg border border-slate-700 bg-[#0B0E14] p-2 text-slate-300 transition-colors hover:border-rose-500/60 hover:bg-rose-950/30 hover:text-rose-200 shrink-0"
                  >
                    <Trash2 className="h-3.5 w-3.5" aria-hidden="true" />
                  </button>
                </div>
              </article>
            );
          })}
        </div>
      )}

      {/* Actual File Clip Player Modal */}
      {playingClip && activeVideoUrl && (
        <div
          role="dialog"
          aria-modal="true"
          aria-labelledby="clip-player-title"
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4 backdrop-blur-sm"
        >
          <div className="w-full max-w-4xl overflow-hidden rounded-xl border border-slate-800 bg-[#121722] shadow-2xl max-h-[92vh] overflow-y-auto">
            <div className="flex items-center justify-between gap-4 border-b border-slate-800 px-5 py-4">
              <div className="min-w-0">
                <h2 id="clip-player-title" className="font-display text-lg font-bold text-white truncate">
                  {playingClip.title}
                </h2>
                <div className="mt-0.5 flex flex-wrap items-center gap-2 text-xs text-slate-400 tabular-nums">
                  <span>{playingClip.durationSec} sec</span>
                  <span aria-hidden="true">·</span>
                  <span className="font-mono text-slate-200">{playingClip.permission.creditText}</span>
                  <span aria-hidden="true">·</span>
                  <span>{playingClip.gameTag}</span>
                  {playingClip.aspectRatio && (
                    <>
                      <span aria-hidden="true">·</span>
                      <span className="text-rose-300 font-semibold">
                        {playingClip.aspectRatio} ({playingClip.fitMode === 'fit' ? 'Fit' : 'Fill'})
                      </span>
                    </>
                  )}
                  {playingClip.filterPreset && playingClip.filterPreset !== 'none' && (
                    <>
                      <span aria-hidden="true">·</span>
                      <span className="text-amber-300">
                        {FILTER_PRESETS.find((f) => f.id === playingClip.filterPreset)?.label}
                      </span>
                    </>
                  )}
                  {playingClip.effectMode && playingClip.effectMode !== 'none' && (
                    <>
                      <span aria-hidden="true">·</span>
                      <span className="text-amber-200">
                        {EFFECT_MODES.find((m) => m.id === playingClip.effectMode)?.label} Mode
                      </span>
                    </>
                  )}
                </div>
              </div>
              <button
                type="button"
                onClick={() => setPlayingClip(null)}
                aria-label="Close player"
                className="rounded-lg p-2 text-slate-400 hover:bg-slate-800 hover:text-white shrink-0"
              >
                <X className="h-5 w-5" aria-hidden="true" />
              </button>
            </div>

            <div className="relative flex items-center justify-center bg-[#06080D] p-2">
              <div
                className={`relative overflow-hidden bg-black ${getAspectContainerClass(
                  playingClip.aspectRatio ?? '16:9'
                )}`}
              >
                <video
                  ref={playerVideoRef}
                  src={activeVideoUrl}
                  controls
                  playsInline
                  onLoadedMetadata={handlePlayerLoadedMetadata}
                  onPlay={handlePlayerPlay}
                  onPause={handlePlayerPause}
                  onTimeUpdate={handlePlayerTimeUpdate}
                  style={{
                    filter: combineCssFilters(playingClip.filterPreset, playingClip.effectMode),
                  }}
                  className={`h-full w-full ${
                    playingClip.fitMode === 'fit' ? 'object-contain' : 'object-cover'
                  }`}
                />
                {playingClip.effectMode === 'cinematic' && (
                  <>
                    <div className="pointer-events-none absolute inset-x-0 top-0 h-[11%] bg-black" />
                    <div className="pointer-events-none absolute inset-x-0 bottom-0 h-[11%] bg-black" />
                  </>
                )}
                {playingClip.autoCaption && (
                  <div className="pointer-events-none absolute inset-x-0 bottom-12 flex justify-center px-4">
                    <span className="rounded bg-black px-3 py-1 text-xs font-bold text-white shadow">
                      {playingClip.autoCaption}
                    </span>
                  </div>
                )}
              </div>
              {activeVoiceUrl && (
                <audio ref={playerVoiceRef} src={activeVoiceUrl} className="hidden" />
              )}
              {activeMusicUrl && (
                <audio ref={playerMusicRef} src={activeMusicUrl} loop className="hidden" />
              )}
            </div>

            <div className="grid grid-cols-1 gap-4 p-5 sm:grid-cols-2">
              <div className="space-y-2 text-xs text-slate-300">
                <div className="font-semibold text-white">Attribution & Audio Mix</div>
                <p className="font-mono text-slate-200">{playingClip.permission.creditText}</p>
                {playingClip.permission.originalVideoLink && (
                  <a
                    href={playingClip.permission.originalVideoLink}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1.5 text-rose-400 hover:text-rose-300"
                  >
                    <span>Original Video Link</span>
                    <ExternalLink className="h-3.5 w-3.5" aria-hidden="true" />
                  </a>
                )}
                <div className="flex flex-wrap items-center gap-3 pt-1 text-slate-400 tabular-nums">
                  <span>Original Audio: {Math.round((playingClip.originalVolume ?? 1) * 100)}%</span>
                  {playingClip.voiceName && (
                    <span>
                      Voice ({playingClip.voiceName}): {Math.round(playingClip.voiceVolume * 100)}%
                    </span>
                  )}
                  {playingClip.musicName && (
                    <span>
                      Music ({playingClip.musicName}): {Math.round(playingClip.musicVolume * 100)}%
                    </span>
                  )}
                </div>
              </div>

              <div className="flex flex-col items-start justify-between gap-3 sm:items-end">
                {activeProofUrl ? (
                  <div className="flex items-center gap-2.5 rounded-lg border border-slate-800 bg-[#0B0E14] p-2">
                    <img
                      src={activeProofUrl}
                      alt="Streamer permission proof"
                      className="h-10 w-10 rounded object-cover"
                      referrerPolicy="no-referrer"
                    />
                    <div className="text-xs">
                      <div className="font-medium text-emerald-300">Permission Proof</div>
                      <div className="text-slate-400 truncate max-w-[160px]">
                        {playingClip.permission.proofFileName}
                      </div>
                    </div>
                  </div>
                ) : playingClip.permission.proofFileName ? (
                  <div className="text-xs text-emerald-300">
                    Proof attached: {playingClip.permission.proofFileName}
                  </div>
                ) : null}

                <div className="flex flex-wrap items-center gap-2">
                  <button
                    type="button"
                    disabled={Boolean(aiEditingClipId)}
                    onClick={() => {
                      const target = playingClip;
                      setPlayingClip(null);
                      void handleRunAiAutoEdit(target);
                    }}
                    className="inline-flex items-center gap-1.5 rounded-lg border border-amber-400/60 bg-amber-500/20 px-3 py-2 text-xs font-bold text-amber-200 hover:bg-amber-500/30 disabled:opacity-60"
                  >
                    <Wand2 className="h-3.5 w-3.5" aria-hidden="true" />
                    <span>AI Auto Edit</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => void handleOneTapTrendingMusicAndCaption(playingClip)}
                    className="inline-flex items-center gap-1.5 rounded-lg bg-amber-500 px-3 py-2 text-xs font-bold text-slate-950 hover:bg-amber-400"
                  >
                    <Sparkles className="h-3.5 w-3.5" aria-hidden="true" />
                    <span>1-Tap Trending + Caption</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      const target = playingClip;
                      setPlayingClip(null);
                      setEditorInitialTab('thumbnail');
                      setEditingClip(target);
                    }}
                    className="inline-flex items-center gap-1.5 rounded-lg border border-amber-500/40 bg-[#0B0E14] px-3 py-2 text-xs font-semibold text-amber-300 hover:border-amber-400"
                  >
                    <ImageIcon className="h-3.5 w-3.5" aria-hidden="true" />
                    <span>Thumbnail</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      const target = playingClip;
                      setPlayingClip(null);
                      setEditorInitialTab('trim');
                      setEditingClip(target);
                    }}
                    className="inline-flex items-center gap-1.5 rounded-lg bg-rose-600 px-3.5 py-2 text-xs font-semibold text-white hover:bg-rose-500"
                  >
                    <SlidersHorizontal className="h-3.5 w-3.5" aria-hidden="true" />
                    <span>Edit Clip</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => handleRequestDownloadClip(playingClip)}
                    className="inline-flex items-center gap-2 rounded-lg border border-slate-700 bg-[#0B0E14] px-3.5 py-2 text-xs font-semibold text-white hover:bg-slate-800"
                  >
                    <Download className="h-3.5 w-3.5" aria-hidden="true" />
                    <span>Download File</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setClipPendingDelete(playingClip)}
                    className="inline-flex items-center gap-1.5 rounded-lg border border-rose-500/40 bg-rose-950/30 px-3.5 py-2 text-xs font-semibold text-rose-200 hover:bg-rose-900/40"
                  >
                    <Trash2 className="h-3.5 w-3.5" aria-hidden="true" />
                    <span>Delete Clip</span>
                  </button>
                </div>

                {/* 1-Tap Share inside Player Modal */}
                <div className="flex flex-wrap items-center gap-1.5 pt-1">
                  <span className="text-[11px] font-semibold text-slate-400 mr-1">
                    Share (#BGMI #ClipKaro):
                  </span>
                  <button
                    type="button"
                    onClick={() => handleRequestShareClip(playingClip, 'youtube')}
                    className="rounded-md bg-red-600 px-2.5 py-1 text-[11px] font-bold text-white hover:bg-red-500"
                  >
                    YouTube Shorts
                  </button>
                  <button
                    type="button"
                    onClick={() => handleRequestShareClip(playingClip, 'instagram')}
                    className="rounded-md bg-fuchsia-600 px-2.5 py-1 text-[11px] font-bold text-white hover:bg-fuchsia-500"
                  >
                    Instagram Reels
                  </button>
                  <button
                    type="button"
                    onClick={() => handleRequestShareClip(playingClip, 'whatsapp')}
                    className="rounded-md bg-emerald-600 px-2.5 py-1 text-[11px] font-bold text-white hover:bg-emerald-500"
                  >
                    WhatsApp
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Long-Press Per-Clip Options Menu (Hide Score / Show Score) */}
      {longPressClip && (
        <div
          role="dialog"
          aria-modal="true"
          aria-label="Clip Options"
          className="fixed inset-0 z-[75] flex items-center justify-center bg-black/75 p-4 backdrop-blur-sm"
          onClick={() => setLongPressClip(null)}
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="w-full max-w-xs rounded-2xl border border-slate-700 bg-[#121722] p-4 shadow-2xl space-y-2.5"
          >
            <div className="flex items-center justify-between gap-2 border-b border-slate-800 pb-2.5">
              <div className="min-w-0">
                <div className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
                  Clip Options
                </div>
                <div className="text-sm font-bold text-white truncate">{longPressClip.title}</div>
              </div>
              <button
                type="button"
                onClick={() => setLongPressClip(null)}
                aria-label="Close options"
                className="rounded p-1 text-slate-400 hover:text-white"
              >
                <X className="h-4 w-4" aria-hidden="true" />
              </button>
            </div>

            {onToggleClipHideScore && (
              <button
                type="button"
                onClick={async () => {
                  const target = longPressClip;
                  setLongPressClip(null);
                  await onToggleClipHideScore(target);
                  setShareNotice(
                    target.hideViralScore
                      ? `Viral Score shown for "${target.title}"`
                      : `Viral Score hidden for "${target.title}"`
                  );
                }}
                className="flex w-full items-center gap-2.5 rounded-xl border border-amber-500/40 bg-amber-500/15 px-3.5 py-2.5 text-xs font-bold text-amber-200 hover:bg-amber-500/25"
              >
                {longPressClip.hideViralScore ? (
                  <Eye className="h-4 w-4 text-amber-400" aria-hidden="true" />
                ) : (
                  <EyeOff className="h-4 w-4 text-amber-400" aria-hidden="true" />
                )}
                <span>{longPressClip.hideViralScore ? 'Show Score' : 'Hide Score'}</span>
              </button>
            )}

            {onToggleFavouriteClip && (
              <button
                type="button"
                onClick={async () => {
                  const target = longPressClip;
                  setLongPressClip(null);
                  await onToggleFavouriteClip(target);
                }}
                className="flex w-full items-center gap-2.5 rounded-xl border border-slate-700 bg-[#0B0E14] px-3.5 py-2.5 text-xs font-semibold text-slate-200 hover:border-slate-500"
              >
                <Star className="h-4 w-4 text-amber-400" aria-hidden="true" />
                <span>{longPressClip.isFavourite ? 'Remove Best / Fav' : 'Mark as Best / Fav'}</span>
              </button>
            )}

            <button
              type="button"
              onClick={() => setLongPressClip(null)}
              className="w-full rounded-xl border border-slate-800 bg-slate-900 px-3.5 py-2 text-xs font-semibold text-slate-400 hover:text-white"
            >
              Cancel
            </button>
          </div>
        </div>
      )}

      {/* Share / Save Prompt: Show Viral Score on video? YES / NO */}
      {pendingExportAction && (
        <ViralScoreExportDialog
          isOpen={Boolean(pendingExportAction)}
          actionLabel={
            pendingExportAction.kind === 'share'
              ? `sharing to ${
                  pendingExportAction.platform === 'youtube'
                    ? 'YouTube Shorts'
                    : pendingExportAction.platform === 'instagram'
                      ? 'Instagram Reels'
                      : 'WhatsApp'
                }`
              : 'saving/downloading video'
          }
          viralScore={calculateViralScore(pendingExportAction.clip).score}
          isProcessing={isExportingViralChoice}
          onChoose={(includeScore) => void handleConfirmExportViralChoice(includeScore)}
          onCancel={() => setPendingExportAction(null)}
        />
      )}

      {/* AI Auto Edit Compare Modal (Original vs AI Edited) */}
      {aiComparisonState && (
        <AiAutoEditModal
          originalClip={aiComparisonState.originalClip}
          analysis={aiComparisonState.analysis}
          onSaveClip={onSaveClip}
          onClose={() => setAiComparisonState(null)}
          onCompleteNotice={(msg) => setShareNotice(msg)}
        />
      )}

      {/* In-App Clip Editor Modal (Trim/Cut + Add Music + Add Voiceover + Thumbnail Maker + Save) */}
      {editingClip && (
        <ClipEditorModal
          clip={editingClip}
          initialTab={editorInitialTab}
          onSaveClip={async (savedClip) => {
            await onSaveClip(savedClip);
            setEditingClip(savedClip);
          }}
          onClose={() => setEditingClip(null)}
        />
      )}

      {/* Delete Confirmation Modal */}
      {clipPendingDelete && (
        <div
          role="alertdialog"
          aria-modal="true"
          aria-labelledby="delete-confirm-title"
          aria-describedby="delete-confirm-desc"
          className="fixed inset-0 z-[60] flex items-center justify-center bg-black/80 p-4 backdrop-blur-sm"
        >
          <div className="w-full max-w-md rounded-xl border border-slate-800 bg-[#121722] p-6 shadow-2xl space-y-4">
            <div className="space-y-1.5">
              <h2 id="delete-confirm-title" className="font-display text-lg font-bold text-white">
                Delete this clip?
              </h2>
              <p id="delete-confirm-desc" className="text-sm text-slate-400">
                Are you sure you want to permanently delete{' '}
                <span className="font-semibold text-slate-200">{clipPendingDelete.title}</span>? This
                removes the video file and any attached voice or music tracks from My Clips.
              </p>
            </div>
            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                type="button"
                disabled={isDeleting}
                onClick={() => setClipPendingDelete(null)}
                className="rounded-lg border border-slate-700 bg-[#0B0E14] px-4 py-2 text-sm font-semibold text-slate-200 hover:bg-slate-800"
              >
                Cancel
              </button>
              <button
                type="button"
                disabled={isDeleting}
                onClick={handleConfirmDelete}
                className="rounded-lg bg-rose-600 px-4 py-2 text-sm font-semibold text-white hover:bg-rose-500 disabled:opacity-60"
              >
                {isDeleting ? 'Deleting…' : 'Confirm Delete'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

import { useEffect, useMemo, useRef, useState } from 'react';
import {
  Download,
  ExternalLink,
  Film,
  Mic,
  Music,
  Play,
  Scissors,
  Search,
  ShieldCheck,
  Sparkles,
  Trash2,
  X,
} from 'lucide-react';
import { ClipItem, GameItem, WorkspaceTab } from '../types/clipkaro';
import { formatSeconds, generateSampleStreamVideoBlob } from '../utils/mediaGenerators';

interface MyClipsViewProps {
  clips: ClipItem[];
  games: GameItem[];
  initialGameFilter?: string;
  onDeleteClip: (id: string) => Promise<void>;
  onSaveClip: (clip: ClipItem) => Promise<void>;
  onNavigate: (tab: WorkspaceTab) => void;
}

type ClipFilterMode = 'all' | 'permission' | 'voice' | 'music';

export function MyClipsView({
  clips,
  games,
  initialGameFilter = 'all',
  onDeleteClip,
  onSaveClip,
  onNavigate,
}: MyClipsViewProps) {
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [gameFilter, setGameFilter] = useState<string>(initialGameFilter);
  const [filterMode, setFilterMode] = useState<ClipFilterMode>('all');

  // Active Player Modal State
  const [playingClip, setPlayingClip] = useState<ClipItem | null>(null);
  const [activeVideoUrl, setActiveVideoUrl] = useState<string | null>(null);
  const [activeVoiceUrl, setActiveVoiceUrl] = useState<string | null>(null);
  const [activeMusicUrl, setActiveMusicUrl] = useState<string | null>(null);
  const [activeProofUrl, setActiveProofUrl] = useState<string | null>(null);

  // Delete Confirmation Modal State
  const [clipPendingDelete, setClipPendingDelete] = useState<ClipItem | null>(null);
  const [isDeleting, setIsDeleting] = useState<boolean>(false);

  // Quick sample creation in My Clips
  const [isCreatingSample, setIsCreatingSample] = useState<boolean>(false);
  const [samplePct, setSamplePct] = useState<number>(0);

  const playerVideoRef = useRef<HTMLVideoElement | null>(null);
  const playerVoiceRef = useRef<HTMLAudioElement | null>(null);
  const playerMusicRef = useRef<HTMLAudioElement | null>(null);

  useEffect(() => {
    setGameFilter(initialGameFilter || 'all');
  }, [initialGameFilter]);

  // Create and revoke object URLs whenever playingClip changes
  useEffect(() => {
    if (!playingClip) {
      setActiveVideoUrl(null);
      setActiveVoiceUrl(null);
      setActiveMusicUrl(null);
      setActiveProofUrl(null);
      return;
    }

    const vUrl = URL.createObjectURL(playingClip.videoBlob);
    const voUrl = playingClip.voiceBlob ? URL.createObjectURL(playingClip.voiceBlob) : null;
    const muUrl = playingClip.musicBlob ? URL.createObjectURL(playingClip.musicBlob) : null;
    const prUrl =
      playingClip.permission.proofBlob &&
      playingClip.permission.proofMimeType?.startsWith('image/')
        ? URL.createObjectURL(playingClip.permission.proofBlob)
        : null;

    setActiveVideoUrl(vUrl);
    setActiveVoiceUrl(voUrl);
    setActiveMusicUrl(muUrl);
    setActiveProofUrl(prUrl);

    return () => {
      URL.revokeObjectURL(vUrl);
      if (voUrl) URL.revokeObjectURL(voUrl);
      if (muUrl) URL.revokeObjectURL(muUrl);
      if (prUrl) URL.revokeObjectURL(prUrl);
    };
  }, [playingClip]);

  // Sync audio track volumes when player mounts
  useEffect(() => {
    if (!playingClip) return;
    if (playerVideoRef.current) {
      playerVideoRef.current.volume = playingClip.originalVolume ?? 1;
    }
    if (playerVoiceRef.current) {
      playerVoiceRef.current.volume = playingClip.voiceVolume ?? 1;
    }
    if (playerMusicRef.current) {
      playerMusicRef.current.volume = playingClip.musicVolume ?? 0.45;
    }
  }, [playingClip, activeVideoUrl, activeVoiceUrl, activeMusicUrl]);

  const filteredClips = useMemo(() => {
    return clips.filter((clip) => {
      const q = searchQuery.trim().toLowerCase();
      if (q) {
        const matchesTitle = clip.title.toLowerCase().includes(q);
        const matchesCredit = clip.permission.creditText.toLowerCase().includes(q);
        const matchesGame = clip.gameTag.toLowerCase().includes(q);
        if (!matchesTitle && !matchesCredit && !matchesGame) return false;
      }
      if (gameFilter !== 'all' && clip.gameTag !== gameFilter) return false;
      if (filterMode === 'permission' && !clip.permission.hasPermission) return false;
      if (filterMode === 'voice' && !clip.voiceBlob) return false;
      if (filterMode === 'music' && !clip.musicBlob) return false;
      return true;
    });
  }, [clips, searchQuery, gameFilter, filterMode]);

  const handlePlayerLoadedMetadata = () => {
    const vEl = playerVideoRef.current;
    if (!vEl || !playingClip) return;
    if (playingClip.trimStart > 0 && playingClip.trimStart < vEl.duration) {
      vEl.currentTime = playingClip.trimStart;
    }
    vEl.play().catch(() => undefined);
  };

  const handlePlayerPlay = () => {
    const vEl = playerVideoRef.current;
    if (!vEl || !playingClip) return;
    const offset = Math.max(0, vEl.currentTime - playingClip.trimStart);
    if (playerVoiceRef.current) {
      playerVoiceRef.current.currentTime = Math.min(
        offset,
        playerVoiceRef.current.duration || offset
      );
      playerVoiceRef.current.play().catch(() => undefined);
    }
    if (playerMusicRef.current) {
      playerMusicRef.current.currentTime =
        playerMusicRef.current.duration > 0 ? offset % playerMusicRef.current.duration : 0;
      playerMusicRef.current.play().catch(() => undefined);
    }
  };

  const handlePlayerPause = () => {
    playerVoiceRef.current?.pause();
    playerMusicRef.current?.pause();
  };

  const handlePlayerTimeUpdate = () => {
    const vEl = playerVideoRef.current;
    if (!vEl || !playingClip) return;
    if (playingClip.trimEnd > playingClip.trimStart && vEl.currentTime >= playingClip.trimEnd) {
      vEl.pause();
      vEl.currentTime = playingClip.trimStart;
      playerVoiceRef.current?.pause();
      playerMusicRef.current?.pause();
    }
  };

  const handleConfirmDelete = async () => {
    if (!clipPendingDelete) return;
    setIsDeleting(true);
    try {
      await onDeleteClip(clipPendingDelete.id);
      if (playingClip?.id === clipPendingDelete.id) {
        setPlayingClip(null);
      }
      setClipPendingDelete(null);
    } finally {
      setIsDeleting(false);
    }
  };

  const handleCreateDemoClip = async () => {
    setIsCreatingSample(true);
    setSamplePct(0);
    try {
      const blob = await generateSampleStreamVideoBlob({
        durationSec: 10,
        title: 'Clutch Arena Highlight',
        creditLine: 'Credit: @AlexPlays',
        onProgress: setSamplePct,
      });
      const sampleClip: ClipItem = {
        id: `clip-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
        title: 'Clutch Arena Highlight',
        platform: 'youtube',
        gameTag: games[0]?.name || 'Valorant & Tactical FPS',
        durationSec: 10,
        trimStart: 0,
        trimEnd: 10,
        createdAt: Date.now(),
        copyrightSafe: true,
        permission: {
          hasPermission: true,
          streamerName: 'AlexPlays',
          originalVideoLink: 'https://www.youtube.com/watch?v=aqz-KE-bpKQ',
          creditText: 'Credit: @AlexPlays',
        },
        videoBlob: blob,
        videoMimeType: blob.type || 'video/webm',
        voiceVolume: 1,
        musicVolume: 0.45,
        originalVolume: 1,
      };
      await onSaveClip(sampleClip);
    } finally {
      setIsCreatingSample(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <h1 className="font-display text-2xl font-bold tracking-tight text-white">My Clips</h1>
          <p className="mt-1 text-sm text-slate-400">
            Play saved video files with synced voiceovers, background music, and streamer attribution, or remove unwanted clips.
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2.5">
          <button
            type="button"
            disabled={isCreatingSample}
            onClick={handleCreateDemoClip}
            className="inline-flex items-center gap-2 rounded-lg border border-slate-700 bg-[#121722] px-3.5 py-2 text-xs font-semibold text-slate-200 hover:border-slate-500 hover:text-white disabled:opacity-60 whitespace-nowrap shrink-0"
          >
            <Sparkles className="h-3.5 w-3.5 text-rose-400" aria-hidden="true" />
            <span>
              {isCreatingSample ? `Creating Demo (${samplePct}%)` : 'Create 10s Sample Clip'}
            </span>
          </button>
          <button
            type="button"
            onClick={() => onNavigate('cut')}
            className="inline-flex items-center gap-2 rounded-lg bg-rose-600 px-4 py-2 text-xs font-semibold text-white hover:bg-rose-500 whitespace-nowrap shrink-0"
          >
            <Scissors className="h-3.5 w-3.5" aria-hidden="true" />
            <span>Cut New Clip</span>
          </button>
        </div>
      </div>

      {/* Filters */}
      <div className="flex flex-col gap-3 rounded-xl border border-slate-800 bg-[#121722] p-4 lg:flex-row lg:items-center lg:justify-between">
        <div className="flex flex-1 flex-col gap-3 sm:flex-row">
          <div className="relative flex-1">
            <Search
              className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-500"
              aria-hidden="true"
            />
            <input
              type="search"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search by title, @streamer, or game..."
              aria-label="Search clips"
              className="w-full rounded-lg border border-slate-700/80 bg-[#0B0E14] py-2 pl-9 pr-3 text-sm text-white placeholder:text-slate-500 focus:border-rose-500 focus:outline-none"
            />
          </div>

          <select
            value={gameFilter}
            onChange={(e) => setGameFilter(e.target.value)}
            aria-label="Filter by game"
            className="rounded-lg border border-slate-700/80 bg-[#0B0E14] px-3 py-2 text-sm text-white focus:border-rose-500 focus:outline-none"
          >
            <option value="all">All Games</option>
            {games.map((g) => (
              <option key={g.id} value={g.name}>
                {g.name}
              </option>
            ))}
            <option value="Just Chatting & IRL">Just Chatting & IRL</option>
          </select>
        </div>

        <div className="flex items-center gap-1 overflow-x-auto rounded-lg border border-slate-800 bg-[#0B0E14] p-1">
          {(
            [
              { id: 'all', label: 'All' },
              { id: 'permission', label: 'Permission Verified' },
              { id: 'voice', label: 'With Voice' },
              { id: 'music', label: 'With Music' },
            ] as { id: ClipFilterMode; label: string }[]
          ).map((tab) => (
            <button
              key={tab.id}
              type="button"
              onClick={() => setFilterMode(tab.id)}
              className={`rounded-md px-3 py-1.5 text-xs font-medium whitespace-nowrap shrink-0 transition-colors ${
                filterMode === tab.id
                  ? 'bg-slate-800 text-white'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* Clips Grid or Empty State */}
      {filteredClips.length === 0 ? (
        <div className="flex flex-col items-center justify-center gap-4 rounded-xl border border-slate-800 bg-[#121722] px-6 py-16 text-center">
          <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-slate-800/80 text-slate-400">
            <Film className="h-6 w-6" aria-hidden="true" />
          </div>
          <div className="max-w-md space-y-1">
            <h2 className="font-display text-base font-semibold text-white">
              {clips.length === 0 ? 'No saved clips yet' : 'No clips match your filters'}
            </h2>
            <p className="text-sm text-slate-400">
              {clips.length === 0
                ? 'Cut a video file in Cut Video or generate a 10-second sample clip to test real playback and deletion.'
                : 'Try clearing your search query or switching back to All Games.'}
            </p>
          </div>
          <div className="flex flex-wrap items-center justify-center gap-3 pt-1">
            <button
              type="button"
              onClick={() => onNavigate('cut')}
              className="inline-flex items-center gap-2 rounded-lg bg-rose-600 px-4 py-2.5 text-sm font-semibold text-white hover:bg-rose-500"
            >
              <Scissors className="h-4 w-4" aria-hidden="true" />
              <span>Go to Cut Video</span>
            </button>
            {clips.length === 0 && (
              <button
                type="button"
                disabled={isCreatingSample}
                onClick={handleCreateDemoClip}
                className="inline-flex items-center gap-2 rounded-lg border border-slate-700 bg-slate-800 px-4 py-2.5 text-sm font-semibold text-white hover:bg-slate-700 disabled:opacity-60"
              >
                <Sparkles className="h-4 w-4 text-rose-400" aria-hidden="true" />
                <span>
                  {isCreatingSample ? `Creating (${samplePct}%)` : 'Create 10s Sample Clip'}
                </span>
              </button>
            )}
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {filteredClips.map((clip) => (
            <article
              key={clip.id}
              className="flex flex-col justify-between overflow-hidden rounded-xl border border-slate-800 bg-[#121722]"
            >
              <div>
                {/* Thumbnail with duration scrim */}
                <div className="relative aspect-video w-full bg-[#07090D] overflow-hidden">
                  {clip.thumbnailDataUrl ? (
                    <img
                      src={clip.thumbnailDataUrl}
                      alt={clip.title}
                      className="h-full w-full object-cover"
                      referrerPolicy="no-referrer"
                    />
                  ) : (
                    <div className="flex h-full w-full items-center justify-center bg-gradient-to-br from-slate-900 to-slate-800">
                      <Film className="h-9 w-9 text-slate-600" aria-hidden="true" />
                    </div>
                  )}
                  <div className="pointer-events-none absolute inset-x-0 bottom-0 h-14 bg-gradient-to-t from-black/85 via-black/40 to-transparent" />
                  <span className="absolute bottom-2.5 right-3 font-mono text-xs font-semibold text-white tabular-nums">
                    {formatSeconds(clip.durationSec)}
                  </span>
                </div>

                {/* Metadata (Zero-pill discipline: unboxed text with separators) */}
                <div className="space-y-2 p-4">
                  <h3 className="font-display text-base font-semibold text-white truncate">
                    {clip.title}
                  </h3>

                  <div className="flex flex-wrap items-center gap-x-2 gap-y-1 text-xs text-slate-400 tabular-nums">
                    <span>{clip.durationSec} sec</span>
                    <span aria-hidden="true">·</span>
                    <span className="capitalize">{clip.platform}</span>
                    <span aria-hidden="true">·</span>
                    <span className="truncate max-w-[160px]">{clip.gameTag}</span>
                  </div>

                  <div className="text-xs text-slate-300 font-mono truncate">
                    {clip.permission.creditText}
                  </div>

                  <div className="flex flex-wrap items-center gap-x-3 gap-y-1 pt-0.5 text-xs text-slate-400">
                    {clip.permission.hasPermission && (
                      <span className="inline-flex items-center gap-1 text-emerald-400">
                        <ShieldCheck className="h-3.5 w-3.5" aria-hidden="true" />
                        <span>Permission verified</span>
                      </span>
                    )}
                    {clip.voiceBlob && (
                      <span className="inline-flex items-center gap-1 text-sky-400">
                        <Mic className="h-3.5 w-3.5" aria-hidden="true" />
                        <span>Voice</span>
                      </span>
                    )}
                    {clip.musicBlob && (
                      <span className="inline-flex items-center gap-1 text-amber-400">
                        <Music className="h-3.5 w-3.5" aria-hidden="true" />
                        <span>Music</span>
                      </span>
                    )}
                  </div>
                </div>
              </div>

              {/* Card Actions: Play & Delete */}
              <div className="flex items-center gap-2.5 border-t border-slate-800/80 px-4 py-3">
                <button
                  type="button"
                  onClick={() => setPlayingClip(clip)}
                  className="inline-flex flex-1 items-center justify-center gap-2 rounded-lg bg-rose-600 px-4 py-2 text-sm font-semibold text-white transition-colors hover:bg-rose-500 whitespace-nowrap"
                >
                  <Play className="h-4 w-4 fill-current" aria-hidden="true" />
                  <span>Play</span>
                </button>
                <button
                  type="button"
                  onClick={() => setClipPendingDelete(clip)}
                  className="inline-flex items-center justify-center gap-1.5 rounded-lg border border-slate-700 bg-[#0B0E14] px-3.5 py-2 text-sm font-medium text-slate-300 transition-colors hover:border-rose-500/60 hover:bg-rose-950/30 hover:text-rose-200 whitespace-nowrap shrink-0"
                >
                  <Trash2 className="h-4 w-4" aria-hidden="true" />
                  <span>Delete</span>
                </button>
              </div>
            </article>
          ))}
        </div>
      )}

      {/* Actual File Clip Player Modal */}
      {playingClip && activeVideoUrl && (
        <div
          role="dialog"
          aria-modal="true"
          aria-labelledby="clip-player-title"
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4 backdrop-blur-sm"
        >
          <div className="w-full max-w-4xl overflow-hidden rounded-xl border border-slate-800 bg-[#121722] shadow-2xl max-h-[92vh] overflow-y-auto">
            <div className="flex items-center justify-between gap-4 border-b border-slate-800 px-5 py-4">
              <div className="min-w-0">
                <h2 id="clip-player-title" className="font-display text-lg font-bold text-white truncate">
                  {playingClip.title}
                </h2>
                <div className="mt-0.5 flex flex-wrap items-center gap-2 text-xs text-slate-400 tabular-nums">
                  <span>{playingClip.durationSec} sec</span>
                  <span aria-hidden="true">·</span>
                  <span className="font-mono text-slate-200">{playingClip.permission.creditText}</span>
                  <span aria-hidden="true">·</span>
                  <span>{playingClip.gameTag}</span>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setPlayingClip(null)}
                aria-label="Close player"
                className="rounded-lg p-2 text-slate-400 hover:bg-slate-800 hover:text-white shrink-0"
              >
                <X className="h-5 w-5" aria-hidden="true" />
              </button>
            </div>

            <div className="relative bg-black">
              <video
                ref={playerVideoRef}
                src={activeVideoUrl}
                controls
                playsInline
                onLoadedMetadata={handlePlayerLoadedMetadata}
                onPlay={handlePlayerPlay}
                onPause={handlePlayerPause}
                onTimeUpdate={handlePlayerTimeUpdate}
                className="aspect-video w-full"
              />
              {playingClip.autoCaption && (
                <div className="pointer-events-none absolute inset-x-0 bottom-12 flex justify-center px-4">
                  <span className="rounded bg-black px-3 py-1 text-xs font-bold text-white shadow">
                    {playingClip.autoCaption}
                  </span>
                </div>
              )}
              {activeVoiceUrl && (
                <audio ref={playerVoiceRef} src={activeVoiceUrl} className="hidden" />
              )}
              {activeMusicUrl && (
                <audio ref={playerMusicRef} src={activeMusicUrl} loop className="hidden" />
              )}
            </div>

            <div className="grid grid-cols-1 gap-4 p-5 sm:grid-cols-2">
              <div className="space-y-2 text-xs text-slate-300">
                <div className="font-semibold text-white">Attribution & Audio Mix</div>
                <p className="font-mono text-slate-200">{playingClip.permission.creditText}</p>
                {playingClip.permission.originalVideoLink && (
                  <a
                    href={playingClip.permission.originalVideoLink}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1.5 text-rose-400 hover:text-rose-300"
                  >
                    <span>Original Video Link</span>
                    <ExternalLink className="h-3.5 w-3.5" aria-hidden="true" />
                  </a>
                )}
                <div className="flex flex-wrap items-center gap-3 pt-1 text-slate-400 tabular-nums">
                  <span>Original Audio: {Math.round((playingClip.originalVolume ?? 1) * 100)}%</span>
                  {playingClip.voiceName && (
                    <span>
                      Voice ({playingClip.voiceName}): {Math.round(playingClip.voiceVolume * 100)}%
                    </span>
                  )}
                  {playingClip.musicName && (
                    <span>
                      Music ({playingClip.musicName}): {Math.round(playingClip.musicVolume * 100)}%
                    </span>
                  )}
                </div>
              </div>

              <div className="flex flex-col items-start justify-between gap-3 sm:items-end">
                {activeProofUrl ? (
                  <div className="flex items-center gap-2.5 rounded-lg border border-slate-800 bg-[#0B0E14] p-2">
                    <img
                      src={activeProofUrl}
                      alt="Streamer permission proof"
                      className="h-10 w-10 rounded object-cover"
                      referrerPolicy="no-referrer"
                    />
                    <div className="text-xs">
                      <div className="font-medium text-emerald-300">Permission Proof</div>
                      <div className="text-slate-400 truncate max-w-[160px]">
                        {playingClip.permission.proofFileName}
                      </div>
                    </div>
                  </div>
                ) : playingClip.permission.proofFileName ? (
                  <div className="text-xs text-emerald-300">
                    Proof attached: {playingClip.permission.proofFileName}
                  </div>
                ) : null}

                <div className="flex items-center gap-2.5">
                  <a
                    href={activeVideoUrl}
                    download={`${playingClip.title.replace(/[^a-z0-9_-]/gi, '_')}.${
                      playingClip.videoMimeType.includes('mp4') ? 'mp4' : 'webm'
                    }`}
                    className="inline-flex items-center gap-2 rounded-lg border border-slate-700 bg-[#0B0E14] px-3.5 py-2 text-xs font-semibold text-white hover:bg-slate-800"
                  >
                    <Download className="h-3.5 w-3.5" aria-hidden="true" />
                    <span>Download File</span>
                  </a>
                  <button
                    type="button"
                    onClick={() => setClipPendingDelete(playingClip)}
                    className="inline-flex items-center gap-1.5 rounded-lg border border-rose-500/40 bg-rose-950/30 px-3.5 py-2 text-xs font-semibold text-rose-200 hover:bg-rose-900/40"
                  >
                    <Trash2 className="h-3.5 w-3.5" aria-hidden="true" />
                    <span>Delete Clip</span>
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {clipPendingDelete && (
        <div
          role="alertdialog"
          aria-modal="true"
          aria-labelledby="delete-confirm-title"
          aria-describedby="delete-confirm-desc"
          className="fixed inset-0 z-[60] flex items-center justify-center bg-black/80 p-4 backdrop-blur-sm"
        >
          <div className="w-full max-w-md rounded-xl border border-slate-800 bg-[#121722] p-6 shadow-2xl space-y-4">
            <div className="space-y-1.5">
              <h2 id="delete-confirm-title" className="font-display text-lg font-bold text-white">
                Delete this clip?
              </h2>
              <p id="delete-confirm-desc" className="text-sm text-slate-400">
                Are you sure you want to permanently delete{' '}
                <span className="font-semibold text-slate-200">{clipPendingDelete.title}</span>? This
                removes the video file and any attached voice or music tracks from My Clips.
              </p>
            </div>
            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                type="button"
                disabled={isDeleting}
                onClick={() => setClipPendingDelete(null)}
                className="rounded-lg border border-slate-700 bg-[#0B0E14] px-4 py-2 text-sm font-semibold text-slate-200 hover:bg-slate-800"
              >
                Cancel
              </button>
              <button
                type="button"
                disabled={isDeleting}
                onClick={handleConfirmDelete}
                className="rounded-lg bg-rose-600 px-4 py-2 text-sm font-semibold text-white hover:bg-rose-500 disabled:opacity-60"
              >
                {isDeleting ? 'Deleting…' : 'Confirm Delete'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

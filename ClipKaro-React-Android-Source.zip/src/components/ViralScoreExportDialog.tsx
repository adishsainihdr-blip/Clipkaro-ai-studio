import { Flame, ShieldCheck, X } from 'lucide-react';

interface ViralScoreExportDialogProps {
  isOpen: boolean;
  actionLabel: string;
  viralScore: number;
  isProcessing?: boolean;
  onChoose: (showScoreOnVideo: boolean) => void | Promise<void>;
  onCancel: () => void;
}

export function ViralScoreExportDialog({
  isOpen,
  actionLabel,
  viralScore,
  isProcessing = false,
  onChoose,
  onCancel,
}: ViralScoreExportDialogProps) {
  if (!isOpen) return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="viral-export-prompt-title"
      className="fixed inset-0 z-[80] flex items-center justify-center bg-black/80 p-4 backdrop-blur-sm"
    >
      <div className="w-full max-w-md rounded-2xl border border-slate-700 bg-[#121722] p-5 shadow-2xl space-y-4">
        <div className="flex items-start justify-between gap-3">
          <div className="flex items-center gap-2.5">
            <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-amber-500/15 text-amber-400">
              <Flame className="h-5 w-5" aria-hidden="true" />
            </span>
            <div>
              <h2 id="viral-export-prompt-title" className="font-display text-base font-bold text-white">
                Show Viral Score on video?
              </h2>
              <p className="text-xs text-slate-400">
                Before {actionLabel} · Score: <span className="font-bold text-amber-300">{viralScore}/100</span>
              </p>
            </div>
          </div>
          <button
            type="button"
            disabled={isProcessing}
            onClick={onCancel}
            aria-label="Cancel"
            className="rounded-lg p-1.5 text-slate-400 hover:bg-slate-800 hover:text-white"
          >
            <X className="h-4 w-4" aria-hidden="true" />
          </button>
        </div>

        <p className="rounded-xl border border-slate-800 bg-[#0B0E14] p-3 text-xs text-slate-300">
          By default, exported videos stay clean without any Viral Score overlay. Choose <strong>NO</strong> for a clean video, or <strong>YES</strong> to include the score badge on the video.
        </p>

        <div className="flex flex-col gap-2 sm:flex-row sm:justify-end">
          <button
            type="button"
            disabled={isProcessing}
            onClick={() => void onChoose(false)}
            className="inline-flex items-center justify-center gap-1.5 rounded-lg bg-emerald-600 px-4 py-2.5 text-xs font-bold text-white hover:bg-emerald-500 disabled:opacity-60"
          >
            <ShieldCheck className="h-4 w-4" aria-hidden="true" />
            <span>{isProcessing ? 'Preparing…' : 'NO (Clean Video)'}</span>
          </button>
          <button
            type="button"
            disabled={isProcessing}
            onClick={() => void onChoose(true)}
            className="inline-flex items-center justify-center gap-1.5 rounded-lg border border-amber-500/60 bg-amber-500/20 px-4 py-2.5 text-xs font-bold text-amber-200 hover:bg-amber-500/30 disabled:opacity-60"
          >
            <Flame className="h-4 w-4" aria-hidden="true" />
            <span>{isProcessing ? 'Rendering…' : 'YES (Show Score)'}</span>
          </button>
        </div>
      </div>
    </div>
  );
}

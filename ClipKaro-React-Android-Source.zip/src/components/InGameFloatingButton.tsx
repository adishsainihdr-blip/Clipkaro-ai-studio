import { PointerEvent as ReactPointerEvent, useEffect, useRef, useState } from 'react';
import {
  Bell,
  Camera,
  CheckCircle2,
  Mic,
  Move,
  Pause,
  Play,
  Repeat,
  Scissors,
  Square,
  Video,
  X,
  Zap,
} from 'lucide-react';
import { AudioSourceMode, ClipItem, VoiceChangerPreset } from '../types/clipkaro';
import { saveVideoToNativeClipKaroFolder } from '../utils/androidPermissions';
import { formatSeconds } from '../utils/mediaGenerators';

interface InGameFloatingButtonProps {
  visible: boolean;
  activeGameName: string;
  isWebPreviewDemo: boolean;
  facecamEnabled?: boolean;
  voiceChanger?: VoiceChangerPreset;
  reactionMode?: boolean;
  onUpdateReactionOptions?: (partial: {
    reactionMode?: boolean;
    facecamEnabled?: boolean;
    voiceChanger?: VoiceChangerPreset;
  }) => void;
  onSaveClip: (clip: ClipItem) => Promise<void>;
  onNavigateToClips: () => void;
  onClose?: () => void;
}

const CLIP_DURATIONS = [10, 20, 30, 40, 50, 60] as const;

const AUDIO_LABELS: Record<AudioSourceMode, string> = {
  game: 'Game/Video Only',
  mic: 'Mic Only',
  both: 'Game+Mic Both',
};

const VOICE_ORDER: VoiceChangerPreset[] = ['normal', 'funny', 'robot', 'deep'];

export function InGameFloatingButton({
  visible,
  activeGameName,
  isWebPreviewDemo,
  facecamEnabled = false,
  voiceChanger = 'normal',
  reactionMode = false,
  onUpdateReactionOptions,
  onSaveClip,
  onNavigateToClips,
  onClose,
}: InGameFloatingButtonProps) {
  const [position, setPosition] = useState<{ x: number; y: number }>(() => {
    if (typeof window === 'undefined') return { x: 24, y: 120 };
    return {
      x: Math.max(16, window.innerWidth - 76),
      y: Math.max(88, window.innerHeight - 132),
    };
  });

  const [menuOpen, setMenuOpen] = useState<boolean>(false);
  const [longPressMenuOpen, setLongPressMenuOpen] = useState<boolean>(false);
  const [isRecording, setIsRecording] = useState<boolean>(false);
  const [recordingModeLabel, setRecordingModeLabel] = useState<string>('');
  const [targetSeconds, setTargetSeconds] = useState<number | null>(null);
  const [elapsedSeconds, setElapsedSeconds] = useState<number>(0);
  const [audioMode, setAudioMode] = useState<AudioSourceMode>('both');
  const [autoContinuous, setAutoContinuous] = useState<boolean>(true);
  const [clipSequence, setClipSequence] = useState<number>(1);
  const [notifBarEnabled, setNotifBarEnabled] = useState<boolean>(false);
  const [autoHighlight, setAutoHighlight] = useState<boolean>(() => {
    try {
      const saved = localStorage.getItem('clipkaro_auto_highlight_enabled');
      return saved === null ? true : saved === 'true';
    } catch {
      return true;
    }
  });
  const [savedToast, setSavedToast] = useState<string | null>(null);
  const [isPaused, setIsPaused] = useState<boolean>(false);
  const [topBanner, setTopBanner] = useState<{
    title: string;
    subtitle: string;
    isRedDot: boolean;
  } | null>(null);

  // Draggable & resizable 120dp circular Facecam window state
  const [facecamSizePx, setFacecamSizePx] = useState<number>(120);
  const [facecamPos, setFacecamPos] = useState<{ x: number; y: number }>(() => {
    if (typeof window === 'undefined') return { x: 20, y: 84 };
    return { x: Math.max(16, window.innerWidth - 144), y: 84 };
  });
  const [facecamLive, setFacecamLive] = useState<boolean>(false);
  const facecamVideoRef = useRef<HTMLVideoElement | null>(null);
  const facecamDragRef = useRef<{
    pointerId: number;
    startX: number;
    startY: number;
    originX: number;
    originY: number;
  } | null>(null);

  const buttonRef = useRef<HTMLButtonElement | null>(null);
  const rootRef = useRef<HTMLDivElement | null>(null);
  const longPressTimerRef = useRef<number | null>(null);
  const dragStateRef = useRef<{
    dragging: boolean;
    pointerId: number;
    startX: number;
    startY: number;
    originX: number;
    originY: number;
    moved: boolean;
    longPressed: boolean;
  } | null>(null);

  // Recording Refs
  const recorderRef = useRef<MediaRecorder | null>(null);
  const chunksRef = useRef<BlobPart[]>([]);
  const activeStreamsRef = useRef<MediaStream[]>([]);
  const audioCtxRef = useRef<AudioContext | null>(null);
  const timerRef = useRef<number | null>(null);
  const topBannerTimerRef = useRef<number | null>(null);
  const canvasRafRef = useRef<number>(0);
  const startedAtRef = useRef<number>(0);
  const pauseStartedAtRef = useRef<number>(0);
  const pausedTotalMsRef = useRef<number>(0);
  const isPausedRef = useRef<boolean>(false);
  const activeTargetSecRef = useRef<number | null>(null);
  const activeLabelRef = useRef<string>('');
  const activeGameRef = useRef<string>(activeGameName);
  const audioModeRef = useRef<AudioSourceMode>('both');
  const autoContinuousRef = useRef<boolean>(true);
  const manualStopRequestedRef = useRef<boolean>(false);
  const clipSeqRef = useRef<number>(1);
  const thumbnailRef = useRef<string | undefined>(undefined);
  const autoHighlightRef = useRef<boolean>(autoHighlight);
  const autoHighlightSavedForSessionRef = useRef<boolean>(false);
  const [facecamManualOff, setFacecamManualOff] = useState<boolean>(() => {
    try {
      return localStorage.getItem('clipkaro_facecam_manual_off') === 'true';
    } catch {
      return false;
    }
  });
  const isFacecamToggleOn = !facecamManualOff && (facecamEnabled || reactionMode);
  const isRecordingRef = useRef<boolean>(false);
  const facecamActiveRef = useRef<boolean>(isFacecamToggleOn);
  const voiceChangerRef = useRef<VoiceChangerPreset>(voiceChanger);
  const reactionModeRef = useRef<boolean>(reactionMode);
  const facecamSizeRef = useRef<number>(facecamSizePx);

  useEffect(() => {
    activeGameRef.current = activeGameName;
  }, [activeGameName]);

  useEffect(() => {
    audioModeRef.current = audioMode;
  }, [audioMode]);

  useEffect(() => {
    autoContinuousRef.current = autoContinuous;
  }, [autoContinuous]);

  useEffect(() => {
    isRecordingRef.current = isRecording;
  }, [isRecording]);

  useEffect(() => {
    if (facecamEnabled) {
      setFacecamManualOff(false);
      try {
        localStorage.setItem('clipkaro_facecam_manual_off', 'false');
      } catch {
        // ignore
      }
    }
  }, [facecamEnabled]);

  useEffect(() => {
    facecamActiveRef.current = isRecording && isFacecamToggleOn;
  }, [isRecording, isFacecamToggleOn]);

  useEffect(() => {
    voiceChangerRef.current = voiceChanger;
  }, [voiceChanger]);

  useEffect(() => {
    reactionModeRef.current = reactionMode;
  }, [reactionMode]);

  useEffect(() => {
    facecamSizeRef.current = facecamSizePx;
  }, [facecamSizePx]);

  // Open Facecam ONLY when Recording is active AND (Facecam toggle is ON OR Reaction Mode is ON)
  useEffect(() => {
    const showCam = visible && isRecording && isFacecamToggleOn;
    if (!showCam) {
      setFacecamLive(false);
      if (facecamVideoRef.current) {
        facecamVideoRef.current.srcObject = null;
      }
      return;
    }
    let camStream: MediaStream | null = null;
    let cancelled = false;
    if (navigator.mediaDevices?.getUserMedia) {
      navigator.mediaDevices
        .getUserMedia({ video: { facingMode: 'user', width: 320, height: 320 }, audio: false })
        .then((stream) => {
          if (cancelled) {
            stream.getTracks().forEach((t) => t.stop());
            return;
          }
          camStream = stream;
          if (facecamVideoRef.current) {
            facecamVideoRef.current.srcObject = stream;
            facecamVideoRef.current.play().catch(() => undefined);
            setFacecamLive(true);
          }
        })
        .catch(() => setFacecamLive(false));
    }
    return () => {
      cancelled = true;
      camStream?.getTracks().forEach((t) => t.stop());
    };
  }, [visible, isRecording, isFacecamToggleOn]);

  useEffect(() => {
    autoHighlightRef.current = autoHighlight;
    try {
      localStorage.setItem('clipkaro_auto_highlight_enabled', String(autoHighlight));
    } catch {
      // ignore storage errors
    }
  }, [autoHighlight]);

  // Keep 32dp button inside viewport on resize
  useEffect(() => {
    const handleResize = () => {
      setPosition((prev) => ({
        x: Math.min(Math.max(12, prev.x), Math.max(12, window.innerWidth - 48)),
        y: Math.min(Math.max(12, prev.y), Math.max(12, window.innerHeight - 48)),
      }));
    };
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  // Auto-collapse when tapping outside the expanded menu or long-press popup
  useEffect(() => {
    if (!menuOpen && !longPressMenuOpen) return;
    const handleOutsideTap = (e: PointerEvent) => {
      if (rootRef.current && !rootRef.current.contains(e.target as Node)) {
        setMenuOpen(false);
        setLongPressMenuOpen(false);
      }
    };
    document.addEventListener('pointerdown', handleOutsideTap);
    return () => document.removeEventListener('pointerdown', handleOutsideTap);
  }, [menuOpen, longPressMenuOpen]);

  // Cleanup active recording resources on unmount
  useEffect(() => {
    return () => {
      manualStopRequestedRef.current = true;
      if (longPressTimerRef.current) window.clearTimeout(longPressTimerRef.current);
      if (timerRef.current) window.clearInterval(timerRef.current);
      if (topBannerTimerRef.current) window.clearTimeout(topBannerTimerRef.current);
      cancelAnimationFrame(canvasRafRef.current);
      activeStreamsRef.current.forEach((s) => s.getTracks().forEach((t) => t.stop()));
      audioCtxRef.current?.close().catch(() => undefined);
    };
  }, []);

  const showTopPopupNotification = (title: string, subtitle: string, isRedDot = true) => {
    if (topBannerTimerRef.current) {
      window.clearTimeout(topBannerTimerRef.current);
      topBannerTimerRef.current = null;
    }
    setTopBanner({ title, subtitle, isRedDot });
    topBannerTimerRef.current = window.setTimeout(() => {
      setTopBanner(null);
      topBannerTimerRef.current = null;
    }, 2000);
  };

  const clearLongPressTimer = () => {
    if (longPressTimerRef.current) {
      window.clearTimeout(longPressTimerRef.current);
      longPressTimerRef.current = null;
    }
  };

  const handlePointerDown = (e: ReactPointerEvent<HTMLButtonElement>) => {
    e.currentTarget.setPointerCapture(e.pointerId);
    clearLongPressTimer();
    const state = {
      dragging: true,
      pointerId: e.pointerId,
      startX: e.clientX,
      startY: e.clientY,
      originX: position.x,
      originY: position.y,
      moved: false,
      longPressed: false,
    };
    dragStateRef.current = state;
    longPressTimerRef.current = window.setTimeout(() => {
      if (dragStateRef.current && !dragStateRef.current.moved) {
        dragStateRef.current.longPressed = true;
        setMenuOpen(false);
        setLongPressMenuOpen(true);
      }
    }, 500);
  };

  const handlePointerMove = (e: ReactPointerEvent<HTMLButtonElement>) => {
    const state = dragStateRef.current;
    if (!state || !state.dragging || state.pointerId !== e.pointerId) return;
    const dx = e.clientX - state.startX;
    const dy = e.clientY - state.startY;
    if (Math.hypot(dx, dy) > 5) {
      state.moved = true;
      clearLongPressTimer();
    }
    const maxX = Math.max(12, window.innerWidth - 64);
    const maxY = Math.max(12, window.innerHeight - 64);
    setPosition({
      x: Math.min(Math.max(12, state.originX + dx), maxX),
      y: Math.min(Math.max(12, state.originY + dy), maxY),
    });
  };

  const handlePointerUp = (e: ReactPointerEvent<HTMLButtonElement>) => {
    clearLongPressTimer();
    const state = dragStateRef.current;
    if (!state || state.pointerId !== e.pointerId) return;
    dragStateRef.current = null;
    if (!state.moved && !state.longPressed) {
      setLongPressMenuOpen(false);
      setMenuOpen((prev) => !prev);
      setSavedToast(null);
    }
  };

  const cleanupRecordingStreams = () => {
    if (timerRef.current) {
      window.clearInterval(timerRef.current);
      timerRef.current = null;
    }
    cancelAnimationFrame(canvasRafRef.current);
    activeStreamsRef.current.forEach((s) => s.getTracks().forEach((t) => t.stop()));
    activeStreamsRef.current = [];
    audioCtxRef.current?.close().catch(() => undefined);
    audioCtxRef.current = null;
  };

  const finalizeAndSaveRecording = async (
    blob: Blob,
    durationSec: number,
    sequenceNum: number,
    highlightEvent?: string,
    reactionPart = false
  ) => {
    const gameName = activeGameRef.current || 'BGMI';
    const cleanDuration = Math.max(1, Math.round(durationSec));
    const safeGameSlug = gameName.replace(/[^A-Za-z0-9_]+/g, '_');
    const fileName = highlightEvent
      ? `ClipKaro_AutoHighlight_${safeGameSlug}_${highlightEvent}_15s_Clip${sequenceNum}.webm`
      : reactionPart
        ? `ClipKaro_Reaction_${safeGameSlug}_Part_${cleanDuration}s_Clip${sequenceNum}.webm`
        : `ClipKaro_${safeGameSlug}_${cleanDuration}s_Clip${sequenceNum}.webm`;

    const newClip: ClipItem = {
      id: `clip-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
      title: highlightEvent
        ? `${gameName} Auto Highlight (${highlightEvent} · 15s)`
        : reactionPart
          ? `${gameName} Reaction Clip (${cleanDuration}s)`
          : `${gameName} Clip #${sequenceNum} (${cleanDuration}s)`,
      platform: 'studio',
      gameTag: gameName,
      durationSec: highlightEvent ? 15 : cleanDuration,
      trimStart: 0,
      trimEnd: highlightEvent ? 15 : cleanDuration,
      createdAt: Date.now(),
      copyrightSafe: true,
      isReaction: reactionPart || reactionModeRef.current,
      hasFacecam: facecamActiveRef.current,
      voiceChanger: voiceChangerRef.current,
      autoCaption: highlightEvent ? 'What a Headshot!' : undefined,
      permission: {
        hasPermission: true,
        streamerName: 'MyGameplay',
        originalVideoLink: '',
        creditText: 'Credit: @MyGameplay',
      },
      videoBlob: blob,
      videoMimeType: blob.type || 'video/webm',
      nativeFileName: fileName,
      audioSourceMode: audioModeRef.current,
      thumbnailDataUrl: thumbnailRef.current,
      voiceVolume: 1,
      musicVolume: 0.45,
      originalVolume: 1,
    };

    await onSaveClip(newClip);
    await saveVideoToNativeClipKaroFolder(fileName, blob);
    setSavedToast(
      highlightEvent
        ? `Auto Highlight (${highlightEvent} · 15s) saved to ClipKaro & My Clips`
        : reactionPart
          ? `Saved Reaction Clip (${cleanDuration}s) with Facecam`
          : `Saved Clip #${sequenceNum} (${cleanDuration}s) to ClipKaro & My Clips`
    );
  };

  const handleSaveReactionPartNow = async () => {
    if (!isRecording || chunksRef.current.length === 0) {
      showTopPopupNotification(
        'Start recording first',
        'Tap 10s–60s or Full Video, then tap Save Clip',
        false
      );
      return;
    }
    const snapshot = new Blob([...chunksRef.current], {
      type: recorderRef.current?.mimeType || 'video/webm',
    });
    const partSec = Math.max(5, Math.min(20, elapsedSeconds || 10));
    await finalizeAndSaveRecording(snapshot, partSec, clipSeqRef.current, undefined, true);
    showTopPopupNotification(
      'Reaction Clip Saved!',
      `Saved ${partSec}s selected part with Facecam → My Clips`,
      false
    );
  };

  const stopRecording = (manualStop = true) => {
    if (manualStop) {
      manualStopRequestedRef.current = true;
      isPausedRef.current = false;
      setIsPaused(false);
      // Auto collapse menu back to 32dp small button when STOP is tapped
      setMenuOpen(false);
    }
    const recorder = recorderRef.current;
    if (recorder && recorder.state !== 'inactive') {
      recorder.stop();
    } else {
      cleanupRecordingStreams();
      setIsRecording(false);
      if (manualStop) {
        showTopPopupNotification(
          'Clipping Saved - My Clips me save ho gayi',
          'Saved to My Clips & ClipKaro',
          false
        );
      }
    }
  };

  // On game / app close (visible -> false), auto-save clip & close Facecam immediately
  useEffect(() => {
    if (!visible && isRecordingRef.current) {
      stopRecording(true);
    }
  }, [visible]);

  const handleToggleFacecamChoice = () => {
    const next = !isFacecamToggleOn;
    setFacecamManualOff(!next);
    try {
      localStorage.setItem('clipkaro_facecam_manual_off', String(!next));
    } catch {
      // ignore
    }
    onUpdateReactionOptions?.({ facecamEnabled: next });
    showTopPopupNotification(
      next ? 'Facecam ON' : 'Facecam OFF',
      next
        ? isRecording
          ? 'Facecam opened with RED dot'
          : 'Facecam will open when Recording starts'
        : 'Facecam closed & preference saved',
      next && isRecording
    );
  };

  const pauseRecording = () => {
    if (!isRecording || isPausedRef.current) return;
    isPausedRef.current = true;
    setIsPaused(true);
    pauseStartedAtRef.current = Date.now();
    facecamVideoRef.current?.pause();
    if (recorderRef.current?.state === 'recording' && typeof recorderRef.current.pause === 'function') {
      try {
        recorderRef.current.pause();
      } catch {
        // ignore if unsupported
      }
    }
    showTopPopupNotification(
      'Recording Paused',
      `Paused at ${formatSeconds(elapsedSeconds)} · Tap Resume to continue`,
      false
    );
  };

  const resumeRecording = () => {
    if (!isRecording || !isPausedRef.current) return;
    if (pauseStartedAtRef.current > 0) {
      pausedTotalMsRef.current += Math.max(0, Date.now() - pauseStartedAtRef.current);
      pauseStartedAtRef.current = 0;
    }
    isPausedRef.current = false;
    setIsPaused(false);
    facecamVideoRef.current?.play().catch(() => undefined);
    if (recorderRef.current?.state === 'paused' && typeof recorderRef.current.resume === 'function') {
      try {
        recorderRef.current.resume();
      } catch {
        // ignore if unsupported
      }
    }
    showTopPopupNotification(
      'Recording Resumed',
      `Continuing from ${formatSeconds(elapsedSeconds)} · Tap CLIP to Stop`,
      true
    );
  };

  const startHdDemoStream = (): MediaStream => {
    const canvas = document.createElement('canvas');
    canvas.width = 1280;
    canvas.height = 720;
    const ctx = canvas.getContext('2d')!;

    const startMs = performance.now();
    let capturedThumb = false;

    const renderFrame = () => {
      const elapsed = performance.now() - startMs;
      const t = elapsed / 1000;

      const grad = ctx.createLinearGradient(0, 0, canvas.width, canvas.height);
      grad.addColorStop(0, '#090d16');
      grad.addColorStop(0.6, '#131b2e');
      grad.addColorStop(1, '#0b1120');
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      ctx.strokeStyle = 'rgba(56, 189, 248, 0.14)';
      ctx.lineWidth = 1.5;
      const scroll = (elapsed * 0.06) % 64;
      for (let x = -64 + scroll; x < canvas.width; x += 64) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, canvas.height);
        ctx.stroke();
      }
      for (let y = 0; y < canvas.height; y += 64) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(canvas.width, y);
        ctx.stroke();
      }

      const cx = canvas.width / 2 + Math.cos(t * 1.4) * 220;
      const cy = canvas.height / 2 + Math.sin(t * 2.1) * 110;
      ctx.strokeStyle = '#f43f5e';
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.arc(cx, cy, 34, 0, Math.PI * 2);
      ctx.stroke();
      ctx.beginPath();
      ctx.moveTo(cx - 48, cy);
      ctx.lineTo(cx + 48, cy);
      ctx.moveTo(cx, cy - 48);
      ctx.lineTo(cx, cy + 48);
      ctx.stroke();

      ctx.fillStyle = 'rgba(11, 14, 20, 0.85)';
      ctx.fillRect(36, 32, 520, 74);
      ctx.fillStyle = '#ffffff';
      ctx.font = '700 26px system-ui, sans-serif';
      ctx.fillText(`${activeGameRef.current || 'Game'} · Clip #${clipSeqRef.current}`, 56, 68);
      ctx.fillStyle = '#34d399';
      ctx.font = '500 16px system-ui, sans-serif';
      ctx.fillText(`1280×720 HD · ${AUDIO_LABELS[audioModeRef.current]}`, 56, 94);

      for (let i = 0; i < 20; i += 1) {
        const h = 14 + Math.abs(Math.sin(t * 6 + i * 0.6)) * 44;
        ctx.fillStyle = i % 2 === 0 ? '#f43f5e' : '#38bdf8';
        ctx.fillRect(36 + i * 18, canvas.height - 56 - h, 10, h);
      }

      ctx.fillStyle = '#f8fafc';
      ctx.font = '600 22px monospace';
      ctx.fillText(`REC ${t.toFixed(1)}s`, canvas.width - 190, canvas.height - 46);

      // Composite circular Facecam into recorded frame when Facecam / Reaction Mode is ON
      if (facecamActiveRef.current) {
        const radius = Math.round(facecamSizeRef.current * 0.58);
        const fcx = canvas.width - radius - 34;
        const fcy = radius + 34;
        ctx.save();
        ctx.beginPath();
        ctx.arc(fcx, fcy, radius, 0, Math.PI * 2);
        ctx.closePath();
        ctx.clip();
        if (facecamVideoRef.current && facecamVideoRef.current.readyState >= 2) {
          ctx.drawImage(
            facecamVideoRef.current,
            fcx - radius,
            fcy - radius,
            radius * 2,
            radius * 2
          );
        } else {
          ctx.fillStyle = '#0f766e';
          ctx.fillRect(fcx - radius, fcy - radius, radius * 2, radius * 2);
          ctx.fillStyle = '#ffffff';
          ctx.font = '700 16px system-ui, sans-serif';
          ctx.textAlign = 'center';
          ctx.fillText('FACECAM', fcx, fcy + 5);
          ctx.textAlign = 'left';
        }
        ctx.restore();
        ctx.strokeStyle = reactionModeRef.current ? '#f43f5e' : '#34d399';
        ctx.lineWidth = 4;
        ctx.beginPath();
        ctx.arc(fcx, fcy, radius, 0, Math.PI * 2);
        ctx.stroke();
      }

      if (!capturedThumb && elapsed > 250) {
        capturedThumb = true;
        try {
          thumbnailRef.current = canvas.toDataURL('image/jpeg', 0.8);
        } catch {
          // ignore
        }
      }

      canvasRafRef.current = requestAnimationFrame(renderFrame);
    };

    canvasRafRef.current = requestAnimationFrame(renderFrame);
    const canvasStream = canvas.captureStream(30);
    activeStreamsRef.current.push(canvasStream);
    return canvasStream;
  };

  const startRecording = async (
    durationSec: number | null,
    label: string,
    sequenceNum = 1
  ) => {
    // Close menu automatically right on tap
    setMenuOpen(false);
    manualStopRequestedRef.current = false;
    isPausedRef.current = false;
    setIsPaused(false);
    pausedTotalMsRef.current = 0;
    pauseStartedAtRef.current = 0;
    setSavedToast(null);
    thumbnailRef.current = undefined;
    chunksRef.current = [];
    clipSeqRef.current = sequenceNum;
    setClipSequence(sequenceNum);
    activeTargetSecRef.current = durationSec;
    activeLabelRef.current = label;
    setTargetSeconds(durationSec);
    setElapsedSeconds(0);
    setRecordingModeLabel(label);

    const startBadgeLabel = durationSec ? `${durationSec} sec Clip` : 'Full Video';
    if (sequenceNum === 1) {
      showTopPopupNotification(
        `Clipping Started - ${startBadgeLabel}`,
        `${startBadgeLabel} · Tap CLIP button to Stop`,
        true
      );
    }

    const mode = audioModeRef.current;
    const wantGameAudio = mode === 'game' || mode === 'both';
    const wantMicAudio = mode === 'mic' || mode === 'both';

    let videoStream: MediaStream | null = null;
    let gameAudioStream: MediaStream | null = null;
    let chatAudioStream: MediaStream | null = null;

    if (navigator.mediaDevices?.getDisplayMedia) {
      try {
        const displayStream = await navigator.mediaDevices.getDisplayMedia({
          video: {
            width: { ideal: 1920 },
            height: { ideal: 1080 },
            frameRate: { ideal: 30 },
          },
          audio: wantGameAudio,
        });
        videoStream = displayStream;
        if (wantGameAudio) gameAudioStream = displayStream;
        activeStreamsRef.current.push(displayStream);

        try {
          const track = displayStream.getVideoTracks()[0];
          const tempVideo = document.createElement('video');
          tempVideo.srcObject = new MediaStream([track]);
          tempVideo.muted = true;
          await tempVideo.play();
          const c = document.createElement('canvas');
          c.width = 480;
          c.height = 270;
          const cx = c.getContext('2d');
          cx?.drawImage(tempVideo, 0, 0, c.width, c.height);
          thumbnailRef.current = c.toDataURL('image/jpeg', 0.8);
          tempVideo.pause();
          tempVideo.srcObject = null;
        } catch {
          // ignore
        }
      } catch {
        videoStream = null;
      }
    }

    if (wantMicAudio && navigator.mediaDevices?.getUserMedia) {
      try {
        const micStream = await navigator.mediaDevices.getUserMedia({
          audio: { echoCancellation: true, noiseSuppression: true },
        });
        chatAudioStream = micStream;
        activeStreamsRef.current.push(micStream);
      } catch {
        chatAudioStream = null;
      }
    }

    if (!videoStream) {
      videoStream = startHdDemoStream();
    }

    const audioCtx = new AudioContext();
    audioCtxRef.current = audioCtx;
    const mixedDest = audioCtx.createMediaStreamDestination();
    let hasAudioTrack = false;

    if (wantGameAudio) {
      if (gameAudioStream && gameAudioStream.getAudioTracks().length > 0) {
        const gameSrc = audioCtx.createMediaStreamSource(
          new MediaStream(gameAudioStream.getAudioTracks())
        );
        gameSrc.connect(mixedDest);
        hasAudioTrack = true;
      } else {
        const osc = audioCtx.createOscillator();
        const gain = audioCtx.createGain();
        osc.type = 'triangle';
        osc.frequency.value = 180;
        gain.gain.value = 0.035;
        osc.connect(gain);
        gain.connect(mixedDest);
        osc.start();
        hasAudioTrack = true;
      }
    }

    if (wantMicAudio && chatAudioStream && chatAudioStream.getAudioTracks().length > 0) {
      const chatSrc = audioCtx.createMediaStreamSource(chatAudioStream);
      const activePreset = voiceChangerRef.current;
      if (activePreset === 'funny') {
        const biquad = audioCtx.createBiquadFilter();
        biquad.type = 'highshelf';
        biquad.frequency.value = 1800;
        biquad.gain.value = 10;
        chatSrc.connect(biquad);
        biquad.connect(mixedDest);
      } else if (activePreset === 'deep') {
        const biquad = audioCtx.createBiquadFilter();
        biquad.type = 'lowpass';
        biquad.frequency.value = 580;
        chatSrc.connect(biquad);
        biquad.connect(mixedDest);
      } else if (activePreset === 'robot') {
        const bp = audioCtx.createBiquadFilter();
        bp.type = 'bandpass';
        bp.frequency.value = 1100;
        bp.Q.value = 3.5;
        const ringGain = audioCtx.createGain();
        ringGain.gain.value = 0.6;
        const lfo = audioCtx.createOscillator();
        const lfoDepth = audioCtx.createGain();
        lfo.frequency.value = 58;
        lfoDepth.gain.value = 0.4;
        lfo.connect(lfoDepth);
        lfoDepth.connect(ringGain.gain);
        lfo.start();
        chatSrc.connect(bp);
        bp.connect(ringGain);
        ringGain.connect(mixedDest);
      } else {
        chatSrc.connect(mixedDest);
      }
      hasAudioTrack = true;
    }

    const combinedStream = new MediaStream([
      ...videoStream.getVideoTracks(),
      ...(hasAudioTrack ? mixedDest.stream.getAudioTracks() : []),
    ]);

    videoStream.getVideoTracks().forEach((track) => {
      track.onended = () => stopRecording(true);
    });

    const mimeType = MediaRecorder.isTypeSupported('video/webm;codecs=vp9,opus')
      ? 'video/webm;codecs=vp9,opus'
      : MediaRecorder.isTypeSupported('video/webm')
        ? 'video/webm'
        : '';

    const recorder = new MediaRecorder(combinedStream, {
      ...(mimeType ? { mimeType } : {}),
      videoBitsPerSecond: 4_000_000,
    });

    recorderRef.current = recorder;
    startedAtRef.current = Date.now();

    recorder.ondataavailable = (ev) => {
      if (ev.data && ev.data.size > 0) chunksRef.current.push(ev.data);
    };

    recorder.onstop = async () => {
      const activeMs = Math.max(
        1000,
        (isPausedRef.current ? pauseStartedAtRef.current : Date.now()) -
          startedAtRef.current -
          pausedTotalMsRef.current
      );
      const actualSec = Math.max(1, activeMs / 1000);
      const finalBlob = new Blob(chunksRef.current, { type: mimeType || 'video/webm' });
      const finishedTarget = activeTargetSecRef.current;
      const finishedSeq = clipSeqRef.current;
      // Recording NEVER stops automatically on timed clip end — only manual STOP ends recording
      const shouldContinue =
        finishedTarget !== null && !manualStopRequestedRef.current;

      cleanupRecordingStreams();
      setIsRecording(false);
      isPausedRef.current = false;
      setIsPaused(false);

      await finalizeAndSaveRecording(
        finalBlob,
        finishedTarget ?? actualSec,
        finishedSeq
      );

      if (shouldContinue && finishedTarget !== null) {
        // Start next clip immediately with exact same duration until STOP
        await startRecording(finishedTarget, activeLabelRef.current, finishedSeq + 1);
      } else {
        setTargetSeconds(null);
        setRecordingModeLabel('');
        showTopPopupNotification(
          'Clipping Saved - My Clips me save ho gayi',
          'Saved to My Clips & ClipKaro',
          false
        );
      }
    };

    // Start recording immediately with RED dot + timer
    recorder.start(250);
    setIsRecording(true);
    autoHighlightSavedForSessionRef.current = false;

    timerRef.current = window.setInterval(() => {
      if (isPausedRef.current) {
        return;
      }
      const secs = Math.max(
        0,
        Math.floor((Date.now() - startedAtRef.current - pausedTotalMsRef.current) / 1000)
      );
      setElapsedSeconds(secs);

      // In web preview mode with Auto Highlight ON during Full Video, save a 15s Kill/Headshot highlight automatically without pressing any button
      if (
        autoHighlightRef.current &&
        activeTargetSecRef.current === null &&
        !autoHighlightSavedForSessionRef.current &&
        secs >= 15 &&
        chunksRef.current.length > 0
      ) {
        autoHighlightSavedForSessionRef.current = true;
        const snapshotBlob = new Blob([...chunksRef.current], {
          type: mimeType || 'video/webm',
        });
        void finalizeAndSaveRecording(snapshotBlob, 15, clipSeqRef.current, 'Headshot');
      }

      if (activeTargetSecRef.current !== null && secs >= activeTargetSecRef.current) {
        // Auto-finish current segment & immediately continue next clip until user taps STOP
        stopRecording(false);
      }
    }, 250);
  };

  const cycleAudioMode = () => {
    setAudioMode((prev) => (prev === 'both' ? 'game' : prev === 'game' ? 'mic' : 'both'));
  };

  const cycleVoicePreset = () => {
    const idx = VOICE_ORDER.indexOf(voiceChanger);
    const next = VOICE_ORDER[(idx + 1) % VOICE_ORDER.length];
    onUpdateReactionOptions?.({ voiceChanger: next });
    setSavedToast(`Voice Changer: ${next.toUpperCase()}`);
  };

  if (!visible) return null;

  const winW = typeof window !== 'undefined' ? window.innerWidth : 390;
  const winH = typeof window !== 'undefined' ? window.innerHeight : 844;
  const menuSize = isRecording ? 246 : 254;
  const expandedLeft = Math.min(Math.max(10, position.x - menuSize / 2 + 16), Math.max(10, winW - menuSize - 10));
  const expandedTop = Math.min(Math.max(16, position.y - menuSize / 2 + 16), Math.max(16, winH - menuSize - 16));
  const openLeftward = position.x > winW * 0.55;
  const showFacecamWindow = isRecording && isFacecamToggleOn;

  return (
    <>
      {/* Draggable & Resizable 120dp Circular Facecam Overlay Window (Opens ONLY during active recording) */}
      {showFacecamWindow && (
        <div
          style={{ left: `${facecamPos.x}px`, top: `${facecamPos.y}px` }}
          className="fixed z-40 flex flex-col items-center select-none"
        >
          <div
            onPointerDown={(e) => {
              e.currentTarget.setPointerCapture(e.pointerId);
              facecamDragRef.current = {
                pointerId: e.pointerId,
                startX: e.clientX,
                startY: e.clientY,
                originX: facecamPos.x,
                originY: facecamPos.y,
              };
            }}
            onPointerMove={(e) => {
              const st = facecamDragRef.current;
              if (!st || st.pointerId !== e.pointerId) return;
              const maxX = Math.max(8, winW - facecamSizePx - 8);
              const maxY = Math.max(12, winH - facecamSizePx - 12);
              setFacecamPos({
                x: Math.min(Math.max(8, st.originX + (e.clientX - st.startX)), maxX),
                y: Math.min(Math.max(12, st.originY + (e.clientY - st.startY)), maxY),
              });
            }}
            onPointerUp={() => {
              facecamDragRef.current = null;
            }}
            style={{ width: `${facecamSizePx}px`, height: `${facecamSizePx}px` }}
            className={`touch-none relative overflow-hidden rounded-full border-2 shadow-2xl flex items-center justify-center cursor-move ${
              reactionMode ? 'border-rose-500 bg-slate-900' : 'border-emerald-400 bg-slate-900'
            }`}
          >
            <video
              ref={facecamVideoRef}
              muted
              playsInline
              className={`h-full w-full object-cover ${facecamLive ? 'block' : 'hidden'}`}
            />
            {!facecamLive && (
              <div className="flex flex-col items-center text-white pointer-events-none">
                <Camera className="h-5 w-5 text-emerald-300" aria-hidden="true" />
                <span className="mt-0.5 text-[9px] font-bold">Facecam {facecamSizePx}dp</span>
              </div>
            )}
            {/* Recording RED dot (or Yellow PAUSED indicator) on Facecam */}
            <div className="pointer-events-none absolute top-1.5 left-1/2 -translate-x-1/2 flex items-center gap-1 rounded-full bg-black/80 px-1.5 py-0.5">
              <span
                className={`h-2 w-2 rounded-full ${
                  isPaused ? 'bg-yellow-400' : 'bg-red-500 animate-pulse'
                }`}
                aria-hidden="true"
              />
              <span className="text-[8px] font-extrabold tracking-wide text-white">
                {isPaused ? 'PAUSED' : 'REC'}
              </span>
            </div>
            <button
              type="button"
              onPointerDown={(e) => e.stopPropagation()}
              onClick={() =>
                setFacecamSizePx((s) => (s === 120 ? 156 : s === 156 ? 96 : 120))
              }
              title="Resize Facecam circle"
              aria-label="Resize Facecam circle"
              className="absolute bottom-1.5 right-1.5 flex h-5 w-5 items-center justify-center rounded-full border border-slate-500 bg-slate-900/90 text-[10px] font-bold text-white"
            >
              ⤢
            </button>
          </div>
          {reactionMode && isRecording && (
            <button
              type="button"
              onClick={() => void handleSaveReactionPartNow()}
              className="mt-1 rounded-full bg-rose-600 px-2.5 py-0.5 text-[10px] font-bold text-white shadow-lg hover:bg-rose-500"
            >
              Save Clip
            </button>
          )}
        </div>
      )}

      {/* 2-Second Top-of-Screen Notification Popup */}
      {topBanner && (
        <div
          role="status"
          aria-live="polite"
          className="fixed top-4 left-1/2 z-[70] -translate-x-1/2 flex items-center gap-2.5 rounded-full border border-slate-600/80 bg-[#0B0E14]/95 px-4 py-2 shadow-2xl backdrop-blur-md max-w-[92vw]"
        >
          <span
            className={`h-2.5 w-2.5 rounded-full shrink-0 ${
              topBanner.isRedDot ? 'bg-red-500 animate-pulse' : 'bg-emerald-400'
            }`}
            aria-hidden="true"
          />
          <div className="min-w-0">
            <div className="text-xs font-extrabold text-white truncate">{topBanner.title}</div>
            <div className="text-[10px] text-slate-300 truncate">{topBanner.subtitle}</div>
          </div>
        </div>
      )}
      {/* Optional Top Notification Recording Bar (for Preview / Notification Quick Controls) */}
      {notifBarEnabled && (
        <div className="fixed bottom-4 left-4 z-40 flex flex-wrap items-center gap-2 rounded-xl border border-slate-700 bg-[#0F172A]/95 px-3 py-2 text-xs text-slate-200 shadow-2xl backdrop-blur-md">
          <Bell className="h-3.5 w-3.5 text-rose-400 shrink-0" aria-hidden="true" />
          <span className="font-semibold">
            {isRecording
              ? `REC ${formatSeconds(elapsedSeconds)}${targetSeconds ? ` / ${formatSeconds(targetSeconds)}` : ''} · #${clipSequence}`
              : 'Notification Record:'}
          </span>
          {isRecording ? (
            <>
              <button
                type="button"
                onClick={isPaused ? resumeRecording : pauseRecording}
                className={`rounded-md px-2 py-1 font-bold ${
                  isPaused
                    ? 'bg-green-600 text-white hover:bg-green-500'
                    : 'bg-yellow-400 text-slate-950 hover:bg-yellow-300'
                }`}
              >
                {isPaused ? 'Resume' : 'Pause'}
              </button>
              <button
                type="button"
                onClick={() => stopRecording(true)}
                className="rounded-md bg-rose-600 px-2.5 py-1 font-bold text-white hover:bg-rose-500"
              >
                Stop
              </button>
            </>
          ) : (
            <>
              <button
                type="button"
                onClick={() => startRecording(10, 'Clip 10 sec')}
                className="rounded-md border border-slate-700 bg-[#0B0E14] px-2 py-1 font-semibold hover:border-rose-500"
              >
                10s Clip
              </button>
              <button
                type="button"
                onClick={() => startRecording(30, 'Clip 30 sec')}
                className="rounded-md border border-slate-700 bg-[#0B0E14] px-2 py-1 font-semibold hover:border-rose-500"
              >
                30s Clip
              </button>
              <button
                type="button"
                onClick={() => startRecording(null, 'Full Video')}
                className="rounded-md bg-rose-600 px-2 py-1 font-semibold text-white hover:bg-rose-500"
              >
                Full
              </button>
            </>
          )}
          <button
            type="button"
            onClick={() => setNotifBarEnabled(false)}
            aria-label="Hide notification bar"
            className="rounded p-0.5 text-slate-400 hover:text-white"
          >
            <X className="h-3.5 w-3.5" aria-hidden="true" />
          </button>
        </div>
      )}

      {/* Draggable Expand / Collapse 32dp (60% Transparent) Floating Bubble & 180dp+ Circular Menu */}
      <div
        ref={rootRef}
        style={
          menuOpen
            ? { left: `${expandedLeft}px`, top: `${expandedTop}px` }
            : { left: `${position.x}px`, top: `${position.y}px` }
        }
        className="fixed z-50 select-none"
      >
        {/* SMALL MODE: 32dp circle, 60% transparent (opacity-40), draggable anywhere */}
        {!menuOpen && (
          <button
            ref={buttonRef}
            type="button"
            onPointerDown={handlePointerDown}
            onPointerMove={handlePointerMove}
            onPointerUp={handlePointerUp}
            onPointerCancel={clearLongPressTimer}
            onContextMenu={(e) => {
              e.preventDefault();
              setMenuOpen(false);
              setLongPressMenuOpen(true);
            }}
            aria-label="ClipKaro 32dp Floating CLIP Button"
            title={
              isWebPreviewDemo
                ? 'ClipKaro 32dp Floating CLIP Button (Tap: Menu · Hold 500ms: Options)'
                : `ClipKaro Floating CLIP (${activeGameName})`
            }
            aria-expanded={menuOpen}
            className={`touch-none flex h-8 w-8 flex-col items-center justify-center rounded-full border shadow-xl opacity-40 hover:opacity-80 transition-opacity focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-rose-400 ${
              isRecording
                ? isPaused
                  ? 'border-yellow-400 bg-[#0F172A] text-white'
                  : 'border-red-500 bg-[#0F172A] text-white'
                : 'border-white/85 bg-rose-600 text-white'
            }`}
          >
            {isRecording ? (
              <>
                <span
                  className={`h-1.5 w-1.5 rounded-full ${
                    isPaused ? 'bg-yellow-400' : 'bg-red-500 animate-pulse'
                  }`}
                  aria-hidden="true"
                />
                <span className="mt-0.5 font-mono text-[8px] font-bold tabular-nums leading-none">
                  {formatSeconds(elapsedSeconds)}
                </span>
              </>
            ) : (
              <div className="flex flex-col items-center justify-center leading-none">
                <Scissors className="h-3 w-3 text-white" aria-hidden="true" />
                <span className="mt-0.5 text-[6px] font-extrabold tracking-tight text-white">
                  CLIP
                </span>
              </div>
            )}
          </button>
        )}

        {/* 500ms Long-Press Popup Menu */}
        {longPressMenuOpen && !menuOpen && (
          <div
            role="menu"
            aria-label="Floating Button Quick Options"
            className={`absolute ${
              openLeftward ? 'right-10' : 'left-10'
            } -top-2 z-[60] w-44 rounded-xl border border-slate-600 bg-[#0B0E14]/95 p-2 shadow-2xl backdrop-blur-md space-y-1.5`}
          >
            <div className="px-1 text-[10px] font-bold uppercase tracking-wider text-slate-400">
              CLIP Options
            </div>
            <button
              type="button"
              onClick={() => {
                setLongPressMenuOpen(false);
                onClose?.();
              }}
              className="w-full rounded-lg bg-slate-800 px-3 py-1.5 text-left text-xs font-semibold text-white hover:bg-slate-700"
            >
              Hide Button
            </button>
            <button
              type="button"
              onClick={() => {
                setLongPressMenuOpen(false);
                if (isRecording) stopRecording(true);
                onClose?.();
              }}
              className="w-full rounded-lg bg-amber-700 px-3 py-1.5 text-left text-xs font-semibold text-white hover:bg-amber-600"
            >
              Stop Recording + Hide
            </button>
            <button
              type="button"
              onClick={() => {
                setLongPressMenuOpen(false);
                if (isRecording) stopRecording(true);
                onClose?.();
              }}
              className="w-full rounded-lg bg-red-600 px-3 py-1.5 text-left text-xs font-bold text-white hover:bg-red-500"
            >
              Stop
            </button>
          </div>
        )}

        {/* Saved Toast next to Small Button */}
        {savedToast && !menuOpen && (
          <div
            className={`absolute ${
              openLeftward ? 'right-10' : 'left-10'
            } top-0 flex items-center gap-2 rounded-lg border border-emerald-500/40 bg-[#121722] px-3 py-1.5 text-xs text-emerald-200 shadow-xl whitespace-nowrap`}
          >
            <CheckCircle2 className="h-3.5 w-3.5 text-emerald-400 shrink-0" aria-hidden="true" />
            <span>{savedToast}</span>
            <button
              type="button"
              onClick={() => {
                setSavedToast(null);
                onNavigateToClips();
              }}
              className="rounded bg-emerald-600 px-2 py-0.5 font-semibold text-white hover:bg-emerald-500"
            >
              Open
            </button>
          </div>
        )}

        {/* BIG MODE: Expanded 246dp Semi-Transparent Dark Circle Menu */}
        {menuOpen && isRecording && (
          <div
            role="dialog"
            aria-label="Recording Controls"
            className="flex h-[246px] w-[246px] flex-col items-center justify-center rounded-full border-2 border-red-500/80 bg-[#0B0E14]/90 p-3 text-center shadow-2xl backdrop-blur-md"
          >
            <div className="flex items-center gap-2">
              <span
                className={`h-2.5 w-2.5 rounded-full ${
                  isPaused ? 'bg-yellow-400' : 'bg-red-500 animate-pulse'
                }`}
                aria-hidden="true"
              />
              <span className="font-mono text-base font-bold text-white tabular-nums">
                {formatSeconds(elapsedSeconds)}
              </span>
              <button
                type="button"
                onClick={() => setMenuOpen(false)}
                aria-label="Collapse floating menu"
                className="flex h-6 w-6 items-center justify-center rounded-full border border-slate-500 bg-slate-800/90 text-white hover:bg-slate-700"
              >
                <X className="h-3.5 w-3.5" aria-hidden="true" />
              </button>
            </div>

            <div
              className={`mt-1 text-[10px] font-semibold truncate max-w-[165px] ${
                isPaused ? 'text-yellow-300' : 'text-slate-300'
              }`}
            >
              {isPaused ? `PAUSED · ${recordingModeLabel}` : `${recordingModeLabel} #${clipSequence}`}
            </div>

            {/* PAUSE (YELLOW) + RESUME (GREEN) */}
            <div className="mt-2 flex items-center justify-center gap-2">
              <button
                type="button"
                disabled={isPaused}
                onClick={pauseRecording}
                className="inline-flex items-center justify-center gap-1 rounded-full bg-yellow-400 px-3 py-1.5 text-[11px] font-extrabold text-slate-950 shadow hover:bg-yellow-300 disabled:opacity-45"
              >
                <Pause className="h-3 w-3 fill-current" aria-hidden="true" />
                <span>PAUSE</span>
              </button>
              <button
                type="button"
                disabled={!isPaused}
                onClick={resumeRecording}
                className="inline-flex items-center justify-center gap-1 rounded-full bg-green-600 px-3 py-1.5 text-[11px] font-extrabold text-white shadow hover:bg-green-500 disabled:opacity-45"
              >
                <Play className="h-3 w-3 fill-current" aria-hidden="true" />
                <span>RESUME</span>
              </button>
            </div>

            {/* Facecam ON / OFF toggle inside Recording menu (saves last choice) */}
            <button
              type="button"
              onClick={handleToggleFacecamChoice}
              className={`mt-1.5 inline-flex items-center justify-center gap-1.5 rounded-full px-3.5 py-1 text-[10px] font-bold transition-colors ${
                isFacecamToggleOn
                  ? 'bg-teal-600 text-white hover:bg-teal-500'
                  : 'border border-slate-600 bg-slate-800 text-slate-300 hover:text-white'
              }`}
            >
              <Camera className="h-3 w-3" aria-hidden="true" />
              <span>{isFacecamToggleOn ? 'Facecam ON' : 'Facecam OFF'}</span>
            </button>

            {reactionMode && (
              <button
                type="button"
                onClick={() => {
                  setMenuOpen(false);
                  void handleSaveReactionPartNow();
                }}
                className="mt-1.5 inline-flex items-center justify-center gap-1 rounded-full bg-rose-700 px-4 py-1 text-[10px] font-bold text-white hover:bg-rose-600"
              >
                <Scissors className="h-3 w-3" aria-hidden="true" />
                <span>Save Clip (Part)</span>
              </button>
            )}

            {/* BIG RED STOP */}
            <button
              type="button"
              onClick={() => stopRecording(true)}
              className="mt-1.5 inline-flex items-center justify-center gap-1.5 rounded-full border-2 border-red-300 bg-red-600 px-6 py-1.5 text-xs font-extrabold text-white shadow-lg transition-transform hover:scale-105 hover:bg-red-500"
            >
              <Square className="h-3.5 w-3.5 fill-current" aria-hidden="true" />
              <span>STOP</span>
            </button>
          </div>
        )}

        {menuOpen && !isRecording && (
          <div
            role="dialog"
            aria-label="In-Game Clip Menu"
            className="flex h-[254px] w-[254px] flex-col items-center justify-between rounded-full border border-slate-500/70 bg-[#0B0E14]/88 px-4 py-3 shadow-2xl backdrop-blur-md"
          >
            {/* Top: CLIP + CLOSE (X) */}
            <div className="flex w-full items-center justify-between px-4">
              <div className="flex items-center gap-1 text-xs font-extrabold text-white">
                <Move className="h-3 w-3 text-rose-400 shrink-0" aria-hidden="true" />
                <span>CLIP</span>
              </div>
              <div className="flex items-center gap-1">
                {onClose && (
                  <button
                    type="button"
                    onClick={() => {
                      setMenuOpen(false);
                      onClose();
                    }}
                    title="Turn off floating bubble"
                    className="rounded-full border border-slate-600 bg-slate-800 px-1.5 py-0.5 text-[9px] font-semibold text-slate-300 hover:text-white"
                  >
                    Off
                  </button>
                )}
                <button
                  type="button"
                  onClick={() => setMenuOpen(false)}
                  aria-label="Close floating menu"
                  className="flex h-6 w-6 items-center justify-center rounded-full border border-slate-500 bg-slate-800 text-white hover:bg-slate-700"
                >
                  <X className="h-3.5 w-3.5" aria-hidden="true" />
                </button>
              </div>
            </div>

            {/* Compact Feature Toggles Row 1: Audio / Auto Loop / Auto Highlight */}
            <div className="grid w-full grid-cols-3 gap-1 px-2">
              <button
                type="button"
                onClick={cycleAudioMode}
                title={`Audio: ${AUDIO_LABELS[audioMode]}`}
                className="inline-flex items-center justify-center gap-0.5 rounded-full bg-rose-600/90 px-1.5 py-1 text-[9px] font-bold text-white hover:bg-rose-500 truncate"
              >
                <Mic className="h-2.5 w-2.5 shrink-0" aria-hidden="true" />
                <span className="truncate">
                  {audioMode === 'game' ? 'Game' : audioMode === 'mic' ? 'Mic' : 'Both'}
                </span>
              </button>
              <button
                type="button"
                onClick={() => {
                  setAutoContinuous(true);
                  setSavedToast('Continuous Clips stays ON until you tap STOP');
                }}
                className="inline-flex items-center justify-center gap-0.5 rounded-full bg-emerald-700/90 px-1.5 py-1 text-[9px] font-bold text-white"
              >
                <Repeat className="h-2.5 w-2.5 shrink-0" aria-hidden="true" />
                <span>Loop:ON</span>
              </button>
              <button
                type="button"
                onClick={() => setAutoHighlight((prev) => !prev)}
                className={`inline-flex items-center justify-center gap-0.5 rounded-full px-1.5 py-1 text-[9px] font-bold ${
                  autoHighlight
                    ? 'bg-amber-600/90 text-white'
                    : 'border border-slate-600 bg-slate-800 text-slate-300'
                }`}
              >
                <Zap className="h-2.5 w-2.5 shrink-0" aria-hidden="true" />
                <span>15sHL</span>
              </button>
            </div>

            {/* Compact Feature Toggles Row 2: Facecam / Voice Changer / Reaction Mode */}
            <div className="grid w-full grid-cols-3 gap-1 px-2">
              <button
                type="button"
                onClick={handleToggleFacecamChoice}
                className={`inline-flex items-center justify-center gap-0.5 rounded-full px-1.5 py-1 text-[9px] font-bold ${
                  isFacecamToggleOn
                    ? 'bg-teal-600 text-white'
                    : 'border border-slate-600 bg-slate-800 text-slate-300'
                }`}
              >
                <Camera className="h-2.5 w-2.5 shrink-0" aria-hidden="true" />
                <span>{isFacecamToggleOn ? 'Facecam ON' : 'Facecam OFF'}</span>
              </button>
              <button
                type="button"
                onClick={cycleVoicePreset}
                className={`inline-flex items-center justify-center gap-0.5 rounded-full px-1.5 py-1 text-[9px] font-bold capitalize ${
                  voiceChanger !== 'normal'
                    ? 'bg-violet-600 text-white'
                    : 'border border-slate-600 bg-slate-800 text-slate-300'
                }`}
              >
                <span>V:{voiceChanger}</span>
              </button>
              <button
                type="button"
                onClick={() => {
                  const nextReact = !reactionMode;
                  if (nextReact) {
                    setFacecamManualOff(false);
                    try {
                      localStorage.setItem('clipkaro_facecam_manual_off', 'false');
                    } catch {
                      // ignore
                    }
                  }
                  onUpdateReactionOptions?.({
                    reactionMode: nextReact,
                    facecamEnabled: nextReact ? true : facecamEnabled,
                  });
                }}
                className={`inline-flex items-center justify-center gap-0.5 rounded-full px-1.5 py-1 text-[9px] font-bold ${
                  reactionMode
                    ? 'bg-rose-600 text-white'
                    : 'border border-slate-600 bg-slate-800 text-slate-300'
                }`}
              >
                <span>{reactionMode ? 'React:ON' : 'React:OFF'}</span>
              </button>
            </div>

            {/* 10 sec - 60 sec Clip Buttons */}
            <div className="grid w-full grid-cols-3 gap-1 px-0.5">
              {CLIP_DURATIONS.map((sec) => (
                <button
                  key={sec}
                  type="button"
                  onClick={() => startRecording(sec, `${sec}s Clip`)}
                  className="rounded-full border border-slate-600 bg-slate-800/95 py-1 text-[10px] font-bold text-white transition-colors hover:border-rose-400 hover:bg-rose-600 tabular-nums"
                >
                  {sec} sec
                </button>
              ))}
            </div>

            {/* Full Video + RED STOP */}
            <div className="flex w-full items-center justify-center gap-1.5 px-3">
              <button
                type="button"
                onClick={() => startRecording(null, 'Full Video')}
                className="inline-flex flex-1 items-center justify-center gap-1 rounded-full bg-teal-700 px-2.5 py-1.5 text-[10px] font-bold text-white hover:bg-teal-600 whitespace-nowrap"
              >
                <Video className="h-3 w-3" aria-hidden="true" />
                <span>Full Video</span>
              </button>
              <button
                type="button"
                onClick={() => stopRecording(true)}
                className="inline-flex items-center justify-center gap-1 rounded-full bg-red-600 px-3 py-1.5 text-[10px] font-extrabold text-white hover:bg-red-500 whitespace-nowrap"
              >
                <Square className="h-2.5 w-2.5 fill-current" aria-hidden="true" />
                <span>STOP</span>
              </button>
            </div>
          </div>
        )}
      </div>
    </>
  );
}

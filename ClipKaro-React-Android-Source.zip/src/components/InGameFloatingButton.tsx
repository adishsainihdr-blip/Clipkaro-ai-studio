import { PointerEvent as ReactPointerEvent, useEffect, useRef, useState } from 'react';
import { CheckCircle2, Film, Mic, Move, Radio, Scissors, Square, Video, X } from 'lucide-react';
import { ClipItem } from '../types/clipkaro';
import { formatSeconds } from '../utils/mediaGenerators';

interface InGameFloatingButtonProps {
  visible: boolean;
  activeGameName: string;
  isWebPreviewDemo: boolean;
  onSaveClip: (clip: ClipItem) => Promise<void>;
  onNavigateToClips: () => void;
  onClose?: () => void;
}

const CLIP_DURATIONS = [10, 20, 30, 40, 50, 60] as const;

export function InGameFloatingButton({
  visible,
  activeGameName,
  isWebPreviewDemo,
  onSaveClip,
  onNavigateToClips,
  onClose,
}: InGameFloatingButtonProps) {
  const [position, setPosition] = useState<{ x: number; y: number }>(() => {
    if (typeof window === 'undefined') return { x: 24, y: 120 };
    return {
      x: Math.max(16, window.innerWidth - 96),
      y: Math.max(88, window.innerHeight - 140),
    };
  });

  const [menuOpen, setMenuOpen] = useState<boolean>(false);
  const [isRecording, setIsRecording] = useState<boolean>(false);
  const [recordingModeLabel, setRecordingModeLabel] = useState<string>('');
  const [targetSeconds, setTargetSeconds] = useState<number | null>(null);
  const [elapsedSeconds, setElapsedSeconds] = useState<number>(0);
  const [audioBadge, setAudioBadge] = useState<string>('In-Game Sound + Game Chat');
  const [savedToast, setSavedToast] = useState<string | null>(null);

  const buttonRef = useRef<HTMLButtonElement | null>(null);
  const dragStateRef = useRef<{
    dragging: boolean;
    pointerId: number;
    startX: number;
    startY: number;
    originX: number;
    originY: number;
    moved: boolean;
  } | null>(null);

  // Recording Refs
  const recorderRef = useRef<MediaRecorder | null>(null);
  const chunksRef = useRef<BlobPart[]>([]);
  const activeStreamsRef = useRef<MediaStream[]>([]);
  const audioCtxRef = useRef<AudioContext | null>(null);
  const timerRef = useRef<number | null>(null);
  const canvasRafRef = useRef<number>(0);
  const startedAtRef = useRef<number>(0);
  const activeTargetSecRef = useRef<number | null>(null);
  const activeGameRef = useRef<string>(activeGameName);
  const thumbnailRef = useRef<string | undefined>(undefined);

  useEffect(() => {
    activeGameRef.current = activeGameName;
  }, [activeGameName]);

  // Keep button inside viewport on resize
  useEffect(() => {
    const handleResize = () => {
      setPosition((prev) => ({
        x: Math.min(Math.max(12, prev.x), Math.max(12, window.innerWidth - 84)),
        y: Math.min(Math.max(12, prev.y), Math.max(12, window.innerHeight - 84)),
      }));
    };
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  // Cleanup active recording resources on unmount
  useEffect(() => {
    return () => {
      if (timerRef.current) window.clearInterval(timerRef.current);
      cancelAnimationFrame(canvasRafRef.current);
      activeStreamsRef.current.forEach((s) => s.getTracks().forEach((t) => t.stop()));
      audioCtxRef.current?.close().catch(() => undefined);
    };
  }, []);

  const handlePointerDown = (e: ReactPointerEvent<HTMLButtonElement>) => {
    e.currentTarget.setPointerCapture(e.pointerId);
    dragStateRef.current = {
      dragging: true,
      pointerId: e.pointerId,
      startX: e.clientX,
      startY: e.clientY,
      originX: position.x,
      originY: position.y,
      moved: false,
    };
  };

  const handlePointerMove = (e: ReactPointerEvent<HTMLButtonElement>) => {
    const state = dragStateRef.current;
    if (!state || !state.dragging || state.pointerId !== e.pointerId) return;
    const dx = e.clientX - state.startX;
    const dy = e.clientY - state.startY;
    if (Math.hypot(dx, dy) > 5) {
      state.moved = true;
    }
    const maxX = Math.max(12, window.innerWidth - 80);
    const maxY = Math.max(12, window.innerHeight - 80);
    setPosition({
      x: Math.min(Math.max(12, state.originX + dx), maxX),
      y: Math.min(Math.max(12, state.originY + dy), maxY),
    });
  };

  const handlePointerUp = (e: ReactPointerEvent<HTMLButtonElement>) => {
    const state = dragStateRef.current;
    if (!state || state.pointerId !== e.pointerId) return;
    dragStateRef.current = null;
    if (!state.moved) {
      setMenuOpen((prev) => !prev);
      setSavedToast(null);
    }
  };

  const cleanupRecordingStreams = () => {
    if (timerRef.current) {
      window.clearInterval(timerRef.current);
      timerRef.current = null;
    }
    cancelAnimationFrame(canvasRafRef.current);
    activeStreamsRef.current.forEach((s) => s.getTracks().forEach((t) => t.stop()));
    activeStreamsRef.current = [];
    audioCtxRef.current?.close().catch(() => undefined);
    audioCtxRef.current = null;
  };

  const finalizeAndSaveRecording = async (blob: Blob, durationSec: number) => {
    const gameName = activeGameRef.current || 'In-Game Capture';
    const cleanDuration = Math.max(1, Math.round(durationSec));
    const newClip: ClipItem = {
      id: `clip-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
      title: `${gameName} HD Clip (${cleanDuration}s)`,
      platform: 'studio',
      gameTag: gameName,
      durationSec: cleanDuration,
      trimStart: 0,
      trimEnd: cleanDuration,
      createdAt: Date.now(),
      copyrightSafe: true,
      permission: {
        hasPermission: true,
        streamerName: 'MyGameplay',
        originalVideoLink: '',
        creditText: 'Credit: @MyGameplay',
      },
      videoBlob: blob,
      videoMimeType: blob.type || 'video/webm',
      thumbnailDataUrl: thumbnailRef.current,
      voiceVolume: 1,
      musicVolume: 0.45,
      originalVolume: 1,
    };

    await onSaveClip(newClip);
    setSavedToast(`Saved ${cleanDuration}s HD clip to My Clips`);
  };

  const stopRecording = () => {
    const recorder = recorderRef.current;
    if (recorder && recorder.state !== 'inactive') {
      recorder.stop();
    } else {
      cleanupRecordingStreams();
      setIsRecording(false);
    }
  };

  const startHdDemoStream = (): MediaStream => {
    const canvas = document.createElement('canvas');
    canvas.width = 1280; // HD 720p
    canvas.height = 720;
    const ctx = canvas.getContext('2d')!;

    const startMs = performance.now();
    let capturedThumb = false;

    const renderFrame = () => {
      const elapsed = performance.now() - startMs;
      const t = elapsed / 1000;

      // Dark tactical HD gameplay HUD simulation
      const grad = ctx.createLinearGradient(0, 0, canvas.width, canvas.height);
      grad.addColorStop(0, '#090d16');
      grad.addColorStop(0.6, '#131b2e');
      grad.addColorStop(1, '#0b1120');
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      // Perspective horizon grid
      ctx.strokeStyle = 'rgba(56, 189, 248, 0.14)';
      ctx.lineWidth = 1.5;
      const scroll = (elapsed * 0.06) % 64;
      for (let x = -64 + scroll; x < canvas.width; x += 64) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, canvas.height);
        ctx.stroke();
      }
      for (let y = 0; y < canvas.height; y += 64) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(canvas.width, y);
        ctx.stroke();
      }

      // Crosshair / dynamic target motion
      const cx = canvas.width / 2 + Math.cos(t * 1.4) * 220;
      const cy = canvas.height / 2 + Math.sin(t * 2.1) * 110;
      ctx.strokeStyle = '#f43f5e';
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.arc(cx, cy, 34, 0, Math.PI * 2);
      ctx.stroke();
      ctx.beginPath();
      ctx.moveTo(cx - 48, cy);
      ctx.lineTo(cx + 48, cy);
      ctx.moveTo(cx, cy - 48);
      ctx.lineTo(cx, cy + 48);
      ctx.stroke();

      // Top HD Game Overlay
      ctx.fillStyle = 'rgba(11, 14, 20, 0.85)';
      ctx.fillRect(36, 32, 460, 74);
      ctx.fillStyle = '#ffffff';
      ctx.font = '700 26px system-ui, sans-serif';
      ctx.fillText(`${activeGameRef.current || 'Game'} · HD Capture`, 56, 68);
      ctx.fillStyle = '#34d399';
      ctx.font = '500 16px system-ui, sans-serif';
      ctx.fillText('1280×720 HD · In-Game Sound + Game Chat', 56, 94);

      // Live audio waveform bars (Game + Chat)
      for (let i = 0; i < 20; i += 1) {
        const h = 14 + Math.abs(Math.sin(t * 6 + i * 0.6)) * 44;
        ctx.fillStyle = i % 2 === 0 ? '#f43f5e' : '#38bdf8';
        ctx.fillRect(36 + i * 18, canvas.height - 56 - h, 10, h);
      }

      // Timecode
      ctx.fillStyle = '#f8fafc';
      ctx.font = '600 22px monospace';
      ctx.fillText(`REC ${t.toFixed(1)}s`, canvas.width - 190, canvas.height - 46);

      if (!capturedThumb && elapsed > 300) {
        capturedThumb = true;
        try {
          thumbnailRef.current = canvas.toDataURL('image/jpeg', 0.8);
        } catch {
          // ignore
        }
      }

      canvasRafRef.current = requestAnimationFrame(renderFrame);
    };

    canvasRafRef.current = requestAnimationFrame(renderFrame);
    const canvasStream = canvas.captureStream(30);
    activeStreamsRef.current.push(canvasStream);
    return canvasStream;
  };

  const startRecording = async (durationSec: number | null, label: string) => {
    if (isRecording) return;

    setSavedToast(null);
    thumbnailRef.current = undefined;
    chunksRef.current = [];
    activeTargetSecRef.current = durationSec;
    setTargetSeconds(durationSec);
    setElapsedSeconds(0);
    setRecordingModeLabel(label);

    let videoStream: MediaStream | null = null;
    let gameAudioStream: MediaStream | null = null;
    let chatAudioStream: MediaStream | null = null;
    let usedRealDisplay = false;

    // 1. Try real HD Screen + System/In-Game Sound capture
    if (navigator.mediaDevices?.getDisplayMedia) {
      try {
        const displayStream = await navigator.mediaDevices.getDisplayMedia({
          video: {
            width: { ideal: 1920 },
            height: { ideal: 1080 },
            frameRate: { ideal: 30 },
          },
          audio: true,
        });
        videoStream = displayStream;
        gameAudioStream = displayStream;
        usedRealDisplay = true;
        activeStreamsRef.current.push(displayStream);

        // Capture frame thumbnail from real stream
        try {
          const track = displayStream.getVideoTracks()[0];
          const tempVideo = document.createElement('video');
          tempVideo.srcObject = new MediaStream([track]);
          tempVideo.muted = true;
          await tempVideo.play();
          const c = document.createElement('canvas');
          c.width = 480;
          c.height = 270;
          const cx = c.getContext('2d');
          cx?.drawImage(tempVideo, 0, 0, c.width, c.height);
          thumbnailRef.current = c.toDataURL('image/jpeg', 0.8);
          tempVideo.pause();
          tempVideo.srcObject = null;
        } catch {
          // ignore thumbnail error
        }
      } catch {
        // Fallback to HD Demo Canvas stream if display capture is cancelled/unavailable in web preview
        videoStream = null;
      }
    }

    // 2. Try Microphone for Game Chat
    if (navigator.mediaDevices?.getUserMedia) {
      try {
        const micStream = await navigator.mediaDevices.getUserMedia({
          audio: { echoCancellation: true, noiseSuppression: true },
        });
        chatAudioStream = micStream;
        activeStreamsRef.current.push(micStream);
      } catch {
        chatAudioStream = null;
      }
    }

    if (!videoStream) {
      videoStream = startHdDemoStream();
    }

    // 3. Mix In-Game Sound + Game Chat via Web Audio API
    const audioCtx = new AudioContext();
    audioCtxRef.current = audioCtx;
    const mixedDest = audioCtx.createMediaStreamDestination();
    let hasInGameTrack = false;
    let hasChatTrack = false;

    if (gameAudioStream && gameAudioStream.getAudioTracks().length > 0) {
      const gameSrc = audioCtx.createMediaStreamSource(
        new MediaStream(gameAudioStream.getAudioTracks())
      );
      gameSrc.connect(mixedDest);
      hasInGameTrack = true;
    } else {
      // Synthesize subtle in-game sound bed in HD demo preview mode
      const osc = audioCtx.createOscillator();
      const gain = audioCtx.createGain();
      osc.type = 'triangle';
      osc.frequency.value = 180;
      gain.gain.value = 0.035;
      osc.connect(gain);
      gain.connect(mixedDest);
      osc.start();
      hasInGameTrack = true;
    }

    if (chatAudioStream && chatAudioStream.getAudioTracks().length > 0) {
      const chatSrc = audioCtx.createMediaStreamSource(chatAudioStream);
      chatSrc.connect(mixedDest);
      hasChatTrack = true;
    }

    setAudioBadge(
      usedRealDisplay
        ? hasChatTrack
          ? 'HD Capture · In-Game Sound + Game Chat Mic'
          : 'HD Capture · In-Game Sound'
        : hasChatTrack
          ? 'HD Demo · In-Game Sound + Game Chat Mic'
          : 'HD Demo · In-Game Sound + Game Chat'
    );

    const combinedStream = new MediaStream([
      ...videoStream.getVideoTracks(),
      ...(hasInGameTrack || hasChatTrack ? mixedDest.stream.getAudioTracks() : []),
    ]);

    // Stop cleanly if user ends browser screen sharing
    videoStream.getVideoTracks().forEach((track) => {
      track.onended = () => {
        stopRecording();
      };
    });

    const mimeType = MediaRecorder.isTypeSupported('video/webm;codecs=vp9,opus')
      ? 'video/webm;codecs=vp9,opus'
      : MediaRecorder.isTypeSupported('video/webm')
        ? 'video/webm'
        : '';

    const recorder = new MediaRecorder(combinedStream, {
      ...(mimeType ? { mimeType } : {}),
      videoBitsPerSecond: 4_000_000, // 4 Mbps HD quality
    });

    recorderRef.current = recorder;
    startedAtRef.current = Date.now();

    recorder.ondataavailable = (ev) => {
      if (ev.data && ev.data.size > 0) chunksRef.current.push(ev.data);
    };

    recorder.onstop = async () => {
      const actualSec = Math.max(1, (Date.now() - startedAtRef.current) / 1000);
      const finalBlob = new Blob(chunksRef.current, { type: mimeType || 'video/webm' });
      cleanupRecordingStreams();
      setIsRecording(false);
      setTargetSeconds(null);
      setRecordingModeLabel('');
      await finalizeAndSaveRecording(finalBlob, activeTargetSecRef.current ?? actualSec);
    };

    recorder.start(250);
    setIsRecording(true);
    setMenuOpen(false);

    timerRef.current = window.setInterval(() => {
      const secs = Math.floor((Date.now() - startedAtRef.current) / 1000);
      setElapsedSeconds(secs);
      if (activeTargetSecRef.current !== null && secs >= activeTargetSecRef.current) {
        stopRecording();
      }
    }, 250);
  };

  if (!visible) return null;

  const openUpward = typeof window !== 'undefined' && position.y > window.innerHeight * 0.5;
  const openLeftward = typeof window !== 'undefined' && position.x > window.innerWidth * 0.55;

  return (
    <div
      style={{ left: `${position.x}px`, top: `${position.y}px` }}
      className="fixed z-50 select-none"
    >
      {/* Draggable Floating Button */}
      <button
        ref={buttonRef}
        type="button"
        onPointerDown={handlePointerDown}
        onPointerMove={handlePointerMove}
        onPointerUp={handlePointerUp}
        aria-label="ClipKaro In-Game Floating Button"
        title={
          isWebPreviewDemo
            ? 'ClipKaro Floating CLIP Button (Web Preview Demo)'
            : `ClipKaro Floating CLIP Button (${activeGameName})`
        }
        aria-expanded={menuOpen}
        className={`touch-none flex h-14 w-14 flex-col items-center justify-center rounded-full border shadow-2xl transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-rose-400 ${
          isRecording
            ? 'border-rose-400 bg-rose-600 text-white'
            : 'border-slate-600 bg-[#121722]/95 text-white hover:border-rose-500'
        }`}
      >
        {isRecording ? (
          <>
            <Radio className="h-4 w-4" aria-hidden="true" />
            <span className="mt-0.5 font-mono text-[10px] font-bold tabular-nums">
              {targetSeconds ? `${Math.max(0, targetSeconds - elapsedSeconds)}s` : formatSeconds(elapsedSeconds)}
            </span>
          </>
        ) : (
          <>
            <Scissors className="h-5 w-5 text-rose-400" aria-hidden="true" />
            <span className="mt-0.5 text-[9px] font-bold tracking-tight text-slate-200">
              CLIP
            </span>
          </>
        )}
      </button>

      {/* Saved Toast next to Floating Button */}
      {savedToast && !menuOpen && (
        <div
          className={`absolute ${
            openLeftward ? 'right-16' : 'left-16'
          } top-1.5 flex items-center gap-2 rounded-lg border border-emerald-500/40 bg-[#121722] px-3 py-2 text-xs text-emerald-200 shadow-xl whitespace-nowrap`}
        >
          <CheckCircle2 className="h-3.5 w-3.5 text-emerald-400 shrink-0" aria-hidden="true" />
          <span>{savedToast}</span>
          <button
            type="button"
            onClick={() => {
              setSavedToast(null);
              onNavigateToClips();
            }}
            className="rounded bg-emerald-600 px-2 py-0.5 font-semibold text-white hover:bg-emerald-500"
          >
            Open
          </button>
        </div>
      )}

      {/* Floating Menu */}
      {menuOpen && (
        <div
          role="dialog"
          aria-label="In-Game Clip Menu"
          className={`absolute w-64 rounded-xl border border-slate-700 bg-[#121722]/98 p-3 shadow-2xl backdrop-blur-md space-y-2.5 ${
            openUpward ? 'bottom-16' : 'top-16'
          } ${openLeftward ? 'right-0' : 'left-0'}`}
        >
          <div className="flex items-center justify-between gap-2 border-b border-slate-800 pb-2">
            <div className="min-w-0">
              <div className="flex items-center gap-1.5 text-xs font-bold text-white truncate">
                <Move className="h-3.5 w-3.5 text-slate-400 shrink-0" aria-hidden="true" />
                <span className="truncate">{activeGameName || 'In-Game Capture'}</span>
              </div>
              <div className="mt-0.5 flex items-center gap-1 text-[11px] text-slate-400">
                <Mic className="h-3 w-3 text-sky-400 shrink-0" aria-hidden="true" />
                <span className="truncate">{audioBadge}</span>
              </div>
            </div>
            {onClose && (
              <button
                type="button"
                onClick={() => {
                  setMenuOpen(false);
                  if (!isRecording) onClose();
                }}
                aria-label="Hide floating button"
                className="rounded p-1 text-slate-400 hover:bg-slate-800 hover:text-white shrink-0"
              >
                <X className="h-3.5 w-3.5" aria-hidden="true" />
              </button>
            )}
          </div>

          {isRecording && (
            <div className="rounded-lg border border-rose-500/40 bg-rose-950/30 px-2.5 py-2 text-xs text-rose-200 flex items-center justify-between tabular-nums">
              <span className="font-medium truncate">{recordingModeLabel}</span>
              <span className="font-mono font-bold">
                {formatSeconds(elapsedSeconds)}
                {targetSeconds ? ` / ${formatSeconds(targetSeconds)}` : ''}
              </span>
            </div>
          )}

          {/* 10-60s Clip Buttons */}
          <div className="grid grid-cols-2 gap-1.5">
            {CLIP_DURATIONS.map((sec) => (
              <button
                key={sec}
                type="button"
                disabled={isRecording}
                onClick={() => startRecording(sec, `Clip ${sec} sec`)}
                className="rounded-lg border border-slate-700/80 bg-[#0B0E14] px-2.5 py-2 text-xs font-semibold text-slate-200 transition-colors hover:border-rose-500 hover:text-white disabled:opacity-45 tabular-nums whitespace-nowrap"
              >
                Clip {sec} sec
              </button>
            ))}
          </div>

          {/* Record Full Gameplay & Stop */}
          <div className="space-y-1.5 pt-0.5">
            <button
              type="button"
              disabled={isRecording}
              onClick={() => startRecording(null, 'Full Gameplay')}
              className="inline-flex w-full items-center justify-center gap-2 rounded-lg bg-rose-600 px-3 py-2 text-xs font-bold text-white transition-colors hover:bg-rose-500 disabled:opacity-45"
            >
              <Video className="h-3.5 w-3.5" aria-hidden="true" />
              <span>Record Full Gameplay</span>
            </button>

            <button
              type="button"
              disabled={!isRecording}
              onClick={stopRecording}
              className="inline-flex w-full items-center justify-center gap-2 rounded-lg border border-slate-700 bg-[#0B0E14] px-3 py-2 text-xs font-semibold text-slate-200 transition-colors hover:border-rose-500 hover:text-white disabled:opacity-40"
            >
              <Square className="h-3.5 w-3.5 fill-current text-rose-400" aria-hidden="true" />
              <span>Stop</span>
            </button>
          </div>

          {savedToast && (
            <div className="flex items-center justify-between gap-2 rounded-lg border border-emerald-500/40 bg-emerald-950/25 px-2.5 py-1.5 text-[11px] text-emerald-200">
              <span className="truncate">{savedToast}</span>
              <button
                type="button"
                onClick={() => {
                  setMenuOpen(false);
                  onNavigateToClips();
                }}
                className="inline-flex items-center gap-1 font-semibold text-emerald-300 hover:text-white shrink-0"
              >
                <Film className="h-3 w-3" aria-hidden="true" />
                <span>View</span>
              </button>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

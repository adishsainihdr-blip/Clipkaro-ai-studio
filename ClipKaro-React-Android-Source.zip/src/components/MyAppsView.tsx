import { FormEvent, useEffect, useRef, useState } from 'react';
import {
  Camera,
  CheckCircle2,
  Crosshair,
  Film,
  Globe,
  MessageCircle,
  Mic,
  Play,
  Plus,
  Rocket,
  Scissors,
  Share2,
  Smartphone,
  Sparkles,
  Square,
  Trash2,
  Video,
} from 'lucide-react';
import { ClipItem, UniversalAppItem, VoiceChangerPreset } from '../types/clipkaro';
import {
  requestCameraPermission,
  saveVideoToNativeClipKaroFolder,
} from '../utils/androidPermissions';
import { formatSeconds } from '../utils/mediaGenerators';

interface MyAppsViewProps {
  clips: ClipItem[];
  floatingVisible: boolean;
  activeFloatingTarget: string;
  reactionMode: boolean;
  facecamEnabled: boolean;
  voiceChanger: VoiceChangerPreset;
  onUpdateReactionOptions: (partial: {
    reactionMode?: boolean;
    facecamEnabled?: boolean;
    voiceChanger?: VoiceChangerPreset;
  }) => void;
  onSaveClip?: (clip: ClipItem) => Promise<void>;
  onActivateFloatingForApp: (appName: string) => void;
  onStopFloatingButton: () => void;
  onViewAppClips: (appName: string) => void;
}

const VOICE_PRESETS: { id: VoiceChangerPreset; label: string; hint: string }[] = [
  { id: 'normal', label: 'Normal', hint: 'Natural mic' },
  { id: 'funny', label: 'Funny', hint: 'High pitch' },
  { id: 'robot', label: 'Robot', hint: 'Synth mod' },
  { id: 'deep', label: 'Deep', hint: 'Heavy bass' },
];

const DEFAULT_UNIVERSAL_APPS: UniversalAppItem[] = [
  {
    id: 'app-youtube',
    name: 'YouTube',
    category: 'Videos & Shorts',
    androidPackage: 'com.google.android.youtube',
    webFallbackUrl: 'https://play.google.com/store/apps/details?id=com.google.android.youtube',
    accentColor: 'red',
    iconKey: 'youtube',
  },
  {
    id: 'app-instagram',
    name: 'Instagram',
    category: 'Reels & Stories',
    androidPackage: 'com.instagram.android',
    webFallbackUrl: 'https://play.google.com/store/apps/details?id=com.instagram.android',
    accentColor: 'fuchsia',
    iconKey: 'instagram',
  },
  {
    id: 'app-facebook',
    name: 'Facebook',
    category: 'Watch & Reels',
    androidPackage: 'com.facebook.katana',
    webFallbackUrl: 'https://play.google.com/store/apps/details?id=com.facebook.katana',
    accentColor: 'sky',
    iconKey: 'facebook',
  },
  {
    id: 'app-whatsapp',
    name: 'WhatsApp',
    category: 'Status & Video Calls',
    androidPackage: 'com.whatsapp',
    webFallbackUrl: 'https://play.google.com/store/apps/details?id=com.whatsapp',
    accentColor: 'emerald',
    iconKey: 'whatsapp',
  },
  {
    id: 'app-bgmi',
    name: 'BGMI',
    category: 'Battle Royale',
    androidPackage: 'com.pubg.imobile',
    webFallbackUrl: 'https://play.google.com/store/apps/details?id=com.pubg.imobile',
    accentColor: 'amber',
    iconKey: 'bgmi',
  },
];

const CUSTOM_APPS_STORAGE_KEY = 'clipkaro_custom_universal_apps';

function loadCustomApps(): UniversalAppItem[] {
  try {
    const raw = localStorage.getItem(CUSTOM_APPS_STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? (parsed as UniversalAppItem[]) : [];
  } catch {
    return [];
  }
}

function saveCustomApps(items: UniversalAppItem[]): void {
  try {
    localStorage.setItem(CUSTOM_APPS_STORAGE_KEY, JSON.stringify(items));
  } catch {
    // ignore storage errors
  }
}

function renderAppIcon(iconKey: UniversalAppItem['iconKey']) {
  switch (iconKey) {
    case 'youtube':
      return <Play className="h-5 w-5 text-red-400 fill-current" aria-hidden="true" />;
    case 'instagram':
      return <Camera className="h-5 w-5 text-fuchsia-400" aria-hidden="true" />;
    case 'facebook':
      return <Share2 className="h-5 w-5 text-sky-400" aria-hidden="true" />;
    case 'whatsapp':
      return <MessageCircle className="h-5 w-5 text-emerald-400" aria-hidden="true" />;
    case 'bgmi':
      return <Crosshair className="h-5 w-5 text-amber-400" aria-hidden="true" />;
    default:
      return <Globe className="h-5 w-5 text-violet-400" aria-hidden="true" />;
  }
}

export function MyAppsView({
  clips,
  floatingVisible,
  activeFloatingTarget,
  reactionMode,
  facecamEnabled,
  voiceChanger,
  onUpdateReactionOptions,
  onSaveClip,
  onActivateFloatingForApp,
  onStopFloatingButton,
  onViewAppClips,
}: MyAppsViewProps) {
  const [customApps, setCustomApps] = useState<UniversalAppItem[]>(() => loadCustomApps());
  const [newAppName, setNewAppName] = useState<string>('');
  const [newAppPackage, setNewAppPackage] = useState<string>('');
  const [statusMessage, setStatusMessage] = useState<string | null>(null);

  // In-App Reaction Studio Player + "Save Clip" (Selected Part) state
  const [reactionPlatformLabel, setReactionPlatformLabel] = useState<string>('YouTube');
  const [reactionPartStart, setReactionPartStart] = useState<number>(0);
  const [reactionPartEnd, setReactionPartEnd] = useState<number>(15);
  const [reactionVideoUrl, setReactionVideoUrl] = useState<string | null>(null);
  const [isSavingReactionPart, setIsSavingReactionPart] = useState<boolean>(false);
  const [reactionFacecamSizePx, setReactionFacecamSizePx] = useState<number>(120);
  const [reactionCamActive, setReactionCamActive] = useState<boolean>(false);
  const [reactionPreviewRequested, setReactionPreviewRequested] = useState<boolean>(false);
  const reactionCamVideoRef = useRef<HTMLVideoElement | null>(null);
  const reactionSourceVideoRef = useRef<HTMLVideoElement | null>(null);

  useEffect(() => {
    if (!reactionMode || !reactionPreviewRequested) {
      setReactionCamActive(false);
      return;
    }
    let activeStream: MediaStream | null = null;
    let cancelled = false;
    if (navigator.mediaDevices?.getUserMedia) {
      navigator.mediaDevices
        .getUserMedia({ video: { facingMode: 'user', width: 320, height: 320 }, audio: false })
        .then((stream) => {
          if (cancelled) {
            stream.getTracks().forEach((t) => t.stop());
            return;
          }
          activeStream = stream;
          if (reactionCamVideoRef.current) {
            reactionCamVideoRef.current.srcObject = stream;
            reactionCamVideoRef.current.play().catch(() => undefined);
            setReactionCamActive(true);
          }
        })
        .catch(() => {
          setReactionCamActive(false);
        });
    }
    return () => {
      cancelled = true;
      activeStream?.getTracks().forEach((t) => t.stop());
    };
  }, [reactionMode, reactionPreviewRequested]);

  useEffect(() => {
    return () => {
      if (reactionVideoUrl) URL.revokeObjectURL(reactionVideoUrl);
    };
  }, [reactionVideoUrl]);

  const allApps = [...DEFAULT_UNIVERSAL_APPS, ...customApps];

  const handleToggleFacecam = () => {
    const next = !facecamEnabled;
    if (next) {
      requestCameraPermission();
    }
    onUpdateReactionOptions({ facecamEnabled: next });
  };

  const handleToggleReactionMode = () => {
    const next = !reactionMode;
    if (next) {
      requestCameraPermission();
      onUpdateReactionOptions({ reactionMode: true, facecamEnabled: true });
    } else {
      onUpdateReactionOptions({ reactionMode: false });
    }
  };

  const handleAddCustomApp = (e: FormEvent) => {
    e.preventDefault();
    if (!newAppName.trim()) return;
    const pkg = newAppPackage.trim() || 'com.android.chrome';
    const item: UniversalAppItem = {
      id: `app-custom-${Date.now()}`,
      name: newAppName.trim(),
      category: 'Custom App',
      androidPackage: pkg,
      webFallbackUrl: `https://play.google.com/store/apps/details?id=${encodeURIComponent(pkg)}`,
      accentColor: 'violet',
      iconKey: 'custom',
      isCustom: true,
    };
    const next = [...customApps, item];
    setCustomApps(next);
    saveCustomApps(next);
    setNewAppName('');
    setNewAppPackage('');
  };

  const handleRemoveCustomApp = (id: string) => {
    const next = customApps.filter((a) => a.id !== id);
    setCustomApps(next);
    saveCustomApps(next);
  };

  const handleOpenAppWithFloatingButton = (app: UniversalAppItem) => {
    if (facecamEnabled || reactionMode) {
      requestCameraPermission();
    }
    onActivateFloatingForApp(app.name);

    const win = window as unknown as {
      Android?: {
        startFloatingWithOptions?: (
          pkg: string,
          fallbackUrl: string,
          appName: string,
          reactionMode: boolean,
          facecamEnabled: boolean,
          voiceEffect: string
        ) => string;
        startFloatingAndLaunchGame?: (pkg: string, fallbackUrl: string, appName: string) => string;
        stopFloatingService?: () => void;
        canDrawOverlays?: () => boolean;
        requestOverlayPermission?: () => void;
      };
    };

    const launchFn = win.Android?.startFloatingWithOptions
      ? () =>
          win.Android!.startFloatingWithOptions!(
            app.androidPackage,
            app.webFallbackUrl,
            app.name,
            reactionMode,
            facecamEnabled,
            voiceChanger
          )
      : win.Android?.startFloatingAndLaunchGame
        ? () =>
            win.Android!.startFloatingAndLaunchGame!(
              app.androidPackage,
              app.webFallbackUrl,
              app.name
            )
        : null;

    if (launchFn) {
      const outcome = launchFn();
      if (outcome === 'overlay_required') {
        setStatusMessage(
          `Overlay Permission needed to show the 32dp Floating CLIP button over ${app.name}.`
        );
      } else {
        setStatusMessage(
          `Floating CLIP started for ${app.name}${
            reactionMode ? ' · Reaction Mode (120dp Facecam + Mic)' : facecamEnabled ? ' · Facecam ON' : ''
          }${voiceChanger !== 'normal' ? ` · ${voiceChanger.toUpperCase()} Voice` : ''}.`
        );
      }
      return;
    }

    setStatusMessage(
      `Universal Floating CLIP active for ${app.name}${
        reactionMode ? ' · Reaction Mode + 120dp Facecam ON' : facecamEnabled ? ' · 120dp Facecam ON' : ''
      } — tap the 32dp circle to record.`
    );
  };

  const handleStopFloating = () => {
    onStopFloatingButton();
    const win = window as unknown as {
      Android?: { stopFloatingService?: () => void };
    };
    win.Android?.stopFloatingService?.();
    setStatusMessage('Floating CLIP button stopped.');
  };

  const handleSaveSelectedReactionPart = async () => {
    if (!onSaveClip || isSavingReactionPart) return;
    const partDur = Math.max(5, Math.min(60, reactionPartEnd - reactionPartStart));
    setIsSavingReactionPart(true);
    try {
      const canvas = document.createElement('canvas');
      canvas.width = 960;
      canvas.height = 540;
      const ctx = canvas.getContext('2d')!;
      const stream = canvas.captureStream(24);
      const mime = MediaRecorder.isTypeSupported('video/webm;codecs=vp9')
        ? 'video/webm;codecs=vp9'
        : 'video/webm';
      const recorder = new MediaRecorder(stream, { mimeType: mime, videoBitsPerSecond: 2_500_000 });
      const chunks: BlobPart[] = [];
      recorder.ondataavailable = (ev) => {
        if (ev.data && ev.data.size > 0) chunks.push(ev.data);
      };

      const renderMs = Math.min(2400, partDur * 180);
      const started = performance.now();
      let thumbDataUrl: string | undefined;

      await new Promise<void>((resolve) => {
        recorder.onstop = () => resolve();
        recorder.start(150);

        const draw = () => {
          const now = performance.now();
          const elapsed = now - started;
          const t = elapsed / 1000;

          if (reactionSourceVideoRef.current && reactionSourceVideoRef.current.readyState >= 2) {
            ctx.drawImage(reactionSourceVideoRef.current, 0, 0, canvas.width, canvas.height);
          } else {
            const g = ctx.createLinearGradient(0, 0, canvas.width, canvas.height);
            g.addColorStop(0, '#0f172a');
            g.addColorStop(1, '#1e1b4b');
            ctx.fillStyle = g;
            ctx.fillRect(0, 0, canvas.width, canvas.height);
            ctx.fillStyle = 'rgba(255,255,255,0.92)';
            ctx.font = '700 28px system-ui, sans-serif';
            ctx.fillText(`${reactionPlatformLabel} Reaction Clip`, 42, 74);
            ctx.fillStyle = '#38bdf8';
            ctx.font = '600 18px system-ui, sans-serif';
            ctx.fillText(
              `Selected Part: ${formatSeconds(reactionPartStart)} → ${formatSeconds(reactionPartEnd)} (${partDur}s) · Voice: ${voiceChanger}`,
              42,
              112
            );
          }

          // Corner Circular Facecam (matching 120dp circle!)
          const camRadius = Math.round(reactionFacecamSizePx * 0.55);
          const camCx = canvas.width - camRadius - 32;
          const camCy = camRadius + 32;
          ctx.save();
          ctx.beginPath();
          ctx.arc(camCx, camCy, camRadius, 0, Math.PI * 2);
          ctx.closePath();
          ctx.clip();
          if (reactionCamVideoRef.current && reactionCamVideoRef.current.readyState >= 2) {
            ctx.drawImage(
              reactionCamVideoRef.current,
              camCx - camRadius,
              camCy - camRadius,
              camRadius * 2,
              camRadius * 2
            );
          } else {
            ctx.fillStyle = '#0f766e';
            ctx.fillRect(camCx - camRadius, camCy - camRadius, camRadius * 2, camRadius * 2);
            ctx.fillStyle = '#ffffff';
            ctx.font = '700 18px system-ui, sans-serif';
            ctx.textAlign = 'center';
            ctx.fillText('FACECAM', camCx, camCy + 6);
            ctx.textAlign = 'left';
          }
          ctx.restore();

          ctx.strokeStyle = '#f43f5e';
          ctx.lineWidth = 4;
          ctx.beginPath();
          ctx.arc(camCx, camCy, camRadius, 0, Math.PI * 2);
          ctx.stroke();

          ctx.fillStyle = 'rgba(0,0,0,0.65)';
          ctx.fillRect(34, canvas.height - 54, 340, 32);
          ctx.fillStyle = '#e2e8f0';
          ctx.font = '600 14px monospace';
          ctx.fillText(`Reaction Part ${(t * 3).toFixed(1)}s · #ClipKaro`, 44, canvas.height - 33);

          if (!thumbDataUrl && elapsed > 200) {
            try {
              thumbDataUrl = canvas.toDataURL('image/jpeg', 0.8);
            } catch {
              // ignore
            }
          }

          if (elapsed < renderMs) {
            requestAnimationFrame(draw);
          } else {
            recorder.stop();
          }
        };
        requestAnimationFrame(draw);
      });

      stream.getTracks().forEach((t) => t.stop());
      const blob = new Blob(chunks, { type: mime });
      const fileName = `ClipKaro_Reaction_${reactionPlatformLabel}_${partDur}s_${Date.now()}.webm`;

      await onSaveClip({
        id: `reaction-${Date.now()}`,
        title: `${reactionPlatformLabel} Reaction (${formatSeconds(reactionPartStart)}–${formatSeconds(reactionPartEnd)})`,
        platform: 'studio',
        gameTag: reactionPlatformLabel,
        durationSec: partDur,
        trimStart: 0,
        trimEnd: partDur,
        createdAt: Date.now(),
        copyrightSafe: true,
        isReaction: true,
        hasFacecam: true,
        voiceChanger,
        autoCaption: 'Live Reaction!',
        thumbnailDataUrl: thumbDataUrl,
        permission: {
          hasPermission: true,
          streamerName: 'MyReaction',
          originalVideoLink: '',
          creditText: 'Reaction · #ClipKaro',
        },
        videoBlob: blob,
        videoMimeType: blob.type || 'video/webm',
        nativeFileName: fileName,
        voiceVolume: 1,
        musicVolume: 0.3,
        originalVolume: 1,
      });
      await saveVideoToNativeClipKaroFolder(fileName, blob);
      setStatusMessage(
        `Saved ${partDur}s Reaction Clip with Facecam in corner to My Clips & ClipKaro folder!`
      );
    } finally {
      setIsSavingReactionPart(false);
    }
  };

  return (
    <div className="space-y-7">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <div className="inline-flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-rose-400">
            <Smartphone className="h-3.5 w-3.5" aria-hidden="true" />
            <span>Universal Floating Button</span>
          </div>
          <h1 className="mt-1 font-display text-2xl font-bold tracking-tight text-white">
            My Apps
          </h1>
          <p className="mt-1 text-sm text-slate-400">
            Tap any app to open it with the 32dp 60% transparent Expand / Collapse CLIP button for 10s–60s, Full Video, Game/Video Sound + Mic, and Auto Continuous Clips.
          </p>
        </div>

        {floatingVisible && (
          <button
            type="button"
            onClick={handleStopFloating}
            className="inline-flex items-center gap-2 rounded-lg border border-rose-500/40 bg-rose-950/30 px-3.5 py-2 text-xs font-bold text-rose-200 hover:bg-rose-900/40 whitespace-nowrap shrink-0"
          >
            <Square className="h-3.5 w-3.5 fill-current" aria-hidden="true" />
            <span>Stop Floating Bubble ({activeFloatingTarget})</span>
          </button>
        )}
      </div>

      {statusMessage && (
        <div className="flex items-center gap-2 rounded-xl border border-emerald-500/40 bg-emerald-950/30 px-4 py-3 text-xs font-semibold text-emerald-200">
          <CheckCircle2 className="h-4 w-4 text-emerald-400 shrink-0" aria-hidden="true" />
          <span>{statusMessage}</span>
        </div>
      )}

      {/* Pre-Recording Facecam, Voice Changer & Reaction Mode Studio */}
      <section
        aria-label="Facecam, Voice Changer & Reaction Mode"
        className="rounded-xl border border-slate-800 bg-[#121722] p-4 sm:p-5 space-y-4"
      >
        <div className="flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between">
          <div>
            <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-teal-400">
              <Video className="h-3.5 w-3.5" aria-hidden="true" />
              <span>Facecam + Voice Changer + Reaction Mode</span>
            </div>
            <p className="mt-0.5 text-xs text-slate-400">
              Turn ON before opening YouTube, Instagram, Facebook, or BGMI. Front camera + screen record together with live Mic Voice Changer.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              role="switch"
              aria-checked={facecamEnabled}
              onClick={handleToggleFacecam}
              className={`inline-flex items-center gap-1.5 rounded-lg border px-3 py-2 text-xs font-bold transition-colors ${
                facecamEnabled
                  ? 'border-emerald-500/60 bg-emerald-500/20 text-emerald-200'
                  : 'border-slate-700 bg-[#0B0E14] text-slate-300 hover:border-slate-500'
              }`}
            >
              <Camera className="h-3.5 w-3.5" aria-hidden="true" />
              <span>Facecam (120dp Circle): {facecamEnabled ? 'ON' : 'OFF'}</span>
            </button>

            <button
              type="button"
              role="switch"
              aria-checked={reactionMode}
              onClick={handleToggleReactionMode}
              className={`inline-flex items-center gap-1.5 rounded-lg border px-3 py-2 text-xs font-bold transition-colors ${
                reactionMode
                  ? 'border-rose-500/70 bg-rose-600/25 text-rose-200'
                  : 'border-slate-700 bg-[#0B0E14] text-slate-300 hover:border-slate-500'
              }`}
            >
              <Sparkles className="h-3.5 w-3.5" aria-hidden="true" />
              <span>Reaction Mode: {reactionMode ? 'ON' : 'OFF'}</span>
            </button>
          </div>
        </div>

        {/* Voice Changer Selector (Normal / Funny / Robot / Deep) */}
        <div className="flex flex-col gap-2 border-t border-slate-800/80 pt-3 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex items-center gap-2 text-xs font-semibold text-slate-300">
            <Mic className="h-4 w-4 text-violet-400 shrink-0" aria-hidden="true" />
            <span>Voice Changer (Applied to Mic in Recording):</span>
          </div>
          <div className="grid grid-cols-4 gap-1.5 sm:w-auto">
            {VOICE_PRESETS.map((preset) => {
              const selected = voiceChanger === preset.id;
              return (
                <button
                  key={preset.id}
                  type="button"
                  onClick={() => onUpdateReactionOptions({ voiceChanger: preset.id })}
                  className={`rounded-lg border px-3 py-1.5 text-center transition-colors ${
                    selected
                      ? 'border-violet-400 bg-violet-600 text-white'
                      : 'border-slate-700 bg-[#0B0E14] text-slate-300 hover:border-slate-500'
                  }`}
                >
                  <div className="text-xs font-bold">{preset.label}</div>
                  <div className="text-[10px] opacity-80 hidden sm:block">{preset.hint}</div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Reaction Mode Preview + Selected Part "Save Clip" Panel */}
        {reactionMode && (
          <div className="rounded-xl border border-rose-500/40 bg-[#0B0E14] p-4 space-y-3">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div>
                <div className="text-sm font-bold text-white">
                  Reaction Studio · Video + Facecam + Mic ({voiceChanger.toUpperCase()})
                </div>
                <p className="text-xs text-slate-400">
                  Watch YouTube / Instagram / Facebook normally or load a video here, then tap Save Clip for only your selected part with corner Facecam.
                </p>
              </div>
              <label className="cursor-pointer rounded-lg border border-slate-700 bg-slate-800 px-3 py-1.5 text-xs font-semibold text-slate-200 hover:bg-slate-700">
                <span>Load Local Video</span>
                <input
                  type="file"
                  accept="video/*"
                  className="hidden"
                  onChange={(e) => {
                    const file = e.target.files?.[0];
                    if (!file) return;
                    if (reactionVideoUrl) URL.revokeObjectURL(reactionVideoUrl);
                    setReactionVideoUrl(URL.createObjectURL(file));
                  }}
                />
              </label>
            </div>

            <div className="relative aspect-video w-full overflow-hidden rounded-lg border border-slate-800 bg-black">
              {reactionVideoUrl ? (
                <video
                  ref={reactionSourceVideoRef}
                  src={reactionVideoUrl}
                  controls
                  playsInline
                  className="h-full w-full object-contain"
                />
              ) : (
                <div className="flex h-full w-full flex-col items-center justify-center gap-2 bg-gradient-to-br from-slate-900 to-indigo-950 p-4 text-center">
                  <Play className="h-8 w-8 text-rose-400" aria-hidden="true" />
                  <div className="text-sm font-semibold text-white">
                    {reactionPlatformLabel} Reaction Feed Ready
                  </div>
                  <div className="text-xs text-slate-400 max-w-md">
                    Launch {reactionPlatformLabel} below with the Floating CLIP button + 120dp corner Facecam, or pick Start/End seconds right here to test Save Clip!
                  </div>
                </div>
              )}

              {/* Live 120dp Circular Corner Facecam Preview (Tap to test/resize; auto-opens on Record Start) */}
              <button
                type="button"
                onClick={() => {
                  if (!reactionPreviewRequested) {
                    setReactionPreviewRequested(true);
                  } else {
                    setReactionFacecamSizePx((s) => (s === 120 ? 148 : s === 148 ? 96 : 120));
                  }
                }}
                title="Tap to preview/resize Facecam circle (opens automatically on Record Start)"
                style={{ width: `${reactionFacecamSizePx}px`, height: `${reactionFacecamSizePx}px` }}
                className="absolute top-3 right-3 overflow-hidden rounded-full border-2 border-rose-500 bg-emerald-900 shadow-2xl flex items-center justify-center"
              >
                <video
                  ref={reactionCamVideoRef}
                  muted
                  playsInline
                  className={`h-full w-full object-cover ${reactionCamActive ? 'block' : 'hidden'}`}
                />
                {!reactionCamActive && (
                  <div className="flex flex-col items-center text-white px-2 text-center">
                    <Camera className="h-5 w-5 text-emerald-300" aria-hidden="true" />
                    <span className="mt-0.5 text-[9px] font-bold">
                      {facecamEnabled ? `Opens on Record (${reactionFacecamSizePx}dp)` : 'Facecam OFF'}
                    </span>
                  </div>
                )}
              </button>
            </div>

            <div className="flex flex-col gap-2.5 sm:flex-row sm:items-center sm:justify-between">
              <div className="flex flex-wrap items-center gap-2 text-xs">
                <select
                  value={reactionPlatformLabel}
                  onChange={(e) => setReactionPlatformLabel(e.target.value)}
                  aria-label="Reaction app label"
                  className="rounded-lg border border-slate-700 bg-[#121722] px-2.5 py-1.5 text-white"
                >
                  <option value="YouTube">YouTube</option>
                  <option value="Instagram">Instagram</option>
                  <option value="Facebook">Facebook</option>
                </select>
                <label className="flex items-center gap-1 text-slate-300">
                  <span>Start (s):</span>
                  <input
                    type="number"
                    min={0}
                    max={600}
                    value={reactionPartStart}
                    onChange={(e) => setReactionPartStart(Math.max(0, Number(e.target.value)))}
                    className="w-16 rounded border border-slate-700 bg-[#121722] px-2 py-1 text-white tabular-nums"
                  />
                </label>
                <label className="flex items-center gap-1 text-slate-300">
                  <span>End (s):</span>
                  <input
                    type="number"
                    min={5}
                    max={660}
                    value={reactionPartEnd}
                    onChange={(e) =>
                      setReactionPartEnd(Math.max(reactionPartStart + 5, Number(e.target.value)))
                    }
                    className="w-16 rounded border border-slate-700 bg-[#121722] px-2 py-1 text-white tabular-nums"
                  />
                </label>
              </div>

              <button
                type="button"
                disabled={isSavingReactionPart}
                onClick={() => void handleSaveSelectedReactionPart()}
                className="inline-flex items-center justify-center gap-1.5 rounded-lg bg-rose-600 px-4 py-2 text-xs font-bold text-white hover:bg-rose-500 disabled:opacity-60"
              >
                <Scissors className="h-3.5 w-3.5" aria-hidden="true" />
                <span>
                  {isSavingReactionPart
                    ? 'Saving Reaction Clip…'
                    : `Save Clip (${Math.max(5, reactionPartEnd - reactionPartStart)}s)`}
                </span>
              </button>
            </div>
          </div>
        )}
      </section>

      {/* Apps Grid */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {allApps.map((app) => {
          const clipCount = clips.filter(
            (c) => c.gameTag.toLowerCase() === app.name.toLowerCase()
          ).length;
          const isCurrentTarget =
            floatingVisible && activeFloatingTarget.toLowerCase() === app.name.toLowerCase();

          return (
            <article
              key={app.id}
              className={`flex flex-col justify-between gap-4 rounded-xl border p-4 transition-colors ${
                isCurrentTarget
                  ? 'border-rose-500/70 bg-[#171E2C]'
                  : 'border-slate-800 bg-[#121722]'
              }`}
            >
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-center gap-3 min-w-0">
                  <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl border border-slate-700/80 bg-[#0B0E14]">
                    {renderAppIcon(app.iconKey)}
                  </span>
                  <div className="min-w-0">
                    <div className="flex items-center gap-2">
                      <h2 className="font-display text-base font-bold text-white truncate">
                        {app.name}
                      </h2>
                      {isCurrentTarget && (
                        <span className="inline-flex items-center gap-1 text-[10px] font-bold text-emerald-400">
                          <span className="h-1.5 w-1.5 rounded-full bg-emerald-400 animate-pulse" />
                          Active
                        </span>
                      )}
                    </div>
                    <div className="mt-0.5 flex items-center gap-1.5 text-xs text-slate-400 tabular-nums">
                      <span className="truncate">{app.category}</span>
                      <span aria-hidden="true">·</span>
                      <span className="shrink-0">
                        {clipCount} {clipCount === 1 ? 'clip' : 'clips'}
                      </span>
                    </div>
                  </div>
                </div>

                {app.isCustom && (
                  <button
                    type="button"
                    onClick={() => handleRemoveCustomApp(app.id)}
                    aria-label={`Remove ${app.name}`}
                    className="rounded p-1 text-slate-500 hover:bg-slate-800 hover:text-rose-300 shrink-0"
                  >
                    <Trash2 className="h-3.5 w-3.5" aria-hidden="true" />
                  </button>
                )}
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => handleOpenAppWithFloatingButton(app)}
                  className="inline-flex flex-1 items-center justify-center gap-2 rounded-lg bg-rose-600 px-3.5 py-2.5 text-xs font-bold text-white transition-colors hover:bg-rose-500 whitespace-nowrap"
                >
                  <Rocket className="h-3.5 w-3.5" aria-hidden="true" />
                  <span>Open with Floating CLIP</span>
                </button>
                <button
                  type="button"
                  onClick={() => onViewAppClips(app.name)}
                  title={`View ${app.name} clips`}
                  className="inline-flex items-center justify-center gap-1 rounded-lg border border-slate-700 bg-[#0B0E14] px-3 py-2.5 text-xs font-semibold text-slate-200 hover:border-slate-500 hover:text-white shrink-0"
                >
                  <Film className="h-3.5 w-3.5" aria-hidden="true" />
                  <span>Clips</span>
                </button>
              </div>
            </article>
          );
        })}
      </div>

      {/* Add Custom App */}
      <form
        onSubmit={handleAddCustomApp}
        className="flex flex-col gap-3 rounded-xl border border-slate-800 bg-[#121722] p-4 sm:flex-row sm:items-end"
      >
        <div className="flex-1 space-y-1.5">
          <label htmlFor="custom-app-name" className="block text-xs font-semibold text-slate-300">
            Add Another App
          </label>
          <input
            id="custom-app-name"
            type="text"
            value={newAppName}
            onChange={(e) => setNewAppName(e.target.value)}
            placeholder="e.g. Chrome, Twitch, Hotstar"
            className="w-full rounded-lg border border-slate-700/80 bg-[#0B0E14] px-3.5 py-2 text-sm text-white placeholder:text-slate-500 focus:border-rose-500 focus:outline-none"
          />
        </div>
        <div className="sm:w-64 space-y-1.5">
          <label htmlFor="custom-app-pkg" className="block text-xs font-semibold text-slate-300">
            Android Package (optional)
          </label>
          <input
            id="custom-app-pkg"
            type="text"
            value={newAppPackage}
            onChange={(e) => setNewAppPackage(e.target.value)}
            placeholder="e.g. tv.twitch.android.app"
            className="w-full rounded-lg border border-slate-700/80 bg-[#0B0E14] px-3.5 py-2 text-sm text-white placeholder:text-slate-500 focus:border-rose-500 focus:outline-none"
          />
        </div>
        <button
          type="submit"
          disabled={!newAppName.trim()}
          className="inline-flex items-center justify-center gap-2 rounded-lg bg-rose-600 px-4 py-2 text-sm font-semibold text-white hover:bg-rose-500 disabled:opacity-50 whitespace-nowrap shrink-0"
        >
          <Plus className="h-4 w-4" aria-hidden="true" />
          <span>Add App</span>
        </button>
      </form>

      {/* Universal Floating Capabilities Summary */}
      <div className="grid grid-cols-1 gap-3 sm:grid-cols-3 rounded-xl border border-slate-800 bg-[#121722] p-4 text-xs text-slate-300">
        <div className="flex items-start gap-2.5">
          <Scissors className="h-4 w-4 text-rose-400 shrink-0 mt-0.5" aria-hidden="true" />
          <div>
            <div className="font-bold text-white">32dp 60% Transparent Expand / Collapse</div>
            <div className="text-slate-400 mt-0.5">
              Tap the tiny 32dp circle to expand 180dp+ controls; auto-collapses to RED dot + timer on record.
            </div>
          </div>
        </div>
        <div className="flex items-start gap-2.5">
          <MessageCircle className="h-4 w-4 text-sky-400 shrink-0 mt-0.5" aria-hidden="true" />
          <div>
            <div className="font-bold text-white">Game/Video Sound + Mic</div>
            <div className="text-slate-400 mt-0.5">
              Switch between Game/Video Only, Mic Only, or Game+Mic Both on any app.
            </div>
          </div>
        </div>
        <div className="flex items-start gap-2.5">
          <Film className="h-4 w-4 text-emerald-400 shrink-0 mt-0.5" aria-hidden="true" />
          <div>
            <div className="font-bold text-white">Auto Continuous Clips</div>
            <div className="text-slate-400 mt-0.5">
              Works for normal YouTube, Instagram, Facebook &amp; WhatsApp videos too until STOP.
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

import { FormEvent, useState } from 'react';
import {
  Camera,
  CheckCircle2,
  Crosshair,
  Film,
  Globe,
  MessageCircle,
  Play,
  Plus,
  Rocket,
  Scissors,
  Share2,
  Smartphone,
  Square,
  Trash2,
} from 'lucide-react';
import { ClipItem, UniversalAppItem } from '../types/clipkaro';

interface MyAppsViewProps {
  clips: ClipItem[];
  floatingVisible: boolean;
  activeFloatingTarget: string;
  onActivateFloatingForApp: (appName: string) => void;
  onStopFloatingButton: () => void;
  onViewAppClips: (appName: string) => void;
}

const DEFAULT_UNIVERSAL_APPS: UniversalAppItem[] = [
  {
    id: 'app-youtube',
    name: 'YouTube',
    category: 'Videos & Shorts',
    androidPackage: 'com.google.android.youtube',
    webFallbackUrl: 'https://play.google.com/store/apps/details?id=com.google.android.youtube',
    accentColor: 'red',
    iconKey: 'youtube',
  },
  {
    id: 'app-instagram',
    name: 'Instagram',
    category: 'Reels & Stories',
    androidPackage: 'com.instagram.android',
    webFallbackUrl: 'https://play.google.com/store/apps/details?id=com.instagram.android',
    accentColor: 'fuchsia',
    iconKey: 'instagram',
  },
  {
    id: 'app-facebook',
    name: 'Facebook',
    category: 'Watch & Reels',
    androidPackage: 'com.facebook.katana',
    webFallbackUrl: 'https://play.google.com/store/apps/details?id=com.facebook.katana',
    accentColor: 'sky',
    iconKey: 'facebook',
  },
  {
    id: 'app-whatsapp',
    name: 'WhatsApp',
    category: 'Status & Video Calls',
    androidPackage: 'com.whatsapp',
    webFallbackUrl: 'https://play.google.com/store/apps/details?id=com.whatsapp',
    accentColor: 'emerald',
    iconKey: 'whatsapp',
  },
  {
    id: 'app-bgmi',
    name: 'BGMI',
    category: 'Battle Royale',
    androidPackage: 'com.pubg.imobile',
    webFallbackUrl: 'https://play.google.com/store/apps/details?id=com.pubg.imobile',
    accentColor: 'amber',
    iconKey: 'bgmi',
  },
];

const CUSTOM_APPS_STORAGE_KEY = 'clipkaro_custom_universal_apps';

function loadCustomApps(): UniversalAppItem[] {
  try {
    const raw = localStorage.getItem(CUSTOM_APPS_STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? (parsed as UniversalAppItem[]) : [];
  } catch {
    return [];
  }
}

function saveCustomApps(items: UniversalAppItem[]): void {
  try {
    localStorage.setItem(CUSTOM_APPS_STORAGE_KEY, JSON.stringify(items));
  } catch {
    // ignore storage errors
  }
}

function renderAppIcon(iconKey: UniversalAppItem['iconKey']) {
  switch (iconKey) {
    case 'youtube':
      return <Play className="h-5 w-5 text-red-400 fill-current" aria-hidden="true" />;
    case 'instagram':
      return <Camera className="h-5 w-5 text-fuchsia-400" aria-hidden="true" />;
    case 'facebook':
      return <Share2 className="h-5 w-5 text-sky-400" aria-hidden="true" />;
    case 'whatsapp':
      return <MessageCircle className="h-5 w-5 text-emerald-400" aria-hidden="true" />;
    case 'bgmi':
      return <Crosshair className="h-5 w-5 text-amber-400" aria-hidden="true" />;
    default:
      return <Globe className="h-5 w-5 text-violet-400" aria-hidden="true" />;
  }
}

export function MyAppsView({
  clips,
  floatingVisible,
  activeFloatingTarget,
  onActivateFloatingForApp,
  onStopFloatingButton,
  onViewAppClips,
}: MyAppsViewProps) {
  const [customApps, setCustomApps] = useState<UniversalAppItem[]>(() => loadCustomApps());
  const [newAppName, setNewAppName] = useState<string>('');
  const [newAppPackage, setNewAppPackage] = useState<string>('');
  const [statusMessage, setStatusMessage] = useState<string | null>(null);

  const allApps = [...DEFAULT_UNIVERSAL_APPS, ...customApps];

  const handleAddCustomApp = (e: FormEvent) => {
    e.preventDefault();
    if (!newAppName.trim()) return;
    const pkg = newAppPackage.trim() || 'com.android.chrome';
    const item: UniversalAppItem = {
      id: `app-custom-${Date.now()}`,
      name: newAppName.trim(),
      category: 'Custom App',
      androidPackage: pkg,
      webFallbackUrl: `https://play.google.com/store/apps/details?id=${encodeURIComponent(pkg)}`,
      accentColor: 'violet',
      iconKey: 'custom',
      isCustom: true,
    };
    const next = [...customApps, item];
    setCustomApps(next);
    saveCustomApps(next);
    setNewAppName('');
    setNewAppPackage('');
  };

  const handleRemoveCustomApp = (id: string) => {
    const next = customApps.filter((a) => a.id !== id);
    setCustomApps(next);
    saveCustomApps(next);
  };

  const handleOpenAppWithFloatingButton = (app: UniversalAppItem) => {
    onActivateFloatingForApp(app.name);

    const win = window as unknown as {
      Android?: {
        startFloatingAndLaunchGame?: (pkg: string, fallbackUrl: string, appName: string) => string;
        stopFloatingService?: () => void;
        canDrawOverlays?: () => boolean;
        requestOverlayPermission?: () => void;
      };
    };

    if (win.Android?.startFloatingAndLaunchGame) {
      const outcome = win.Android.startFloatingAndLaunchGame(
        app.androidPackage,
        app.webFallbackUrl,
        app.name
      );
      if (outcome === 'overlay_required') {
        setStatusMessage(
          `Overlay Permission needed to show the 32dp Floating CLIP button over ${app.name}.`
        );
      } else {
        setStatusMessage(
          `Universal Floating CLIP started (32dp · 60% transparent). Opening ${app.name}…`
        );
      }
      return;
    }

    setStatusMessage(
      `Universal Floating CLIP active for ${app.name} — tap the 32dp circle to expand 10s–60s or Full Video controls.`
    );
  };

  const handleStopFloating = () => {
    onStopFloatingButton();
    const win = window as unknown as {
      Android?: { stopFloatingService?: () => void };
    };
    win.Android?.stopFloatingService?.();
    setStatusMessage('Floating CLIP button stopped.');
  };

  return (
    <div className="space-y-7">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <div className="inline-flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-rose-400">
            <Smartphone className="h-3.5 w-3.5" aria-hidden="true" />
            <span>Universal Floating Button</span>
          </div>
          <h1 className="mt-1 font-display text-2xl font-bold tracking-tight text-white">
            My Apps
          </h1>
          <p className="mt-1 text-sm text-slate-400">
            Tap any app to open it with the 32dp 60% transparent Expand / Collapse CLIP button for 10s–60s, Full Video, Game/Video Sound + Mic, and Auto Continuous Clips.
          </p>
        </div>

        {floatingVisible && (
          <button
            type="button"
            onClick={handleStopFloating}
            className="inline-flex items-center gap-2 rounded-lg border border-rose-500/40 bg-rose-950/30 px-3.5 py-2 text-xs font-bold text-rose-200 hover:bg-rose-900/40 whitespace-nowrap shrink-0"
          >
            <Square className="h-3.5 w-3.5 fill-current" aria-hidden="true" />
            <span>Stop Floating Bubble ({activeFloatingTarget})</span>
          </button>
        )}
      </div>

      {statusMessage && (
        <div className="flex items-center gap-2 rounded-xl border border-emerald-500/40 bg-emerald-950/30 px-4 py-3 text-xs font-semibold text-emerald-200">
          <CheckCircle2 className="h-4 w-4 text-emerald-400 shrink-0" aria-hidden="true" />
          <span>{statusMessage}</span>
        </div>
      )}

      {/* Apps Grid */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {allApps.map((app) => {
          const clipCount = clips.filter(
            (c) => c.gameTag.toLowerCase() === app.name.toLowerCase()
          ).length;
          const isCurrentTarget =
            floatingVisible && activeFloatingTarget.toLowerCase() === app.name.toLowerCase();

          return (
            <article
              key={app.id}
              className={`flex flex-col justify-between gap-4 rounded-xl border p-4 transition-colors ${
                isCurrentTarget
                  ? 'border-rose-500/70 bg-[#171E2C]'
                  : 'border-slate-800 bg-[#121722]'
              }`}
            >
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-center gap-3 min-w-0">
                  <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl border border-slate-700/80 bg-[#0B0E14]">
                    {renderAppIcon(app.iconKey)}
                  </span>
                  <div className="min-w-0">
                    <div className="flex items-center gap-2">
                      <h2 className="font-display text-base font-bold text-white truncate">
                        {app.name}
                      </h2>
                      {isCurrentTarget && (
                        <span className="inline-flex items-center gap-1 text-[10px] font-bold text-emerald-400">
                          <span className="h-1.5 w-1.5 rounded-full bg-emerald-400 animate-pulse" />
                          Active
                        </span>
                      )}
                    </div>
                    <div className="mt-0.5 flex items-center gap-1.5 text-xs text-slate-400 tabular-nums">
                      <span className="truncate">{app.category}</span>
                      <span aria-hidden="true">·</span>
                      <span className="shrink-0">
                        {clipCount} {clipCount === 1 ? 'clip' : 'clips'}
                      </span>
                    </div>
                  </div>
                </div>

                {app.isCustom && (
                  <button
                    type="button"
                    onClick={() => handleRemoveCustomApp(app.id)}
                    aria-label={`Remove ${app.name}`}
                    className="rounded p-1 text-slate-500 hover:bg-slate-800 hover:text-rose-300 shrink-0"
                  >
                    <Trash2 className="h-3.5 w-3.5" aria-hidden="true" />
                  </button>
                )}
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => handleOpenAppWithFloatingButton(app)}
                  className="inline-flex flex-1 items-center justify-center gap-2 rounded-lg bg-rose-600 px-3.5 py-2.5 text-xs font-bold text-white transition-colors hover:bg-rose-500 whitespace-nowrap"
                >
                  <Rocket className="h-3.5 w-3.5" aria-hidden="true" />
                  <span>Open with Floating CLIP</span>
                </button>
                <button
                  type="button"
                  onClick={() => onViewAppClips(app.name)}
                  title={`View ${app.name} clips`}
                  className="inline-flex items-center justify-center gap-1 rounded-lg border border-slate-700 bg-[#0B0E14] px-3 py-2.5 text-xs font-semibold text-slate-200 hover:border-slate-500 hover:text-white shrink-0"
                >
                  <Film className="h-3.5 w-3.5" aria-hidden="true" />
                  <span>Clips</span>
                </button>
              </div>
            </article>
          );
        })}
      </div>

      {/* Add Custom App */}
      <form
        onSubmit={handleAddCustomApp}
        className="flex flex-col gap-3 rounded-xl border border-slate-800 bg-[#121722] p-4 sm:flex-row sm:items-end"
      >
        <div className="flex-1 space-y-1.5">
          <label htmlFor="custom-app-name" className="block text-xs font-semibold text-slate-300">
            Add Another App
          </label>
          <input
            id="custom-app-name"
            type="text"
            value={newAppName}
            onChange={(e) => setNewAppName(e.target.value)}
            placeholder="e.g. Chrome, Twitch, Hotstar"
            className="w-full rounded-lg border border-slate-700/80 bg-[#0B0E14] px-3.5 py-2 text-sm text-white placeholder:text-slate-500 focus:border-rose-500 focus:outline-none"
          />
        </div>
        <div className="sm:w-64 space-y-1.5">
          <label htmlFor="custom-app-pkg" className="block text-xs font-semibold text-slate-300">
            Android Package (optional)
          </label>
          <input
            id="custom-app-pkg"
            type="text"
            value={newAppPackage}
            onChange={(e) => setNewAppPackage(e.target.value)}
            placeholder="e.g. tv.twitch.android.app"
            className="w-full rounded-lg border border-slate-700/80 bg-[#0B0E14] px-3.5 py-2 text-sm text-white placeholder:text-slate-500 focus:border-rose-500 focus:outline-none"
          />
        </div>
        <button
          type="submit"
          disabled={!newAppName.trim()}
          className="inline-flex items-center justify-center gap-2 rounded-lg bg-rose-600 px-4 py-2 text-sm font-semibold text-white hover:bg-rose-500 disabled:opacity-50 whitespace-nowrap shrink-0"
        >
          <Plus className="h-4 w-4" aria-hidden="true" />
          <span>Add App</span>
        </button>
      </form>

      {/* Universal Floating Capabilities Summary */}
      <div className="grid grid-cols-1 gap-3 sm:grid-cols-3 rounded-xl border border-slate-800 bg-[#121722] p-4 text-xs text-slate-300">
        <div className="flex items-start gap-2.5">
          <Scissors className="h-4 w-4 text-rose-400 shrink-0 mt-0.5" aria-hidden="true" />
          <div>
            <div className="font-bold text-white">32dp 60% Transparent Expand / Collapse</div>
            <div className="text-slate-400 mt-0.5">
              Tap the tiny 32dp circle to expand 180dp+ controls; auto-collapses to RED dot + timer on record.
            </div>
          </div>
        </div>
        <div className="flex items-start gap-2.5">
          <MessageCircle className="h-4 w-4 text-sky-400 shrink-0 mt-0.5" aria-hidden="true" />
          <div>
            <div className="font-bold text-white">Game/Video Sound + Mic</div>
            <div className="text-slate-400 mt-0.5">
              Switch between Game/Video Only, Mic Only, or Game+Mic Both on any app.
            </div>
          </div>
        </div>
        <div className="flex items-start gap-2.5">
          <Film className="h-4 w-4 text-emerald-400 shrink-0 mt-0.5" aria-hidden="true" />
          <div>
            <div className="font-bold text-white">Auto Continuous Clips</div>
            <div className="text-slate-400 mt-0.5">
              Works for normal YouTube, Instagram, Facebook &amp; WhatsApp videos too until STOP.
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

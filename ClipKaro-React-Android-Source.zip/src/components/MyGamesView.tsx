import { FormEvent, useEffect, useRef, useState } from 'react';
import {
  Box,
  Car,
  Crosshair,
  Film,
  Flame,
  Gamepad2,
  Plus,
  Rocket,
  Scissors,
  Shield,
  Sparkles,
  Swords,
  Target,
  Trash2,
  X,
} from 'lucide-react';
import { ClipItem, GameItem } from '../types/clipkaro';
import { generateSampleStreamVideoBlob } from '../utils/mediaGenerators';

interface MyGamesViewProps {
  games: GameItem[];
  clips: ClipItem[];
  onAddGame: (name: string, genre: string) => Promise<void>;
  onDeleteCustomGame: (id: string) => Promise<void>;
  onViewGameClips: (gameName: string) => void;
  onCutClipForGame: (gameName: string) => void;
  onSaveClip: (clip: ClipItem) => Promise<void>;
  onActivateFloatingButton?: (gameName: string) => void;
}

const CUSTOM_GAME_CARD: GameItem = {
  id: 'game-custom-launcher',
  name: 'Custom Game',
  genre: 'Custom Title',
  coverUrl: '/src/assets/images/game_tactical_arena_1795269900712.jpg',
  iconKey: 'custom',
};

function renderGameIcon(iconKey?: GameItem['iconKey']) {
  switch (iconKey) {
    case 'bgmi':
      return <Crosshair className="h-5 w-5 text-amber-400" aria-hidden="true" />;
    case 'freefire':
      return <Flame className="h-5 w-5 text-orange-400" aria-hidden="true" />;
    case 'gtav':
      return <Car className="h-5 w-5 text-emerald-400" aria-hidden="true" />;
    case 'minecraft':
      return <Box className="h-5 w-5 text-lime-400" aria-hidden="true" />;
    case 'valorant':
      return <Swords className="h-5 w-5 text-rose-400" aria-hidden="true" />;
    case 'codm':
      return <Shield className="h-5 w-5 text-sky-400" aria-hidden="true" />;
    default:
      return <Gamepad2 className="h-5 w-5 text-violet-400" aria-hidden="true" />;
  }
}

export function MyGamesView({
  games,
  clips,
  onAddGame,
  onDeleteCustomGame,
  onViewGameClips,
  onCutClipForGame,
  onSaveClip,
  onActivateFloatingButton,
}: MyGamesViewProps) {
  const [newName, setNewName] = useState<string>('');
  const [newGenre, setNewGenre] = useState<string>('Action / Stream');
  const [isAdding, setIsAdding] = useState<boolean>(false);

  // Open Game / Launch Game Modal State
  const [openedGame, setOpenedGame] = useState<GameItem | null>(null);
  const [customLaunchName, setCustomLaunchName] = useState<string>('');
  const [customLaunchUrl, setCustomLaunchUrl] = useState<string>('');
  const [launchStatus, setLaunchStatus] = useState<string | null>(null);

  // Interactive Mini-Game: Highlight Timing Challenge
  const [isPlayingMini, setIsPlayingMini] = useState<boolean>(false);
  const [cursorPos, setCursorPos] = useState<number>(0.15);
  const [targetStart, setTargetStart] = useState<number>(0.42);
  const [streak, setStreak] = useState<number>(0);
  const [bestStreak, setBestStreak] = useState<number>(0);
  const [lastResult, setLastResult] = useState<string>(
    'Press Hit Target when the marker enters the highlighted zone.'
  );
  const [isSavingReplay, setIsSavingReplay] = useState<boolean>(false);
  const [replayPct, setReplayPct] = useState<number>(0);

  const dirRef = useRef<number>(1);
  const posRef = useRef<number>(0.15);
  const rafRef = useRef<number>(0);

  useEffect(() => {
    if (!isPlayingMini) {
      cancelAnimationFrame(rafRef.current);
      return;
    }

    let lastTime = performance.now();
    const tick = (now: number) => {
      const dt = (now - lastTime) / 1000;
      lastTime = now;
      const speed = 0.85 + Math.min(streak * 0.08, 0.9);
      let next = posRef.current + dirRef.current * speed * dt;
      if (next >= 0.96) {
        next = 0.96;
        dirRef.current = -1;
      } else if (next <= 0.04) {
        next = 0.04;
        dirRef.current = 1;
      }
      posRef.current = next;
      setCursorPos(next);
      rafRef.current = requestAnimationFrame(tick);
    };
    rafRef.current = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(rafRef.current);
  }, [isPlayingMini, streak]);

  const handleHitTarget = () => {
    if (!isPlayingMini) {
      setIsPlayingMini(true);
      setLastResult('Timing active — click Hit Target inside the rose zone!');
      return;
    }
    const targetEnd = targetStart + 0.16;
    if (posRef.current >= targetStart && posRef.current <= targetEnd) {
      const nextStreak = streak + 1;
      setStreak(nextStreak);
      setBestStreak((prev) => Math.max(prev, nextStreak));
      setLastResult(`Clean clip hit! Streak ${nextStreak}.`);
      setTargetStart(0.15 + Math.random() * 0.62);
    } else {
      setStreak(0);
      setLastResult('Missed timing window — streak reset to 0.');
    }
  };

  const handleSaveMiniGameReplay = async () => {
    setIsSavingReplay(true);
    setReplayPct(0);
    try {
      const blob = await generateSampleStreamVideoBlob({
        durationSec: 10,
        title: `Highlight Challenge (Best Streak ${bestStreak})`,
        creditLine: 'Credit: @ClipKaroPlayer',
        onProgress: setReplayPct,
      });
      await onSaveClip({
        id: `clip-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
        title: `Reaction Streak ${bestStreak} Highlight`,
        platform: 'studio',
        gameTag: games[0]?.name || 'BGMI',
        durationSec: 10,
        trimStart: 0,
        trimEnd: 10,
        createdAt: Date.now(),
        copyrightSafe: true,
        permission: {
          hasPermission: true,
          streamerName: 'ClipKaroPlayer',
          originalVideoLink: '',
          creditText: 'Credit: @ClipKaroPlayer',
        },
        videoBlob: blob,
        videoMimeType: blob.type || 'video/webm',
        voiceVolume: 1,
        musicVolume: 0.45,
        originalVolume: 1,
      });
      setLastResult('10s highlight clip saved to My Clips.');
    } finally {
      setIsSavingReplay(false);
    }
  };

  const handleAddSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (!newName.trim()) return;
    setIsAdding(true);
    try {
      await onAddGame(newName.trim(), newGenre.trim() || 'Stream Category');
      setNewName('');
    } finally {
      setIsAdding(false);
    }
  };

  const handleOpenGame = (game: GameItem) => {
    setOpenedGame(game);
    setLaunchStatus(null);
    setCustomLaunchName(game.id === CUSTOM_GAME_CARD.id ? '' : game.name);
    setCustomLaunchUrl(game.androidPackage ?? '');
    onActivateFloatingButton?.(game.name);
  };

  const allDisplayedGames: GameItem[] = [...games, CUSTOM_GAME_CARD];

  const effectiveLaunchTitle =
    openedGame?.id === CUSTOM_GAME_CARD.id
      ? customLaunchName.trim() || 'Custom Game'
      : openedGame?.name || 'Game';

  const effectivePackageName = (
    openedGame?.id === CUSTOM_GAME_CARD.id
      ? customLaunchUrl.trim()
      : openedGame?.androidPackage || ''
  ).trim();

  const handleLaunchGame = () => {
    const targetTitle = effectiveLaunchTitle;
    onActivateFloatingButton?.(targetTitle);

    const win = window as unknown as {
      Android?: {
        launchApp?: (pkg: string, fallbackUrl?: string) => boolean;
        startFloatingAndLaunchGame?: (pkg: string, fallbackUrl: string, gameName: string) => string;
        canDrawOverlays?: () => boolean;
        requestOverlayPermission?: () => void;
      };
      Capacitor?: { isNativePlatform?: () => boolean };
    };

    const isAndroidUa = typeof navigator !== 'undefined' && /Android/i.test(navigator.userAgent);
    const hasNativeBridge = Boolean(
      win.Android?.startFloatingAndLaunchGame ||
        win.Android?.launchApp ||
        win.Capacitor?.isNativePlatform?.()
    );
    const isInIframe = typeof window !== 'undefined' && window.self !== window.top;

    // Web preview (non-Android or embedded preview iframe without native APK bridge)
    if (!hasNativeBridge && (!isAndroidUa || isInIframe)) {
      setLaunchStatus('Install ClipKaro APK to launch game directly, preview cannot open game app');
      return;
    }

    if (!effectivePackageName) {
      setLaunchStatus('Enter an Android package name (e.g. com.pubg.imobile) to launch.');
      return;
    }

    const playStoreUrl = `https://play.google.com/store/apps/details?id=${encodeURIComponent(
      effectivePackageName
    )}`;

    if (win.Android?.startFloatingAndLaunchGame) {
      const outcome = win.Android.startFloatingAndLaunchGame(
        effectivePackageName,
        playStoreUrl,
        targetTitle
      );
      if (outcome === 'overlay_required') {
        setLaunchStatus(
          `Permission Required: Enable Display over other apps to show the Floating CLIP bubble over ${targetTitle}.`
        );
      } else {
        setLaunchStatus(
          `Starting Floating CLIP Service and launching ${targetTitle} (${effectivePackageName})…`
        );
      }
      return;
    }

    if (win.Android?.launchApp) {
      if (win.Android.canDrawOverlays && !win.Android.canDrawOverlays()) {
        win.Android.requestOverlayPermission?.();
        setLaunchStatus(
          `Permission Required: Enable Display over other apps to show the Floating CLIP bubble over ${targetTitle}.`
        );
        return;
      }
      const launched = win.Android.launchApp(effectivePackageName, playStoreUrl);
      setLaunchStatus(
        launched
          ? `Launching ${targetTitle}…`
          : `Opening Google Play Store for ${targetTitle}…`
      );
      return;
    }

    // Android Intent URI: opens installed app directly or falls back to Google Play Store page
    const intentUri = `intent:#Intent;action=android.intent.action.MAIN;category=android.intent.category.LAUNCHER;package=${encodeURIComponent(
      effectivePackageName
    )};S.browser_fallback_url=${encodeURIComponent(playStoreUrl)};end`;

    setLaunchStatus(`Launching ${targetTitle} (${effectivePackageName})…`);
    window.location.href = intentUri;
  };

  return (
    <div className="space-y-8">
      <div className="flex flex-col gap-2 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <h1 className="font-display text-2xl font-bold tracking-tight text-white">My Games</h1>
          <p className="mt-1 text-sm text-slate-400">
            Select a game to launch, manage custom titles, or jump straight into cutting highlights.
          </p>
        </div>
      </div>

      {/* Add Custom Game Bar */}
      <form
        onSubmit={handleAddSubmit}
        className="flex flex-col gap-3 rounded-xl border border-slate-800 bg-[#121722] p-4 sm:flex-row sm:items-end"
      >
        <div className="flex-1 space-y-1.5">
          <label htmlFor="custom-game-name" className="block text-xs font-semibold text-slate-300">
            Add Game Title
          </label>
          <input
            id="custom-game-name"
            type="text"
            value={newName}
            onChange={(e) => setNewName(e.target.value)}
            placeholder="e.g. Apex Legends, Counter-Strike 2"
            className="w-full rounded-lg border border-slate-700/80 bg-[#0B0E14] px-3.5 py-2 text-sm text-white placeholder:text-slate-500 focus:border-rose-500 focus:outline-none"
          />
        </div>
        <div className="sm:w-56 space-y-1.5">
          <label htmlFor="custom-game-genre" className="block text-xs font-semibold text-slate-300">
            Genre
          </label>
          <input
            id="custom-game-genre"
            type="text"
            value={newGenre}
            onChange={(e) => setNewGenre(e.target.value)}
            className="w-full rounded-lg border border-slate-700/80 bg-[#0B0E14] px-3.5 py-2 text-sm text-white focus:border-rose-500 focus:outline-none"
          />
        </div>
        <button
          type="submit"
          disabled={!newName.trim() || isAdding}
          className="inline-flex items-center justify-center gap-2 rounded-lg bg-rose-600 px-4 py-2 text-sm font-semibold text-white hover:bg-rose-500 disabled:opacity-50 whitespace-nowrap shrink-0"
        >
          <Plus className="h-4 w-4" aria-hidden="true" />
          <span>Add Game</span>
        </button>
      </form>

      {/* Games Grid */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {allDisplayedGames.map((game) => {
          const isCustomLauncher = game.id === CUSTOM_GAME_CARD.id;
          const count = isCustomLauncher
            ? clips.filter((c) => !games.some((g) => g.name === c.gameTag)).length
            : clips.filter((c) => c.gameTag === game.name).length;

          return (
            <article
              key={game.id}
              className="flex flex-col justify-between gap-4 rounded-xl border border-slate-800 bg-[#121722] p-4"
            >
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-center gap-3 min-w-0">
                  <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-lg border border-slate-700/80 bg-[#0B0E14]">
                    {renderGameIcon(game.iconKey)}
                  </span>
                  <div className="min-w-0">
                    <h2 className="font-display text-base font-semibold text-white truncate">
                      {game.name}
                    </h2>
                    <div className="mt-0.5 flex items-center gap-1.5 text-xs text-slate-400 tabular-nums">
                      <span className="truncate">{game.genre}</span>
                      {!isCustomLauncher && (
                        <>
                          <span aria-hidden="true">·</span>
                          <span className="shrink-0">
                            {count} {count === 1 ? 'clip' : 'clips'}
                          </span>
                        </>
                      )}
                    </div>
                  </div>
                </div>

                {game.isCustom && (
                  <button
                    type="button"
                    onClick={() => onDeleteCustomGame(game.id)}
                    aria-label={`Remove ${game.name}`}
                    className="rounded p-1 text-slate-500 hover:bg-slate-800 hover:text-rose-300 shrink-0"
                  >
                    <Trash2 className="h-3.5 w-3.5" aria-hidden="true" />
                  </button>
                )}
              </div>

              <button
                type="button"
                onClick={() => handleOpenGame(game)}
                className="inline-flex w-full items-center justify-center gap-2 rounded-lg bg-rose-600 px-4 py-2.5 text-sm font-semibold text-white transition-colors hover:bg-rose-500 whitespace-nowrap"
              >
                <Gamepad2 className="h-4 w-4" aria-hidden="true" />
                <span>Open Game</span>
              </button>
            </article>
          );
        })}
      </div>

      {/* Playable Creator Mini-Game */}
      <section className="rounded-xl border border-slate-800 bg-[#121722] p-5 sm:p-6 space-y-4">
        <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex items-center gap-3">
            <span className="flex h-10 w-10 items-center justify-center rounded-lg bg-rose-500/15 text-rose-400">
              <Gamepad2 className="h-5 w-5" aria-hidden="true" />
            </span>
            <div>
              <h2 className="font-display text-base font-bold text-white">
                Clip Timing Mini-Game
              </h2>
              <p className="text-xs text-slate-400">{lastResult}</p>
            </div>
          </div>
          <div className="flex items-center gap-4 text-xs text-slate-300 tabular-nums">
            <span>Streak: {streak}</span>
            <span aria-hidden="true">·</span>
            <span>Best: {bestStreak}</span>
          </div>
        </div>

        <div className="relative h-10 w-full overflow-hidden rounded-lg border border-slate-800 bg-[#0B0E14]">
          <div
            className="absolute inset-y-0 bg-rose-500/25 border-x border-rose-500/60"
            style={{
              left: `${targetStart * 100}%`,
              width: '16%',
            }}
          />
          <div
            className="absolute inset-y-1 w-1.5 rounded-full bg-white shadow"
            style={{ left: `calc(${cursorPos * 100}% - 3px)` }}
          />
        </div>

        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2.5">
            <button
              type="button"
              onClick={handleHitTarget}
              className="inline-flex items-center gap-2 rounded-lg bg-rose-600 px-4 py-2 text-sm font-semibold text-white hover:bg-rose-500"
            >
              <Target className="h-4 w-4" aria-hidden="true" />
              <span>{isPlayingMini ? 'Hit Target' : 'Start Challenge'}</span>
            </button>
            {isPlayingMini && (
              <button
                type="button"
                onClick={() => setIsPlayingMini(false)}
                className="rounded-lg border border-slate-700 bg-[#0B0E14] px-3.5 py-2 text-sm font-medium text-slate-300 hover:text-white"
              >
                Pause
              </button>
            )}
          </div>

          <button
            type="button"
            disabled={isSavingReplay}
            onClick={handleSaveMiniGameReplay}
            className="inline-flex items-center gap-2 rounded-lg border border-slate-700 bg-[#0B0E14] px-3.5 py-2 text-xs font-semibold text-slate-200 hover:border-slate-500 hover:text-white disabled:opacity-60"
          >
            <Sparkles className="h-3.5 w-3.5 text-rose-400" aria-hidden="true" />
            <span>
              {isSavingReplay ? `Saving Replay (${replayPct}%)` : 'Save 10s Highlight to My Clips'}
            </span>
          </button>
        </div>
      </section>

      {/* Open Game / Launch Game Modal */}
      {openedGame && (
        <div
          role="dialog"
          aria-modal="true"
          aria-labelledby="open-game-modal-title"
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4 backdrop-blur-sm"
        >
          <div className="w-full max-w-md rounded-xl border border-slate-800 bg-[#121722] p-6 shadow-2xl space-y-5">
            <div className="flex items-start justify-between gap-4">
              <div className="flex items-center gap-3">
                <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl border border-slate-700 bg-[#0B0E14]">
                  {renderGameIcon(openedGame.iconKey)}
                </span>
                <div>
                  <h2 id="open-game-modal-title" className="font-display text-lg font-bold text-white">
                    {openedGame.name}
                  </h2>
                  <p className="text-xs text-slate-400">{openedGame.genre}</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setOpenedGame(null)}
                aria-label="Close game dialog"
                className="rounded-lg p-1.5 text-slate-400 hover:bg-slate-800 hover:text-white"
              >
                <X className="h-5 w-5" aria-hidden="true" />
              </button>
            </div>

            {openedGame.id === CUSTOM_GAME_CARD.id && (
              <div className="space-y-3 rounded-lg border border-slate-800 bg-[#0B0E14] p-4">
                <div className="space-y-1.5">
                  <label htmlFor="launch-custom-name" className="block text-xs font-semibold text-slate-300">
                    Custom Game Name
                  </label>
                  <input
                    id="launch-custom-name"
                    type="text"
                    value={customLaunchName}
                    onChange={(e) => setCustomLaunchName(e.target.value)}
                    placeholder="e.g. Apex Legends"
                    className="w-full rounded-lg border border-slate-700 bg-[#121722] px-3 py-2 text-sm text-white placeholder:text-slate-500 focus:border-rose-500 focus:outline-none"
                  />
                </div>
                <div className="space-y-1.5">
                  <label htmlFor="launch-custom-package" className="block text-xs font-semibold text-slate-300">
                    Android Package Name
                  </label>
                  <input
                    id="launch-custom-package"
                    type="text"
                    value={customLaunchUrl}
                    onChange={(e) => setCustomLaunchUrl(e.target.value)}
                    placeholder="e.g. com.ea.gp.apexlegendsmobilefps"
                    className="w-full rounded-lg border border-slate-700 bg-[#121722] px-3 py-2 text-sm text-white placeholder:text-slate-500 focus:border-rose-500 focus:outline-none"
                  />
                </div>
              </div>
            )}

            <div className="space-y-2.5">
              <button
                type="button"
                onClick={handleLaunchGame}
                className="inline-flex w-full items-center justify-center gap-2 rounded-lg bg-rose-600 px-4 py-3 text-sm font-bold text-white transition-colors hover:bg-rose-500"
              >
                <Rocket className="h-4 w-4" aria-hidden="true" />
                <span>Launch Game</span>
              </button>

              <div className="grid grid-cols-2 gap-2.5">
                <button
                  type="button"
                  onClick={() => {
                    const targetName = effectiveLaunchTitle;
                    setOpenedGame(null);
                    onViewGameClips(targetName);
                  }}
                  className="inline-flex items-center justify-center gap-1.5 rounded-lg border border-slate-700 bg-[#0B0E14] px-3 py-2 text-xs font-semibold text-slate-200 hover:border-slate-500 hover:text-white"
                >
                  <Film className="h-3.5 w-3.5" aria-hidden="true" />
                  <span>View Clips</span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    const targetName = effectiveLaunchTitle;
                    setOpenedGame(null);
                    onCutClipForGame(targetName);
                  }}
                  className="inline-flex items-center justify-center gap-1.5 rounded-lg border border-slate-700 bg-[#0B0E14] px-3 py-2 text-xs font-semibold text-slate-200 hover:border-slate-500 hover:text-white"
                >
                  <Scissors className="h-3.5 w-3.5" aria-hidden="true" />
                  <span>Cut Clip</span>
                </button>
              </div>
            </div>

            {launchStatus && (
              <div className="rounded-lg border border-emerald-500/40 bg-emerald-950/25 px-3.5 py-2.5 text-xs text-emerald-200">
                {launchStatus}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

import { useEffect, useMemo, useRef, useState } from 'react';
import {
  CheckCircle2,
  Flame,
  Music,
  Play,
  Scissors,
  Sparkles,
  Wand2,
  X,
} from 'lucide-react';
import { ClipItem } from '../types/clipkaro';
import { AiAutoEditAnalysis } from '../utils/aiAutoEditor';
import { formatSeconds } from '../utils/mediaGenerators';
import { saveVideoToNativeClipKaroFolder } from '../utils/androidPermissions';
import { combineCssFilters, getAspectContainerClass } from '../utils/videoEditorPresets';
import { calculateViralScore } from '../utils/viralScore';

interface AiAutoEditModalProps {
  originalClip: ClipItem;
  analysis: AiAutoEditAnalysis;
  onSaveClip: (clip: ClipItem) => Promise<void>;
  onClose: () => void;
  onCompleteNotice: (message: string) => void;
}

export function AiAutoEditModal({
  originalClip,
  analysis,
  onSaveClip,
  onClose,
  onCompleteNotice,
}: AiAutoEditModalProps) {
  const [activeVersion, setActiveVersion] = useState<'ai' | 'original'>('ai');
  const [isSaving, setIsSaving] = useState<boolean>(false);

  const [origVideoUrl, setOrigVideoUrl] = useState<string>('');
  const [aiVideoUrl, setAiVideoUrl] = useState<string>('');
  const [aiMusicUrl, setAiMusicUrl] = useState<string | null>(null);

  const videoRef = useRef<HTMLVideoElement | null>(null);
  const musicAudioRef = useRef<HTMLAudioElement | null>(null);

  const activeClip = activeVersion === 'ai' ? analysis.editedClip : originalClip;

  const originalViral = useMemo(() => calculateViralScore(originalClip), [originalClip]);
  const aiViral = useMemo(() => calculateViralScore(analysis.editedClip), [analysis.editedClip]);

  useEffect(() => {
    const oUrl = URL.createObjectURL(originalClip.videoBlob);
    setOrigVideoUrl(oUrl);
    const sameBlob = analysis.editedClip.videoBlob === originalClip.videoBlob;
    const aUrl = sameBlob ? oUrl : URL.createObjectURL(analysis.editedClip.videoBlob);
    setAiVideoUrl(aUrl);
    const mUrl = analysis.editedClip.musicBlob
      ? URL.createObjectURL(analysis.editedClip.musicBlob)
      : null;
    setAiMusicUrl(mUrl);

    return () => {
      URL.revokeObjectURL(oUrl);
      if (!sameBlob) URL.revokeObjectURL(aUrl);
      if (mUrl) URL.revokeObjectURL(mUrl);
    };
  }, [originalClip, analysis]);

  useEffect(() => {
    const v = videoRef.current;
    const m = musicAudioRef.current;
    if (m) {
      m.pause();
      m.currentTime = 0;
      m.volume = analysis.editedClip.musicVolume ?? 0.45;
    }
    if (v) {
      v.volume = activeClip.originalVolume ?? 1;
      const start = Math.max(0, activeClip.trimStart || 0);
      if (v.readyState >= 1) {
        v.currentTime = start;
      }
      v.play().catch(() => undefined);
    }
  }, [activeVersion, activeClip, analysis.editedClip.musicVolume]);

  const handleLoadedMetadata = () => {
    const v = videoRef.current;
    if (!v) return;
    if (activeClip.trimStart > 0 && activeClip.trimStart < v.duration) {
      v.currentTime = activeClip.trimStart;
    }
    v.volume = activeClip.originalVolume ?? 1;
    v.play().catch(() => undefined);
  };

  const handlePlay = () => {
    const v = videoRef.current;
    if (!v) return;
    if (activeVersion === 'ai' && musicAudioRef.current) {
      const offset = Math.max(0, v.currentTime - activeClip.trimStart);
      musicAudioRef.current.currentTime =
        musicAudioRef.current.duration > 0 ? offset % musicAudioRef.current.duration : 0;
      musicAudioRef.current.play().catch(() => undefined);
    }
  };

  const handlePause = () => {
    musicAudioRef.current?.pause();
  };

  const handleTimeUpdate = () => {
    const v = videoRef.current;
    if (!v) return;
    if (activeClip.trimEnd > activeClip.trimStart && v.currentTime >= activeClip.trimEnd) {
      v.pause();
      v.currentTime = activeClip.trimStart;
      musicAudioRef.current?.pause();
    }
  };

  const handleSaveAiVersion = async (replaceOriginal: boolean) => {
    setIsSaving(true);
    try {
      const clipToSave: ClipItem = replaceOriginal
        ? {
            ...analysis.editedClip,
            id: originalClip.id,
            title: originalClip.title,
          }
        : analysis.editedClip;

      await onSaveClip(clipToSave);
      if (clipToSave.nativeFileName) {
        await saveVideoToNativeClipKaroFolder(clipToSave.nativeFileName, clipToSave.videoBlob).catch(
          () => undefined
        );
      }
      onCompleteNotice(
        replaceOriginal
          ? `Replaced "${originalClip.title}" with AI Edited ${analysis.cutDurationSec}s Highlight (${aiViral.score}/100 Viral Score)!`
          : `Saved AI Edited ${analysis.cutDurationSec}s Highlight as new clip (Original kept safe)!`
      );
      onClose();
    } finally {
      setIsSaving(false);
    }
  };

  const activeSrc = activeVersion === 'ai' ? aiVideoUrl : origVideoUrl;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="ai-auto-edit-title"
      className="fixed inset-0 z-[70] flex items-center justify-center bg-black/85 p-3 sm:p-4 backdrop-blur-sm"
    >
      <div className="w-full max-w-4xl max-h-[94vh] overflow-y-auto rounded-2xl border border-slate-800 bg-[#121722] shadow-2xl">
        {/* Header */}
        <div className="flex items-start justify-between gap-4 border-b border-slate-800 px-5 py-4">
          <div className="min-w-0">
            <div className="inline-flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider text-amber-400">
              <Wand2 className="h-3.5 w-3.5" aria-hidden="true" />
              <span>AI Auto Editing · Choose Version to Save</span>
            </div>
            <h2
              id="ai-auto-edit-title"
              className="mt-0.5 font-display text-lg font-bold text-white truncate"
            >
              {originalClip.title}
            </h2>
            <p className="text-xs text-slate-400">
              AI detected <span className="font-semibold text-rose-300">{analysis.detectedMoment}</span> at{' '}
              <span className="font-mono text-white">{formatSeconds(analysis.peakTimestampSec)}</span> · Auto-cut{' '}
              <span className="font-mono text-white">{analysis.cutDurationSec}s</span> ({formatSeconds(analysis.cutStartSec)}–{formatSeconds(analysis.cutEndSec)})
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close AI Auto Edit"
            className="rounded-lg p-2 text-slate-400 hover:bg-slate-800 hover:text-white shrink-0"
          >
            <X className="h-5 w-5" aria-hidden="true" />
          </button>
        </div>

        {/* Version Switcher Cards (Original vs AI Edited) */}
        <div className="grid grid-cols-1 gap-3 border-b border-slate-800 bg-[#0B0E14]/70 p-4 sm:grid-cols-2">
          <button
            type="button"
            onClick={() => setActiveVersion('original')}
            className={`flex items-center justify-between gap-3 rounded-xl border p-3 text-left transition-colors ${
              activeVersion === 'original'
                ? 'border-sky-400 bg-sky-950/30'
                : 'border-slate-800 bg-[#121722] hover:border-slate-600'
            }`}
          >
            <div className="min-w-0">
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold uppercase tracking-wider text-slate-300">
                  1. Original Version
                </span>
                {activeVersion === 'original' && (
                  <span className="rounded bg-sky-500/20 px-1.5 py-0.5 text-[10px] font-bold text-sky-300">
                    Playing
                  </span>
                )}
              </div>
              <div className="mt-1 text-xs text-slate-400 tabular-nums">
                {originalClip.durationSec}s · {originalClip.musicName ? 'Has Music' : 'Raw Audio'} ·{' '}
                {originalClip.filterPreset && originalClip.filterPreset !== 'none'
                  ? originalClip.filterPreset
                  : 'No Filter'}
              </div>
            </div>
            <div className="shrink-0 text-right">
              <div className="font-mono text-sm font-bold text-slate-200 tabular-nums">
                {originalViral.score}/100
              </div>
              <div className="text-[10px] text-slate-400">Viral Score</div>
            </div>
          </button>

          <button
            type="button"
            onClick={() => setActiveVersion('ai')}
            className={`flex items-center justify-between gap-3 rounded-xl border p-3 text-left transition-colors ${
              activeVersion === 'ai'
                ? 'border-amber-400 bg-amber-950/30'
                : 'border-slate-800 bg-[#121722] hover:border-slate-600'
            }`}
          >
            <div className="min-w-0">
              <div className="flex items-center gap-2">
                <Sparkles className="h-3.5 w-3.5 text-amber-400 shrink-0" aria-hidden="true" />
                <span className="text-xs font-bold uppercase tracking-wider text-amber-300">
                  2. AI Edited (Best {analysis.cutDurationSec}s)
                </span>
                {activeVersion === 'ai' && (
                  <span className="rounded bg-amber-500/20 px-1.5 py-0.5 text-[10px] font-bold text-amber-200">
                    Playing
                  </span>
                )}
              </div>
              <div className="mt-1 text-xs text-slate-300 truncate">
                {analysis.detectedMoment} · Cinematic + Trending Music + "{analysis.autoCaption}"
              </div>
            </div>
            <div className="shrink-0 text-right">
              <div className="font-mono text-sm font-bold text-emerald-300 tabular-nums">
                {aiViral.score}/100
              </div>
              <div className="text-[10px] text-emerald-400">Boosted</div>
            </div>
          </button>
        </div>

        {/* Live Comparison Player */}
        <div className="bg-[#06080D] p-3">
          <div
            className={`relative overflow-hidden rounded-lg bg-black ${getAspectContainerClass(
              activeClip.aspectRatio ?? '16:9'
            )}`}
          >
            {activeSrc && (
              <video
                key={activeVersion}
                ref={videoRef}
                src={activeSrc}
                controls
                playsInline
                onLoadedMetadata={handleLoadedMetadata}
                onPlay={handlePlay}
                onPause={handlePause}
                onTimeUpdate={handleTimeUpdate}
                style={{
                  filter: combineCssFilters(activeClip.filterPreset, activeClip.effectMode),
                }}
                className={`h-full w-full ${
                  activeClip.fitMode === 'fit' ? 'object-contain' : 'object-cover'
                }`}
              />
            )}

            {activeClip.effectMode === 'cinematic' && (
              <>
                <div className="pointer-events-none absolute inset-x-0 top-0 h-[10%] bg-black" />
                <div className="pointer-events-none absolute inset-x-0 bottom-0 h-[10%] bg-black" />
              </>
            )}

            {activeClip.autoCaption && (
              <div className="pointer-events-none absolute inset-x-0 bottom-12 flex justify-center px-4">
                <span className="rounded bg-black/90 px-3 py-1 text-xs font-extrabold text-white shadow-lg border border-amber-400/50">
                  {activeClip.autoCaption}
                </span>
              </div>
            )}

            <div className="pointer-events-none absolute top-3 left-3 inline-flex items-center gap-1.5 rounded-md bg-black/75 px-2.5 py-1 text-[11px] font-bold text-white">
              <Play className="h-3 w-3 fill-current text-rose-400" aria-hidden="true" />
              <span>
                {activeVersion === 'ai'
                  ? `AI Edited · ${analysis.cutDurationSec}s Cinematic`
                  : `Original · ${originalClip.durationSec}s`}
              </span>
            </div>
          </div>

          {aiMusicUrl && <audio ref={musicAudioRef} src={aiMusicUrl} loop className="hidden" />}
        </div>

        {/* AI Enhancements Summary + Choose Which Version to Save */}
        <div className="p-5 space-y-4">
          <div className="grid grid-cols-1 gap-2.5 sm:grid-cols-4 text-xs">
            <div className="rounded-lg border border-slate-800 bg-[#0B0E14] p-2.5">
              <div className="flex items-center gap-1.5 font-bold text-rose-300">
                <Scissors className="h-3.5 w-3.5" aria-hidden="true" />
                <span>Best Moment Cut</span>
              </div>
              <div className="mt-0.5 text-slate-300">
                {analysis.detectedMoment} · {analysis.cutDurationSec}s
              </div>
            </div>
            <div className="rounded-lg border border-slate-800 bg-[#0B0E14] p-2.5">
              <div className="flex items-center gap-1.5 font-bold text-amber-300">
                <Music className="h-3.5 w-3.5" aria-hidden="true" />
                <span>Trending Music</span>
              </div>
              <div className="mt-0.5 text-slate-300 truncate">{analysis.musicName}</div>
            </div>
            <div className="rounded-lg border border-slate-800 bg-[#0B0E14] p-2.5">
              <div className="flex items-center gap-1.5 font-bold text-sky-300">
                <Sparkles className="h-3.5 w-3.5" aria-hidden="true" />
                <span>Auto Caption + Filter</span>
              </div>
              <div className="mt-0.5 text-slate-300 truncate">
                "{analysis.autoCaption}" · Cinematic
              </div>
            </div>
            <div className="rounded-lg border border-emerald-500/30 bg-emerald-950/20 p-2.5">
              <div className="flex items-center gap-1.5 font-bold text-emerald-300">
                <Flame className="h-3.5 w-3.5" aria-hidden="true" />
                <span>AI Viral Score</span>
              </div>
              <div className="mt-0.5 text-emerald-200 font-semibold">
                {aiViral.score}/100 · {aiViral.verdict}
              </div>
            </div>
          </div>

          <div className="flex flex-col-reverse gap-2.5 sm:flex-row sm:items-center sm:justify-between border-t border-slate-800 pt-4">
            <button
              type="button"
              disabled={isSaving}
              onClick={() => {
                onCompleteNotice(`Kept Original clip "${originalClip.title}" unchanged.`);
                onClose();
              }}
              className="rounded-lg border border-slate-700 bg-[#0B0E14] px-4 py-2.5 text-xs font-semibold text-slate-300 hover:bg-slate-800 hover:text-white"
            >
              Keep Original Only
            </button>

            <div className="flex flex-wrap items-center gap-2">
              <button
                type="button"
                disabled={isSaving}
                onClick={() => void handleSaveAiVersion(true)}
                className="rounded-lg border border-amber-500/50 bg-amber-950/30 px-4 py-2.5 text-xs font-bold text-amber-200 hover:bg-amber-900/40 disabled:opacity-60"
              >
                Replace Original with AI Edited
              </button>
              <button
                type="button"
                disabled={isSaving}
                onClick={() => void handleSaveAiVersion(false)}
                className="inline-flex items-center gap-1.5 rounded-lg bg-rose-600 px-4 py-2.5 text-xs font-bold text-white hover:bg-rose-500 disabled:opacity-60"
              >
                <CheckCircle2 className="h-4 w-4" aria-hidden="true" />
                <span>{isSaving ? 'Saving…' : 'Save AI Edited (New Clip)'}</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

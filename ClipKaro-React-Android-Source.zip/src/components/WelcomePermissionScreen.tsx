import { useEffect, useState } from 'react';
import {
  AlertTriangle,
  BatteryCharging,
  CheckCircle2,
  Eye,
  FolderOpen,
  Layers,
  Mic,
  RefreshCw,
  ShieldAlert,
} from 'lucide-react';
import {
  ClipKaroPermissionState,
  PermissionKind,
  markPermissionSetupDone,
  requestBatteryPermission,
  requestMicrophonePermission,
  requestOverlayPermission,
  requestStoragePermission,
  requestUsageAccessPermission,
  setPreviewPermissionDenied,
} from '../utils/androidPermissions';

interface WelcomePermissionScreenProps {
  permissionState: ClipKaroPermissionState;
  onRefreshPermissions: () => ClipKaroPermissionState;
  onComplete: () => void;
}

type PermissionFlags = Record<PermissionKind, boolean>;

const INITIAL_FLAGS: PermissionFlags = {
  overlay: false,
  storage: false,
  microphone: false,
  battery: false,
  usageAccess: false,
};

export function WelcomePermissionScreen({
  permissionState,
  onRefreshPermissions,
  onComplete,
}: WelcomePermissionScreenProps) {
  const [awaitingReturn, setAwaitingReturn] = useState<PermissionFlags>(INITIAL_FLAGS);
  const [stillDenied, setStillDenied] = useState<PermissionFlags>(INITIAL_FLAGS);
  const [micNote, setMicNote] = useState<string | null>(null);

  const allGranted =
    permissionState.overlay &&
    permissionState.storage &&
    permissionState.microphone &&
    permissionState.battery &&
    permissionState.usageAccess;

  // Automatically save SharedPreferences & enter Home Screen once permissions are granted
  useEffect(() => {
    if (allGranted) {
      markPermissionSetupDone(true);
      onComplete();
    }
  }, [allGranted, onComplete]);

  // Auto re-check all permissions whenever user returns from Android Settings
  useEffect(() => {
    const checkReturnFromSettings = () => {
      const latest = onRefreshPermissions();

      setAwaitingReturn((prevAwaiting) => {
        const nextAwaiting: PermissionFlags = { ...prevAwaiting };
        const deniedUpdates: Partial<PermissionFlags> = {};

        (
          [
            'overlay',
            'storage',
            'microphone',
            'battery',
            'usageAccess',
          ] as PermissionKind[]
        ).forEach((key) => {
          if (latest[key]) {
            nextAwaiting[key] = false;
            deniedUpdates[key] = false;
          } else if (prevAwaiting[key]) {
            nextAwaiting[key] = false;
            deniedUpdates[key] = true;
          }
        });

        if (Object.keys(deniedUpdates).length > 0) {
          setStillDenied((prevDenied) => ({ ...prevDenied, ...deniedUpdates }));
        }

        return nextAwaiting;
      });
    };

    const handleVisibility = () => {
      if (document.visibilityState === 'visible') {
        checkReturnFromSettings();
      }
    };

    window.addEventListener('focus', checkReturnFromSettings);
    window.addEventListener('clipkaro-permissions-updated', checkReturnFromSettings);
    document.addEventListener('visibilitychange', handleVisibility);

    return () => {
      window.removeEventListener('focus', checkReturnFromSettings);
      window.removeEventListener('clipkaro-permissions-updated', checkReturnFromSettings);
      document.removeEventListener('visibilitychange', handleVisibility);
    };
  }, [onRefreshPermissions]);

  const handleAllowFloatingButton = () => {
    setStillDenied((prev) => ({ ...prev, overlay: false }));
    const { awaitingNativeSettings } = requestOverlayPermission();
    if (awaitingNativeSettings) {
      setAwaitingReturn((prev) => ({ ...prev, overlay: true }));
    } else {
      onRefreshPermissions();
    }
  };

  const handleAllowStorage = () => {
    setStillDenied((prev) => ({ ...prev, storage: false }));
    const { awaitingNativeSettings } = requestStoragePermission();
    if (awaitingNativeSettings) {
      setAwaitingReturn((prev) => ({ ...prev, storage: true }));
    } else {
      onRefreshPermissions();
    }
  };

  const handleAllowMicrophone = async () => {
    const openSettingsAgain = stillDenied.microphone;
    setStillDenied((prev) => ({ ...prev, microphone: false }));
    const { awaitingNativeSettings } = await requestMicrophonePermission(openSettingsAgain);
    if (awaitingNativeSettings) {
      setAwaitingReturn((prev) => ({ ...prev, microphone: true }));
    } else {
      const latest = onRefreshPermissions();
      if (!latest.isNativeAndroid && latest.microphone) {
        setMicNote('Microphone access ready for voiceover and in-game chat.');
      }
    }
  };

  const handleAllowBattery = () => {
    setStillDenied((prev) => ({ ...prev, battery: false }));
    const { awaitingNativeSettings } = requestBatteryPermission();
    if (awaitingNativeSettings) {
      setAwaitingReturn((prev) => ({ ...prev, battery: true }));
    } else {
      onRefreshPermissions();
    }
  };

  const handleAllowUsageAccess = () => {
    setStillDenied((prev) => ({ ...prev, usageAccess: false }));
    const { awaitingNativeSettings } = requestUsageAccessPermission();
    if (awaitingNativeSettings) {
      setAwaitingReturn((prev) => ({ ...prev, usageAccess: true }));
    } else {
      onRefreshPermissions();
    }
  };

  const handlePreviewDeny = (kind: PermissionKind) => {
    setPreviewPermissionDenied(kind);
    setStillDenied((prev) => ({ ...prev, [kind]: true }));
    onRefreshPermissions();
  };

  const handleContinueClick = () => {
    if (!permissionState.overlay) {
      setStillDenied((prev) => ({ ...prev, overlay: true }));
      return;
    }
    markPermissionSetupDone(true);
    onComplete();
  };

  const handleContinueLimited = () => {
    markPermissionSetupDone(true);
    onComplete();
  };

  return (
    <div className="min-h-screen bg-[#0B0E14] text-slate-100 flex items-center justify-center px-4 py-8">
      <div className="w-full max-w-2xl rounded-2xl border border-slate-800 bg-[#121722] p-6 sm:p-8 shadow-2xl space-y-6">
        {/* Header */}
        <div className="space-y-2">
          <div className="inline-flex items-center gap-2 rounded-lg border border-rose-500/30 bg-rose-500/10 px-3 py-1 text-xs font-semibold text-rose-300">
            <span>ClipKaro First-Launch Setup</span>
          </div>
          <h1 className="font-display text-2xl sm:text-3xl font-bold tracking-tight text-white">
            Welcome to ClipKaro
          </h1>
          <p className="text-sm text-slate-400">
            Grant permissions directly via Android deep links so you never have to search Settings manually. Screen Capture is NOT asked here — it is requested per-app only when you tap Record.
          </p>
        </div>

        {/* Red Warning Banner if Overlay Permission Denied */}
        {stillDenied.overlay && !permissionState.overlay && (
          <div
            role="alert"
            className="flex flex-col gap-3 rounded-xl border border-rose-500/70 bg-rose-950/50 p-4 sm:flex-row sm:items-center sm:justify-between"
          >
            <div className="flex items-start gap-3">
              <ShieldAlert className="h-5 w-5 text-rose-400 shrink-0 mt-0.5" aria-hidden="true" />
              <div>
                <p className="text-sm font-bold text-rose-200">
                  Floating button will not appear in BGMI without this permission
                </p>
                <p className="mt-0.5 text-xs text-rose-300/90">
                  Tap Open Settings Again to jump directly to ClipKaro&rsquo;s Display over other apps toggle.
                </p>
              </div>
            </div>
            <button
              type="button"
              onClick={handleAllowFloatingButton}
              className="inline-flex items-center justify-center gap-1.5 rounded-lg bg-rose-600 px-3.5 py-2 text-xs font-bold text-white hover:bg-rose-500 shrink-0 whitespace-nowrap"
            >
              <RefreshCw className="h-3.5 w-3.5" aria-hidden="true" />
              <span>Open Settings Again</span>
            </button>
          </div>
        )}

        {/* 4 Permission Cards */}
        <div className="space-y-3.5">
          {/* 1. Display Over Other Apps — Most Important */}
          <section
            className={`rounded-xl border p-4 sm:p-5 transition-colors ${
              permissionState.overlay
                ? 'border-emerald-500/40 bg-emerald-950/20'
                : 'border-rose-500/50 bg-[#0B0E14]'
            }`}
          >
            <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
              <div className="flex items-start gap-3.5">
                <span
                  className={`flex h-11 w-11 shrink-0 items-center justify-center rounded-xl ${
                    permissionState.overlay
                      ? 'bg-emerald-500/15 text-emerald-400'
                      : 'bg-rose-500/15 text-rose-400'
                  }`}
                >
                  <Layers className="h-5 w-5" aria-hidden="true" />
                </span>
                <div className="space-y-1">
                  <div className="flex flex-wrap items-center gap-2">
                    <h2 className="font-display text-sm sm:text-base font-bold text-white">
                      1. Display over other apps (Floating CLIP button)
                    </h2>
                    <span className="rounded bg-rose-600/20 px-2 py-0.5 text-[11px] font-bold text-rose-300">
                      Most important
                    </span>
                  </div>
                  <p className="text-xs text-slate-400">
                    Directly opens ClipKaro&rsquo;s Overlay Permission Settings page so the draggable CLIP bubble stays on top of BGMI.
                  </p>
                  {!permissionState.overlay && (
                    <p className="flex items-center gap-1.5 pt-0.5 text-xs font-semibold text-amber-300">
                      <AlertTriangle className="h-3.5 w-3.5 shrink-0" aria-hidden="true" />
                      <span>Permission Required to show CLIP button in BGMI</span>
                    </p>
                  )}
                </div>
              </div>

              <div className="flex flex-wrap items-center gap-2 shrink-0">
                {permissionState.overlay ? (
                  <span className="inline-flex items-center gap-1.5 rounded-lg border border-emerald-500/40 bg-emerald-500/15 px-3.5 py-2 text-xs font-bold text-emerald-300">
                    <CheckCircle2 className="h-4 w-4" aria-hidden="true" />
                    <span>Granted</span>
                  </span>
                ) : (
                  <>
                    <button
                      type="button"
                      onClick={handleAllowFloatingButton}
                      className="inline-flex items-center justify-center gap-2 rounded-lg bg-rose-600 px-4 py-2.5 text-xs font-bold text-white transition-colors hover:bg-rose-500 whitespace-nowrap"
                    >
                      <span>{stillDenied.overlay ? 'Open Settings Again' : 'Allow Floating Button'}</span>
                    </button>
                    {!permissionState.isNativeAndroid && (
                      <button
                        type="button"
                        onClick={() => handlePreviewDeny('overlay')}
                        className="rounded-lg border border-slate-700 bg-[#121722] px-3 py-2 text-xs font-medium text-slate-300 hover:border-rose-500/50 hover:text-rose-300"
                      >
                        Deny
                      </button>
                    )}
                  </>
                )}
              </div>
            </div>
          </section>

          {/* 2. Storage / Photos & Videos */}
          <section
            className={`rounded-xl border p-4 sm:p-5 transition-colors ${
              permissionState.storage
                ? 'border-emerald-500/40 bg-emerald-950/20'
                : 'border-slate-800 bg-[#0B0E14]'
            }`}
          >
            <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
              <div className="flex items-start gap-3.5">
                <span
                  className={`flex h-11 w-11 shrink-0 items-center justify-center rounded-xl ${
                    permissionState.storage
                      ? 'bg-emerald-500/15 text-emerald-400'
                      : 'bg-sky-500/15 text-sky-400'
                  }`}
                >
                  <FolderOpen className="h-5 w-5" aria-hidden="true" />
                </span>
                <div className="space-y-1">
                  <h2 className="font-display text-sm sm:text-base font-bold text-white">
                    2. Storage / Photos &amp; Videos
                  </h2>
                  <p className="text-xs text-slate-400">
                    Directly opens ClipKaro App Details Settings to grant Photos &amp; Videos access (<span className="font-mono text-slate-300">READ_MEDIA_VIDEO</span> &amp; <span className="font-mono text-slate-300">READ_MEDIA_IMAGES</span>).
                  </p>
                  {stillDenied.storage && !permissionState.storage && (
                    <p className="text-xs font-semibold text-rose-300">
                      Storage permission is still off in App Settings.
                    </p>
                  )}
                </div>
              </div>

              <div className="flex flex-wrap items-center gap-2 shrink-0">
                {permissionState.storage ? (
                  <span className="inline-flex items-center gap-1.5 rounded-lg border border-emerald-500/40 bg-emerald-500/15 px-3.5 py-2 text-xs font-bold text-emerald-300">
                    <CheckCircle2 className="h-4 w-4" aria-hidden="true" />
                    <span>Granted</span>
                  </span>
                ) : (
                  <>
                    <button
                      type="button"
                      onClick={handleAllowStorage}
                      className={`inline-flex items-center justify-center rounded-lg px-4 py-2.5 text-xs font-bold text-white transition-colors whitespace-nowrap ${
                        stillDenied.storage
                          ? 'bg-rose-600 hover:bg-rose-500'
                          : 'border border-slate-700 bg-slate-800 hover:bg-slate-700'
                      }`}
                    >
                      {stillDenied.storage ? 'Open Settings Again' : 'Allow Storage'}
                    </button>
                    {!permissionState.isNativeAndroid && (
                      <button
                        type="button"
                        onClick={() => handlePreviewDeny('storage')}
                        className="rounded-lg border border-slate-700 bg-[#121722] px-3 py-2 text-xs font-medium text-slate-300 hover:border-rose-500/50 hover:text-rose-300"
                      >
                        Deny
                      </button>
                    )}
                  </>
                )}
              </div>
            </div>
          </section>

          {/* 3. Microphone */}
          <section
            className={`rounded-xl border p-4 sm:p-5 transition-colors ${
              permissionState.microphone
                ? 'border-emerald-500/40 bg-emerald-950/20'
                : 'border-slate-800 bg-[#0B0E14]'
            }`}
          >
            <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
              <div className="flex items-start gap-3.5">
                <span
                  className={`flex h-11 w-11 shrink-0 items-center justify-center rounded-xl ${
                    permissionState.microphone
                      ? 'bg-emerald-500/15 text-emerald-400'
                      : 'bg-amber-500/15 text-amber-400'
                  }`}
                >
                  <Mic className="h-5 w-5" aria-hidden="true" />
                </span>
                <div className="space-y-1">
                  <h2 className="font-display text-sm sm:text-base font-bold text-white">
                    3. Microphone
                  </h2>
                  <p className="text-xs text-slate-400">
                    Requests <span className="font-mono text-slate-300">RECORD_AUDIO</span> for game sound + voiceover, and opens App Details Settings if denied.
                  </p>
                  {stillDenied.microphone && !permissionState.microphone && (
                    <p className="text-xs font-semibold text-rose-300">
                      Microphone permission is still denied in App Settings.
                    </p>
                  )}
                  {micNote && <p className="text-[11px] text-emerald-300">{micNote}</p>}
                </div>
              </div>

              <div className="flex flex-wrap items-center gap-2 shrink-0">
                {permissionState.microphone ? (
                  <span className="inline-flex items-center gap-1.5 rounded-lg border border-emerald-500/40 bg-emerald-500/15 px-3.5 py-2 text-xs font-bold text-emerald-300">
                    <CheckCircle2 className="h-4 w-4" aria-hidden="true" />
                    <span>Granted</span>
                  </span>
                ) : (
                  <>
                    <button
                      type="button"
                      onClick={handleAllowMicrophone}
                      className={`inline-flex items-center justify-center rounded-lg px-4 py-2.5 text-xs font-bold text-white transition-colors whitespace-nowrap ${
                        stillDenied.microphone
                          ? 'bg-rose-600 hover:bg-rose-500'
                          : 'border border-slate-700 bg-slate-800 hover:bg-slate-700'
                      }`}
                    >
                      {stillDenied.microphone ? 'Open Settings Again' : 'Allow Microphone'}
                    </button>
                    {!permissionState.isNativeAndroid && (
                      <button
                        type="button"
                        onClick={() => handlePreviewDeny('microphone')}
                        className="rounded-lg border border-slate-700 bg-[#121722] px-3 py-2 text-xs font-medium text-slate-300 hover:border-rose-500/50 hover:text-rose-300"
                      >
                        Deny
                      </button>
                    )}
                  </>
                )}
              </div>
            </div>
          </section>

          {/* 4. Battery / Background */}
          <section
            className={`rounded-xl border p-4 sm:p-5 transition-colors ${
              permissionState.battery
                ? 'border-emerald-500/40 bg-emerald-950/20'
                : 'border-slate-800 bg-[#0B0E14]'
            }`}
          >
            <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
              <div className="flex items-start gap-3.5">
                <span
                  className={`flex h-11 w-11 shrink-0 items-center justify-center rounded-xl ${
                    permissionState.battery
                      ? 'bg-emerald-500/15 text-emerald-400'
                      : 'bg-purple-500/15 text-purple-400'
                  }`}
                >
                  <BatteryCharging className="h-5 w-5" aria-hidden="true" />
                </span>
                <div className="space-y-1">
                  <h2 className="font-display text-sm sm:text-base font-bold text-white">
                    4. Battery / Background
                  </h2>
                  <p className="text-xs text-slate-400">
                    Directly opens ClipKaro Battery Optimization Settings so the floating CLIP service is never killed while playing BGMI.
                  </p>
                  {stillDenied.battery && !permissionState.battery && (
                    <p className="text-xs font-semibold text-rose-300">
                      Background battery exemption is still not enabled.
                    </p>
                  )}
                </div>
              </div>

              <div className="flex flex-wrap items-center gap-2 shrink-0">
                {permissionState.battery ? (
                  <span className="inline-flex items-center gap-1.5 rounded-lg border border-emerald-500/40 bg-emerald-500/15 px-3.5 py-2 text-xs font-bold text-emerald-300">
                    <CheckCircle2 className="h-4 w-4" aria-hidden="true" />
                    <span>Granted</span>
                  </span>
                ) : (
                  <>
                    <button
                      type="button"
                      onClick={handleAllowBattery}
                      className={`inline-flex items-center justify-center rounded-lg px-4 py-2.5 text-xs font-bold text-white transition-colors whitespace-nowrap ${
                        stillDenied.battery
                          ? 'bg-rose-600 hover:bg-rose-500'
                          : 'border border-slate-700 bg-slate-800 hover:bg-slate-700'
                      }`}
                    >
                      {stillDenied.battery ? 'Open Settings Again' : 'Allow Battery / Background'}
                    </button>
                    {!permissionState.isNativeAndroid && (
                      <button
                        type="button"
                        onClick={() => handlePreviewDeny('battery')}
                        className="rounded-lg border border-slate-700 bg-[#121722] px-3 py-2 text-xs font-medium text-slate-300 hover:border-rose-500/50 hover:text-rose-300"
                      >
                        Deny
                      </button>
                    )}
                  </>
                )}
              </div>
            </div>
          </section>
          {/* 5. Auto-Hide App Detection (Usage Access) */}
          <section
            className={`rounded-xl border p-4 sm:p-5 transition-colors ${
              permissionState.usageAccess
                ? 'border-emerald-500/40 bg-emerald-950/20'
                : 'border-slate-800 bg-[#0B0E14]'
            }`}
          >
            <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
              <div className="flex items-start gap-3.5">
                <span
                  className={`flex h-11 w-11 shrink-0 items-center justify-center rounded-xl ${
                    permissionState.usageAccess
                      ? 'bg-emerald-500/15 text-emerald-400'
                      : 'bg-cyan-500/15 text-cyan-400'
                  }`}
                >
                  <Eye className="h-5 w-5" aria-hidden="true" />
                </span>
                <div className="space-y-1">
                  <h2 className="font-display text-sm sm:text-base font-bold text-white">
                    5. App Detection (Auto-Hide Floating Button)
                  </h2>
                  <p className="text-xs text-slate-400">
                    Detects when you close BGMI or YouTube so the floating CLIP button automatically saves &amp; hides itself after 3 seconds.
                  </p>
                  {stillDenied.usageAccess && !permissionState.usageAccess && (
                    <p className="text-xs font-semibold text-rose-300">
                      Usage Access is still off in Settings.
                    </p>
                  )}
                </div>
              </div>

              <div className="flex flex-wrap items-center gap-2 shrink-0">
                {permissionState.usageAccess ? (
                  <span className="inline-flex items-center gap-1.5 rounded-lg border border-emerald-500/40 bg-emerald-500/15 px-3.5 py-2 text-xs font-bold text-emerald-300">
                    <CheckCircle2 className="h-4 w-4" aria-hidden="true" />
                    <span>Granted</span>
                  </span>
                ) : (
                  <>
                    <button
                      type="button"
                      onClick={handleAllowUsageAccess}
                      className={`inline-flex items-center justify-center rounded-lg px-4 py-2.5 text-xs font-bold text-white transition-colors whitespace-nowrap ${
                        stillDenied.usageAccess
                          ? 'bg-rose-600 hover:bg-rose-500'
                          : 'border border-slate-700 bg-slate-800 hover:bg-slate-700'
                      }`}
                    >
                      {stillDenied.usageAccess ? 'Open Settings Again' : 'Allow Auto-Hide'}
                    </button>
                    {!permissionState.isNativeAndroid && (
                      <button
                        type="button"
                        onClick={() => handlePreviewDeny('usageAccess')}
                        className="rounded-lg border border-slate-700 bg-[#121722] px-3 py-2 text-xs font-medium text-slate-300 hover:border-rose-500/50 hover:text-rose-300"
                      >
                        Deny
                      </button>
                    )}
                  </>
                )}
              </div>
            </div>
          </section>
        </div>

        {/* Footer Actions */}
        <div className="flex flex-col gap-3 border-t border-slate-800 pt-5 sm:flex-row sm:items-center sm:justify-between">
          <p className="text-xs text-slate-400">
            {allGranted
              ? 'All permissions granted — opening Home Screen…'
              : 'Grant Floating Button and permissions above to enter ClipKaro.'}
          </p>

          <div className="flex flex-wrap items-center gap-2.5">
            {stillDenied.overlay && !permissionState.overlay && (
              <button
                type="button"
                onClick={handleContinueLimited}
                className="rounded-lg border border-slate-700 bg-[#0B0E14] px-3.5 py-2 text-xs font-semibold text-slate-300 hover:border-slate-500 hover:text-white"
              >
                Continue Without My Games
              </button>
            )}
            <button
              type="button"
              onClick={handleContinueClick}
              className="rounded-lg bg-rose-600 px-4 py-2 text-xs font-bold text-white transition-colors hover:bg-rose-500"
            >
              Continue to Home
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

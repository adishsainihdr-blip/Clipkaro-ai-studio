import { useEffect, useState } from 'react';
import {
  AlertTriangle,
  CheckCircle2,
  FolderOpen,
  Layers,
  Mic,
  RefreshCw,
  ShieldAlert,
} from 'lucide-react';
import {
  ClipKaroPermissionState,
  markPermissionSetupDone,
  requestMicrophonePermission,
  requestOverlayPermission,
  requestStoragePermission,
  setPreviewOverlayDenied,
} from '../utils/androidPermissions';

interface WelcomePermissionScreenProps {
  permissionState: ClipKaroPermissionState;
  onRefreshPermissions: () => ClipKaroPermissionState;
  onComplete: () => void;
}

export function WelcomePermissionScreen({
  permissionState,
  onRefreshPermissions,
  onComplete,
}: WelcomePermissionScreenProps) {
  const [awaitingOverlayReturn, setAwaitingOverlayReturn] = useState(false);
  const [overlayDeniedWarning, setOverlayDeniedWarning] = useState(false);
  const [micNote, setMicNote] = useState<string | null>(null);

  const allGranted =
    permissionState.overlay && permissionState.storage && permissionState.microphone;

  // Automatically save SharedPreferences & enter Home Screen once all 3 permissions are granted
  useEffect(() => {
    if (allGranted) {
      markPermissionSetupDone(true);
      onComplete();
    }
  }, [allGranted, onComplete]);

  // Detect return from Android Settings.ACTION_MANAGE_OVERLAY_PERMISSION with Overlay still denied
  useEffect(() => {
    const checkReturnFromSettings = () => {
      const latest = onRefreshPermissions();
      if (awaitingOverlayReturn) {
        setAwaitingOverlayReturn(false);
        if (!latest.overlay) {
          setOverlayDeniedWarning(true);
        } else {
          setOverlayDeniedWarning(false);
        }
      }
    };

    const handleVisibility = () => {
      if (document.visibilityState === 'visible') {
        checkReturnFromSettings();
      }
    };

    window.addEventListener('focus', checkReturnFromSettings);
    window.addEventListener('clipkaro-permissions-updated', checkReturnFromSettings);
    document.addEventListener('visibilitychange', handleVisibility);

    return () => {
      window.removeEventListener('focus', checkReturnFromSettings);
      window.removeEventListener('clipkaro-permissions-updated', checkReturnFromSettings);
      document.removeEventListener('visibilitychange', handleVisibility);
    };
  }, [awaitingOverlayReturn, onRefreshPermissions]);

  const handleAllowFloatingButton = () => {
    setOverlayDeniedWarning(false);
    const { awaitingNativeSettings } = requestOverlayPermission();
    if (awaitingNativeSettings) {
      setAwaitingOverlayReturn(true);
    } else {
      onRefreshPermissions();
    }
  };

  const handleDenyOverlayTest = () => {
    setPreviewOverlayDenied();
    setOverlayDeniedWarning(true);
    onRefreshPermissions();
  };

  const handleAllowStorage = () => {
    requestStoragePermission();
    onRefreshPermissions();
  };

  const handleAllowMicrophone = async () => {
    await requestMicrophonePermission();
    const latest = onRefreshPermissions();
    if (!latest.isNativeAndroid && latest.microphone) {
      setMicNote('Microphone access ready for voiceover and in-game chat.');
    }
  };

  const handleContinueClick = () => {
    if (!permissionState.overlay) {
      setOverlayDeniedWarning(true);
      return;
    }
    markPermissionSetupDone(true);
    onComplete();
  };

  const handleContinueLimited = () => {
    markPermissionSetupDone(true);
    onComplete();
  };

  return (
    <div className="min-h-screen bg-[#0B0E14] text-slate-100 flex items-center justify-center px-4 py-8">
      <div className="w-full max-w-2xl rounded-2xl border border-slate-800 bg-[#121722] p-6 sm:p-8 shadow-2xl space-y-6">
        {/* Header */}
        <div className="space-y-2">
          <div className="inline-flex items-center gap-2 rounded-lg border border-rose-500/30 bg-rose-500/10 px-3 py-1 text-xs font-semibold text-rose-300">
            <span>ClipKaro First-Launch Setup</span>
          </div>
          <h1 className="font-display text-2xl sm:text-3xl font-bold tracking-tight text-white">
            Welcome to ClipKaro
          </h1>
          <p className="text-sm text-slate-400">
            Grant these 3 permissions to unlock the floating CLIP button in BGMI, video gallery picking, and game sound + voice recording.
          </p>
        </div>

        {/* Red Warning Banner if Overlay Permission Denied */}
        {overlayDeniedWarning && !permissionState.overlay && (
          <div
            role="alert"
            className="flex flex-col gap-3 rounded-xl border border-rose-500/70 bg-rose-950/50 p-4 sm:flex-row sm:items-center sm:justify-between"
          >
            <div className="flex items-start gap-3">
              <ShieldAlert className="h-5 w-5 text-rose-400 shrink-0 mt-0.5" aria-hidden="true" />
              <div>
                <p className="text-sm font-bold text-rose-200">
                  Floating button will not appear in BGMI without this permission
                </p>
                <p className="mt-0.5 text-xs text-rose-300/90">
                  Enable &ldquo;Display over other apps&rdquo; for ClipKaro to launch games and record highlights.
                </p>
              </div>
            </div>
            <button
              type="button"
              onClick={handleAllowFloatingButton}
              className="inline-flex items-center justify-center gap-1.5 rounded-lg bg-rose-600 px-3.5 py-2 text-xs font-bold text-white hover:bg-rose-500 shrink-0"
            >
              <RefreshCw className="h-3.5 w-3.5" aria-hidden="true" />
              <span>Try Again</span>
            </button>
          </div>
        )}

        {/* 3 Permission Cards */}
        <div className="space-y-3.5">
          {/* 1. Display Over Other Apps — Most Important */}
          <section
            className={`rounded-xl border p-4 sm:p-5 transition-colors ${
              permissionState.overlay
                ? 'border-emerald-500/40 bg-emerald-950/20'
                : 'border-rose-500/50 bg-[#0B0E14]'
            }`}
          >
            <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
              <div className="flex items-start gap-3.5">
                <span
                  className={`flex h-11 w-11 shrink-0 items-center justify-center rounded-xl ${
                    permissionState.overlay
                      ? 'bg-emerald-500/15 text-emerald-400'
                      : 'bg-rose-500/15 text-rose-400'
                  }`}
                >
                  <Layers className="h-5 w-5" aria-hidden="true" />
                </span>
                <div className="space-y-1">
                  <div className="flex flex-wrap items-center gap-2">
                    <h2 className="font-display text-sm sm:text-base font-bold text-white">
                      1. Display over other apps (Floating CLIP button)
                    </h2>
                    <span className="rounded bg-rose-600/20 px-2 py-0.5 text-[11px] font-bold text-rose-300">
                      Most important
                    </span>
                  </div>
                  <p className="text-xs text-slate-400">
                    Opens Android Overlay Permission Settings so the draggable CLIP button works on top of games.
                  </p>
                  {!permissionState.overlay && (
                    <p className="flex items-center gap-1.5 pt-0.5 text-xs font-semibold text-amber-300">
                      <AlertTriangle className="h-3.5 w-3.5 shrink-0" aria-hidden="true" />
                      <span>Permission Required to show CLIP button in BGMI</span>
                    </p>
                  )}
                </div>
              </div>

              <div className="flex flex-wrap items-center gap-2 shrink-0">
                {permissionState.overlay ? (
                  <span className="inline-flex items-center gap-1.5 rounded-lg border border-emerald-500/40 bg-emerald-500/15 px-3.5 py-2 text-xs font-bold text-emerald-300">
                    <CheckCircle2 className="h-4 w-4" aria-hidden="true" />
                    <span>Granted</span>
                  </span>
                ) : (
                  <>
                    <button
                      type="button"
                      onClick={handleAllowFloatingButton}
                      className="inline-flex items-center justify-center gap-2 rounded-lg bg-rose-600 px-4 py-2.5 text-xs font-bold text-white transition-colors hover:bg-rose-500 whitespace-nowrap"
                    >
                      <span>{overlayDeniedWarning ? 'Try Again' : 'Allow Floating Button'}</span>
                    </button>
                    {!permissionState.isNativeAndroid && (
                      <button
                        type="button"
                        onClick={handleDenyOverlayTest}
                        className="rounded-lg border border-slate-700 bg-[#121722] px-3 py-2 text-xs font-medium text-slate-300 hover:border-rose-500/50 hover:text-rose-300"
                      >
                        Deny
                      </button>
                    )}
                  </>
                )}
              </div>
            </div>
          </section>

          {/* 2. Storage / Photos & Videos */}
          <section
            className={`rounded-xl border p-4 sm:p-5 transition-colors ${
              permissionState.storage
                ? 'border-emerald-500/40 bg-emerald-950/20'
                : 'border-slate-800 bg-[#0B0E14]'
            }`}
          >
            <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
              <div className="flex items-start gap-3.5">
                <span
                  className={`flex h-11 w-11 shrink-0 items-center justify-center rounded-xl ${
                    permissionState.storage
                      ? 'bg-emerald-500/15 text-emerald-400'
                      : 'bg-sky-500/15 text-sky-400'
                  }`}
                >
                  <FolderOpen className="h-5 w-5" aria-hidden="true" />
                </span>
                <div className="space-y-1">
                  <h2 className="font-display text-sm sm:text-base font-bold text-white">
                    2. Storage / Photos &amp; Videos
                  </h2>
                  <p className="text-xs text-slate-400">
                    For Gallery and Saving Clips (<span className="font-mono text-slate-300">READ_MEDIA_VIDEO</span> &amp; <span className="font-mono text-slate-300">READ_MEDIA_IMAGES</span>).
                  </p>
                </div>
              </div>

              <div className="shrink-0">
                {permissionState.storage ? (
                  <span className="inline-flex items-center gap-1.5 rounded-lg border border-emerald-500/40 bg-emerald-500/15 px-3.5 py-2 text-xs font-bold text-emerald-300">
                    <CheckCircle2 className="h-4 w-4" aria-hidden="true" />
                    <span>Granted</span>
                  </span>
                ) : (
                  <button
                    type="button"
                    onClick={handleAllowStorage}
                    className="inline-flex items-center justify-center rounded-lg border border-slate-700 bg-slate-800 px-4 py-2.5 text-xs font-bold text-white transition-colors hover:bg-slate-700 whitespace-nowrap"
                  >
                    Allow Storage
                  </button>
                )}
              </div>
            </div>
          </section>

          {/* 3. Microphone */}
          <section
            className={`rounded-xl border p-4 sm:p-5 transition-colors ${
              permissionState.microphone
                ? 'border-emerald-500/40 bg-emerald-950/20'
                : 'border-slate-800 bg-[#0B0E14]'
            }`}
          >
            <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
              <div className="flex items-start gap-3.5">
                <span
                  className={`flex h-11 w-11 shrink-0 items-center justify-center rounded-xl ${
                    permissionState.microphone
                      ? 'bg-emerald-500/15 text-emerald-400'
                      : 'bg-amber-500/15 text-amber-400'
                  }`}
                >
                  <Mic className="h-5 w-5" aria-hidden="true" />
                </span>
                <div className="space-y-1">
                  <h2 className="font-display text-sm sm:text-base font-bold text-white">
                    3. Microphone
                  </h2>
                  <p className="text-xs text-slate-400">
                    For Game Sound + Voice (<span className="font-mono text-slate-300">RECORD_AUDIO</span>).
                  </p>
                  {micNote && <p className="text-[11px] text-emerald-300">{micNote}</p>}
                </div>
              </div>

              <div className="shrink-0">
                {permissionState.microphone ? (
                  <span className="inline-flex items-center gap-1.5 rounded-lg border border-emerald-500/40 bg-emerald-500/15 px-3.5 py-2 text-xs font-bold text-emerald-300">
                    <CheckCircle2 className="h-4 w-4" aria-hidden="true" />
                    <span>Granted</span>
                  </span>
                ) : (
                  <button
                    type="button"
                    onClick={handleAllowMicrophone}
                    className="inline-flex items-center justify-center rounded-lg border border-slate-700 bg-slate-800 px-4 py-2.5 text-xs font-bold text-white transition-colors hover:bg-slate-700 whitespace-nowrap"
                  >
                    Allow Microphone
                  </button>
                )}
              </div>
            </div>
          </section>
        </div>

        {/* Footer Actions */}
        <div className="flex flex-col gap-3 border-t border-slate-800 pt-5 sm:flex-row sm:items-center sm:justify-between">
          <p className="text-xs text-slate-400">
            {allGranted
              ? 'All permissions granted — opening Home Screen…'
              : 'Grant all 3 permissions above to enter ClipKaro automatically.'}
          </p>

          <div className="flex flex-wrap items-center gap-2.5">
            {overlayDeniedWarning && !permissionState.overlay && (
              <button
                type="button"
                onClick={handleContinueLimited}
                className="rounded-lg border border-slate-700 bg-[#0B0E14] px-3.5 py-2 text-xs font-semibold text-slate-300 hover:border-slate-500 hover:text-white"
              >
                Continue Without My Games
              </button>
            )}
            <button
              type="button"
              onClick={handleContinueClick}
              className="rounded-lg bg-rose-600 px-4 py-2 text-xs font-bold text-white transition-colors hover:bg-rose-500"
            >
              Continue to Home
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

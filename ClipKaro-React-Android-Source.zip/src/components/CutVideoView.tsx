import { ChangeEvent, useEffect, useMemo, useRef, useState } from 'react';
import {
  Check,
  Copy,
  FileCheck2,
  Film,
  FolderOpen,
  Link2,
  Play,
  Pause,
  Scissors,
  ShieldCheck,
  ShieldAlert,
  Sparkles,
  Trash2,
  Upload,
  Video,
} from 'lucide-react';
import {
  CLIP_LENGTH_OPTIONS,
  ClipItem,
  ClipLengthOption,
  GameItem,
  SocialPlatform,
} from '../types/clipkaro';
import { formatCreditHandle } from '../utils/embedUrl';
import { trimVideoWithFFmpeg } from '../utils/ffmpegCutter';
import {
  captureVideoThumbnail,
  formatSeconds,
  generateSampleStreamVideoBlob,
} from '../utils/mediaGenerators';

interface CutVideoViewProps {
  copyrightSafeMode: boolean;
  onToggleCopyrightSafeMode: () => void;
  games: GameItem[];
  initialOriginalLink?: string;
  initialPlatform?: SocialPlatform | 'upload' | 'studio';
  initialStreamerName?: string;
  initialGameTag?: string;
  onSaveClip: (clip: ClipItem) => Promise<void>;
  onGoToMyClips: () => void;
}

export function CutVideoView({
  copyrightSafeMode,
  onToggleCopyrightSafeMode,
  games,
  initialOriginalLink = '',
  initialPlatform = 'youtube',
  initialStreamerName = '',
  initialGameTag = '',
  onSaveClip,
  onGoToMyClips,
}: CutVideoViewProps) {
  // Permission Clip Section State (Top)
  const [hasPermission, setHasPermission] = useState<boolean>(false);
  const [streamerName, setStreamerName] = useState<string>(initialStreamerName);
  const [proofFile, setProofFile] = useState<File | null>(null);
  const [proofPreviewUrl, setProofPreviewUrl] = useState<string | null>(null);
  const [originalVideoLink, setOriginalVideoLink] = useState<string>(initialOriginalLink);
  const [copiedCredit, setCopiedCredit] = useState<boolean>(false);

  // Clip Length Chips State (Default 10 sec)
  const [clipLength, setClipLength] = useState<ClipLengthOption>(10);

  // Source Video & Trimmer State
  const [videoBlob, setVideoBlob] = useState<Blob | null>(null);
  const [videoUrl, setVideoUrl] = useState<string | null>(null);
  const [videoFileName, setVideoFileName] = useState<string>('');
  const [videoDuration, setVideoDuration] = useState<number>(0);
  const [trimStart, setTrimStart] = useState<number>(0);
  const [isPlayingSegment, setIsPlayingSegment] = useState<boolean>(false);
  const [clipTitle, setClipTitle] = useState<string>('');
  const [selectedGame, setSelectedGame] = useState<string>(
    initialGameTag || games[0]?.name || 'General Stream'
  );
  const [autoCaptionEnabled, setAutoCaptionEnabled] = useState<boolean>(true);
  const [autoCaptionText, setAutoCaptionText] = useState<string>('');
  const [sourcePlatform, setSourcePlatform] = useState<SocialPlatform | 'upload' | 'studio'>(
    initialPlatform
  );

  // Generation / Saving Feedback State
  const [isGeneratingSample, setIsGeneratingSample] = useState<boolean>(false);
  const [sampleProgress, setSampleProgress] = useState<number>(0);
  const [isSaving, setIsSaving] = useState<boolean>(false);
  const [cutProgress, setCutProgress] = useState<number>(0);
  const [cutStage, setCutStage] = useState<string>('');
  const [saveError, setSaveError] = useState<string | null>(null);
  const [savedSuccessClipTitle, setSavedSuccessClipTitle] = useState<string | null>(null);

  const videoRef = useRef<HTMLVideoElement | null>(null);
  const videoInputRef = useRef<HTMLInputElement | null>(null);
  const proofInputRef = useRef<HTMLInputElement | null>(null);

  useEffect(() => {
    if (initialOriginalLink) setOriginalVideoLink(initialOriginalLink);
  }, [initialOriginalLink]);

  useEffect(() => {
    if (initialStreamerName) setStreamerName(initialStreamerName);
  }, [initialStreamerName]);

  useEffect(() => {
    if (initialPlatform) setSourcePlatform(initialPlatform);
  }, [initialPlatform]);

  useEffect(() => {
    if (initialGameTag) setSelectedGame(initialGameTag);
  }, [initialGameTag]);

  // Clean up object URLs
  useEffect(() => {
    return () => {
      if (videoUrl) URL.revokeObjectURL(videoUrl);
    };
  }, [videoUrl]);

  useEffect(() => {
    return () => {
      if (proofPreviewUrl) URL.revokeObjectURL(proofPreviewUrl);
    };
  }, [proofPreviewUrl]);

  const autoCreditText = useMemo(() => formatCreditHandle(streamerName), [streamerName]);

  const effectiveTrimEnd = useMemo(() => {
    if (videoDuration <= 0) return clipLength;
    return Math.min(videoDuration, trimStart + clipLength);
  }, [videoDuration, trimStart, clipLength]);

  const maxTrimStart = useMemo(() => {
    if (videoDuration <= clipLength) return 0;
    return Math.max(0, Math.floor((videoDuration - clipLength) * 10) / 10);
  }, [videoDuration, clipLength]);

  const handleSelectLength = (sec: ClipLengthOption) => {
    setClipLength(sec);
    if (videoDuration > 0 && trimStart + sec > videoDuration) {
      setTrimStart(Math.max(0, Math.floor((videoDuration - sec) * 10) / 10));
    }
  };

  const handleCopyCredit = async () => {
    try {
      await navigator.clipboard.writeText(autoCreditText);
      setCopiedCredit(true);
      window.setTimeout(() => setCopiedCredit(false), 1800);
    } catch {
      // Fallback ignored if clipboard blocked
    }
  };

  const handleProofUpload = (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (proofPreviewUrl) URL.revokeObjectURL(proofPreviewUrl);
    setProofFile(file);
    if (file.type.startsWith('image/')) {
      setProofPreviewUrl(URL.createObjectURL(file));
    } else {
      setProofPreviewUrl(null);
    }
  };

  const handleClearProof = () => {
    if (proofPreviewUrl) URL.revokeObjectURL(proofPreviewUrl);
    setProofFile(null);
    setProofPreviewUrl(null);
    if (proofInputRef.current) proofInputRef.current.value = '';
  };

  const loadVideoSource = (blob: Blob, name: string, platform: SocialPlatform | 'upload' | 'studio') => {
    if (videoUrl) URL.revokeObjectURL(videoUrl);
    const nextUrl = URL.createObjectURL(blob);
    setVideoBlob(blob);
    setVideoUrl(nextUrl);
    setVideoFileName(name);
    setSourcePlatform(platform);
    setVideoDuration(0);
    setTrimStart(0);
    setIsPlayingSegment(false);
    setSaveError(null);
    setSavedSuccessClipTitle(null);
    if (!clipTitle.trim()) {
      const cleanedName = name.replace(/\.[^/.]+$/, '');
      setClipTitle(cleanedName || 'Highlight Clip');
    }
  };

  const handleVideoFileChange = (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    loadVideoSource(file, file.name, originalVideoLink ? sourcePlatform : 'upload');
    e.target.value = '';
  };

  const handleGenerateSampleVideo = async () => {
    setIsGeneratingSample(true);
    setSampleProgress(0);
    setSaveError(null);
    try {
      const sampleDur = Math.max(12, Math.min(clipLength + 2, 16));
      const blob = await generateSampleStreamVideoBlob({
        durationSec: sampleDur,
        title: clipTitle.trim() || 'Streamer Highlight Feed',
        creditLine: autoCreditText,
        onProgress: setSampleProgress,
      });
      loadVideoSource(blob, 'sample-stream-feed.webm', 'studio');
      if (!clipTitle.trim()) {
        setClipTitle(
          streamerName.trim()
            ? `${streamerName.trim().replace(/^@+/, '')} Highlight`
            : 'Sample Stream Clip'
        );
      }
    } catch {
      setSaveError('Unable to generate sample stream video in this browser.');
    } finally {
      setIsGeneratingSample(false);
    }
  };

  const handleLoadedMetadata = () => {
    const el = videoRef.current;
    if (!el) return;
    el.muted = false;
    if (el.volume === 0) el.volume = 1;

    if (el.duration === Infinity || !Number.isFinite(el.duration)) {
      // Resolve actual duration for MediaRecorder WebM streams in Chromium
      const resolveDuration = () => {
        el.removeEventListener('timeupdate', resolveDuration);
        const resolvedDur = Number.isFinite(el.duration) ? el.duration : 0;
        el.currentTime = 0;
        setVideoDuration(resolvedDur);
        setTrimStart(0);
      };
      el.addEventListener('timeupdate', resolveDuration);
      el.currentTime = 1e101;
      return;
    }

    setVideoDuration(el.duration);
    setTrimStart(0);
  };

  const handleToggleSegmentPreview = () => {
    const el = videoRef.current;
    if (!el) return;
    if (isPlayingSegment) {
      el.pause();
      setIsPlayingSegment(false);
      return;
    }
    el.muted = false;
    if (el.volume === 0) el.volume = 1;
    if (Math.abs(el.currentTime - trimStart) > 0.15) {
      el.currentTime = trimStart;
    }
    setIsPlayingSegment(true);
    el.play().catch(() => {
      setIsPlayingSegment(false);
      setSaveError('Unable to start preview playback. Press Play directly on the video player.');
    });
  };

  const handleVideoTimeUpdate = () => {
    const el = videoRef.current;
    if (!el) return;
    if (isPlayingSegment && effectiveTrimEnd > trimStart && el.currentTime >= effectiveTrimEnd) {
      el.pause();
      el.currentTime = trimStart;
      setIsPlayingSegment(false);
    }
  };

  const handleSaveClip = async () => {
    setSaveError(null);
    setSavedSuccessClipTitle(null);

    if (!videoBlob) {
      setSaveError('Please upload a video file or generate a sample stream video first.');
      return;
    }

    if (copyrightSafeMode) {
      if (!hasPermission) {
        setSaveError(
          'Copyright-Safe Mode is ON. Please confirm "I have permission from streamer" in the Permission Clip section above.'
        );
        return;
      }
      if (!streamerName.trim()) {
        setSaveError(
          'Copyright-Safe Mode is ON. Please enter the Streamer Channel Name so credit can be generated.'
        );
        return;
      }
    }

    setIsSaving(true);
    setCutProgress(0);
    setCutStage('Initializing FFmpeg…');
    try {
      let thumbnailDataUrl: string | undefined;
      if (videoRef.current) {
        thumbnailDataUrl = await captureVideoThumbnail(videoRef.current);
      }

      const actualDuration =
        videoDuration > 0 ? Math.max(1, Math.round(effectiveTrimEnd - trimStart)) : clipLength;

      const finalTitle =
        clipTitle.trim() ||
        (streamerName.trim()
          ? `${streamerName.trim().replace(/^@+/, '')} (${clipLength}s Clip)`
          : `Clip (${clipLength}s)`);

      const resolvedCaption = autoCaptionEnabled
        ? autoCaptionText.trim() || finalTitle
        : '';

      const { mp4Blob } = await trimVideoWithFFmpeg({
        sourceBlob: videoBlob,
        sourceFileName: videoFileName || 'source-video.mp4',
        startSec: trimStart,
        durationSec: actualDuration,
        videoWidth: videoRef.current?.videoWidth || 1280,
        burnCredit: hasPermission,
        creditText: autoCreditText,
        burnAutoCaption: autoCaptionEnabled,
        autoCaptionText: resolvedCaption,
        onProgress: (pct, stage) => {
          setCutProgress(pct);
          setCutStage(stage);
        },
      });

      const newClip: ClipItem = {
        id: `clip-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
        title: finalTitle,
        platform: sourcePlatform,
        gameTag: selectedGame,
        durationSec: actualDuration,
        trimStart: 0,
        trimEnd: actualDuration,
        createdAt: Date.now(),
        copyrightSafe: copyrightSafeMode,
        permission: {
          hasPermission,
          streamerName: streamerName.trim().replace(/^@+/, ''),
          proofFileName: proofFile?.name,
          proofMimeType: proofFile?.type,
          proofBlob: proofFile ?? undefined,
          originalVideoLink: originalVideoLink.trim(),
          creditText: autoCreditText,
        },
        videoBlob: mp4Blob,
        videoMimeType: 'video/mp4',
        thumbnailDataUrl,
        autoCaption: resolvedCaption || undefined,
        voiceVolume: 1,
        musicVolume: 0.45,
        originalVolume: 1,
      };

      await onSaveClip(newClip);
      setSavedSuccessClipTitle(finalTitle);
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'FFmpeg failed to cut this video file.';
      setSaveError(`Could not trim video with FFmpeg: ${msg}`);
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <h1 className="font-display text-2xl font-bold tracking-tight text-white">
            Cut Video
          </h1>
          <p className="mt-1 text-sm text-slate-400">
            Verify streamer permission on top, pick your clip duration, and trim an authorized clip for My Clips.
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2.5 self-start sm:self-auto">
          <button
            type="button"
            onClick={() => videoInputRef.current?.click()}
            className="inline-flex items-center gap-2 rounded-lg bg-rose-600 px-3.5 py-2 text-xs font-semibold text-white transition-colors hover:bg-rose-500 whitespace-nowrap shrink-0"
          >
            <FolderOpen className="h-4 w-4" aria-hidden="true" />
            <span>My Gallery</span>
          </button>
          <button
            type="button"
            onClick={onToggleCopyrightSafeMode}
            className={`inline-flex items-center gap-2 rounded-lg border px-3 py-2 text-xs font-semibold transition-colors whitespace-nowrap shrink-0 ${
              copyrightSafeMode
                ? 'border-emerald-500/40 bg-emerald-950/30 text-emerald-300'
                : 'border-amber-500/40 bg-amber-950/30 text-amber-300'
            }`}
          >
            {copyrightSafeMode ? (
              <ShieldCheck className="h-4 w-4" aria-hidden="true" />
            ) : (
              <ShieldAlert className="h-4 w-4" aria-hidden="true" />
            )}
            <span>Copyright-Safe Mode {copyrightSafeMode ? 'ON' : 'OFF'}</span>
          </button>
        </div>
      </div>

      {/* SECTION 1 (TOP): Permission Clip */}
      <section
        aria-labelledby="permission-clip-heading"
        className="rounded-xl border border-slate-800 bg-[#121722] p-5 sm:p-6 space-y-5"
      >
        <div className="flex flex-col gap-4 border-b border-slate-800/80 pb-4 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h2 id="permission-clip-heading" className="font-display text-lg font-bold text-white">
              Permission Clip
            </h2>
            <p className="mt-0.5 text-xs text-slate-400">
              Attach streamer authorization, proof screenshot, original link, and automatic channel credit.
            </p>
          </div>

          {/* Toggle: I have permission from streamer */}
          <button
            type="button"
            role="switch"
            aria-checked={hasPermission}
            onClick={() => setHasPermission((prev) => !prev)}
            className={`inline-flex items-center gap-3 rounded-lg border px-4 py-2.5 text-sm font-semibold transition-colors whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-rose-500 ${
              hasPermission
                ? 'border-emerald-500/50 bg-emerald-950/30 text-emerald-200'
                : 'border-slate-700 bg-[#0B0E14] text-slate-300 hover:border-slate-600'
            }`}
          >
            <span
              className={`relative inline-flex h-5 w-9 shrink-0 items-center rounded-full transition-colors ${
                hasPermission ? 'bg-emerald-500' : 'bg-slate-700'
              }`}
            >
              <span
                className={`inline-block h-3.5 w-3.5 rounded-full bg-white transition-transform ${
                  hasPermission ? 'translate-x-[18px]' : 'translate-x-[3px]'
                }`}
              />
            </span>
            <span>I have permission from streamer</span>
          </button>
        </div>

        {/* Permission Fields */}
        <div className="grid grid-cols-1 gap-4 md:grid-cols-3">
          {/* Field 1: Streamer Channel Name */}
          <div className="space-y-1.5">
            <label
              htmlFor="streamer-channel-name"
              className="block text-xs font-semibold text-slate-300"
            >
              Streamer Channel Name
            </label>
            <input
              id="streamer-channel-name"
              type="text"
              value={streamerName}
              onChange={(e) => setStreamerName(e.target.value)}
              placeholder="e.g. StreamerName"
              className="w-full rounded-lg border border-slate-700/80 bg-[#0B0E14] px-3.5 py-2.5 text-sm text-white placeholder:text-slate-500 focus:border-rose-500 focus:outline-none"
            />
          </div>

          {/* Field 2: Permission Proof Upload */}
          <div className="space-y-1.5">
            <label
              htmlFor="permission-proof-upload"
              className="block text-xs font-semibold text-slate-300"
            >
              Permission Proof Upload
            </label>
            <input
              ref={proofInputRef}
              id="permission-proof-upload"
              type="file"
              accept="image/*,.pdf,.txt"
              onChange={handleProofUpload}
              className="sr-only"
            />
            {proofFile ? (
              <div className="flex items-center justify-between gap-2 rounded-lg border border-emerald-500/40 bg-emerald-950/20 px-3 py-2 text-xs text-emerald-200">
                <div className="flex items-center gap-2 min-w-0">
                  {proofPreviewUrl ? (
                    <img
                      src={proofPreviewUrl}
                      alt="Permission proof preview"
                      className="h-6 w-6 rounded object-cover shrink-0"
                      referrerPolicy="no-referrer"
                    />
                  ) : (
                    <FileCheck2 className="h-4 w-4 shrink-0 text-emerald-400" aria-hidden="true" />
                  )}
                  <span className="truncate">{proofFile.name}</span>
                </div>
                <button
                  type="button"
                  onClick={handleClearProof}
                  aria-label="Remove permission proof"
                  className="rounded p-1 text-slate-400 hover:bg-slate-800 hover:text-white shrink-0"
                >
                  <Trash2 className="h-3.5 w-3.5" aria-hidden="true" />
                </button>
              </div>
            ) : (
              <button
                type="button"
                onClick={() => proofInputRef.current?.click()}
                className="flex w-full items-center justify-center gap-2 rounded-lg border border-dashed border-slate-700 bg-[#0B0E14] px-3.5 py-2.5 text-sm text-slate-300 transition-colors hover:border-slate-500 hover:text-white"
              >
                <Upload className="h-4 w-4 text-slate-400" aria-hidden="true" />
                <span className="truncate">Upload Screenshot or PDF</span>
              </button>
            )}
          </div>

          {/* Field 3: Original Video Link */}
          <div className="space-y-1.5">
            <label
              htmlFor="original-video-link"
              className="block text-xs font-semibold text-slate-300"
            >
              Original Video Link
            </label>
            <div className="relative">
              <Link2
                className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-500"
                aria-hidden="true"
              />
              <input
                id="original-video-link"
                type="url"
                value={originalVideoLink}
                onChange={(e) => setOriginalVideoLink(e.target.value)}
                placeholder="https://youtube.com/watch?v=..."
                className="w-full rounded-lg border border-slate-700/80 bg-[#0B0E14] py-2.5 pl-9 pr-3.5 text-sm text-white placeholder:text-slate-500 focus:border-rose-500 focus:outline-none"
              />
            </div>
          </div>
        </div>

        {/* Auto Credit Display */}
        <div className="flex flex-wrap items-center justify-between gap-3 rounded-lg border border-slate-800 bg-[#0B0E14] px-4 py-3">
          <div className="flex flex-wrap items-center gap-3">
            <span className="text-xs font-medium text-slate-400">Auto-generated credit:</span>
            <span
              data-testid="auto-credit-text"
              className="font-mono text-sm font-semibold text-white"
            >
              {autoCreditText}
            </span>
          </div>
          <button
            type="button"
            onClick={handleCopyCredit}
            className="inline-flex items-center gap-1.5 rounded-md border border-slate-700 bg-slate-800/80 px-3 py-1.5 text-xs font-medium text-slate-200 transition-colors hover:bg-slate-700 whitespace-nowrap shrink-0"
          >
            {copiedCredit ? (
              <>
                <Check className="h-3.5 w-3.5 text-emerald-400" aria-hidden="true" />
                <span>Copied</span>
              </>
            ) : (
              <>
                <Copy className="h-3.5 w-3.5" aria-hidden="true" />
                <span>Copy Credit</span>
              </>
            )}
          </button>
        </div>
      </section>

      {/* SECTION 2: Clip Length Chips & Video Trimmer */}
      <section className="grid grid-cols-1 gap-6 lg:grid-cols-12">
        {/* Left: Video Player & Source Controls */}
        <div className="space-y-4 rounded-xl border border-slate-800 bg-[#121722] p-5 sm:p-6 lg:col-span-7">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <h2 className="font-display text-base font-bold text-white">Video Source & Preview</h2>
            <div className="flex flex-wrap items-center gap-2">
              <input
                ref={videoInputRef}
                type="file"
                accept="video/*"
                onChange={handleVideoFileChange}
                className="sr-only"
              />
              <button
                type="button"
                onClick={() => videoInputRef.current?.click()}
                className="inline-flex items-center gap-2 rounded-lg border border-slate-700 bg-[#0B0E14] px-3 py-2 text-xs font-semibold text-slate-200 hover:border-slate-500 hover:text-white whitespace-nowrap shrink-0"
              >
                <Upload className="h-3.5 w-3.5" aria-hidden="true" />
                <span>Upload Video File</span>
              </button>
              <button
                type="button"
                disabled={isGeneratingSample}
                onClick={handleGenerateSampleVideo}
                className="inline-flex items-center gap-2 rounded-lg border border-slate-700 bg-slate-800 px-3 py-2 text-xs font-semibold text-white hover:bg-slate-700 disabled:opacity-60 whitespace-nowrap shrink-0"
              >
                <Sparkles className="h-3.5 w-3.5 text-rose-400" aria-hidden="true" />
                <span>
                  {isGeneratingSample
                    ? `Recording Sample (${sampleProgress}%)`
                    : 'Generate Sample Stream'}
                </span>
              </button>
            </div>
          </div>

          {videoUrl ? (
            <div className="space-y-4">
              <div className="relative overflow-hidden rounded-xl border border-slate-800 bg-black">
                <video
                  key={videoUrl}
                  ref={videoRef}
                  src={videoUrl}
                  controls
                  playsInline
                  preload="auto"
                  onLoadedMetadata={handleLoadedMetadata}
                  onTimeUpdate={handleVideoTimeUpdate}
                  onPlay={() => {
                    if (videoRef.current) {
                      videoRef.current.muted = false;
                      if (videoRef.current.volume === 0) videoRef.current.volume = 1;
                    }
                  }}
                  onPause={() => setIsPlayingSegment(false)}
                  onEnded={() => setIsPlayingSegment(false)}
                  onError={() =>
                    setSaveError('This video format could not be decoded in preview. Try an MP4 or WebM file.')
                  }
                  className="aspect-video w-full"
                />
                {autoCaptionEnabled && (autoCaptionText.trim() || clipTitle.trim()) && (
                  <div className="pointer-events-none absolute inset-x-0 bottom-12 flex justify-center px-4">
                    <span className="rounded bg-black px-3 py-1 text-xs font-bold text-white shadow">
                      {autoCaptionText.trim() || clipTitle.trim()}
                    </span>
                  </div>
                )}
              </div>

              {/* Timeline Start Slider */}
              <div className="space-y-2.5 rounded-lg border border-slate-800 bg-[#0B0E14] p-4">
                <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
                  <span className="font-medium text-slate-300">
                    Trim Window ({clipLength} sec chip)
                  </span>
                  <span className="font-mono text-slate-200 tabular-nums">
                    {formatSeconds(trimStart)} → {formatSeconds(effectiveTrimEnd)}
                    {videoDuration > 0 ? ` / Total ${formatSeconds(videoDuration)}` : ''}
                  </span>
                </div>

                <input
                  type="range"
                  min={0}
                  max={maxTrimStart > 0 ? maxTrimStart : 0}
                  step={0.5}
                  value={trimStart}
                  disabled={maxTrimStart === 0}
                  onChange={(e) => {
                    const nextStart = parseFloat(e.target.value);
                    setTrimStart(nextStart);
                    if (videoRef.current) {
                      videoRef.current.currentTime = nextStart;
                    }
                  }}
                  aria-label="Clip start time"
                  className="w-full accent-rose-500"
                />

                <div className="flex flex-wrap items-center justify-between gap-3 pt-1">
                  <span className="text-xs text-slate-400 truncate max-w-[260px]">
                    Loaded: {videoFileName}
                  </span>
                  <button
                    type="button"
                    onClick={handleToggleSegmentPreview}
                    className="inline-flex items-center gap-2 rounded-lg bg-slate-800 px-3.5 py-2 text-xs font-semibold text-white hover:bg-slate-700 whitespace-nowrap shrink-0"
                  >
                    {isPlayingSegment ? (
                      <>
                        <Pause className="h-3.5 w-3.5" aria-hidden="true" />
                        <span>Pause Segment</span>
                      </>
                    ) : (
                      <>
                        <Play className="h-3.5 w-3.5" aria-hidden="true" />
                        <span>Preview {clipLength}s Segment</span>
                      </>
                    )}
                  </button>
                </div>
              </div>
            </div>
          ) : (
            <div className="flex aspect-video flex-col items-center justify-center gap-4 rounded-xl border border-dashed border-slate-700/80 bg-[#0B0E14] p-6 text-center">
              <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-slate-800/80 text-slate-300">
                <Video className="h-6 w-6" aria-hidden="true" />
              </div>
              <div className="max-w-sm space-y-1">
                <p className="font-display text-sm font-semibold text-white">
                  Load a video to cut your {clipLength}s clip
                </p>
                <p className="text-xs text-slate-400">
                  Upload any MP4, WebM, or MOV video file from your device, or click Generate Sample Stream to create a playable test stream right now.
                </p>
              </div>
              {isGeneratingSample && (
                <div className="w-full max-w-xs space-y-1.5">
                  <div className="h-2 overflow-hidden rounded-full bg-slate-800">
                    <div
                      className="h-full bg-rose-500 transition-all"
                      style={{ width: `${sampleProgress}%` }}
                    />
                  </div>
                  <p className="text-xs text-slate-400 tabular-nums">
                    Creating sample WebM stream… {sampleProgress}%
                  </p>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Right: Clip Length Chips & Save Details */}
        <div className="flex flex-col justify-between gap-6 rounded-xl border border-slate-800 bg-[#121722] p-5 sm:p-6 lg:col-span-5">
          <div className="space-y-5">
            {/* Clip Length Chips */}
            <div className="space-y-2.5">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-slate-300">Clip Length</span>
                <span className="text-xs text-slate-400 tabular-nums">
                  Selected: {clipLength} sec
                </span>
              </div>
              <div className="grid grid-cols-3 gap-2">
                {CLIP_LENGTH_OPTIONS.map((sec) => {
                  const selected = clipLength === sec;
                  return (
                    <button
                      key={sec}
                      type="button"
                      onClick={() => handleSelectLength(sec)}
                      aria-pressed={selected}
                      className={`rounded-lg border px-3 py-2.5 text-sm font-semibold tabular-nums transition-colors whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-rose-500 ${
                        selected
                          ? 'border-rose-500 bg-rose-600 text-white'
                          : 'border-slate-700/80 bg-[#0B0E14] text-slate-300 hover:border-slate-500 hover:text-white'
                      }`}
                    >
                      {sec} sec
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Clip Title */}
            <div className="space-y-1.5">
              <label htmlFor="clip-title-input" className="block text-xs font-semibold text-slate-300">
                Clip Title
              </label>
              <input
                id="clip-title-input"
                type="text"
                value={clipTitle}
                onChange={(e) => setClipTitle(e.target.value)}
                placeholder="e.g. Final Round Clutch"
                className="w-full rounded-lg border border-slate-700/80 bg-[#0B0E14] px-3.5 py-2.5 text-sm text-white placeholder:text-slate-500 focus:border-rose-500 focus:outline-none"
              />
            </div>

            {/* Game Tag */}
            <div className="space-y-1.5">
              <label htmlFor="clip-game-select" className="block text-xs font-semibold text-slate-300">
                Game Category
              </label>
              <select
                id="clip-game-select"
                value={selectedGame}
                onChange={(e) => setSelectedGame(e.target.value)}
                className="w-full rounded-lg border border-slate-700/80 bg-[#0B0E14] px-3.5 py-2.5 text-sm text-white focus:border-rose-500 focus:outline-none"
              >
                {games.map((g) => (
                  <option key={g.id} value={g.name}>
                    {g.name}
                  </option>
                ))}
                <option value="Just Chatting & IRL">Just Chatting & IRL</option>
              </select>
            </div>

            {/* Auto-Caption (Black Background) */}
            <div className="space-y-2 rounded-lg border border-slate-800 bg-[#0B0E14] p-3">
              <div className="flex items-center justify-between gap-2">
                <label
                  htmlFor="auto-caption-input"
                  className="text-xs font-semibold text-slate-300"
                >
                  Auto-Caption (Black Background)
                </label>
                <button
                  type="button"
                  role="switch"
                  aria-checked={autoCaptionEnabled}
                  onClick={() => setAutoCaptionEnabled((prev) => !prev)}
                  className={`rounded-md px-2.5 py-1 text-xs font-semibold transition-colors ${
                    autoCaptionEnabled
                      ? 'bg-emerald-600 text-white'
                      : 'bg-slate-800 text-slate-400'
                  }`}
                >
                  {autoCaptionEnabled ? 'ON' : 'OFF'}
                </button>
              </div>
              {autoCaptionEnabled && (
                <input
                  id="auto-caption-input"
                  type="text"
                  value={autoCaptionText}
                  onChange={(e) => setAutoCaptionText(e.target.value)}
                  placeholder={clipTitle.trim() || 'Auto-caption text (defaults to Clip Title)'}
                  className="w-full rounded-md border border-slate-700/80 bg-black px-3 py-2 text-xs font-medium text-white placeholder:text-slate-500 focus:border-rose-500 focus:outline-none"
                />
              )}
            </div>

            {/* Copyright-Safe Notice */}
            {copyrightSafeMode && (!hasPermission || !streamerName.trim()) && (
              <div className="rounded-lg border border-amber-500/40 bg-amber-950/20 p-3.5 text-xs text-amber-200 space-y-1">
                <div className="font-semibold flex items-center gap-1.5">
                  <ShieldCheck className="h-4 w-4 text-amber-400 shrink-0" aria-hidden="true" />
                  <span>Permission Required (Copyright-Safe Mode ON)</span>
                </div>
                <p className="text-amber-200/80">
                  Enable &ldquo;I have permission from streamer&rdquo; and enter the Streamer Channel Name at the top before saving.
                </p>
              </div>
            )}

            {saveError && (
              <div
                role="alert"
                className="rounded-lg border border-rose-500/40 bg-rose-950/30 p-3.5 text-xs text-rose-200"
              >
                {saveError}
              </div>
            )}

            {isSaving && (
              <div
                aria-live="polite"
                className="rounded-lg border border-slate-700 bg-[#0B0E14] p-3.5 space-y-2"
              >
                <div className="flex items-center justify-between gap-2 text-xs">
                  <span className="font-medium text-slate-200 truncate">
                    {cutStage || 'Cutting video with FFmpeg…'}
                  </span>
                  <span className="font-mono font-semibold text-rose-400 tabular-nums shrink-0">
                    {cutProgress}%
                  </span>
                </div>
                <div className="h-2 w-full overflow-hidden rounded-full bg-slate-800">
                  <div
                    className="h-full bg-rose-500 transition-all duration-150"
                    style={{ width: `${cutProgress}%` }}
                  />
                </div>
              </div>
            )}

            {savedSuccessClipTitle && (
              <div className="rounded-lg border border-emerald-500/40 bg-emerald-950/25 p-3.5 text-xs text-emerald-200 flex items-center justify-between gap-3">
                <span>
                  Saved <strong>{savedSuccessClipTitle}</strong> (.mp4) to My Clips.
                </span>
                <button
                  type="button"
                  onClick={onGoToMyClips}
                  className="inline-flex items-center gap-1.5 rounded-md bg-emerald-600 px-3 py-1.5 font-semibold text-white hover:bg-emerald-500 whitespace-nowrap shrink-0"
                >
                  <Film className="h-3.5 w-3.5" aria-hidden="true" />
                  <span>Open My Clips</span>
                </button>
              </div>
            )}
          </div>

          <button
            type="button"
            disabled={isSaving || isGeneratingSample}
            onClick={handleSaveClip}
            className="inline-flex w-full items-center justify-center gap-2 rounded-lg bg-rose-600 px-5 py-3 text-sm font-bold text-white transition-colors hover:bg-rose-500 disabled:opacity-60"
          >
            <Scissors className="h-4 w-4" aria-hidden="true" />
            <span>
              {isSaving ? `Cutting MP4 (${cutProgress}%)…` : `Cut & Save ${clipLength}s Clip`}
            </span>
          </button>
        </div>
      </section>
    </div>
  );
}

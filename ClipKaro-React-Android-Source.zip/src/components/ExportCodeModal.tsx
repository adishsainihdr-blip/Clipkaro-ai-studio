import { useEffect, useMemo, useState } from 'react';
import {
  Check,
  Code2,
  Copy,
  Download,
  FileCode2,
  FolderArchive,
  Loader2,
  Search,
  Smartphone,
  X,
} from 'lucide-react';
import type { ProjectFileCategory, ProjectSourceFile } from '../utils/projectFilesManifest';
import { createZipBlob, triggerBlobDownload, type ZipInputFile } from '../utils/zipBuilder';

interface ExportCodeModalProps {
  isOpen: boolean;
  onClose: () => void;
}

function formatBytes(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
}

export function ExportCodeModal({ isOpen, onClose }: ExportCodeModalProps) {
  const [files, setFiles] = useState<ProjectSourceFile[]>([]);
  const [assetPaths, setAssetPaths] = useState<string[]>([]);
  const [isLoadingFiles, setIsLoadingFiles] = useState(false);

  const [categoryFilter, setCategoryFilter] = useState<'all' | ProjectFileCategory>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedPath, setSelectedPath] = useState<string>(
    'android/app/src/main/java/com/clipkaro/app/MainActivity.java'
  );
  const [copiedPath, setCopiedPath] = useState<string | null>(null);

  const [isBuildingSourceZip, setIsBuildingSourceZip] = useState(false);
  const [isDownloadingFullZip, setIsDownloadingFullZip] = useState(false);
  const [fullZipProgress, setFullZipProgress] = useState<number>(0);
  const [statusMessage, setStatusMessage] = useState<string>('');
  const [errorMessage, setErrorMessage] = useState<string>('');

  useEffect(() => {
    if (!isOpen) return;
    let active = true;
    setIsLoadingFiles(true);
    setErrorMessage('');

    import('../utils/projectFilesManifest')
      .then((mod) => {
        if (!active) return;
        setFiles(mod.PROJECT_SOURCE_FILES);
        setAssetPaths(mod.ASSET_IMAGE_PATHS);
        if (
          mod.PROJECT_SOURCE_FILES.length > 0 &&
          !mod.PROJECT_SOURCE_FILES.some((f) => f.path === selectedPath)
        ) {
          setSelectedPath(mod.PROJECT_SOURCE_FILES[0].path);
        }
      })
      .catch((err) => {
        if (!active) return;
        setErrorMessage(
          err instanceof Error ? err.message : 'Unable to load project source files.'
        );
      })
      .finally(() => {
        if (active) setIsLoadingFiles(false);
      });

    return () => {
      active = false;
    };
  }, [isOpen, selectedPath]);

  const filteredFiles = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    return files.filter((f) => {
      if (categoryFilter !== 'all' && f.category !== categoryFilter) return false;
      if (q && !f.path.toLowerCase().includes(q)) return false;
      return true;
    });
  }, [files, categoryFilter, searchQuery]);

  const activeFile = useMemo(() => {
    return files.find((f) => f.path === selectedPath) || filteredFiles[0] || null;
  }, [files, filteredFiles, selectedPath]);

  const counts = useMemo(() => {
    return {
      all: files.length,
      android: files.filter((f) => f.category === 'android').length,
      react: files.filter((f) => f.category === 'react').length,
      build: files.filter((f) => f.category === 'build').length,
    };
  }, [files]);

  if (!isOpen) return null;

  const handleDownloadSingleFile = (file: ProjectSourceFile) => {
    const fileName = file.path.split('/').pop() || 'file.txt';
    const blob = new Blob([file.content], { type: 'text/plain;charset=utf-8' });
    triggerBlobDownload(blob, fileName);
    setStatusMessage(`Downloaded ${file.path} (${formatBytes(file.sizeBytes)})`);
    setErrorMessage('');
  };

  const handleCopyFile = async (file: ProjectSourceFile) => {
    try {
      await navigator.clipboard.writeText(file.content);
      setCopiedPath(file.path);
      setStatusMessage(`Copied ${file.path} to clipboard`);
      setTimeout(() => setCopiedPath(null), 2000);
    } catch {
      setErrorMessage('Clipboard access was blocked; use Download File instead.');
    }
  };

  const handleDownloadSourceZip = async () => {
    if (files.length === 0 || isBuildingSourceZip) return;
    setIsBuildingSourceZip(true);
    setErrorMessage('');
    setStatusMessage('Packaging React + Android project files...');

    try {
      const zipEntries: ZipInputFile[] = files.map((f) => ({
        path: f.path,
        content: f.content,
      }));

      // Include binary game cover images so npm run build works immediately
      for (const imgPath of assetPaths) {
        try {
          const res = await fetch(`/${imgPath}`);
          if (res.ok) {
            const buf = await res.arrayBuffer();
            zipEntries.push({
              path: imgPath,
              content: new Uint8Array(buf),
            });
          }
        } catch {
          // Skip optional image if offline
        }
      }

      const zipBlob = createZipBlob(zipEntries);
      triggerBlobDownload(zipBlob, 'ClipKaro-React-Android-Source.zip');
      setStatusMessage(
        `Downloaded ClipKaro-React-Android-Source.zip (${zipEntries.length} files, ${formatBytes(
          zipBlob.size
        )}). Run npm install to auto-populate FFmpeg WASM.`
      );
    } catch (err) {
      setErrorMessage(err instanceof Error ? err.message : 'Failed to build ZIP archive.');
    } finally {
      setIsBuildingSourceZip(false);
    }
  };

  const handleDownloadFullBundleZip = async () => {
    if (isDownloadingFullZip) return;
    setIsDownloadingFullZip(true);
    setFullZipProgress(0);
    setErrorMessage('');
    setStatusMessage('Downloading ClipKaro-complete-code.zip with FFmpeg engine...');

    try {
      const res = await fetch('/ClipKaro-complete-code.zip');
      if (!res.ok) {
        throw new Error(`Server returned HTTP ${res.status}`);
      }
      const contentType = (res.headers.get('content-type') || '').toLowerCase();
      if (contentType.includes('text/html')) {
        throw new Error('Complete ZIP bundle is not available on server; use Source + Android ZIP.');
      }

      const contentLengthHeader = res.headers.get('content-length');
      const totalBytes = contentLengthHeader ? parseInt(contentLengthHeader, 10) : 0;

      if (!res.body) {
        const blob = await res.blob();
        triggerBlobDownload(blob, 'ClipKaro-complete-code.zip');
        setFullZipProgress(100);
        setStatusMessage(
          `Downloaded ClipKaro-complete-code.zip (${formatBytes(blob.size)})`
        );
        return;
      }

      const reader = res.body.getReader();
      const chunks: Uint8Array[] = [];
      let received = 0;

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        if (value) {
          chunks.push(value);
          received += value.byteLength;
          if (totalBytes > 0) {
            setFullZipProgress(Math.min(99, Math.round((received / totalBytes) * 100)));
          }
        }
      }

      const blob = new Blob(chunks as BlobPart[], { type: 'application/zip' });
      triggerBlobDownload(blob, 'ClipKaro-complete-code.zip');
      setFullZipProgress(100);
      setStatusMessage(
        `Downloaded ClipKaro-complete-code.zip (${formatBytes(blob.size)})`
      );
    } catch (err) {
      setErrorMessage(
        err instanceof Error
          ? `${err.message}. Try the instant Source ZIP button instead.`
          : 'Download failed. Try the instant Source ZIP button instead.'
      );
    } finally {
      setIsDownloadingFullZip(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-3 sm:p-5 backdrop-blur-sm"
      role="dialog"
      aria-modal="true"
      aria-labelledby="export-code-title"
    >
      <div className="flex h-[90vh] w-full max-w-6xl flex-col overflow-hidden rounded-2xl border border-slate-800 bg-[#0E131D] shadow-2xl">
        {/* Header */}
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-800 px-4 py-3.5 sm:px-6">
          <div className="flex items-center gap-3">
            <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-rose-500/15 text-rose-400">
              <FolderArchive className="h-5 w-5" aria-hidden="true" />
            </span>
            <div>
              <h2 id="export-code-title" className="font-display text-lg font-bold text-white">
                ClipKaro React + Android Project Files
              </h2>
              <p className="text-xs text-slate-400">
                Inspect, copy, or download every real source file or export a ready-to-build ZIP for Android APK.
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            aria-label="Close code export"
            className="rounded-lg border border-slate-700 bg-slate-800/80 p-2 text-slate-300 hover:bg-slate-700 hover:text-white"
          >
            <X className="h-4 w-4" aria-hidden="true" />
          </button>
        </div>

        {/* Download Action Banner */}
        <div className="border-b border-slate-800 bg-[#121722] px-4 py-3.5 sm:px-6 space-y-3">
          <div className="flex flex-col gap-2.5 lg:flex-row lg:items-center lg:justify-between">
            <div className="flex flex-wrap items-center gap-2.5">
              <button
                type="button"
                onClick={handleDownloadSourceZip}
                disabled={isBuildingSourceZip || files.length === 0}
                className="inline-flex items-center gap-2 rounded-lg bg-rose-600 px-4 py-2.5 text-sm font-semibold text-white transition-colors hover:bg-rose-500 disabled:opacity-50"
              >
                {isBuildingSourceZip ? (
                  <Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" />
                ) : (
                  <Download className="h-4 w-4" aria-hidden="true" />
                )}
                <span>Download Source + Android ZIP (Recommended)</span>
              </button>

              <button
                type="button"
                onClick={handleDownloadFullBundleZip}
                disabled={isDownloadingFullZip}
                className="inline-flex items-center gap-2 rounded-lg border border-slate-700 bg-[#0B0E14] px-4 py-2.5 text-sm font-semibold text-slate-200 transition-colors hover:border-slate-500 hover:text-white disabled:opacity-50"
              >
                {isDownloadingFullZip ? (
                  <Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" />
                ) : (
                  <FolderArchive className="h-4 w-4 text-amber-400" aria-hidden="true" />
                )}
                <span>
                  {isDownloadingFullZip
                    ? `Downloading Full ZIP (${fullZipProgress}%)`
                    : 'Download Offline Bundle ZIP (with FFmpeg)'}
                </span>
              </button>

              <a
                href="/ClipKaro-React-Android-Source.zip"
                download="ClipKaro-React-Android-Source.zip"
                className="inline-flex items-center gap-1.5 rounded-lg border border-slate-800 px-3 py-2 text-xs font-medium text-slate-300 hover:border-slate-700 hover:text-white"
              >
                <Download className="h-3.5 w-3.5" aria-hidden="true" />
                <span>Direct ZIP Link</span>
              </a>
            </div>

            <div className="flex items-center gap-2 text-xs text-slate-400">
              <Smartphone className="h-4 w-4 text-emerald-400 shrink-0" aria-hidden="true" />
              <span>Includes Gradle 8.7 + SDK 35 + GitHub Mobile APK Workflow</span>
            </div>
          </div>

          {isDownloadingFullZip && (
            <div className="h-1.5 w-full overflow-hidden rounded-full bg-slate-800">
              <div
                className="h-full bg-rose-500 transition-all duration-150"
                style={{ width: `${fullZipProgress}%` }}
              />
            </div>
          )}

          {statusMessage && (
            <div className="rounded-lg border border-emerald-500/30 bg-emerald-950/30 px-3 py-2 text-xs text-emerald-300">
              {statusMessage}
            </div>
          )}

          {errorMessage && (
            <div className="rounded-lg border border-rose-500/40 bg-rose-950/30 px-3 py-2 text-xs text-rose-300">
              {errorMessage}
            </div>
          )}
        </div>

        {/* File Explorer + Code Preview */}
        <div className="grid min-h-0 flex-1 grid-cols-1 lg:grid-cols-12">
          {/* Left File Tree */}
          <div className="flex min-h-0 flex-col border-b border-slate-800 lg:col-span-4 lg:border-b-0 lg:border-r">
            <div className="space-y-2.5 border-b border-slate-800 p-3">
              <div className="relative">
                <Search
                  className="pointer-events-none absolute left-3 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-slate-500"
                  aria-hidden="true"
                />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Filter files (e.g. MainActivity, CutVideo)..."
                  className="w-full rounded-lg border border-slate-800 bg-[#0B0E14] py-1.5 pl-8 pr-3 text-xs text-white placeholder:text-slate-500 focus:border-rose-500 focus:outline-none"
                />
              </div>

              <div className="flex flex-wrap gap-1.5">
                {(
                  [
                    { id: 'all', label: `All (${counts.all})` },
                    { id: 'android', label: `Android (${counts.android})` },
                    { id: 'react', label: `React (${counts.react})` },
                    { id: 'build', label: `APK Build (${counts.build})` },
                  ] as const
                ).map((tab) => (
                  <button
                    key={tab.id}
                    type="button"
                    onClick={() => setCategoryFilter(tab.id)}
                    className={`rounded-md px-2.5 py-1 text-[11px] font-semibold transition-colors ${
                      categoryFilter === tab.id
                        ? 'bg-rose-600 text-white'
                        : 'bg-[#0B0E14] text-slate-400 hover:text-white'
                    }`}
                  >
                    {tab.label}
                  </button>
                ))}
              </div>
            </div>

            <div className="min-h-0 flex-1 overflow-y-auto p-2 space-y-1">
              {isLoadingFiles ? (
                <div className="flex items-center justify-center py-10 text-xs text-slate-400">
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" aria-hidden="true" />
                  Loading live workspace files...
                </div>
              ) : filteredFiles.length === 0 ? (
                <div className="py-8 text-center text-xs text-slate-500">
                  No project files match that filter.
                </div>
              ) : (
                filteredFiles.map((file) => {
                  const selected = activeFile?.path === file.path;
                  return (
                    <div
                      key={file.path}
                      className={`flex items-center justify-between gap-2 rounded-lg px-2.5 py-2 text-left transition-colors ${
                        selected
                          ? 'bg-rose-600/15 text-white border border-rose-500/40'
                          : 'text-slate-300 hover:bg-slate-800/60 border border-transparent'
                      }`}
                    >
                      <button
                        type="button"
                        onClick={() => setSelectedPath(file.path)}
                        className="flex min-w-0 flex-1 items-center gap-2 text-left"
                      >
                        <FileCode2
                          className={`h-4 w-4 shrink-0 ${
                            file.category === 'android'
                              ? 'text-emerald-400'
                              : file.category === 'build'
                                ? 'text-amber-400'
                                : 'text-sky-400'
                          }`}
                          aria-hidden="true"
                        />
                        <div className="min-w-0 flex-1">
                          <div className="truncate font-mono text-[11px] font-medium">
                            {file.path}
                          </div>
                          <div className="text-[10px] text-slate-500">
                            {formatBytes(file.sizeBytes)}
                          </div>
                        </div>
                      </button>

                      <button
                        type="button"
                        onClick={() => handleDownloadSingleFile(file)}
                        title={`Download ${file.path}`}
                        aria-label={`Download ${file.path}`}
                        className="rounded-md p-1.5 text-slate-400 hover:bg-slate-700 hover:text-white shrink-0"
                      >
                        <Download className="h-3.5 w-3.5" aria-hidden="true" />
                      </button>
                    </div>
                  );
                })
              )}
            </div>
          </div>

          {/* Right Source Code Viewer */}
          <div className="flex min-h-0 flex-col bg-[#090D14] lg:col-span-8">
            {activeFile ? (
              <>
                <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-800 bg-[#111622] px-4 py-2.5">
                  <div className="flex min-w-0 items-center gap-2">
                    <Code2 className="h-4 w-4 text-rose-400 shrink-0" aria-hidden="true" />
                    <span className="truncate font-mono text-xs font-semibold text-slate-200">
                      {activeFile.path}
                    </span>
                    <span className="text-[11px] text-slate-500 shrink-0">
                      ({formatBytes(activeFile.sizeBytes)})
                    </span>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => handleCopyFile(activeFile)}
                      className="inline-flex items-center gap-1.5 rounded-lg border border-slate-700 bg-slate-800 px-3 py-1.5 text-xs font-semibold text-slate-200 hover:bg-slate-700"
                    >
                      {copiedPath === activeFile.path ? (
                        <>
                          <Check className="h-3.5 w-3.5 text-emerald-400" aria-hidden="true" />
                          <span>Copied</span>
                        </>
                      ) : (
                        <>
                          <Copy className="h-3.5 w-3.5" aria-hidden="true" />
                          <span>Copy Code</span>
                        </>
                      )}
                    </button>
                    <button
                      type="button"
                      onClick={() => handleDownloadSingleFile(activeFile)}
                      className="inline-flex items-center gap-1.5 rounded-lg bg-rose-600 px-3 py-1.5 text-xs font-semibold text-white hover:bg-rose-500"
                    >
                      <Download className="h-3.5 w-3.5" aria-hidden="true" />
                      <span>Download File</span>
                    </button>
                  </div>
                </div>

                <pre className="min-h-0 flex-1 overflow-auto p-4 font-mono text-xs leading-relaxed text-slate-200">
                  <code>{activeFile.content}</code>
                </pre>
              </>
            ) : (
              <div className="flex flex-1 items-center justify-center p-6 text-xs text-slate-500">
                Select any React or Android file on the left to inspect or download it.
              </div>
            )}

            {/* Quick Mobile APK Build Footer */}
            <div className="border-t border-slate-800 bg-[#121722] px-4 py-2.5 text-[11px] text-slate-400">
              <span className="font-semibold text-white">Build APK on Mobile:</span> Download & unzip{' '}
              <span className="font-mono text-slate-200">ClipKaro-React-Android-Source.zip</span> → upload folder to a new GitHub repo (include{' '}
              <span className="font-mono text-slate-200">.github</span>,{' '}
              <span className="font-mono text-slate-200">android</span>,{' '}
              <span className="font-mono text-slate-200">src</span>) → open{' '}
              <span className="font-semibold text-slate-200">Actions → Build ClipKaro Android APK</span> → download{' '}
              <span className="font-mono text-emerald-300">app-debug.apk</span>.
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

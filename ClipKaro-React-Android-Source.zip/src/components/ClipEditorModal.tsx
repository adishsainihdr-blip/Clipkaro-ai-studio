import { ChangeEvent, useEffect, useMemo, useRef, useState } from 'react';
import {
  CheckCircle2,
  Download,
  Film,
  Gauge,
  Image as ImageIcon,
  Layers,
  Maximize2,
  Mic,
  Music,
  Pause,
  Play,
  RefreshCw,
  RotateCcw,
  Save,
  Scissors,
  Share2,
  Sparkles,
  SplitSquareHorizontal,
  Square,
  Trash2,
  Upload,
  Volume2,
  Wand2,
  X,
} from 'lucide-react';
import {
  AspectRatioOption,
  ClipItem,
  SpeedPreset,
  SpeedSegment,
  VideoEffectMode,
  VideoFilterPreset,
  VideoFitMode,
} from '../types/clipkaro';
import { trimVideoWithFFmpeg } from '../utils/ffmpegCutter';
import {
  formatSeconds,
  generateRoyaltyFreeWavBlob,
  generateStyledThumbnailDataUrl,
  ROYALTY_FREE_TRACKS,
  ThumbnailStylePreset,
} from '../utils/mediaGenerators';
import {
  saveVideoToNativeClipKaroFolder,
  shareClipToPlatform,
  ShareTargetPlatform,
} from '../utils/androidPermissions';
import {
  ASPECT_RATIO_OPTIONS,
  combineCssFilters,
  EFFECT_MODES,
  FILTER_PRESETS,
  getAspectContainerClass,
  getSpeedAtTime,
  getSpeedSegmentClasses,
  SPEED_OPTIONS,
} from '../utils/videoEditorPresets';

export type EditorTab = 'trim' | 'ratio' | 'looks' | 'speed' | 'music' | 'voice' | 'thumbnail';

interface ClipEditorModalProps {
  clip: ClipItem;
  initialTab?: EditorTab;
  onSaveClip: (clip: ClipItem) => Promise<void>;
  onClose: () => void;
}

const CAPTION_PRESETS = [
  'What a Headshot!',
  '1 VS 4 CLUTCH!',
  'Squad Wipe!',
  'Clean Knock!',
] as const;

const THUMBNAIL_TEXT_PRESETS = [
  '1 VS 4 CLUTCH',
  'HEADSHOT KING',
  'WHAT A CLUTCH!',
  'SQUAD WIPE',
] as const;

export function ClipEditorModal({
  clip,
  initialTab = 'trim',
  onSaveClip,
  onClose,
}: ClipEditorModalProps) {
  const [editorTab, setEditorTab] = useState<EditorTab>(initialTab);
  const [title, setTitle] = useState<string>(clip.title);
  const [autoCaption, setAutoCaption] = useState<string>(clip.autoCaption ?? '');
  const [videoDuration, setVideoDuration] = useState<number>(Math.max(1, clip.durationSec));

  // Trim / Cut state
  const [trimStart, setTrimStart] = useState<number>(Math.max(0, clip.trimStart || 0));
  const [trimEnd, setTrimEnd] = useState<number>(
    clip.trimEnd > clip.trimStart ? clip.trimEnd : Math.max(1, clip.durationSec)
  );
  const [applyHardTrim, setApplyHardTrim] = useState<boolean>(false);

  // Aspect Ratio + Fit/Fill state
  const [aspectRatio, setAspectRatio] = useState<AspectRatioOption>(clip.aspectRatio ?? '16:9');
  const [fitMode, setFitMode] = useState<VideoFitMode>(clip.fitMode ?? 'fill');

  // Cinematic + Filters & Modes state
  const [filterPreset, setFilterPreset] = useState<VideoFilterPreset>(clip.filterPreset ?? 'none');
  const [effectMode, setEffectMode] = useState<VideoEffectMode>(clip.effectMode ?? 'none');

  // Speed Control + Split Speed state
  const initialSpan = Math.max(
    1,
    (clip.trimEnd > clip.trimStart ? clip.trimEnd : Math.max(1, clip.durationSec)) -
      Math.max(0, clip.trimStart || 0)
  );
  const [speedSegments, setSpeedSegments] = useState<SpeedSegment[]>(() =>
    clip.speedSegments && clip.speedSegments.length > 0
      ? clip.speedSegments
      : [{ id: 'seg-0', startSec: 0, endSec: initialSpan, speed: 1 }]
  );
  const [selectedSegmentId, setSelectedSegmentId] = useState<string>(
    clip.speedSegments?.[0]?.id ?? 'seg-0'
  );
  const [splitCursorSec, setSplitCursorSec] = useState<number>(
    Math.round((initialSpan / 2) * 10) / 10
  );
  const [livePlaybackSpeed, setLivePlaybackSpeed] = useState<SpeedPreset>(
    clip.speedSegments?.[0]?.speed ?? 1
  );

  // Audio Mix Volumes
  const [originalVolume, setOriginalVolume] = useState<number>(clip.originalVolume ?? 1);
  const [musicVolume, setMusicVolume] = useState<number>(clip.musicVolume ?? 0.45);
  const [voiceVolume, setVoiceVolume] = useState<number>(clip.voiceVolume ?? 1);

  // Music state
  const [musicBlob, setMusicBlob] = useState<Blob | undefined>(clip.musicBlob);
  const [musicName, setMusicName] = useState<string | undefined>(clip.musicName);
  const [selectedPresetId, setSelectedPresetId] = useState<string>(ROYALTY_FREE_TRACKS[0].id);
  const [previewTrackId, setPreviewTrackId] = useState<string | null>(null);

  // Voiceover state
  const [voiceBlob, setVoiceBlob] = useState<Blob | undefined>(clip.voiceBlob);
  const [voiceName, setVoiceName] = useState<string | undefined>(clip.voiceName);
  const [isRecordingVoice, setIsRecordingVoice] = useState<boolean>(false);
  const [voiceRecSeconds, setVoiceRecSeconds] = useState<number>(0);
  const [voiceError, setVoiceError] = useState<string | null>(null);

  // Thumbnail Maker state
  const [thumbnailDataUrl, setThumbnailDataUrl] = useState<string | undefined>(
    clip.thumbnailDataUrl
  );
  const [thumbHeadline, setThumbHeadline] = useState<string>('1 VS 4 CLUTCH');
  const [thumbBadge, setThumbBadge] = useState<string>('#BGMI');
  const [thumbStyle, setThumbStyle] = useState<ThumbnailStylePreset>('clutch-red-gold');
  const [isGeneratingThumb, setIsGeneratingThumb] = useState<boolean>(false);

  // Playback & Save Status
  const [videoUrl, setVideoUrl] = useState<string>('');
  const [musicUrl, setMusicUrl] = useState<string | null>(null);
  const [voiceUrl, setVoiceUrl] = useState<string | null>(null);
  const [isSaving, setIsSaving] = useState<boolean>(false);
  const [isSharing, setIsSharing] = useState<boolean>(false);
  const [saveStage, setSaveStage] = useState<string>('');
  const [saveProgress, setSaveProgress] = useState<number>(0);
  const [savedMessage, setSavedMessage] = useState<string | null>(null);

  const videoRef = useRef<HTMLVideoElement | null>(null);
  const musicAudioRef = useRef<HTMLAudioElement | null>(null);
  const voiceAudioRef = useRef<HTMLAudioElement | null>(null);
  const trackPreviewAudioRef = useRef<HTMLAudioElement | null>(null);
  const trackPreviewUrlRef = useRef<string | null>(null);
  const customMusicInputRef = useRef<HTMLInputElement | null>(null);
  const customVoiceInputRef = useRef<HTMLInputElement | null>(null);

  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const micStreamRef = useRef<MediaStream | null>(null);
  const recTimerRef = useRef<number | null>(null);
  const waveCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const audioCtxRef = useRef<AudioContext | null>(null);
  const analyserRef = useRef<AnalyserNode | null>(null);
  const waveRafRef = useRef<number>(0);

  const builtInTrackBlobs = useMemo(() => {
    const map: Record<string, Blob> = {};
    for (const track of ROYALTY_FREE_TRACKS) {
      map[track.id] = generateRoyaltyFreeWavBlob(track.id);
    }
    return map;
  }, []);

  useEffect(() => {
    const url = URL.createObjectURL(clip.videoBlob);
    setVideoUrl(url);
    return () => URL.revokeObjectURL(url);
  }, [clip.videoBlob]);

  useEffect(() => {
    if (!musicBlob) {
      setMusicUrl(null);
      return;
    }
    const u = URL.createObjectURL(musicBlob);
    setMusicUrl(u);
    return () => URL.revokeObjectURL(u);
  }, [musicBlob]);

  useEffect(() => {
    if (!voiceBlob) {
      setVoiceUrl(null);
      return;
    }
    const u = URL.createObjectURL(voiceBlob);
    setVoiceUrl(u);
    return () => URL.revokeObjectURL(u);
  }, [voiceBlob]);

  useEffect(() => {
    return () => {
      trackPreviewAudioRef.current?.pause();
      if (trackPreviewUrlRef.current) URL.revokeObjectURL(trackPreviewUrlRef.current);
      if (recTimerRef.current) window.clearInterval(recTimerRef.current);
      cancelAnimationFrame(waveRafRef.current);
      micStreamRef.current?.getTracks().forEach((t) => t.stop());
      audioCtxRef.current?.close().catch(() => undefined);
    };
  }, []);

  useEffect(() => {
    setEditorTab(initialTab);
  }, [initialTab]);

  useEffect(() => {
    if (videoRef.current) videoRef.current.volume = originalVolume;
    if (musicAudioRef.current) musicAudioRef.current.volume = musicVolume;
    if (voiceAudioRef.current) voiceAudioRef.current.volume = voiceVolume;
  }, [originalVolume, musicVolume, voiceVolume]);

  const handleRenderThumbnail = async (
    nextHeadline = thumbHeadline,
    nextBadge = thumbBadge,
    nextStyle = thumbStyle
  ) => {
    setIsGeneratingThumb(true);
    try {
      const rendered = await generateStyledThumbnailDataUrl({
        videoEl: videoRef.current,
        fallbackImageUrl: clip.thumbnailDataUrl,
        headline: nextHeadline,
        badgeText: nextBadge,
        stylePreset: nextStyle,
      });
      setThumbnailDataUrl(rendered);
      return rendered;
    } finally {
      setIsGeneratingThumb(false);
    }
  };

  useEffect(() => {
    if (editorTab === 'thumbnail') {
      void handleRenderThumbnail();
    }
  }, [editorTab]);

  const handleOneTapTrendingAndCaption = () => {
    const trendingTrack = ROYALTY_FREE_TRACKS[0];
    setSelectedPresetId(trendingTrack.id);
    setMusicBlob(builtInTrackBlobs[trendingTrack.id]);
    setMusicName(trendingTrack.title);
    setMusicVolume(0.45);
    setOriginalVolume(0.85);
    setAutoCaption('What a Headshot!');
    setSavedMessage('Applied Trending Music + Auto Caption: "What a Headshot!" (Click Save Clip to persist)');
  };

  const handleSaveThumbnailWithClip = async () => {
    const rendered = await handleRenderThumbnail();
    setIsSaving(true);
    try {
      await onSaveClip({
        ...clip,
        title: title.trim() || clip.title,
        autoCaption: autoCaption.trim() || undefined,
        thumbnailDataUrl: rendered,
        musicBlob,
        musicName,
        musicVolume,
        voiceBlob,
        voiceName,
        voiceVolume,
        originalVolume,
      });
      setSavedMessage('Thumbnail ("' + thumbHeadline + '") saved with clip!');
    } finally {
      setIsSaving(false);
    }
  };

  const handleQuickShare = async (platform: ShareTargetPlatform) => {
    setIsSharing(true);
    try {
      const msg = await shareClipToPlatform({
        platform,
        title: title.trim() || clip.title,
        gameTag: clip.gameTag,
        autoCaption: autoCaption.trim() || 'What a Headshot!',
        videoBlob: clip.videoBlob,
        videoMimeType: clip.videoMimeType,
        nativeUri: clip.nativeUri,
      });
      setSavedMessage(msg);
    } finally {
      setIsSharing(false);
    }
  };

  const clipSpanSec = Math.max(0.5, Math.round((trimEnd - trimStart) * 10) / 10);

  // Keep last speed segment end aligned with trimmed duration
  useEffect(() => {
    setSpeedSegments((prev) => {
      if (prev.length === 0) {
        return [{ id: 'seg-0', startSec: 0, endSec: clipSpanSec, speed: 1 }];
      }
      const next = prev.map((s) => ({ ...s }));
      next[0].startSec = 0;
      const filtered = next.filter((s, idx) => idx === 0 || s.startSec < clipSpanSec - 0.3);
      filtered[filtered.length - 1].endSec = clipSpanSec;
      return filtered;
    });
    setSplitCursorSec((c) => Math.min(Math.max(0.4, c), Math.max(0.5, clipSpanSec - 0.4)));
  }, [clipSpanSec]);

  const handleSplitAtPoint = () => {
    const point = Math.round(
      Math.min(Math.max(0.4, splitCursorSec), Math.max(0.5, clipSpanSec - 0.4)) * 10
    ) / 10;

    setSpeedSegments((prev) => {
      const idx = prev.findIndex((s) => point > s.startSec + 0.3 && point < s.endSec - 0.3);
      if (idx === -1) return prev;
      const target = prev[idx];
      const left: SpeedSegment = {
        id: target.id,
        startSec: target.startSec,
        endSec: point,
        speed: target.speed,
      };
      const newId = `seg-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 5)}`;
      const right: SpeedSegment = {
        id: newId,
        startSec: point,
        endSec: target.endSec,
        speed: target.speed,
      };
      const updated = [...prev.slice(0, idx), left, right, ...prev.slice(idx + 1)];
      setSelectedSegmentId(newId);
      return updated;
    });
    setSavedMessage(`Split clip at ${point.toFixed(1)}s — tap a part below to change its speed.`);
  };

  const handleSetSelectedSegmentSpeed = (speed: SpeedPreset) => {
    setSpeedSegments((prev) =>
      prev.map((seg) => (seg.id === selectedSegmentId ? { ...seg, speed } : seg))
    );
    setLivePlaybackSpeed(speed);
    if (videoRef.current) {
      const offset = Math.max(0, videoRef.current.currentTime - trimStart);
      const activeSeg = speedSegments.find((s) => offset >= s.startSec && offset <= s.endSec);
      if (!activeSeg || activeSeg.id === selectedSegmentId) {
        videoRef.current.playbackRate = speed;
      }
    }
  };

  const handleApplyKillSlowMoPreset = () => {
    const p1 = Math.round(clipSpanSec * 0.42 * 10) / 10;
    const p2 = Math.round(clipSpanSec * 0.74 * 10) / 10;
    if (p1 < 0.5 || p2 <= p1 + 0.5 || clipSpanSec - p2 < 0.5) {
      handleSetSelectedSegmentSpeed(0.5);
      return;
    }
    const seg1: SpeedSegment = { id: 'seg-normal', startSec: 0, endSec: p1, speed: 1 };
    const seg2: SpeedSegment = { id: 'seg-kill-slow', startSec: p1, endSec: p2, speed: 0.5 };
    const seg3: SpeedSegment = { id: 'seg-fast-outro', startSec: p2, endSec: clipSpanSec, speed: 2 };
    setSpeedSegments([seg1, seg2, seg3]);
    setSelectedSegmentId('seg-kill-slow');
    setSavedMessage('Applied Kill Slow-Mo Split: Normal 1x → Slow-Mo 0.5x → Fast 2x!');
  };

  const handleResetSpeedSplits = () => {
    setSpeedSegments([{ id: 'seg-0', startSec: 0, endSec: clipSpanSec, speed: 1 }]);
    setSelectedSegmentId('seg-0');
    setLivePlaybackSpeed(1);
    if (videoRef.current) videoRef.current.playbackRate = 1;
    setSavedMessage('Speed reset to 1x Normal.');
  };

  const handleLoadedMetadata = () => {
    const el = videoRef.current;
    if (!el || !Number.isFinite(el.duration) || el.duration <= 0) return;
    const dur = Math.max(1, Math.round(el.duration * 10) / 10);
    setVideoDuration(dur);
    if (clip.trimEnd > dur || clip.trimEnd <= clip.trimStart) {
      setTrimEnd(dur);
    }
  };

  const handleVideoPlay = () => {
    const el = videoRef.current;
    if (!el) return;
    if (el.currentTime < trimStart || el.currentTime >= trimEnd) {
      el.currentTime = trimStart;
    }
    const offset = Math.max(0, el.currentTime - trimStart);
    const activeSpd = getSpeedAtTime(speedSegments, offset);
    el.playbackRate = activeSpd;
    setLivePlaybackSpeed(activeSpd);
    if (voiceAudioRef.current) {
      voiceAudioRef.current.currentTime = Math.min(offset, voiceAudioRef.current.duration || offset);
      voiceAudioRef.current.play().catch(() => undefined);
    }
    if (musicAudioRef.current) {
      musicAudioRef.current.currentTime =
        musicAudioRef.current.duration > 0 ? offset % musicAudioRef.current.duration : 0;
      musicAudioRef.current.play().catch(() => undefined);
    }
  };

  const handleVideoPause = () => {
    voiceAudioRef.current?.pause();
    musicAudioRef.current?.pause();
  };

  const handleVideoTimeUpdate = () => {
    const el = videoRef.current;
    if (!el) return;
    const offset = Math.max(0, Math.min(clipSpanSec, el.currentTime - trimStart));
    setSplitCursorSec(Math.round(offset * 10) / 10);

    const activeSpd = getSpeedAtTime(speedSegments, offset);
    if (el.playbackRate !== activeSpd) {
      el.playbackRate = activeSpd;
    }
    if (livePlaybackSpeed !== activeSpd) {
      setLivePlaybackSpeed(activeSpd);
    }

    if (trimEnd > trimStart && el.currentTime >= trimEnd) {
      el.pause();
      el.currentTime = trimStart;
      voiceAudioRef.current?.pause();
      musicAudioRef.current?.pause();
    }
  };

  const togglePresetPreview = (trackId: string) => {
    if (previewTrackId === trackId) {
      trackPreviewAudioRef.current?.pause();
      setPreviewTrackId(null);
      return;
    }
    const blob = builtInTrackBlobs[trackId];
    if (!blob) return;
    if (trackPreviewUrlRef.current) URL.revokeObjectURL(trackPreviewUrlRef.current);
    const url = URL.createObjectURL(blob);
    trackPreviewUrlRef.current = url;
    if (!trackPreviewAudioRef.current) {
      trackPreviewAudioRef.current = new Audio();
    }
    trackPreviewAudioRef.current.src = url;
    trackPreviewAudioRef.current.volume = musicVolume;
    trackPreviewAudioRef.current.onended = () => setPreviewTrackId(null);
    trackPreviewAudioRef.current.play().then(() => setPreviewTrackId(trackId)).catch(() => undefined);
  };

  const handleSelectBuiltInMusic = (trackId: string, trackTitle: string) => {
    setSelectedPresetId(trackId);
    setMusicBlob(builtInTrackBlobs[trackId]);
    setMusicName(trackTitle);
    setSavedMessage(null);
  };

  const handleCustomMusicUpload = (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setMusicBlob(file);
    setMusicName(file.name);
    setSelectedPresetId('custom');
    setSavedMessage(null);
  };

  const handleCustomVoiceUpload = (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setVoiceBlob(file);
    setVoiceName(file.name);
    setVoiceError(null);
    setSavedMessage(null);
  };

  const drawWaveform = () => {
    const canvas = waveCanvasRef.current;
    const analyser = analyserRef.current;
    if (!canvas || !analyser) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const len = analyser.frequencyBinCount;
    const data = new Uint8Array(len);
    analyser.getByteTimeDomainData(data);

    ctx.fillStyle = '#0B0E14';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    ctx.lineWidth = 2;
    ctx.strokeStyle = '#38bdf8';
    ctx.beginPath();

    const step = canvas.width / len;
    let x = 0;
    for (let i = 0; i < len; i += 1) {
      const v = data[i] / 128.0;
      const y = (v * canvas.height) / 2;
      if (i === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
      x += step;
    }
    ctx.lineTo(canvas.width, canvas.height / 2);
    ctx.stroke();
    waveRafRef.current = requestAnimationFrame(drawWaveform);
  };

  const handleToggleVoiceRecord = async () => {
    if (isRecordingVoice) {
      mediaRecorderRef.current?.stop();
      return;
    }

    setVoiceError(null);
    setSavedMessage(null);
    if (!navigator.mediaDevices?.getUserMedia) {
      setVoiceError('Microphone is unavailable here. Upload a voiceover file instead.');
      return;
    }

    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      micStreamRef.current = stream;

      const audioCtx = new AudioContext();
      audioCtxRef.current = audioCtx;
      const src = audioCtx.createMediaStreamSource(stream);
      const analyser = audioCtx.createAnalyser();
      analyser.fftSize = 256;
      src.connect(analyser);
      analyserRef.current = analyser;

      const chunks: BlobPart[] = [];
      const recorder = new MediaRecorder(stream);
      mediaRecorderRef.current = recorder;

      recorder.ondataavailable = (ev) => {
        if (ev.data && ev.data.size > 0) chunks.push(ev.data);
      };

      recorder.onstop = () => {
        if (recTimerRef.current) {
          window.clearInterval(recTimerRef.current);
          recTimerRef.current = null;
        }
        cancelAnimationFrame(waveRafRef.current);
        stream.getTracks().forEach((t) => t.stop());
        audioCtx.close().catch(() => undefined);
        setIsRecordingVoice(false);

        const recorded = new Blob(chunks, { type: recorder.mimeType || 'audio/webm' });
        if (recorded.size > 0) {
          setVoiceBlob(recorded);
          setVoiceName(`Voiceover_${new Date().toLocaleTimeString()}`);
        }
      };

      setVoiceRecSeconds(0);
      setIsRecordingVoice(true);
      recorder.start();
      drawWaveform();
      recTimerRef.current = window.setInterval(() => {
        setVoiceRecSeconds((s) => s + 1);
      }, 1000);
    } catch {
      setVoiceError('Microphone permission denied. Allow mic or upload a voice track.');
    }
  };

  const handleSaveEditedClip = async (asNewVersion = true) => {
    setIsSaving(true);
    setSavedMessage(null);
    setSaveProgress(5);
    setSaveStage('Preparing new clip version…');

    try {
      const safeStart = Math.max(0, trimStart);
      const safeEnd = Math.max(safeStart + 0.5, trimEnd);
      const cutDuration = Math.max(1, Math.round((safeEnd - safeStart) * 10) / 10);

      let finalVideoBlob = clip.videoBlob;
      let finalVideoMime = clip.videoMimeType;
      let finalTrimStart = safeStart;
      let finalTrimEnd = safeEnd;
      let finalDuration = Math.round(cutDuration);

      const trimRangeChanged =
        safeStart > 0.2 || Math.abs(safeEnd - videoDuration) > 0.2;
      const visualChanged =
        aspectRatio !== '16:9' || filterPreset !== 'none' || effectMode !== 'none';
      const uniformSpeed =
        speedSegments.length === 1 && speedSegments[0].speed !== 1
          ? speedSegments[0].speed
          : undefined;

      const bakedWithFfmpeg = Boolean(
        applyHardTrim && (trimRangeChanged || visualChanged || uniformSpeed)
      );

      if (bakedWithFfmpeg) {
        setSaveStage('Rendering edited MP4 via FFmpeg…');
        const trimmed = await trimVideoWithFFmpeg({
          sourceBlob: clip.videoBlob,
          sourceFileName: clip.nativeFileName || `${clip.title}.mp4`,
          startSec: safeStart,
          durationSec: cutDuration,
          burnCredit: false,
          creditText: clip.permission.creditText,
          burnAutoCaption: autoCaption.trim().length > 0,
          autoCaptionText: autoCaption.trim(),
          aspectRatio,
          fitMode,
          filterPreset,
          effectMode,
          uniformSpeed,
          onProgress: (pct, stg) => {
            setSaveProgress(pct);
            setSaveStage(stg);
          },
        });
        finalVideoBlob = trimmed.mp4Blob;
        finalVideoMime = 'video/mp4';
        finalTrimStart = 0;
        finalTrimEnd = Math.round(cutDuration);
        finalDuration = Math.round(cutDuration);
      }

      const rawTitle = title.trim() || clip.title;
      const versionTitle = asNewVersion
        ? rawTitle === clip.title
          ? `${rawTitle} (Edited)`
          : rawTitle
        : rawTitle;

      const updatedClip: ClipItem = {
        ...clip,
        id: asNewVersion
          ? `clip-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`
          : clip.id,
        title: versionTitle,
        createdAt: asNewVersion ? Date.now() : clip.createdAt,
        durationSec: finalDuration,
        trimStart: finalTrimStart,
        trimEnd: finalTrimEnd,
        autoCaption: autoCaption.trim() || undefined,
        thumbnailDataUrl,
        videoBlob: finalVideoBlob,
        videoMimeType: finalVideoMime,
        musicBlob,
        musicName,
        musicVolume,
        voiceBlob,
        voiceName,
        voiceVolume,
        originalVolume,
        aspectRatio,
        fitMode,
        filterPreset: bakedWithFfmpeg ? 'none' : filterPreset,
        effectMode: bakedWithFfmpeg ? 'none' : effectMode,
        speedSegments:
          bakedWithFfmpeg && uniformSpeed
            ? [{ id: 'seg-0', startSec: 0, endSec: finalDuration, speed: 1 }]
            : speedSegments,
      };

      setSaveProgress(92);
      setSaveStage('Saving new version to My Clips…');
      await onSaveClip(updatedClip);

      // Save directly to Movies/ClipKaro folder on Android APK without removing original clip
      const cleanFileName = `${updatedClip.title.replace(/[^a-z0-9_-]+/gi, '_')}_${Date.now()}.mp4`;
      const savedNative = await saveVideoToNativeClipKaroFolder(cleanFileName, finalVideoBlob);

      setSaveProgress(100);
      setSavedMessage(
        savedNative
          ? 'Saved new version to My Clips & Movies/ClipKaro (original clip kept)!'
          : 'Saved new version to My Clips (original clip kept)!'
      );
    } catch (err) {
      setVoiceError(
        err instanceof Error ? err.message : 'Unable to save clip edits.'
      );
    } finally {
      setIsSaving(false);
    }
  };

  const selectedSegment =
    speedSegments.find((s) => s.id === selectedSegmentId) ?? speedSegments[0];
  const liveCssFilter = combineCssFilters(filterPreset, effectMode);

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="in-app-editor-title"
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 p-3 sm:p-5 backdrop-blur-sm"
    >
      <div className="flex max-h-[94vh] w-full max-w-5xl flex-col overflow-hidden rounded-2xl border border-slate-800 bg-[#121722] shadow-2xl">
        {/* Header */}
        <div className="flex items-center justify-between gap-3 border-b border-slate-800 px-5 py-3.5">
          <div className="min-w-0">
            <h2 id="in-app-editor-title" className="font-display text-lg font-bold text-white truncate">
              ClipKaro In-App Editor
            </h2>
            <p className="text-xs text-slate-400 truncate">
              Ratio · Cinematic Modes · Split Speed · Trim · Music · Voiceover · Thumbnail
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close editor"
            className="rounded-lg p-2 text-slate-400 hover:bg-slate-800 hover:text-white shrink-0"
          >
            <X className="h-5 w-5" aria-hidden="true" />
          </button>
        </div>

        {/* Body */}
        <div className="grid flex-1 grid-cols-1 gap-5 overflow-y-auto p-4 sm:p-5 lg:grid-cols-12">
          {/* Left: Video Preview + Basic Details */}
          <div className="space-y-4 lg:col-span-6">
            <div className="flex items-center justify-center rounded-xl border border-slate-800 bg-[#05070B] p-2">
              <div
                className={`relative overflow-hidden rounded-lg bg-black ${getAspectContainerClass(
                  aspectRatio
                )}`}
              >
                {videoUrl && (
                  <video
                    ref={videoRef}
                    src={videoUrl}
                    controls
                    playsInline
                    onLoadedMetadata={handleLoadedMetadata}
                    onPlay={handleVideoPlay}
                    onPause={handleVideoPause}
                    onTimeUpdate={handleVideoTimeUpdate}
                    style={{ filter: liveCssFilter }}
                    className={`h-full w-full ${
                      fitMode === 'fill' ? 'object-cover' : 'object-contain'
                    }`}
                  />
                )}
                {/* 2.35:1 Cinematic Letterbox Black Bars */}
                {effectMode === 'cinematic' && (
                  <>
                    <div className="pointer-events-none absolute inset-x-0 top-0 h-[12%] bg-black" />
                    <div className="pointer-events-none absolute inset-x-0 bottom-0 h-[12%] bg-black" />
                  </>
                )}
                {autoCaption.trim() && (
                  <div className="pointer-events-none absolute inset-x-0 bottom-12 flex justify-center px-4">
                    <span className="rounded bg-black px-3 py-1 text-xs font-bold text-white shadow">
                      {autoCaption}
                    </span>
                  </div>
                )}
                {musicUrl && <audio ref={musicAudioRef} src={musicUrl} loop className="hidden" />}
                {voiceUrl && <audio ref={voiceAudioRef} src={voiceUrl} className="hidden" />}
              </div>
            </div>

            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
              <div className="space-y-1">
                <label htmlFor="editor-clip-title" className="text-xs font-semibold text-slate-300">
                  Clip Title
                </label>
                <input
                  id="editor-clip-title"
                  type="text"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  className="w-full rounded-lg border border-slate-700 bg-[#0B0E14] px-3 py-2 text-xs text-white focus:border-rose-500 focus:outline-none"
                />
              </div>
              <div className="space-y-1.5">
                <label htmlFor="editor-clip-caption" className="text-xs font-semibold text-slate-300">
                  Auto Caption (Black Box)
                </label>
                <input
                  id="editor-clip-caption"
                  type="text"
                  value={autoCaption}
                  onChange={(e) => setAutoCaption(e.target.value)}
                  placeholder="e.g. What a Headshot!"
                  className="w-full rounded-lg border border-slate-700 bg-[#0B0E14] px-3 py-2 text-xs text-white placeholder:text-slate-500 focus:border-rose-500 focus:outline-none"
                />
                <div className="flex flex-wrap gap-1 pt-0.5">
                  {CAPTION_PRESETS.map((preset) => (
                    <button
                      key={preset}
                      type="button"
                      onClick={() => setAutoCaption(preset)}
                      className={`rounded border px-2 py-0.5 text-[10px] font-semibold transition-colors ${
                        autoCaption === preset
                          ? 'border-rose-500 bg-rose-950/40 text-rose-200'
                          : 'border-slate-700 bg-[#0B0E14] text-slate-300 hover:border-rose-500/60'
                      }`}
                    >
                      {preset}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Active Mix & Style Summary */}
            <div className="rounded-xl border border-slate-800 bg-[#0B0E14] p-3.5 text-xs text-slate-300 space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-semibold text-white">Timeline &amp; Style Summary</span>
                <span className="font-mono text-rose-300 tabular-nums">
                  {trimStart.toFixed(1)}s → {trimEnd.toFixed(1)}s ({clipSpanSec}s) · {livePlaybackSpeed}x
                </span>
              </div>
              <div className="flex flex-wrap items-center gap-2.5 text-[11px] text-slate-400">
                <span className="text-slate-200 font-semibold">
                  {aspectRatio} ({fitMode === 'fill' ? 'Fill' : 'Fit'})
                </span>
                <span>·</span>
                <span className="capitalize">
                  Filter: {filterPreset === 'bw' ? 'B&W' : filterPreset}
                </span>
                <span>·</span>
                <span className="capitalize">Mode: {effectMode}</span>
                <span>·</span>
                <span className={musicBlob ? 'text-amber-300' : ''}>
                  Music: {musicName ? `${musicName}` : 'None'}
                </span>
                <span>·</span>
                <span className={voiceBlob ? 'text-sky-300' : ''}>
                  Voice: {voiceName ? `${voiceName}` : 'None'}
                </span>
              </div>
            </div>
          </div>

          {/* Right: 4 Editor Tool Tabs + 1-Tap Trending Bar */}
          <div className="flex flex-col justify-between space-y-4 lg:col-span-6">
            <div className="space-y-4">
              {/* 1-Tap Trending Music + Auto Caption Banner */}
              <div className="flex flex-wrap items-center justify-between gap-2 rounded-xl border border-amber-500/35 bg-gradient-to-r from-amber-950/40 via-rose-950/30 to-[#0B0E14] p-3">
                <div className="min-w-0">
                  <div className="text-xs font-bold text-white">Trending Music + Auto Caption</div>
                  <div className="text-[11px] text-amber-200/90 truncate">
                    Adds Trending Phonk beat &amp; &ldquo;What a Headshot!&rdquo; caption in 1 tap
                  </div>
                </div>
                <button
                  type="button"
                  onClick={handleOneTapTrendingAndCaption}
                  className="inline-flex items-center gap-1.5 rounded-lg bg-amber-500 px-3 py-1.5 text-xs font-bold text-slate-950 hover:bg-amber-400 shrink-0"
                >
                  <Sparkles className="h-3.5 w-3.5" aria-hidden="true" />
                  <span>1-Tap Apply</span>
                </button>
              </div>

              {/* Tool Tabs (7 concise tabs covering Ratio, Cinematic, Speed + Trim, Music, Voice, Thumbnail) */}
              <div className="grid grid-cols-4 sm:grid-cols-7 gap-1 rounded-xl border border-slate-800 bg-[#0B0E14] p-1">
                {(
                  [
                    { id: 'trim', label: 'Trim', icon: Scissors },
                    { id: 'ratio', label: 'Ratio', icon: Maximize2 },
                    { id: 'looks', label: 'Cinematic', icon: Wand2 },
                    { id: 'speed', label: 'Speed', icon: Gauge },
                    { id: 'music', label: 'Music', icon: Music },
                    { id: 'voice', label: 'Voice', icon: Mic },
                    { id: 'thumbnail', label: 'Thumb', icon: ImageIcon },
                  ] as const
                ).map((t) => {
                  const Icon = t.icon;
                  const active = editorTab === t.id;
                  return (
                    <button
                      key={t.id}
                      type="button"
                      onClick={() => setEditorTab(t.id)}
                      className={`inline-flex flex-col sm:flex-row items-center justify-center gap-1 rounded-lg px-1.5 py-2 text-[11px] font-bold transition-colors ${
                        active
                          ? 'bg-rose-600 text-white'
                          : 'text-slate-400 hover:bg-slate-800 hover:text-slate-100'
                      }`}
                    >
                      <Icon className="h-3.5 w-3.5 shrink-0" aria-hidden="true" />
                      <span className="truncate">{t.label}</span>
                    </button>
                  );
                })}
              </div>

              {/* Tab 1: Trim / Cut */}
              {editorTab === 'trim' && (
                <div className="rounded-xl border border-slate-800 bg-[#0B0E14] p-4 space-y-4">
                  <div className="flex items-center justify-between">
                    <h3 className="text-sm font-bold text-white">Trim / Cut Clip Range</h3>
                    <span className="font-mono text-xs text-emerald-300 tabular-nums">
                      Selected: {clipSpanSec}s / {videoDuration.toFixed(1)}s
                    </span>
                  </div>

                  <div className="space-y-3">
                    <div className="space-y-1">
                      <div className="flex items-center justify-between text-xs text-slate-300">
                        <span>Start Time</span>
                        <span className="font-mono tabular-nums">{trimStart.toFixed(1)}s</span>
                      </div>
                      <input
                        type="range"
                        min={0}
                        max={Math.max(0.5, trimEnd - 0.5)}
                        step={0.5}
                        value={trimStart}
                        onChange={(e) => {
                          const v = Number(e.target.value);
                          setTrimStart(v);
                          if (videoRef.current) videoRef.current.currentTime = v;
                        }}
                        className="w-full accent-rose-500"
                      />
                    </div>

                    <div className="space-y-1">
                      <div className="flex items-center justify-between text-xs text-slate-300">
                        <span>End Time</span>
                        <span className="font-mono tabular-nums">{trimEnd.toFixed(1)}s</span>
                      </div>
                      <input
                        type="range"
                        min={Math.min(videoDuration, trimStart + 0.5)}
                        max={Math.max(1, videoDuration)}
                        step={0.5}
                        value={trimEnd}
                        onChange={(e) => {
                          const v = Number(e.target.value);
                          setTrimEnd(v);
                          if (videoRef.current) videoRef.current.currentTime = v;
                        }}
                        className="w-full accent-rose-500"
                      />
                    </div>
                  </div>

                  <label className="flex items-start gap-2.5 rounded-lg border border-slate-800 bg-[#121722] p-3 text-xs text-slate-300 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={applyHardTrim}
                      onChange={(e) => setApplyHardTrim(e.target.checked)}
                      className="mt-0.5 accent-rose-500"
                    />
                    <div>
                      <div className="font-semibold text-white">Export newly rendered MP4 via FFmpeg</div>
                      <div className="text-[11px] text-slate-400">
                        Unchecked saves instant new version with ratio, filters, speed &amp; trim; checked renders a standalone MP4 file.
                      </div>
                    </div>
                  </label>
                </div>
              )}

              {/* Tab 2: Aspect Ratio (16:9, 9:16, 1:1, 4:5 + Auto Fit/Fill) */}
              {editorTab === 'ratio' && (
                <div className="rounded-xl border border-slate-800 bg-[#0B0E14] p-4 space-y-4">
                  <div className="flex items-center justify-between gap-2">
                    <h3 className="text-sm font-bold text-white">Aspect Ratio</h3>
                    <div className="inline-flex rounded-lg border border-slate-700 bg-[#121722] p-0.5">
                      <button
                        type="button"
                        onClick={() => setFitMode('fill')}
                        className={`rounded-md px-2.5 py-1 text-[11px] font-bold transition-colors ${
                          fitMode === 'fill'
                            ? 'bg-rose-600 text-white'
                            : 'text-slate-300 hover:text-white'
                        }`}
                      >
                        Auto Fill (No Black Bars)
                      </button>
                      <button
                        type="button"
                        onClick={() => setFitMode('fit')}
                        className={`rounded-md px-2.5 py-1 text-[11px] font-bold transition-colors ${
                          fitMode === 'fit'
                            ? 'bg-rose-600 text-white'
                            : 'text-slate-300 hover:text-white'
                        }`}
                      >
                        Fit Full Video
                      </button>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-2.5">
                    {ASPECT_RATIO_OPTIONS.map((opt) => {
                      const active = aspectRatio === opt.id;
                      return (
                        <button
                          key={opt.id}
                          type="button"
                          onClick={() => setAspectRatio(opt.id)}
                          className={`flex flex-col items-start gap-1 rounded-xl border p-3 text-left transition-colors ${
                            active
                              ? 'border-rose-500 bg-rose-950/30 text-white'
                              : 'border-slate-800 bg-[#121722] text-slate-300 hover:border-slate-600'
                          }`}
                        >
                          <div className="flex w-full items-center justify-between">
                            <span className="font-display text-sm font-extrabold">{opt.label}</span>
                            <Layers className="h-3.5 w-3.5 text-rose-400" aria-hidden="true" />
                          </div>
                          <span className="text-[11px] text-slate-400">{opt.platformHint}</span>
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* Tab 3: Cinematic + Filters & Modes */}
              {editorTab === 'looks' && (
                <div className="rounded-xl border border-slate-800 bg-[#0B0E14] p-4 space-y-4">
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <h3 className="text-sm font-bold text-white">Pro Filters</h3>
                      <button
                        type="button"
                        onClick={() => {
                          setFilterPreset('none');
                          setEffectMode('none');
                        }}
                        className="text-[11px] font-semibold text-slate-400 hover:text-white"
                      >
                        Reset Looks
                      </button>
                    </div>
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5">
                      {FILTER_PRESETS.map((flt) => {
                        const active = filterPreset === flt.id;
                        return (
                          <button
                            key={flt.id}
                            type="button"
                            onClick={() => setFilterPreset(flt.id)}
                            className={`rounded-lg border px-2.5 py-2 text-xs font-bold transition-colors ${
                              active
                                ? 'border-rose-500 bg-rose-600 text-white'
                                : 'border-slate-800 bg-[#121722] text-slate-300 hover:border-slate-600'
                            }`}
                          >
                            {flt.label}
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  <div className="space-y-2 border-t border-slate-800 pt-3">
                    <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400">
                      Cinematic &amp; Scene Modes
                    </h4>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      {EFFECT_MODES.map((mode) => {
                        const active = effectMode === mode.id;
                        return (
                          <button
                            key={mode.id}
                            type="button"
                            onClick={() => setEffectMode(mode.id)}
                            className={`flex flex-col items-start rounded-xl border px-3 py-2 text-left transition-colors ${
                              active
                                ? 'border-amber-400 bg-amber-950/30 text-white'
                                : 'border-slate-800 bg-[#121722] text-slate-300 hover:border-slate-600'
                            }`}
                          >
                            <div className="flex items-center gap-1.5 text-xs font-bold">
                              <Film className="h-3.5 w-3.5 text-amber-400" aria-hidden="true" />
                              <span>{mode.label}</span>
                            </div>
                            <span className="mt-0.5 text-[11px] text-slate-400">
                              {mode.description}
                            </span>
                          </button>
                        );
                      })}
                    </div>
                  </div>
                </div>
              )}

              {/* Tab 4: Speed Control + Split Speed Timeline */}
              {editorTab === 'speed' && (
                <div className="rounded-xl border border-slate-800 bg-[#0B0E14] p-4 space-y-4">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <h3 className="text-sm font-bold text-white">Speed Control &amp; Split Speed</h3>
                    <div className="flex items-center gap-1.5">
                      <button
                        type="button"
                        onClick={handleApplyKillSlowMoPreset}
                        className="rounded-lg border border-sky-500/40 bg-sky-950/30 px-2.5 py-1 text-[11px] font-bold text-sky-300 hover:bg-sky-900/40"
                      >
                        1-Tap Kill Slow-Mo
                      </button>
                      <button
                        type="button"
                        onClick={handleResetSpeedSplits}
                        className="inline-flex items-center gap-1 rounded-lg border border-slate-700 bg-[#121722] px-2 py-1 text-[11px] font-semibold text-slate-300 hover:text-white"
                      >
                        <RotateCcw className="h-3 w-3" aria-hidden="true" />
                        <span>Reset</span>
                      </button>
                    </div>
                  </div>

                  {/* Color-Coded Speed Timeline */}
                  <div className="space-y-1.5">
                    <div className="flex items-center justify-between text-[11px] text-slate-400">
                      <span>Tap any part to change its speed</span>
                      <span className="flex items-center gap-2">
                        <span className="text-sky-300">■ Slow</span>
                        <span className="text-emerald-300">■ 1x</span>
                        <span className="text-rose-300">■ Fast</span>
                      </span>
                    </div>
                    <div className="flex h-10 w-full overflow-hidden rounded-lg border border-slate-700 bg-[#121722] p-0.5 gap-0.5">
                      {speedSegments.map((seg, idx) => {
                        const pct = Math.max(8, ((seg.endSec - seg.startSec) / clipSpanSec) * 100);
                        const styles = getSpeedSegmentClasses(seg.speed);
                        const isSelected = selectedSegment?.id === seg.id;
                        return (
                          <button
                            key={seg.id}
                            type="button"
                            onClick={() => {
                              setSelectedSegmentId(seg.id);
                              if (videoRef.current) {
                                videoRef.current.currentTime = trimStart + seg.startSec;
                              }
                            }}
                            style={{ width: `${pct}%` }}
                            className={`flex items-center justify-center rounded text-[11px] font-extrabold text-white transition-all ${
                              styles.barClass
                            } ${isSelected ? 'ring-2 ring-white' : 'opacity-85'}`}
                            title={`Part ${idx + 1}: ${seg.startSec.toFixed(1)}s–${seg.endSec.toFixed(1)}s (${seg.speed}x)`}
                          >
                            {seg.speed}x
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  {/* Split Playhead Scrubber + Split Button */}
                  <div className="flex flex-col gap-2 rounded-lg border border-slate-800 bg-[#121722] p-3">
                    <div className="flex items-center justify-between text-xs text-slate-300">
                      <span>Split Position</span>
                      <span className="font-mono font-bold text-white tabular-nums">
                        {splitCursorSec.toFixed(1)}s / {clipSpanSec.toFixed(1)}s
                      </span>
                    </div>
                    <div className="flex items-center gap-2.5">
                      <input
                        type="range"
                        min={0.4}
                        max={Math.max(0.5, clipSpanSec - 0.4)}
                        step={0.1}
                        value={splitCursorSec}
                        onChange={(e) => {
                          const v = Number(e.target.value);
                          setSplitCursorSec(v);
                          if (videoRef.current) videoRef.current.currentTime = trimStart + v;
                        }}
                        className="flex-1 accent-rose-500"
                      />
                      <button
                        type="button"
                        onClick={handleSplitAtPoint}
                        className="inline-flex items-center gap-1.5 rounded-lg bg-rose-600 px-3 py-1.5 text-xs font-bold text-white hover:bg-rose-500 shrink-0"
                      >
                        <SplitSquareHorizontal className="h-3.5 w-3.5" aria-hidden="true" />
                        <span>Split</span>
                      </button>
                    </div>
                  </div>

                  {/* Speed Buttons + Slider for Selected Part */}
                  {selectedSegment && (
                    <div className="space-y-2.5 border-t border-slate-800 pt-3">
                      <div className="flex items-center justify-between text-xs">
                        <span className="font-semibold text-slate-300">
                          Part Speed ({selectedSegment.startSec.toFixed(1)}s → {selectedSegment.endSec.toFixed(1)}s)
                        </span>
                        <span className="font-mono font-bold text-amber-300">
                          {selectedSegment.speed}x
                        </span>
                      </div>
                      <div className="grid grid-cols-5 gap-1.5">
                        {SPEED_OPTIONS.map((spd) => {
                          const active = selectedSegment.speed === spd;
                          return (
                            <button
                              key={spd}
                              type="button"
                              onClick={() => handleSetSelectedSegmentSpeed(spd)}
                              className={`rounded-lg border py-1.5 text-xs font-extrabold transition-colors ${
                                active
                                  ? 'border-rose-500 bg-rose-600 text-white'
                                  : 'border-slate-700 bg-[#121722] text-slate-300 hover:border-slate-500'
                              }`}
                            >
                              {spd}x
                            </button>
                          );
                        })}
                      </div>
                      <input
                        type="range"
                        min={0}
                        max={SPEED_OPTIONS.length - 1}
                        step={1}
                        value={Math.max(0, SPEED_OPTIONS.indexOf(selectedSegment.speed))}
                        onChange={(e) => {
                          const idx = Number(e.target.value);
                          handleSetSelectedSegmentSpeed(SPEED_OPTIONS[idx] ?? 1);
                        }}
                        aria-label="Speed slider"
                        className="w-full accent-rose-500"
                      />
                    </div>
                  )}
                </div>
              )}

              {/* Tab 2: Add Music */}
              {editorTab === 'music' && (
                <div className="rounded-xl border border-slate-800 bg-[#0B0E14] p-4 space-y-4">
                  <div className="flex items-center justify-between gap-2">
                    <h3 className="text-sm font-bold text-white">Add Background Music</h3>
                    <div className="flex items-center gap-2">
                      <input
                        ref={customMusicInputRef}
                        type="file"
                        accept="audio/*"
                        onChange={handleCustomMusicUpload}
                        className="hidden"
                      />
                      <button
                        type="button"
                        onClick={() => customMusicInputRef.current?.click()}
                        className="inline-flex items-center gap-1.5 rounded-lg border border-slate-700 bg-[#121722] px-2.5 py-1.5 text-xs font-semibold text-slate-200 hover:border-rose-500"
                      >
                        <Upload className="h-3.5 w-3.5" aria-hidden="true" />
                        <span>Upload Audio</span>
                      </button>
                      {musicBlob && (
                        <button
                          type="button"
                          onClick={() => {
                            setMusicBlob(undefined);
                            setMusicName(undefined);
                          }}
                          className="rounded-lg border border-rose-500/40 bg-rose-950/30 p-1.5 text-rose-300 hover:bg-rose-900/40"
                          title="Remove music"
                        >
                          <Trash2 className="h-3.5 w-3.5" aria-hidden="true" />
                        </button>
                      )}
                    </div>
                  </div>

                  <div className="max-h-44 space-y-1.5 overflow-y-auto pr-1">
                    {ROYALTY_FREE_TRACKS.map((track) => {
                      const active = musicName === track.title || selectedPresetId === track.id;
                      const previewing = previewTrackId === track.id;
                      return (
                        <div
                          key={track.id}
                          className={`flex items-center justify-between gap-2 rounded-lg border px-3 py-2 text-xs ${
                            active
                              ? 'border-rose-500/60 bg-rose-950/20 text-white'
                              : 'border-slate-800 bg-[#121722] text-slate-300'
                          }`}
                        >
                          <button
                            type="button"
                            onClick={() => handleSelectBuiltInMusic(track.id, track.title)}
                            className="min-w-0 flex-1 text-left"
                          >
                            <div className="font-semibold truncate">{track.title}</div>
                            <div className="text-[11px] text-slate-400">
                              {track.mood} · {track.bpm} BPM
                            </div>
                          </button>
                          <button
                            type="button"
                            onClick={() => togglePresetPreview(track.id)}
                            aria-label={previewing ? 'Pause preview' : 'Preview track'}
                            className="rounded-md border border-slate-700 bg-[#0B0E14] p-1.5 text-slate-200 hover:border-rose-500"
                          >
                            {previewing ? (
                              <Pause className="h-3.5 w-3.5" aria-hidden="true" />
                            ) : (
                              <Play className="h-3.5 w-3.5" aria-hidden="true" />
                            )}
                          </button>
                        </div>
                      );
                    })}
                  </div>

                  {/* Mix Sliders */}
                  <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 border-t border-slate-800 pt-3">
                    <div className="space-y-1">
                      <div className="flex items-center justify-between text-xs text-slate-300">
                        <span className="inline-flex items-center gap-1">
                          <Volume2 className="h-3.5 w-3.5 text-amber-400" aria-hidden="true" />
                          <span>Music Volume</span>
                        </span>
                        <span className="font-mono tabular-nums">{Math.round(musicVolume * 100)}%</span>
                      </div>
                      <input
                        type="range"
                        min={0}
                        max={1}
                        step={0.05}
                        value={musicVolume}
                        onChange={(e) => setMusicVolume(Number(e.target.value))}
                        className="w-full accent-amber-400"
                      />
                    </div>
                    <div className="space-y-1">
                      <div className="flex items-center justify-between text-xs text-slate-300">
                        <span>Game Sound Volume</span>
                        <span className="font-mono tabular-nums">{Math.round(originalVolume * 100)}%</span>
                      </div>
                      <input
                        type="range"
                        min={0}
                        max={1}
                        step={0.05}
                        value={originalVolume}
                        onChange={(e) => setOriginalVolume(Number(e.target.value))}
                        className="w-full accent-rose-500"
                      />
                    </div>
                  </div>
                </div>
              )}

              {/* Tab 3: Add Voiceover */}
              {editorTab === 'voice' && (
                <div className="rounded-xl border border-slate-800 bg-[#0B0E14] p-4 space-y-4">
                  <div className="flex items-center justify-between gap-2">
                    <h3 className="text-sm font-bold text-white">Record or Upload Voiceover</h3>
                    <div className="flex items-center gap-2">
                      <input
                        ref={customVoiceInputRef}
                        type="file"
                        accept="audio/*"
                        onChange={handleCustomVoiceUpload}
                        className="hidden"
                      />
                      <button
                        type="button"
                        onClick={() => customVoiceInputRef.current?.click()}
                        className="inline-flex items-center gap-1.5 rounded-lg border border-slate-700 bg-[#121722] px-2.5 py-1.5 text-xs font-semibold text-slate-200 hover:border-sky-500"
                      >
                        <Upload className="h-3.5 w-3.5" aria-hidden="true" />
                        <span>Upload</span>
                      </button>
                      {voiceBlob && (
                        <button
                          type="button"
                          onClick={() => {
                            setVoiceBlob(undefined);
                            setVoiceName(undefined);
                          }}
                          className="rounded-lg border border-rose-500/40 bg-rose-950/30 p-1.5 text-rose-300 hover:bg-rose-900/40"
                          title="Clear voiceover"
                        >
                          <Trash2 className="h-3.5 w-3.5" aria-hidden="true" />
                        </button>
                      )}
                    </div>
                  </div>

                  <canvas
                    ref={waveCanvasRef}
                    width={420}
                    height={56}
                    className="w-full rounded-lg border border-slate-800 bg-[#0B0E14]"
                  />

                  <div className="flex items-center justify-between gap-3">
                    <button
                      type="button"
                      onClick={handleToggleVoiceRecord}
                      className={`inline-flex items-center gap-2 rounded-lg px-4 py-2 text-xs font-bold text-white transition-colors ${
                        isRecordingVoice
                          ? 'bg-rose-600 hover:bg-rose-500'
                          : 'bg-sky-600 hover:bg-sky-500'
                      }`}
                    >
                      {isRecordingVoice ? (
                        <>
                          <Square className="h-3.5 w-3.5 fill-current" aria-hidden="true" />
                          <span>Stop ({formatSeconds(voiceRecSeconds)})</span>
                        </>
                      ) : (
                        <>
                          <Mic className="h-3.5 w-3.5" aria-hidden="true" />
                          <span>Record Voiceover</span>
                        </>
                      )}
                    </button>

                    {voiceName && (
                      <span className="truncate text-xs font-medium text-sky-300">{voiceName}</span>
                    )}
                  </div>

                  {voiceError && (
                    <p className="text-xs text-rose-300">{voiceError}</p>
                  )}

                  <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 border-t border-slate-800 pt-3">
                    <div className="space-y-1">
                      <div className="flex items-center justify-between text-xs text-slate-300">
                        <span>Voiceover Volume</span>
                        <span className="font-mono tabular-nums">{Math.round(voiceVolume * 100)}%</span>
                      </div>
                      <input
                        type="range"
                        min={0}
                        max={1}
                        step={0.05}
                        value={voiceVolume}
                        onChange={(e) => setVoiceVolume(Number(e.target.value))}
                        className="w-full accent-sky-400"
                      />
                    </div>
                    <div className="space-y-1">
                      <div className="flex items-center justify-between text-xs text-slate-300">
                        <span>Game Sound Volume</span>
                        <span className="font-mono tabular-nums">{Math.round(originalVolume * 100)}%</span>
                      </div>
                      <input
                        type="range"
                        min={0}
                        max={1}
                        step={0.05}
                        value={originalVolume}
                        onChange={(e) => setOriginalVolume(Number(e.target.value))}
                        className="w-full accent-rose-500"
                      />
                    </div>
                  </div>
                </div>
              )}

              {/* Tab 4: Thumbnail Maker ("1 VS 4 CLUTCH") */}
              {editorTab === 'thumbnail' && (
                <div className="rounded-xl border border-slate-800 bg-[#0B0E14] p-4 space-y-3.5">
                  <div className="flex items-center justify-between gap-2">
                    <h3 className="text-sm font-bold text-white">Thumbnail Maker</h3>
                    <button
                      type="button"
                      disabled={isGeneratingThumb}
                      onClick={() => handleRenderThumbnail()}
                      className="inline-flex items-center gap-1.5 rounded-lg border border-slate-700 bg-[#121722] px-2.5 py-1.5 text-xs font-semibold text-slate-200 hover:border-rose-500 disabled:opacity-50"
                    >
                      <RefreshCw className={`h-3.5 w-3.5 ${isGeneratingThumb ? 'animate-spin' : ''}`} aria-hidden="true" />
                      <span>Capture Frame</span>
                    </button>
                  </div>

                  <div className="overflow-hidden rounded-lg border border-slate-800 bg-black aspect-video">
                    {thumbnailDataUrl ? (
                      <img
                        src={thumbnailDataUrl}
                        alt="Generated thumbnail preview"
                        className="h-full w-full object-cover"
                      />
                    ) : (
                      <div className="flex h-full items-center justify-center text-xs text-slate-400">
                        Rendering thumbnail preview…
                      </div>
                    )}
                  </div>

                  <div className="grid grid-cols-1 gap-2.5 sm:grid-cols-2">
                    <div className="space-y-1">
                      <label htmlFor="thumb-headline" className="text-[11px] font-semibold text-slate-300">
                        Bold Text Style
                      </label>
                      <input
                        id="thumb-headline"
                        type="text"
                        value={thumbHeadline}
                        onChange={(e) => {
                          const next = e.target.value;
                          setThumbHeadline(next);
                          void handleRenderThumbnail(next, thumbBadge, thumbStyle);
                        }}
                        className="w-full rounded-lg border border-slate-700 bg-[#121722] px-2.5 py-1.5 text-xs font-bold text-white focus:border-rose-500 focus:outline-none"
                      />
                    </div>
                    <div className="space-y-1">
                      <label htmlFor="thumb-badge" className="text-[11px] font-semibold text-slate-300">
                        Corner Tag
                      </label>
                      <input
                        id="thumb-badge"
                        type="text"
                        value={thumbBadge}
                        onChange={(e) => {
                          const next = e.target.value;
                          setThumbBadge(next);
                          void handleRenderThumbnail(thumbHeadline, next, thumbStyle);
                        }}
                        className="w-full rounded-lg border border-slate-700 bg-[#121722] px-2.5 py-1.5 text-xs font-bold text-white focus:border-rose-500 focus:outline-none"
                      />
                    </div>
                  </div>

                  <div className="flex flex-wrap gap-1.5">
                    {THUMBNAIL_TEXT_PRESETS.map((preset) => (
                      <button
                        key={preset}
                        type="button"
                        onClick={() => {
                          setThumbHeadline(preset);
                          void handleRenderThumbnail(preset, thumbBadge, thumbStyle);
                        }}
                        className={`rounded-md border px-2 py-1 text-[11px] font-bold transition-colors ${
                          thumbHeadline === preset
                            ? 'border-amber-400 bg-amber-950/40 text-amber-200'
                            : 'border-slate-700 bg-[#121722] text-slate-300 hover:border-rose-500'
                        }`}
                      >
                        {preset}
                      </button>
                    ))}
                  </div>

                  <div className="flex flex-wrap items-center justify-between gap-2 pt-1">
                    <div className="flex items-center gap-1.5">
                      {(
                        [
                          { id: 'clutch-red-gold', label: 'Red & Gold' },
                          { id: 'cyber-cyan', label: 'Cyber Cyan' },
                          { id: 'dark-impact', label: 'Dark Impact' },
                        ] as { id: ThumbnailStylePreset; label: string }[]
                      ).map((st) => (
                        <button
                          key={st.id}
                          type="button"
                          onClick={() => {
                            setThumbStyle(st.id);
                            void handleRenderThumbnail(thumbHeadline, thumbBadge, st.id);
                          }}
                          className={`rounded-md px-2.5 py-1 text-[11px] font-semibold transition-colors ${
                            thumbStyle === st.id
                              ? 'bg-rose-600 text-white'
                              : 'border border-slate-700 bg-[#121722] text-slate-300 hover:text-white'
                          }`}
                        >
                          {st.label}
                        </button>
                      ))}
                    </div>

                    <div className="flex items-center gap-2">
                      {thumbnailDataUrl && (
                        <a
                          href={thumbnailDataUrl}
                          download={`${title.replace(/[^a-z0-9_-]/gi, '_')}_thumbnail.jpg`}
                          className="inline-flex items-center gap-1 rounded-lg border border-slate-700 bg-[#121722] px-2.5 py-1.5 text-xs font-semibold text-slate-200 hover:text-white"
                        >
                          <Download className="h-3.5 w-3.5" aria-hidden="true" />
                          <span>PNG/JPG</span>
                        </a>
                      )}
                      <button
                        type="button"
                        disabled={isSaving || isGeneratingThumb}
                        onClick={handleSaveThumbnailWithClip}
                        className="inline-flex items-center gap-1.5 rounded-lg bg-emerald-600 px-3 py-1.5 text-xs font-bold text-white hover:bg-emerald-500 disabled:opacity-50"
                      >
                        <Save className="h-3.5 w-3.5" aria-hidden="true" />
                        <span>Save Thumbnail with Clip</span>
                      </button>
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Save Progress, 1-Tap Share + Save Buttons */}
            <div className="space-y-3 border-t border-slate-800 pt-4">
              {isSaving && (
                <div className="space-y-1">
                  <div className="flex items-center justify-between text-xs text-slate-300">
                    <span>{saveStage}</span>
                    <span className="font-mono">{saveProgress}%</span>
                  </div>
                  <div className="h-2 w-full overflow-hidden rounded-full bg-slate-800">
                    <div
                      className="h-full bg-rose-500 transition-all"
                      style={{ width: `${saveProgress}%` }}
                    />
                  </div>
                </div>
              )}

              {savedMessage && (
                <div className="flex items-center gap-2 rounded-lg border border-emerald-500/40 bg-emerald-950/30 px-3 py-2 text-xs font-semibold text-emerald-200">
                  <CheckCircle2 className="h-4 w-4 text-emerald-400 shrink-0" aria-hidden="true" />
                  <span>{savedMessage}</span>
                </div>
              )}

              {/* 1-Tap Share Strip */}
              <div className="flex flex-wrap items-center justify-between gap-2 rounded-lg border border-slate-800 bg-[#0B0E14] px-3 py-2">
                <span className="inline-flex items-center gap-1.5 text-[11px] font-semibold text-slate-300">
                  <Share2 className="h-3.5 w-3.5 text-rose-400" aria-hidden="true" />
                  <span>1-Tap Share (#BGMI #ClipKaro):</span>
                </span>
                <div className="flex flex-wrap items-center gap-1.5">
                  <button
                    type="button"
                    disabled={isSharing}
                    onClick={() => handleQuickShare('youtube')}
                    className="rounded-md bg-red-600 px-2.5 py-1 text-[11px] font-bold text-white hover:bg-red-500 disabled:opacity-50"
                  >
                    YouTube Shorts
                  </button>
                  <button
                    type="button"
                    disabled={isSharing}
                    onClick={() => handleQuickShare('instagram')}
                    className="rounded-md bg-fuchsia-600 px-2.5 py-1 text-[11px] font-bold text-white hover:bg-fuchsia-500 disabled:opacity-50"
                  >
                    Instagram Reels
                  </button>
                  <button
                    type="button"
                    disabled={isSharing}
                    onClick={() => handleQuickShare('whatsapp')}
                    className="rounded-md bg-emerald-600 px-2.5 py-1 text-[11px] font-bold text-white hover:bg-emerald-500 disabled:opacity-50"
                  >
                    WhatsApp
                  </button>
                </div>
              </div>

              <div className="flex flex-wrap items-center justify-end gap-2.5">
                <button
                  type="button"
                  onClick={onClose}
                  className="rounded-lg border border-slate-700 bg-[#0B0E14] px-3.5 py-2 text-xs font-semibold text-slate-300 hover:text-white"
                >
                  Close
                </button>
                <button
                  type="button"
                  disabled={isSaving}
                  onClick={() => handleSaveEditedClip(true)}
                  className="inline-flex items-center gap-1.5 rounded-lg bg-rose-600 px-4 py-2 text-xs font-bold text-white hover:bg-rose-500 disabled:opacity-50"
                >
                  <Save className="h-3.5 w-3.5" aria-hidden="true" />
                  <span>{isSaving ? 'Saving…' : 'Save New Version'}</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

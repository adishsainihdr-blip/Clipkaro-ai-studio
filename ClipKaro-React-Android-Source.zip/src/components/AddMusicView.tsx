import { ChangeEvent, useEffect, useMemo, useRef, useState } from 'react';
import {
  CheckCircle2,
  Film,
  Music,
  Pause,
  Play,
  Scissors,
  ShieldCheck,
  Upload,
  Volume2,
} from 'lucide-react';
import { ClipItem, WorkspaceTab } from '../types/clipkaro';
import { generateRoyaltyFreeWavBlob, ROYALTY_FREE_TRACKS } from '../utils/mediaGenerators';

interface AddMusicViewProps {
  clips: ClipItem[];
  copyrightSafeMode: boolean;
  onSaveClip: (clip: ClipItem) => Promise<void>;
  onNavigate: (tab: WorkspaceTab) => void;
}

export function AddMusicView({
  clips,
  copyrightSafeMode,
  onSaveClip,
  onNavigate,
}: AddMusicViewProps) {
  const [selectedClipId, setSelectedClipId] = useState<string>(clips[0]?.id ?? '');
  const [selectedTrackId, setSelectedTrackId] = useState<string>(ROYALTY_FREE_TRACKS[0].id);
  const [customBlob, setCustomBlob] = useState<Blob | null>(null);
  const [customName, setCustomName] = useState<string>('');
  const [customLicenseConfirmed, setCustomLicenseConfirmed] = useState<boolean>(false);

  const [musicVolume, setMusicVolume] = useState<number>(0.45);
  const [originalVolume, setOriginalVolume] = useState<number>(0.85);
  const [previewPlayingId, setPreviewPlayingId] = useState<string | null>(null);
  const [isSaving, setIsSaving] = useState<boolean>(false);
  const [savedNotice, setSavedNotice] = useState<string | null>(null);

  const previewAudioRef = useRef<HTMLAudioElement | null>(null);
  const previewUrlRef = useRef<string | null>(null);
  const customInputRef = useRef<HTMLInputElement | null>(null);

  useEffect(() => {
    if (!selectedClipId && clips.length > 0) {
      setSelectedClipId(clips[0].id);
    }
  }, [clips, selectedClipId]);

  useEffect(() => {
    return () => {
      previewAudioRef.current?.pause();
      if (previewUrlRef.current) URL.revokeObjectURL(previewUrlRef.current);
    };
  }, []);

  const builtInTrackBlobs = useMemo(() => {
    const map: Record<string, Blob> = {};
    for (const track of ROYALTY_FREE_TRACKS) {
      map[track.id] = generateRoyaltyFreeWavBlob(track.id);
    }
    return map;
  }, []);

  const handleTogglePreview = (trackId: string, blob: Blob) => {
    if (previewPlayingId === trackId) {
      previewAudioRef.current?.pause();
      setPreviewPlayingId(null);
      return;
    }

    if (previewUrlRef.current) URL.revokeObjectURL(previewUrlRef.current);
    const nextUrl = URL.createObjectURL(blob);
    previewUrlRef.current = nextUrl;

    if (!previewAudioRef.current) {
      previewAudioRef.current = new Audio();
    }
    previewAudioRef.current.src = nextUrl;
    previewAudioRef.current.volume = musicVolume;
    previewAudioRef.current.onended = () => setPreviewPlayingId(null);
    previewAudioRef.current.play().then(() => setPreviewPlayingId(trackId)).catch(() => undefined);
  };

  const handleCustomMusicUpload = (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setCustomBlob(file);
    setCustomName(file.name);
    setSelectedTrackId('custom');
    setSavedNotice(null);
  };

  const activeBlob =
    selectedTrackId === 'custom' ? customBlob : builtInTrackBlobs[selectedTrackId] ?? null;

  const activeTrackLabel =
    selectedTrackId === 'custom'
      ? customName
      : ROYALTY_FREE_TRACKS.find((t) => t.id === selectedTrackId)?.title ?? 'Music Track';

  const canAttach =
    Boolean(selectedClipId) &&
    Boolean(activeBlob) &&
    (!copyrightSafeMode || selectedTrackId !== 'custom' || customLicenseConfirmed);

  const handleAttachMusic = async () => {
    const target = clips.find((c) => c.id === selectedClipId);
    if (!target || !activeBlob) return;
    setIsSaving(true);
    setSavedNotice(null);
    try {
      await onSaveClip({
        ...target,
        musicBlob: activeBlob,
        musicName: activeTrackLabel,
        musicVolume,
        originalVolume,
      });
      setSavedNotice(`"${activeTrackLabel}" attached to "${target.title}".`);
    } finally {
      setIsSaving(false);
    }
  };

  const selectedClip = clips.find((c) => c.id === selectedClipId) ?? null;

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-2 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <h1 className="font-display text-2xl font-bold tracking-tight text-white">Add Music</h1>
          <p className="mt-1 text-sm text-slate-400">
            Select a built-in copyright-safe royalty-free track or upload licensed audio to mix under your clip.
          </p>
        </div>
        {copyrightSafeMode && (
          <span className="inline-flex items-center gap-1.5 text-xs font-semibold text-emerald-400">
            <ShieldCheck className="h-4 w-4" aria-hidden="true" />
            <span>Copyright-Safe Library Prioritized</span>
          </span>
        )}
      </div>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
        {/* Left: Royalty-Free Track List + Custom Upload */}
        <section className="space-y-4 rounded-xl border border-slate-800 bg-[#121722] p-5 sm:p-6 lg:col-span-7">
          <div className="flex items-center justify-between">
            <h2 className="font-display text-base font-bold text-white">
              Royalty-Free Music Library
            </h2>
            <span className="text-xs text-slate-400">CC0 Safe Audio</span>
          </div>

          <div className="divide-y divide-slate-800/80 rounded-xl border border-slate-800 bg-[#0B0E14]">
            {ROYALTY_FREE_TRACKS.map((track) => {
              const isSelected = selectedTrackId === track.id;
              const isPreviewing = previewPlayingId === track.id;
              const blob = builtInTrackBlobs[track.id];

              return (
                <div
                  key={track.id}
                  className={`flex flex-wrap items-center justify-between gap-3 px-4 py-3.5 transition-colors ${
                    isSelected ? 'bg-rose-950/20' : 'hover:bg-slate-900/50'
                  }`}
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <button
                      type="button"
                      onClick={() => handleTogglePreview(track.id, blob)}
                      aria-label={isPreviewing ? `Pause ${track.title}` : `Preview ${track.title}`}
                      className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg border border-slate-700 bg-slate-900 text-white hover:border-rose-500"
                    >
                      {isPreviewing ? (
                        <Pause className="h-4 w-4" aria-hidden="true" />
                      ) : (
                        <Play className="h-4 w-4 fill-current" aria-hidden="true" />
                      )}
                    </button>
                    <div className="min-w-0">
                      <div className="font-display text-sm font-semibold text-white truncate">
                        {track.title}
                      </div>
                      <div className="flex flex-wrap items-center gap-2 text-xs text-slate-400 tabular-nums">
                        <span>{track.mood}</span>
                        <span aria-hidden="true">·</span>
                        <span>{track.bpm} BPM</span>
                        <span aria-hidden="true">·</span>
                        <span className="text-emerald-400">{track.license}</span>
                      </div>
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={() => {
                      setSelectedTrackId(track.id);
                      setSavedNotice(null);
                    }}
                    className={`rounded-lg px-3.5 py-1.5 text-xs font-semibold transition-colors whitespace-nowrap shrink-0 ${
                      isSelected
                        ? 'bg-rose-600 text-white'
                        : 'border border-slate-700 bg-slate-900 text-slate-300 hover:text-white'
                    }`}
                  >
                    {isSelected ? 'Selected' : 'Use Track'}
                  </button>
                </div>
              );
            })}
          </div>

          {/* Custom Music Upload */}
          <div className="rounded-xl border border-slate-800 bg-[#0B0E14] p-4 space-y-3">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div>
                <div className="text-sm font-semibold text-white">Custom Audio Upload</div>
                <div className="text-xs text-slate-400">
                  Upload MP3, WAV, or OGG background music from your device.
                </div>
              </div>
              <input
                ref={customInputRef}
                type="file"
                accept="audio/*"
                onChange={handleCustomMusicUpload}
                className="sr-only"
              />
              <button
                type="button"
                onClick={() => customInputRef.current?.click()}
                className="inline-flex items-center gap-2 rounded-lg border border-slate-700 bg-slate-900 px-3.5 py-2 text-xs font-semibold text-white hover:border-slate-500"
              >
                <Upload className="h-3.5 w-3.5" aria-hidden="true" />
                <span>Choose Audio</span>
              </button>
            </div>

            {customBlob && (
              <div className="flex flex-wrap items-center justify-between gap-3 border-t border-slate-800 pt-3">
                <div className="flex items-center gap-2 text-xs text-slate-200 truncate">
                  <Music className="h-4 w-4 text-amber-400 shrink-0" aria-hidden="true" />
                  <span className="truncate">{customName}</span>
                </div>
                <button
                  type="button"
                  onClick={() => handleTogglePreview('custom', customBlob)}
                  className="rounded-md border border-slate-700 px-3 py-1 text-xs font-medium text-white hover:bg-slate-800"
                >
                  {previewPlayingId === 'custom' ? 'Pause' : 'Preview'}
                </button>
              </div>
            )}

            {selectedTrackId === 'custom' && copyrightSafeMode && (
              <label className="flex items-start gap-2.5 pt-1 text-xs text-amber-200 cursor-pointer">
                <input
                  type="checkbox"
                  checked={customLicenseConfirmed}
                  onChange={(e) => setCustomLicenseConfirmed(e.target.checked)}
                  className="mt-0.5 rounded border-slate-600 accent-emerald-500"
                />
                <span>
                  Copyright-Safe Mode ON: I confirm I own or have commercial license rights to use this custom music file.
                </span>
              </label>
            )}
          </div>
        </section>

        {/* Right: Mix & Save */}
        <section className="flex flex-col justify-between gap-6 rounded-xl border border-slate-800 bg-[#121722] p-5 sm:p-6 lg:col-span-5">
          <div className="space-y-5">
            <h2 className="font-display text-base font-bold text-white">Mix with Clip</h2>

            {clips.length === 0 ? (
              <div className="space-y-3 rounded-lg border border-slate-800 bg-[#0B0E14] p-4 text-xs text-slate-400">
                <p>No clips saved yet. Cut a clip first before attaching music.</p>
                <button
                  type="button"
                  onClick={() => onNavigate('cut')}
                  className="inline-flex items-center gap-2 rounded-lg bg-slate-800 px-3.5 py-2 font-semibold text-white hover:bg-slate-700"
                >
                  <Scissors className="h-3.5 w-3.5" aria-hidden="true" />
                  <span>Go to Cut Video</span>
                </button>
              </div>
            ) : (
              <>
                <div className="space-y-1.5">
                  <label htmlFor="music-target-clip" className="block text-xs font-semibold text-slate-300">
                    Target Clip
                  </label>
                  <select
                    id="music-target-clip"
                    value={selectedClipId}
                    onChange={(e) => setSelectedClipId(e.target.value)}
                    className="w-full rounded-lg border border-slate-700/80 bg-[#0B0E14] px-3.5 py-2.5 text-sm text-white focus:border-rose-500 focus:outline-none"
                  >
                    {clips.map((c) => (
                      <option key={c.id} value={c.id}>
                        {c.title} ({c.durationSec}s)
                      </option>
                    ))}
                  </select>
                </div>

                {selectedClip && (
                  <div className="rounded-lg border border-slate-800 bg-[#0B0E14] p-3 text-xs text-slate-400 space-y-1">
                    <div className="font-medium text-slate-200">{selectedClip.title}</div>
                    <div>Selected track: {activeTrackLabel}</div>
                    {selectedClip.musicName && (
                      <div className="text-amber-400">Current music: {selectedClip.musicName}</div>
                    )}
                  </div>
                )}

                <div className="space-y-3">
                  <div className="space-y-1.5">
                    <div className="flex items-center justify-between text-xs">
                      <span className="inline-flex items-center gap-1.5 text-slate-300">
                        <Volume2 className="h-3.5 w-3.5 text-amber-400" aria-hidden="true" />
                        <span>Music Volume</span>
                      </span>
                      <span className="font-mono text-slate-300 tabular-nums">
                        {Math.round(musicVolume * 100)}%
                      </span>
                    </div>
                    <input
                      type="range"
                      min={0}
                      max={1}
                      step={0.05}
                      value={musicVolume}
                      onChange={(e) => {
                        const val = parseFloat(e.target.value);
                        setMusicVolume(val);
                        if (previewAudioRef.current) previewAudioRef.current.volume = val;
                      }}
                      className="w-full accent-amber-400"
                    />
                  </div>

                  <div className="space-y-1.5">
                    <div className="flex items-center justify-between text-xs">
                      <span className="text-slate-300">Original Video Audio</span>
                      <span className="font-mono text-slate-300 tabular-nums">
                        {Math.round(originalVolume * 100)}%
                      </span>
                    </div>
                    <input
                      type="range"
                      min={0}
                      max={1}
                      step={0.05}
                      value={originalVolume}
                      onChange={(e) => setOriginalVolume(parseFloat(e.target.value))}
                      className="w-full accent-rose-500"
                    />
                  </div>
                </div>
              </>
            )}

            {savedNotice && (
              <div className="flex items-center justify-between gap-2 rounded-lg border border-emerald-500/40 bg-emerald-950/25 p-3 text-xs text-emerald-200">
                <span className="inline-flex items-center gap-1.5">
                  <CheckCircle2 className="h-4 w-4 text-emerald-400 shrink-0" aria-hidden="true" />
                  <span>{savedNotice}</span>
                </span>
                <button
                  type="button"
                  onClick={() => onNavigate('clips')}
                  className="inline-flex items-center gap-1 rounded bg-emerald-600 px-2.5 py-1 font-semibold text-white hover:bg-emerald-500 shrink-0"
                >
                  <Film className="h-3 w-3" aria-hidden="true" />
                  <span>Play</span>
                </button>
              </div>
            )}
          </div>

          <button
            type="button"
            disabled={!canAttach || isSaving}
            onClick={handleAttachMusic}
            className="inline-flex w-full items-center justify-center gap-2 rounded-lg bg-rose-600 px-4 py-3 text-sm font-bold text-white transition-colors hover:bg-rose-500 disabled:opacity-50"
          >
            <Music className="h-4 w-4" aria-hidden="true" />
            <span>{isSaving ? 'Saving…' : 'Save Music to Clip'}</span>
          </button>
        </section>
      </div>
    </div>
  );
}

import { ChangeEvent, useEffect, useRef, useState } from 'react';
import {
  CheckCircle2,
  Film,
  Mic,
  Scissors,
  Square,
  Trash2,
  Upload,
  Volume2,
} from 'lucide-react';
import { ClipItem, WorkspaceTab } from '../types/clipkaro';
import { formatSeconds } from '../utils/mediaGenerators';

interface AddVoiceViewProps {
  clips: ClipItem[];
  onSaveClip: (clip: ClipItem) => Promise<void>;
  onNavigate: (tab: WorkspaceTab) => void;
}

export function AddVoiceView({ clips, onSaveClip, onNavigate }: AddVoiceViewProps) {
  const [selectedClipId, setSelectedClipId] = useState<string>(clips[0]?.id ?? '');
  const [voiceBlob, setVoiceBlob] = useState<Blob | null>(null);
  const [voiceUrl, setVoiceUrl] = useState<string | null>(null);
  const [voiceName, setVoiceName] = useState<string>('');
  const [voiceVolume, setVoiceVolume] = useState<number>(1);
  const [originalVolume, setOriginalVolume] = useState<number>(0.75);

  const [isRecording, setIsRecording] = useState<boolean>(false);
  const [recordSeconds, setRecordSeconds] = useState<number>(0);
  const [micError, setMicError] = useState<string | null>(null);
  const [isSaving, setIsSaving] = useState<boolean>(false);
  const [savedNotice, setSavedNotice] = useState<string | null>(null);

  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const timerRef = useRef<number | null>(null);
  const analyserRef = useRef<AnalyserNode | null>(null);
  const audioCtxRef = useRef<AudioContext | null>(null);
  const rafRef = useRef<number>(0);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  useEffect(() => {
    if (!selectedClipId && clips.length > 0) {
      setSelectedClipId(clips[0].id);
    }
  }, [clips, selectedClipId]);

  useEffect(() => {
    return () => {
      if (voiceUrl) URL.revokeObjectURL(voiceUrl);
    };
  }, [voiceUrl]);

  useEffect(() => {
    return () => {
      if (timerRef.current) window.clearInterval(timerRef.current);
      cancelAnimationFrame(rafRef.current);
      streamRef.current?.getTracks().forEach((t) => t.stop());
      audioCtxRef.current?.close().catch(() => undefined);
    };
  }, []);

  const drawWaveform = () => {
    const canvas = canvasRef.current;
    const analyser = analyserRef.current;
    if (!canvas || !analyser) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const bufferLen = analyser.frequencyBinCount;
    const dataArray = new Uint8Array(bufferLen);
    analyser.getByteTimeDomainData(dataArray);

    ctx.fillStyle = '#0B0E14';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    ctx.lineWidth = 2;
    ctx.strokeStyle = '#38bdf8';
    ctx.beginPath();

    const sliceWidth = canvas.width / bufferLen;
    let x = 0;
    for (let i = 0; i < bufferLen; i += 1) {
      const v = dataArray[i] / 128.0;
      const y = (v * canvas.height) / 2;
      if (i === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
      x += sliceWidth;
    }
    ctx.lineTo(canvas.width, canvas.height / 2);
    ctx.stroke();

    rafRef.current = requestAnimationFrame(drawWaveform);
  };

  const handleStartRecording = async () => {
    setMicError(null);
    setSavedNotice(null);
    if (!navigator.mediaDevices?.getUserMedia) {
      setMicError('Microphone recording is not supported in this browser. You can upload an audio file instead.');
      return;
    }

    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      streamRef.current = stream;

      const audioCtx = new AudioContext();
      audioCtxRef.current = audioCtx;
      const source = audioCtx.createMediaStreamSource(stream);
      const analyser = audioCtx.createAnalyser();
      analyser.fftSize = 256;
      source.connect(analyser);
      analyserRef.current = analyser;

      const recorder = new MediaRecorder(stream);
      mediaRecorderRef.current = recorder;
      const chunks: BlobPart[] = [];

      recorder.ondataavailable = (ev) => {
        if (ev.data.size > 0) chunks.push(ev.data);
      };

      recorder.onstop = () => {
        const blob = new Blob(chunks, { type: recorder.mimeType || 'audio/webm' });
        if (voiceUrl) URL.revokeObjectURL(voiceUrl);
        setVoiceBlob(blob);
        setVoiceUrl(URL.createObjectURL(blob));
        setVoiceName(`Voiceover (${formatSeconds(recordSeconds)})`);
        stream.getTracks().forEach((t) => t.stop());
        audioCtx.close().catch(() => undefined);
        cancelAnimationFrame(rafRef.current);
      };

      setRecordSeconds(0);
      recorder.start(200);
      setIsRecording(true);
      timerRef.current = window.setInterval(() => {
        setRecordSeconds((prev) => prev + 1);
      }, 1000);
      rafRef.current = requestAnimationFrame(drawWaveform);
    } catch {
      setMicError(
        'Microphone access was denied or unavailable. Please allow microphone access or upload an audio file.'
      );
    }
  };

  const handleStopRecording = () => {
    if (timerRef.current) {
      window.clearInterval(timerRef.current);
      timerRef.current = null;
    }
    if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
      mediaRecorderRef.current.stop();
    }
    setIsRecording(false);
  };

  const handleVoiceUpload = (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setMicError(null);
    setSavedNotice(null);
    if (voiceUrl) URL.revokeObjectURL(voiceUrl);
    setVoiceBlob(file);
    setVoiceUrl(URL.createObjectURL(file));
    setVoiceName(file.name);
  };

  const handleAttachToClip = async () => {
    const target = clips.find((c) => c.id === selectedClipId);
    if (!target || !voiceBlob) return;
    setIsSaving(true);
    setSavedNotice(null);
    try {
      await onSaveClip({
        ...target,
        voiceBlob,
        voiceName: voiceName || 'Voiceover Track',
        voiceVolume,
        originalVolume,
      });
      setSavedNotice(`Voiceover attached to "${target.title}".`);
    } finally {
      setIsSaving(false);
    }
  };

  const selectedClip = clips.find((c) => c.id === selectedClipId) ?? null;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-2xl font-bold tracking-tight text-white">Add Voice</h1>
        <p className="mt-1 text-sm text-slate-400">
          Record live commentary with your microphone or upload a voiceover file, then attach it to any saved clip.
        </p>
      </div>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
        {/* Left: Recorder & Upload */}
        <section className="space-y-5 rounded-xl border border-slate-800 bg-[#121722] p-5 sm:p-6 lg:col-span-7">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <h2 className="font-display text-base font-bold text-white">Voiceover Studio</h2>
            <span className="font-mono text-xs text-slate-400 tabular-nums">
              {isRecording ? `Recording ${formatSeconds(recordSeconds)}` : 'Ready'}
            </span>
          </div>

          {/* Live Waveform Canvas */}
          <div className="overflow-hidden rounded-xl border border-slate-800 bg-[#0B0E14]">
            <canvas
              ref={canvasRef}
              width={640}
              height={120}
              className="h-28 w-full block"
            />
          </div>

          <div className="flex flex-wrap items-center gap-3">
            {isRecording ? (
              <button
                type="button"
                onClick={handleStopRecording}
                className="inline-flex items-center gap-2 rounded-lg bg-rose-600 px-4 py-2.5 text-sm font-semibold text-white hover:bg-rose-500"
              >
                <Square className="h-4 w-4 fill-current" aria-hidden="true" />
                <span>Stop Recording</span>
              </button>
            ) : (
              <button
                type="button"
                onClick={handleStartRecording}
                className="inline-flex items-center gap-2 rounded-lg bg-rose-600 px-4 py-2.5 text-sm font-semibold text-white hover:bg-rose-500"
              >
                <Mic className="h-4 w-4" aria-hidden="true" />
                <span>Record Voiceover</span>
              </button>
            )}

            <input
              ref={fileInputRef}
              type="file"
              accept="audio/*"
              onChange={handleVoiceUpload}
              className="sr-only"
            />
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className="inline-flex items-center gap-2 rounded-lg border border-slate-700 bg-[#0B0E14] px-4 py-2.5 text-sm font-semibold text-slate-200 hover:border-slate-500 hover:text-white"
            >
              <Upload className="h-4 w-4" aria-hidden="true" />
              <span>Upload Audio File</span>
            </button>
          </div>

          {micError && (
            <div
              role="alert"
              className="rounded-lg border border-amber-500/40 bg-amber-950/20 p-3.5 text-xs text-amber-200"
            >
              {micError}
            </div>
          )}

          {voiceUrl && (
            <div className="space-y-3 rounded-xl border border-slate-800 bg-[#0B0E14] p-4">
              <div className="flex items-center justify-between gap-3">
                <span className="text-xs font-semibold text-slate-200 truncate">{voiceName}</span>
                <button
                  type="button"
                  onClick={() => {
                    if (voiceUrl) URL.revokeObjectURL(voiceUrl);
                    setVoiceBlob(null);
                    setVoiceUrl(null);
                    setVoiceName('');
                  }}
                  className="inline-flex items-center gap-1 text-xs text-slate-400 hover:text-rose-300"
                >
                  <Trash2 className="h-3.5 w-3.5" aria-hidden="true" />
                  <span>Clear</span>
                </button>
              </div>
              <audio src={voiceUrl} controls className="w-full" />
            </div>
          )}
        </section>

        {/* Right: Mix & Save to Clip */}
        <section className="flex flex-col justify-between gap-6 rounded-xl border border-slate-800 bg-[#121722] p-5 sm:p-6 lg:col-span-5">
          <div className="space-y-5">
            <h2 className="font-display text-base font-bold text-white">Attach to Clip</h2>

            {clips.length === 0 ? (
              <div className="space-y-3 rounded-lg border border-slate-800 bg-[#0B0E14] p-4 text-xs text-slate-400">
                <p>No clips in My Clips yet. Cut a clip first so you can attach this voiceover.</p>
                <button
                  type="button"
                  onClick={() => onNavigate('cut')}
                  className="inline-flex items-center gap-2 rounded-lg bg-slate-800 px-3.5 py-2 font-semibold text-white hover:bg-slate-700"
                >
                  <Scissors className="h-3.5 w-3.5" aria-hidden="true" />
                  <span>Go to Cut Video</span>
                </button>
              </div>
            ) : (
              <>
                <div className="space-y-1.5">
                  <label htmlFor="voice-target-clip" className="block text-xs font-semibold text-slate-300">
                    Target Clip
                  </label>
                  <select
                    id="voice-target-clip"
                    value={selectedClipId}
                    onChange={(e) => setSelectedClipId(e.target.value)}
                    className="w-full rounded-lg border border-slate-700/80 bg-[#0B0E14] px-3.5 py-2.5 text-sm text-white focus:border-rose-500 focus:outline-none"
                  >
                    {clips.map((c) => (
                      <option key={c.id} value={c.id}>
                        {c.title} ({c.durationSec}s)
                      </option>
                    ))}
                  </select>
                </div>

                {selectedClip && (
                  <div className="rounded-lg border border-slate-800 bg-[#0B0E14] p-3 text-xs text-slate-400 space-y-1">
                    <div className="font-medium text-slate-200">{selectedClip.title}</div>
                    <div>{selectedClip.permission.creditText}</div>
                    {selectedClip.voiceName && (
                      <div className="text-sky-400">Current voice: {selectedClip.voiceName}</div>
                    )}
                  </div>
                )}

                <div className="space-y-3">
                  <div className="space-y-1.5">
                    <div className="flex items-center justify-between text-xs">
                      <span className="inline-flex items-center gap-1.5 text-slate-300">
                        <Volume2 className="h-3.5 w-3.5 text-sky-400" aria-hidden="true" />
                        <span>Voiceover Volume</span>
                      </span>
                      <span className="font-mono text-slate-300 tabular-nums">
                        {Math.round(voiceVolume * 100)}%
                      </span>
                    </div>
                    <input
                      type="range"
                      min={0}
                      max={1}
                      step={0.05}
                      value={voiceVolume}
                      onChange={(e) => setVoiceVolume(parseFloat(e.target.value))}
                      className="w-full accent-sky-400"
                    />
                  </div>

                  <div className="space-y-1.5">
                    <div className="flex items-center justify-between text-xs">
                      <span className="text-slate-300">Original Video Audio</span>
                      <span className="font-mono text-slate-300 tabular-nums">
                        {Math.round(originalVolume * 100)}%
                      </span>
                    </div>
                    <input
                      type="range"
                      min={0}
                      max={1}
                      step={0.05}
                      value={originalVolume}
                      onChange={(e) => setOriginalVolume(parseFloat(e.target.value))}
                      className="w-full accent-rose-500"
                    />
                  </div>
                </div>
              </>
            )}

            {savedNotice && (
              <div className="flex items-center justify-between gap-2 rounded-lg border border-emerald-500/40 bg-emerald-950/25 p-3 text-xs text-emerald-200">
                <span className="inline-flex items-center gap-1.5">
                  <CheckCircle2 className="h-4 w-4 text-emerald-400 shrink-0" aria-hidden="true" />
                  <span>{savedNotice}</span>
                </span>
                <button
                  type="button"
                  onClick={() => onNavigate('clips')}
                  className="inline-flex items-center gap-1 rounded bg-emerald-600 px-2.5 py-1 font-semibold text-white hover:bg-emerald-500 shrink-0"
                >
                  <Film className="h-3 w-3" aria-hidden="true" />
                  <span>Play</span>
                </button>
              </div>
            )}
          </div>

          <button
            type="button"
            disabled={!selectedClip || !voiceBlob || isSaving}
            onClick={handleAttachToClip}
            className="inline-flex w-full items-center justify-center gap-2 rounded-lg bg-rose-600 px-4 py-3 text-sm font-bold text-white transition-colors hover:bg-rose-500 disabled:opacity-50"
          >
            <Mic className="h-4 w-4" aria-hidden="true" />
            <span>{isSaving ? 'Saving…' : 'Save Voice to Clip'}</span>
          </button>
        </section>
      </div>
    </div>
  );
}

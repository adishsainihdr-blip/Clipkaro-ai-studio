import { ClipItem } from '../types/clipkaro';
import {
  formatSeconds,
  generateRoyaltyFreeWavBlob,
  generateStyledThumbnailDataUrl,
  ROYALTY_FREE_TRACKS,
} from './mediaGenerators';
import { trimVideoWithFFmpeg } from './ffmpegCutter';

export type AiDetectedMomentType = 'Headshot' | 'Kill Clutch' | 'Funny Moment';

export interface AiAutoEditAnalysis {
  detectedMoment: AiDetectedMomentType;
  peakTimestampSec: number;
  cutStartSec: number;
  cutEndSec: number;
  cutDurationSec: number;
  autoCaption: string;
  musicName: string;
  editedClip: ClipItem;
  hardCutApplied: boolean;
}

async function detectAudioPeakTimeSec(blob: Blob, totalDurationSec: number): Promise<number | null> {
  if (typeof AudioContext === 'undefined' || blob.size > 45 * 1024 * 1024) {
    return null;
  }
  let ctx: AudioContext | null = null;
  try {
    const buf = await blob.arrayBuffer();
    ctx = new AudioContext();
    const audioBuf = await ctx.decodeAudioData(buf.slice(0));
    const channel = audioBuf.getChannelData(0);
    const dur = audioBuf.duration || totalDurationSec;
    if (!channel.length || dur <= 1) return null;

    const bucketSec = 1;
    const sampleStep = Math.max(1, Math.floor(audioBuf.sampleRate / 25));
    const bucketCount = Math.max(1, Math.floor(dur / bucketSec));
    let bestBucket = 0;
    let bestRms = -1;

    for (let b = 0; b < bucketCount; b += 1) {
      const startSample = Math.floor(b * bucketSec * audioBuf.sampleRate);
      const endSample = Math.min(channel.length, Math.floor((b + 1) * bucketSec * audioBuf.sampleRate));
      let sumSq = 0;
      let count = 0;
      for (let i = startSample; i < endSample; i += sampleStep) {
        const s = channel[i];
        sumSq += s * s;
        count += 1;
      }
      const rms = count > 0 ? Math.sqrt(sumSq / count) : 0;
      if (rms > bestRms) {
        bestRms = rms;
        bestBucket = b;
      }
    }

    return Math.min(dur, bestBucket + 0.5);
  } catch {
    return null;
  } finally {
    ctx?.close().catch(() => undefined);
  }
}

function inferMomentAndCaption(clip: ClipItem): {
  moment: AiDetectedMomentType;
  caption: string;
  trackIndex: number;
} {
  const hay = `${clip.title} ${clip.gameTag} ${clip.autoCaption || ''}`.toLowerCase();
  const isNormalSocial =
    hay.includes('youtube') ||
    hay.includes('instagram') ||
    hay.includes('facebook') ||
    hay.includes('whatsapp') ||
    hay.includes('vlog') ||
    hay.includes('reaction') ||
    Boolean(clip.isReaction);

  if (hay.includes('headshot') || hay.includes('awm') || hay.includes('sniper')) {
    return {
      moment: 'Headshot',
      caption: 'What a Headshot!',
      trackIndex: 0,
    };
  }

  if (
    hay.includes('funny') ||
    hay.includes('comedy') ||
    hay.includes('meme') ||
    hay.includes('fail') ||
    isNormalSocial
  ) {
    return {
      moment: 'Funny Moment',
      caption: isNormalSocial ? 'Wait For This Moment!' : 'What a Funny Clutch!',
      trackIndex: 1,
    };
  }

  if (
    hay.includes('bgmi') ||
    hay.includes('kill') ||
    hay.includes('clutch') ||
    hay.includes('free fire') ||
    hay.includes('valorant') ||
    hay.includes('cod')
  ) {
    return {
      moment: 'Headshot',
      caption: 'What a Headshot!',
      trackIndex: 0,
    };
  }

  return {
    moment: 'Kill Clutch',
    caption: 'What a Headshot!',
    trackIndex: 0,
  };
}

export async function runAiAutoEdit(
  clip: ClipItem,
  onProgress?: (stage: string, pct: number) => void
): Promise<AiAutoEditAnalysis> {
  onProgress?.('AI scanning clip for Kill / Headshot / Funny peak…', 18);

  const totalDur = Math.max(1, clip.durationSec || clip.trimEnd || 15);
  const targetLen = Math.min(15, totalDur);

  const audioPeak = await detectAudioPeakTimeSec(clip.videoBlob, totalDur);
  const fallbackPeak = totalDur > 16 ? Math.round(totalDur * 0.58 * 10) / 10 : Math.round((totalDur / 2) * 10) / 10;
  const peakSec = audioPeak !== null ? Math.round(audioPeak * 10) / 10 : fallbackPeak;

  let cutStart = 0;
  let cutEnd = totalDur;
  if (totalDur > 15.2) {
    cutStart = Math.max(0, Math.round((peakSec - targetLen / 2) * 10) / 10);
    if (cutStart + targetLen > totalDur) {
      cutStart = Math.max(0, Math.round((totalDur - targetLen) * 10) / 10);
    }
    cutEnd = Math.min(totalDur, Math.round((cutStart + targetLen) * 10) / 10);
  }
  const cutDur = Math.max(1, Math.round(cutEnd - cutStart));

  onProgress?.('Selecting best 15s highlight & Trending Music…', 48);

  const { moment, caption, trackIndex } = inferMomentAndCaption(clip);
  const trendingTrack = ROYALTY_FREE_TRACKS[trackIndex] ?? ROYALTY_FREE_TRACKS[0];
  const musicBlob = generateRoyaltyFreeWavBlob(trendingTrack.id);

  let finalBlob = clip.videoBlob;
  let finalMime = clip.videoMimeType;
  let finalTrimStart = cutStart;
  let finalTrimEnd = cutEnd;
  let hardCutApplied = false;

  // Attempt hard 15s MP4 cut with Cinematic filter + Auto Caption if clip is long and FFmpeg is available online/cached
  if (totalDur > 16) {
    try {
      onProgress?.('Auto-cutting best 15s clip & applying Cinematic look…', 68);
      const trimmed = await trimVideoWithFFmpeg({
        sourceBlob: clip.videoBlob,
        sourceFileName: clip.nativeFileName || `${clip.title}.mp4`,
        startSec: cutStart,
        durationSec: cutDur,
        burnCredit: false,
        creditText: clip.permission.creditText,
        burnAutoCaption: false,
      });
      finalBlob = trimmed.mp4Blob;
      finalMime = 'video/mp4';
      finalTrimStart = 0;
      finalTrimEnd = cutDur;
      hardCutApplied = true;
    } catch {
      // Offline / fast fallback: non-destructive exact 15s peak window + live Cinematic filter & caption
      hardCutApplied = false;
    }
  }

  onProgress?.('Polishing AI Auto Caption & Cinematic Thumbnail…', 88);

  let aiThumb = clip.thumbnailDataUrl;
  try {
    aiThumb = await generateStyledThumbnailDataUrl({
      fallbackImageUrl: clip.thumbnailDataUrl,
      headline: moment === 'Funny Moment' ? 'BEST MOMENT!' : '1 VS 4 CLUTCH',
      badgeText: clip.gameTag ? `#${clip.gameTag.replace(/\s+/g, '')}` : '#BGMI',
      stylePreset: 'clutch-red-gold',
    });
  } catch {
    // keep existing thumbnail
  }

  const baseTitle = clip.title.replace(/\s*\(AI Edited\)$/i, '').trim() || 'Highlight Clip';
  const editedClip: ClipItem = {
    ...clip,
    id: `clip-ai-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
    title: `${baseTitle} (AI Edited)`,
    createdAt: Date.now(),
    durationSec: cutDur,
    trimStart: finalTrimStart,
    trimEnd: finalTrimEnd,
    videoBlob: finalBlob,
    videoMimeType: finalMime,
    autoCaption: caption,
    musicBlob,
    musicName: trendingTrack.title,
    musicVolume: 0.45,
    originalVolume: 0.85,
    filterPreset: 'cinematic',
    effectMode: 'cinematic',
    thumbnailDataUrl: aiThumb,
    killCount: Math.max(clip.killCount ?? 0, moment === 'Headshot' || moment === 'Kill Clutch' ? 2 : 0),
    nativeUri: undefined,
    nativeFileName: `ClipKaro_AI_${clip.gameTag.replace(/[^a-z0-9]/gi, '')}_${cutDur}s_${Date.now()}.${
      finalMime.includes('mp4') ? 'mp4' : 'webm'
    }`,
  };

  onProgress?.(
    `Ready! Best ${cutDur}s ${moment} detected at ${formatSeconds(peakSec)}`,
    100
  );

  return {
    detectedMoment: moment,
    peakTimestampSec: peakSec,
    cutStartSec: cutStart,
    cutEndSec: cutEnd,
    cutDurationSec: cutDur,
    autoCaption: caption,
    musicName: trendingTrack.title,
    editedClip,
    hardCutApplied,
  };
}

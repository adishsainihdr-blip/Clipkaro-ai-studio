import { SocialPlatform } from '../types/clipkaro';

export interface ParsedEmbedResult {
  platform: SocialPlatform;
  originalUrl: string;
  embedUrl: string | null;
  displayLabel: string;
  isValidUrl: boolean;
  hint?: string;
}

export interface PlatformPreset {
  id: string;
  platform: SocialPlatform;
  label: string;
  creator: string;
  url: string;
}

export const PLATFORM_PRESETS: PlatformPreset[] = [
  {
    id: 'yt-1',
    platform: 'youtube',
    label: 'Blender Studio Open Reel',
    creator: 'BlenderFoundation',
    url: 'https://www.youtube.com/watch?v=aqz-KE-bpKQ',
  },
  {
    id: 'yt-2',
    platform: 'youtube',
    label: 'Lofi Coding & Stream Session',
    creator: 'LofiStudio',
    url: 'https://www.youtube.com/watch?v=jfKfPfyJRdk',
  },
  {
    id: 'ig-1',
    platform: 'instagram',
    label: 'Instagram Creator Reel',
    creator: 'creators',
    url: 'https://www.instagram.com/reel/C8xYz91vK2P/',
  },
  {
    id: 'fb-1',
    platform: 'facebook',
    label: 'Facebook Gaming Highlight',
    creator: 'FacebookGaming',
    url: 'https://www.facebook.com/facebook/videos/10153231379946729/',
  },
];

export function formatCreditHandle(rawName: string): string {
  const cleaned = rawName.trim().replace(/^@+/, '').replace(/\s+/g, '');
  if (!cleaned) {
    return 'Credit: @StreamerName';
  }
  return `Credit: @${cleaned}`;
}

export function extractYouTubeId(url: string): string | null {
  try {
    const parsed = new URL(url);
    const host = parsed.hostname.replace(/^www\./, '');
    if (host === 'youtu.be') {
      const id = parsed.pathname.split('/').filter(Boolean)[0];
      return id || null;
    }
    if (host === 'youtube.com' || host === 'm.youtube.com' || host === 'youtube-nocookie.com') {
      if (parsed.pathname === '/watch') {
        return parsed.searchParams.get('v');
      }
      const parts = parsed.pathname.split('/').filter(Boolean);
      if (parts[0] === 'embed' || parts[0] === 'shorts' || parts[0] === 'live') {
        return parts[1] || null;
      }
    }
    return null;
  } catch {
    return null;
  }
}

export function parseSocialEmbedUrl(inputUrl: string, activePlatform: SocialPlatform): ParsedEmbedResult {
  const trimmed = inputUrl.trim();
  if (!trimmed) {
    return {
      platform: activePlatform,
      originalUrl: '',
      embedUrl: null,
      displayLabel: 'Enter a link to open inside ClipKaro',
      isValidUrl: false,
    };
  }

  let normalized = trimmed;
  if (!/^https?:\/\//i.test(normalized)) {
    normalized = `https://${normalized}`;
  }

  let parsed: URL;
  try {
    parsed = new URL(normalized);
  } catch {
    return {
      platform: activePlatform,
      originalUrl: trimmed,
      embedUrl: null,
      displayLabel: 'Invalid URL format',
      isValidUrl: false,
      hint: 'Please enter a complete YouTube, Instagram, or Facebook link.',
    };
  }

  const host = parsed.hostname.toLowerCase();

  if (host.includes('youtube.com') || host.includes('youtu.be')) {
    const videoId = extractYouTubeId(normalized);
    if (videoId) {
      return {
        platform: 'youtube',
        originalUrl: normalized,
        embedUrl: `https://www.youtube.com/embed/${encodeURIComponent(videoId)}?rel=0&modestbranding=1`,
        displayLabel: `YouTube Video (${videoId})`,
        isValidUrl: true,
      };
    }
    return {
      platform: 'youtube',
      originalUrl: normalized,
      embedUrl: null,
      displayLabel: 'YouTube link detected',
      isValidUrl: true,
      hint: 'Paste a specific YouTube watch, Shorts, or live video URL to embed the player.',
    };
  }

  if (host.includes('instagram.com')) {
    const parts = parsed.pathname.split('/').filter(Boolean);
    const kind = parts[0];
    const code = parts[1];
    if ((kind === 'p' || kind === 'reel' || kind === 'reels' || kind === 'tv') && code) {
      const embedKind = kind === 'reels' ? 'reel' : kind;
      return {
        platform: 'instagram',
        originalUrl: normalized,
        embedUrl: `https://www.instagram.com/${embedKind}/${encodeURIComponent(code)}/embed/`,
        displayLabel: `Instagram ${embedKind === 'reel' ? 'Reel' : 'Post'} (${code})`,
        isValidUrl: true,
        hint: 'If Instagram restricts embedding for private or age-gated posts, open the link externally or upload your authorized clip in Cut Video.',
      };
    }
    return {
      platform: 'instagram',
      originalUrl: normalized,
      embedUrl: null,
      displayLabel: 'Instagram profile or page',
      isValidUrl: true,
      hint: 'Paste a direct Instagram Reel or Post URL (/reel/... or /p/...) to open it inside the viewer.',
    };
  }

  if (host.includes('facebook.com') || host.includes('fb.watch')) {
    return {
      platform: 'facebook',
      originalUrl: normalized,
      embedUrl: `https://www.facebook.com/plugins/video.php?href=${encodeURIComponent(normalized)}&show_text=false&width=720`,
      displayLabel: 'Facebook Video Viewer',
      isValidUrl: true,
      hint: 'Public Facebook videos load directly in the embed frame. Private group or restricted videos may require uploading an authorized file.',
    };
  }

  return {
    platform: activePlatform,
    originalUrl: normalized,
    embedUrl: null,
    displayLabel: parsed.hostname,
    isValidUrl: true,
    hint: 'Only YouTube, Instagram, and Facebook URLs support direct social embedding here.',
  };
}

export interface AndroidBridge {
  launchApp?: (packageName: string, playStoreUrl?: string) => boolean;
  canDrawOverlays?: () => boolean;
  requestOverlayPermission?: () => void;
  hasStoragePermission?: () => boolean;
  requestStoragePermission?: () => void;
  hasMicrophonePermission?: () => boolean;
  requestMicrophonePermission?: () => void;
  isPermissionSetupDone?: () => boolean;
  setPermissionSetupDone?: (done: boolean) => void;
  getPermissionStatusJson?: () => string;
}

export interface ClipKaroPermissionState {
  overlay: boolean;
  storage: boolean;
  microphone: boolean;
  setupDone: boolean;
  isNativeAndroid: boolean;
}

const KEY_SETUP_DONE = 'clipkaro_permission_screen_done';
const KEY_OVERLAY = 'clipkaro_perm_overlay_granted';
const KEY_STORAGE = 'clipkaro_perm_storage_granted';
const KEY_MIC = 'clipkaro_perm_mic_granted';

function getAndroidBridge(): AndroidBridge | undefined {
  if (typeof window === 'undefined') return undefined;
  return (window as unknown as { Android?: AndroidBridge }).Android;
}

function readLocalBool(key: string): boolean {
  try {
    return localStorage.getItem(key) === 'true';
  } catch {
    return false;
  }
}

function writeLocalBool(key: string, value: boolean): void {
  try {
    localStorage.setItem(key, value ? 'true' : 'false');
  } catch {
    // ignore storage quota/privacy mode errors
  }
}

export function dispatchPermissionsUpdated(): void {
  if (typeof window !== 'undefined') {
    window.dispatchEvent(new CustomEvent('clipkaro-permissions-updated'));
  }
}

export function getPermissionState(): ClipKaroPermissionState {
  const android = getAndroidBridge();
  if (android && typeof android.getPermissionStatusJson === 'function') {
    try {
      const parsed = JSON.parse(android.getPermissionStatusJson()) as {
        overlay?: boolean;
        storage?: boolean;
        microphone?: boolean;
        setupDone?: boolean;
      };
      return {
        overlay: Boolean(parsed.overlay),
        storage: Boolean(parsed.storage),
        microphone: Boolean(parsed.microphone),
        setupDone: Boolean(parsed.setupDone),
        isNativeAndroid: true,
      };
    } catch {
      // fall through to individual bridge checks
    }
  }

  if (android) {
    return {
      overlay: android.canDrawOverlays ? android.canDrawOverlays() : false,
      storage: android.hasStoragePermission ? android.hasStoragePermission() : false,
      microphone: android.hasMicrophonePermission ? android.hasMicrophonePermission() : false,
      setupDone: android.isPermissionSetupDone ? android.isPermissionSetupDone() : false,
      isNativeAndroid: true,
    };
  }

  return {
    overlay: readLocalBool(KEY_OVERLAY),
    storage: readLocalBool(KEY_STORAGE),
    microphone: readLocalBool(KEY_MIC),
    setupDone: readLocalBool(KEY_SETUP_DONE),
    isNativeAndroid: false,
  };
}

export function markPermissionSetupDone(done = true): void {
  const android = getAndroidBridge();
  if (android?.setPermissionSetupDone) {
    android.setPermissionSetupDone(done);
  }
  writeLocalBool(KEY_SETUP_DONE, done);
  dispatchPermissionsUpdated();
}

export function requestOverlayPermission(): { awaitingNativeSettings: boolean } {
  const android = getAndroidBridge();
  if (android?.requestOverlayPermission) {
    android.requestOverlayPermission();
    return { awaitingNativeSettings: true };
  }

  // Web preview simulation of allowing Display Over Other Apps
  writeLocalBool(KEY_OVERLAY, true);
  dispatchPermissionsUpdated();
  return { awaitingNativeSettings: false };
}

export function setPreviewOverlayDenied(): void {
  const android = getAndroidBridge();
  if (android) return;
  writeLocalBool(KEY_OVERLAY, false);
  dispatchPermissionsUpdated();
}

export function requestStoragePermission(): void {
  const android = getAndroidBridge();
  if (android?.requestStoragePermission) {
    android.requestStoragePermission();
    return;
  }

  writeLocalBool(KEY_STORAGE, true);
  dispatchPermissionsUpdated();
}

export async function requestMicrophonePermission(): Promise<void> {
  const android = getAndroidBridge();
  if (android?.requestMicrophonePermission) {
    android.requestMicrophonePermission();
    return;
  }

  try {
    if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      stream.getTracks().forEach((t) => t.stop());
    }
    writeLocalBool(KEY_MIC, true);
  } catch {
    // In web preview iframes, browser microphone policy may block prompt; allow preview testing
    writeLocalBool(KEY_MIC, true);
  }
  dispatchPermissionsUpdated();
}

export type PermissionKind = 'overlay' | 'storage' | 'microphone' | 'battery';

export interface NativeClipEntry {
  uri: string;
  fileName: string;
  durationSec: number;
  createdAtMs: number;
}

export interface AndroidBridge {
  launchApp?: (packageName: string, playStoreUrl?: string) => boolean;
  startFloatingAndLaunchGame?: (packageName: string, playStoreUrl: string, gameName: string) => string;
  stopFloatingService?: () => void;
  canDrawOverlays?: () => boolean;
  requestOverlayPermission?: () => void;
  hasStoragePermission?: () => boolean;
  requestStoragePermission?: () => void;
  hasMicrophonePermission?: () => boolean;
  requestMicrophonePermission?: () => void;
  openMicrophoneSettings?: () => void;
  hasBatteryPermission?: () => boolean;
  requestBatteryPermission?: () => void;
  isPermissionSetupDone?: () => boolean;
  setPermissionSetupDone?: (done: boolean) => void;
  getPermissionStatusJson?: () => string;
  listNativeClipKaroVideosJson?: () => string;
  saveVideoFileToClipKaroFolder?: (fileName: string, base64Video: string) => boolean;
  shareVideoToPlatform?: (
    targetPlatform: string,
    fileName: string,
    base64Video: string,
    nativeUriStr: string,
    captionText: string
  ) => boolean;
}

export interface ClipKaroPermissionState {
  overlay: boolean;
  storage: boolean;
  microphone: boolean;
  battery: boolean;
  setupDone: boolean;
  isNativeAndroid: boolean;
}

const KEY_SETUP_DONE = 'clipkaro_permission_screen_done';
const KEY_OVERLAY = 'clipkaro_perm_overlay_granted';
const KEY_STORAGE = 'clipkaro_perm_storage_granted';
const KEY_MIC = 'clipkaro_perm_mic_granted';
const KEY_BATTERY = 'clipkaro_perm_battery_granted';

function getAndroidBridge(): AndroidBridge | undefined {
  if (typeof window === 'undefined') return undefined;
  return (window as unknown as { Android?: AndroidBridge }).Android;
}

function readLocalBool(key: string): boolean {
  try {
    return localStorage.getItem(key) === 'true';
  } catch {
    return false;
  }
}

function writeLocalBool(key: string, value: boolean): void {
  try {
    localStorage.setItem(key, value ? 'true' : 'false');
  } catch {
    // ignore storage quota/privacy mode errors
  }
}

export function dispatchPermissionsUpdated(): void {
  if (typeof window !== 'undefined') {
    window.dispatchEvent(new CustomEvent('clipkaro-permissions-updated'));
  }
}

export function getPermissionState(): ClipKaroPermissionState {
  const android = getAndroidBridge();
  if (android && typeof android.getPermissionStatusJson === 'function') {
    try {
      const parsed = JSON.parse(android.getPermissionStatusJson()) as {
        overlay?: boolean;
        storage?: boolean;
        microphone?: boolean;
        battery?: boolean;
        setupDone?: boolean;
      };
      return {
        overlay: Boolean(parsed.overlay),
        storage: Boolean(parsed.storage),
        microphone: Boolean(parsed.microphone),
        battery: parsed.battery !== undefined ? Boolean(parsed.battery) : true,
        setupDone: Boolean(parsed.setupDone),
        isNativeAndroid: true,
      };
    } catch {
      // fall through to individual bridge checks
    }
  }

  if (android) {
    return {
      overlay: android.canDrawOverlays ? android.canDrawOverlays() : false,
      storage: android.hasStoragePermission ? android.hasStoragePermission() : false,
      microphone: android.hasMicrophonePermission ? android.hasMicrophonePermission() : false,
      battery: android.hasBatteryPermission ? android.hasBatteryPermission() : true,
      setupDone: android.isPermissionSetupDone ? android.isPermissionSetupDone() : false,
      isNativeAndroid: true,
    };
  }

  return {
    overlay: readLocalBool(KEY_OVERLAY),
    storage: readLocalBool(KEY_STORAGE),
    microphone: readLocalBool(KEY_MIC),
    battery: readLocalBool(KEY_BATTERY),
    setupDone: readLocalBool(KEY_SETUP_DONE),
    isNativeAndroid: false,
  };
}

export function markPermissionSetupDone(done = true): void {
  const android = getAndroidBridge();
  if (android?.setPermissionSetupDone) {
    android.setPermissionSetupDone(done);
  }
  writeLocalBool(KEY_SETUP_DONE, done);
  dispatchPermissionsUpdated();
}

export function requestOverlayPermission(): { awaitingNativeSettings: boolean } {
  const android = getAndroidBridge();
  if (android?.requestOverlayPermission) {
    android.requestOverlayPermission();
    return { awaitingNativeSettings: true };
  }

  writeLocalBool(KEY_OVERLAY, true);
  dispatchPermissionsUpdated();
  return { awaitingNativeSettings: false };
}

export function requestStoragePermission(): { awaitingNativeSettings: boolean } {
  const android = getAndroidBridge();
  if (android?.requestStoragePermission) {
    android.requestStoragePermission();
    return { awaitingNativeSettings: true };
  }

  writeLocalBool(KEY_STORAGE, true);
  dispatchPermissionsUpdated();
  return { awaitingNativeSettings: false };
}

export async function requestMicrophonePermission(
  openAppSettingsDirectly = false
): Promise<{ awaitingNativeSettings: boolean }> {
  const android = getAndroidBridge();
  if (android) {
    if (openAppSettingsDirectly && android.openMicrophoneSettings) {
      android.openMicrophoneSettings();
      return { awaitingNativeSettings: true };
    }
    if (android.requestMicrophonePermission) {
      android.requestMicrophonePermission();
      return { awaitingNativeSettings: true };
    }
  }

  try {
    if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      stream.getTracks().forEach((t) => t.stop());
    }
    writeLocalBool(KEY_MIC, true);
  } catch {
    // In web preview iframes, browser microphone policy may block prompt; allow preview testing
    writeLocalBool(KEY_MIC, true);
  }
  dispatchPermissionsUpdated();
  return { awaitingNativeSettings: false };
}

export function requestBatteryPermission(): { awaitingNativeSettings: boolean } {
  const android = getAndroidBridge();
  if (android?.requestBatteryPermission) {
    android.requestBatteryPermission();
    return { awaitingNativeSettings: true };
  }

  writeLocalBool(KEY_BATTERY, true);
  dispatchPermissionsUpdated();
  return { awaitingNativeSettings: false };
}

export function setPreviewPermissionDenied(kind: PermissionKind): void {
  const android = getAndroidBridge();
  if (android) return;
  const keyMap: Record<PermissionKind, string> = {
    overlay: KEY_OVERLAY,
    storage: KEY_STORAGE,
    microphone: KEY_MIC,
    battery: KEY_BATTERY,
  };
  writeLocalBool(keyMap[kind], false);
  dispatchPermissionsUpdated();
}

export function setPreviewOverlayDenied(): void {
  setPreviewPermissionDenied('overlay');
}

export function listNativeClipKaroVideos(): NativeClipEntry[] {
  const android = getAndroidBridge();
  if (!android?.listNativeClipKaroVideosJson) return [];
  try {
    const raw = android.listNativeClipKaroVideosJson();
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? (parsed as NativeClipEntry[]) : [];
  } catch {
    return [];
  }
}

export async function fetchNativeClipBlob(uri: string): Promise<Blob | null> {
  if (!uri) return null;
  try {
    const res = await fetch(`https://appassets.androidplatform.net/native-clip?uri=${encodeURIComponent(uri)}`);
    if (!res.ok) return null;
    return await res.blob();
  } catch {
    return null;
  }
}

export async function saveVideoToNativeClipKaroFolder(fileName: string, blob: Blob): Promise<boolean> {
  const android = getAndroidBridge();
  if (!android?.saveVideoFileToClipKaroFolder) return false;
  try {
    const bytes = new Uint8Array(await blob.arrayBuffer());
    let binary = '';
    const chunkSize = 0x8000;
    for (let i = 0; i < bytes.length; i += chunkSize) {
      binary += String.fromCharCode(...bytes.subarray(i, i + chunkSize));
    }
    const base64 = btoa(binary);
    return Boolean(android.saveVideoFileToClipKaroFolder(fileName, base64));
  } catch {
    return false;
  }
}

export type ShareTargetPlatform = 'youtube' | 'instagram' | 'whatsapp';

export async function shareClipToPlatform(params: {
  platform: ShareTargetPlatform;
  title: string;
  gameTag: string;
  autoCaption?: string;
  videoBlob: Blob;
  videoMimeType: string;
  nativeUri?: string;
}): Promise<string> {
  const { platform, title, gameTag, autoCaption, videoBlob, videoMimeType, nativeUri } = params;
  const gameHashtag = gameTag.toLowerCase().includes('bgmi') ? '#BGMI' : `#${gameTag.replace(/[^A-Za-z0-9]/g, '')}`;
  const shareText = [
    autoCaption?.trim() || title.trim(),
    `${gameHashtag === '#BGMI' ? '' : `${gameHashtag} `}#BGMI #ClipKaro #Gaming`,
  ]
    .filter(Boolean)
    .join(' ');

  const ext = videoMimeType.includes('mp4') ? 'mp4' : 'webm';
  const fileName = `${title.replace(/[^A-Za-z0-9_-]+/g, '_') || 'ClipKaro_Clip'}.${ext}`;

  const android = getAndroidBridge();
  if (android?.shareVideoToPlatform) {
    let base64 = '';
    if (!nativeUri) {
      const bytes = new Uint8Array(await videoBlob.arrayBuffer());
      let binary = '';
      const chunkSize = 0x8000;
      for (let i = 0; i < bytes.length; i += chunkSize) {
        binary += String.fromCharCode(...bytes.subarray(i, i + chunkSize));
      }
      base64 = btoa(binary);
    }
    const ok = android.shareVideoToPlatform(
      platform,
      fileName,
      base64,
      nativeUri || '',
      shareText
    );
    if (ok) {
      const appNames: Record<ShareTargetPlatform, string> = {
        youtube: 'YouTube Shorts',
        instagram: 'Instagram Reels',
        whatsapp: 'WhatsApp',
      };
      return `Opened ${appNames[platform]} share with hashtags #BGMI #ClipKaro`;
    }
  }

  // Web Browser / Preview fallback: copy hashtags and invoke Web Share API or trigger download
  try {
    await navigator.clipboard?.writeText(shareText);
  } catch {
    // ignore clipboard permission errors
  }

  try {
    const file = new File([videoBlob], fileName, { type: videoMimeType || 'video/mp4' });
    if (navigator.share && navigator.canShare?.({ files: [file] })) {
      await navigator.share({
        title,
        text: shareText,
        files: [file],
      });
      return `Shared clip with #BGMI #ClipKaro`;
    }
  } catch {
    // fall through to clean download + copied hashtag toast
  }

  const blobUrl = URL.createObjectURL(videoBlob);
  const a = document.createElement('a');
  a.href = blobUrl;
  a.download = fileName;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(blobUrl), 2500);

  const label =
    platform === 'youtube'
      ? 'YouTube Shorts'
      : platform === 'instagram'
        ? 'Instagram Reels'
        : 'WhatsApp';
  return `Downloaded clip for ${label} & copied hashtags: #BGMI #ClipKaro`;
}



import { FFmpeg } from '@ffmpeg/ffmpeg';
import { fetchFile, toBlobURL } from '@ffmpeg/util';

let ffmpegInstance: FFmpeg | null = null;
let loadPromise: Promise<FFmpeg> | null = null;

async function getLoadedFFmpeg(onStatus?: (msg: string) => void): Promise<FFmpeg> {
  if (ffmpegInstance && ffmpegInstance.loaded) {
    return ffmpegInstance;
  }
  if (loadPromise) {
    return loadPromise;
  }

  loadPromise = (async () => {
    onStatus?.('Loading FFmpeg video engine…');
    const ffmpeg = new FFmpeg();
    const coreURL = await toBlobURL('/ffmpeg/ffmpeg-core.js', 'text/javascript');
    const wasmURL = await toBlobURL('/ffmpeg/ffmpeg-core.wasm', 'application/wasm');
    await ffmpeg.load({ coreURL, wasmURL });
    ffmpegInstance = ffmpeg;
    return ffmpeg;
  })();

  try {
    return await loadPromise;
  } catch (err) {
    loadPromise = null;
    throw err;
  }
}

async function createTextBarPng(
  text: string,
  targetWidth: number,
  variant: 'credit' | 'caption'
): Promise<Uint8Array> {
  const width = Math.max(320, Math.round(targetWidth / 2) * 2);
  const height = Math.max(48, Math.round((width * (variant === 'caption' ? 72 : 58)) / 1280));
  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext('2d');
  if (!ctx) {
    throw new Error('Canvas 2D context unavailable for overlay');
  }

  if (variant === 'caption') {
    // Auto-Caption with solid black background pill/bar for clear legibility
    ctx.clearRect(0, 0, width, height);
    const fontSize = Math.max(18, Math.round((width * 26) / 1280));
    ctx.font = `700 ${fontSize}px system-ui, -apple-system, sans-serif`;
    const metrics = ctx.measureText(text);
    const padX = Math.round((width * 28) / 1280);
    const boxW = Math.min(width - 24, Math.round(metrics.width + padX * 2));
    const boxH = Math.round(height * 0.78);
    const boxX = Math.round((width - boxW) / 2);
    const boxY = Math.round((height - boxH) / 2);

    ctx.fillStyle = '#000000';
    ctx.fillRect(boxX, boxY, boxW, boxH);

    ctx.fillStyle = '#ffffff';
    ctx.textBaseline = 'middle';
    ctx.textAlign = 'center';
    ctx.fillText(text, width / 2, height / 2, boxW - 16);
  } else {
    // Top credit bar with black background
    ctx.fillStyle = 'rgba(0, 0, 0, 0.88)';
    ctx.fillRect(0, 0, width, height);

    ctx.fillStyle = 'rgba(244, 63, 94, 0.9)';
    ctx.fillRect(0, height - 2, width, 2);

    const fontSize = Math.max(16, Math.round((width * 24) / 1280));
    ctx.font = `700 ${fontSize}px system-ui, -apple-system, sans-serif`;
    ctx.fillStyle = '#ffffff';
    ctx.textBaseline = 'middle';
    ctx.textAlign = 'center';
    ctx.fillText(text, width / 2, height / 2, width - 32);
  }

  const blob = await new Promise<Blob>((resolve, reject) => {
    canvas.toBlob((b) => {
      if (b) resolve(b);
      else reject(new Error('Failed to render overlay PNG'));
    }, 'image/png');
  });

  const buf = await blob.arrayBuffer();
  return new Uint8Array(buf);
}

export interface TrimVideoParams {
  sourceBlob: Blob;
  sourceFileName: string;
  startSec: number;
  durationSec: number;
  videoWidth?: number;
  burnCredit: boolean;
  creditText: string;
  burnAutoCaption?: boolean;
  autoCaptionText?: string;
  onProgress?: (percent: number, stage: string) => void;
}

export interface TrimVideoResult {
  mp4Blob: Blob;
  thumbnailDataUrl?: string;
}

export async function trimVideoWithFFmpeg(params: TrimVideoParams): Promise<TrimVideoResult> {
  const {
    sourceBlob,
    sourceFileName,
    startSec,
    durationSec,
    videoWidth,
    burnCredit,
    creditText,
    burnAutoCaption = false,
    autoCaptionText = '',
    onProgress,
  } = params;

  onProgress?.(5, 'Loading FFmpeg engine…');
  const ffmpeg = await getLoadedFFmpeg((msg) => onProgress?.(10, msg));

  const extMatch = sourceFileName.match(/\.([a-z0-9]+)$/i);
  const inputExt = extMatch
    ? extMatch[1].toLowerCase()
    : sourceBlob.type.includes('mp4')
      ? 'mp4'
      : 'webm';
  const ts = Date.now();
  const inputFile = `input_${ts}.${inputExt}`;
  const creditOverlayFile = `credit_${ts}.png`;
  const captionOverlayFile = `caption_${ts}.png`;
  const outputFile = `output_${ts}.mp4`;

  const hasCreditOverlay = burnCredit && creditText.trim().length > 0;
  const hasCaptionOverlay = burnAutoCaption && autoCaptionText.trim().length > 0;

  const progressHandler = ({ progress }: { progress: number }) => {
    const safePct = Math.max(15, Math.min(96, 15 + Math.round((progress || 0) * 80)));
    onProgress?.(
      safePct,
      hasCreditOverlay || hasCaptionOverlay
        ? 'Trimming & burning overlays onto MP4…'
        : 'Cutting MP4 video…'
    );
  };

  ffmpeg.on('progress', progressHandler);

  try {
    onProgress?.(12, 'Preparing video file…');
    await ffmpeg.writeFile(inputFile, await fetchFile(sourceBlob));

    const safeStart = Math.max(0, startSec).toFixed(2);
    const safeDur = Math.max(1, durationSec).toFixed(2);
    const targetW = Math.max(320, Math.round((videoWidth || 1280) / 2) * 2);

    const args: string[] = ['-ss', safeStart, '-t', safeDur, '-i', inputFile];

    if (hasCreditOverlay) {
      const creditPng = await createTextBarPng(creditText.trim(), targetW, 'credit');
      await ffmpeg.writeFile(creditOverlayFile, creditPng);
      args.push('-i', creditOverlayFile);
    }

    if (hasCaptionOverlay) {
      const captionPng = await createTextBarPng(autoCaptionText.trim(), targetW, 'caption');
      await ffmpeg.writeFile(captionOverlayFile, captionPng);
      args.push('-i', captionOverlayFile);
    }

    if (hasCreditOverlay && hasCaptionOverlay) {
      args.push(
        '-filter_complex',
        `[0:v]scale=${targetW}:-2[base];[base][1:v]overlay=0:0[withcredit];[withcredit][2:v]overlay=0:H-h-16[outv]`,
        '-map',
        '[outv]',
        '-map',
        '0:a?'
      );
    } else if (hasCreditOverlay) {
      args.push(
        '-filter_complex',
        `[0:v]scale=${targetW}:-2[base];[base][1:v]overlay=0:0[outv]`,
        '-map',
        '[outv]',
        '-map',
        '0:a?'
      );
    } else if (hasCaptionOverlay) {
      args.push(
        '-filter_complex',
        `[0:v]scale=${targetW}:-2[base];[base][1:v]overlay=0:H-h-16[outv]`,
        '-map',
        '[outv]',
        '-map',
        '0:a?'
      );
    } else {
      args.push(
        '-vf',
        'scale=trunc(iw/2)*2:trunc(ih/2)*2',
        '-map',
        '0:v:0',
        '-map',
        '0:a?'
      );
    }

    args.push(
      '-c:v',
      'libx264',
      '-preset',
      'ultrafast',
      '-crf',
      '23',
      '-pix_fmt',
      'yuv420p',
      '-c:a',
      'aac',
      '-b:a',
      '128k',
      '-movflags',
      '+faststart',
      '-t',
      safeDur,
      outputFile
    );

    const exitCode = await ffmpeg.exec(args);

    if (exitCode !== 0) {
      throw new Error(`FFmpeg exited with code ${exitCode}`);
    }

    onProgress?.(98, 'Finalizing MP4 clip…');
    const outputData = await ffmpeg.readFile(outputFile);
    if (typeof outputData === 'string') {
      throw new Error('Unexpected string output from FFmpeg');
    }

    const copiedBytes = new Uint8Array(outputData.byteLength);
    copiedBytes.set(outputData);
    const mp4Blob = new Blob([copiedBytes.buffer], { type: 'video/mp4' });
    onProgress?.(100, 'Complete');

    return { mp4Blob };
  } finally {
    ffmpeg.off('progress', progressHandler);
    await ffmpeg.deleteFile(inputFile).catch(() => undefined);
    await ffmpeg.deleteFile(creditOverlayFile).catch(() => undefined);
    await ffmpeg.deleteFile(captionOverlayFile).catch(() => undefined);
    await ffmpeg.deleteFile(outputFile).catch(() => undefined);
  }
}

import { FFmpeg } from '@ffmpeg/ffmpeg';
import { fetchFile, toBlobURL } from '@ffmpeg/util';
import {
  AspectRatioOption,
  SpeedPreset,
  VideoEffectMode,
  VideoFilterPreset,
  VideoFitMode,
} from '../types/clipkaro';

let ffmpegInstance: FFmpeg | null = null;
let loadPromise: Promise<FFmpeg> | null = null;

async function getLoadedFFmpeg(onStatus?: (msg: string) => void): Promise<FFmpeg> {
  if (ffmpegInstance && ffmpegInstance.loaded) {
    return ffmpegInstance;
  }
  if (loadPromise) {
    return loadPromise;
  }

  loadPromise = (async () => {
    onStatus?.('Loading FFmpeg video engine…');
    const ffmpeg = new FFmpeg();
    let basePath = '/ffmpeg';
    try {
      const probe = await fetch('/ffmpeg/ffmpeg-core.js', { method: 'HEAD' });
      const ctype = probe.headers.get('content-type') || '';
      if (!probe.ok || ctype.includes('text/html')) {
        basePath = 'https://unpkg.com/@ffmpeg/core@0.12.10/dist/esm';
      }
    } catch {
      basePath = 'https://unpkg.com/@ffmpeg/core@0.12.10/dist/esm';
    }
    const coreURL = await toBlobURL(`${basePath}/ffmpeg-core.js`, 'text/javascript');
    const wasmURL = await toBlobURL(`${basePath}/ffmpeg-core.wasm`, 'application/wasm');
    await ffmpeg.load({ coreURL, wasmURL });
    ffmpegInstance = ffmpeg;
    return ffmpeg;
  })();

  try {
    return await loadPromise;
  } catch (err) {
    loadPromise = null;
    throw err;
  }
}

async function createTextBarPng(
  text: string,
  targetWidth: number,
  variant: 'credit' | 'caption' | 'viral'
): Promise<Uint8Array> {
  if (variant === 'viral') {
    const badgeW = Math.max(220, Math.round((targetWidth * 360) / 1280));
    const badgeH = Math.max(40, Math.round((badgeW * 52) / 360));
    const canvas = document.createElement('canvas');
    canvas.width = badgeW;
    canvas.height = badgeH;
    const ctx = canvas.getContext('2d');
    if (!ctx) {
      throw new Error('Canvas 2D context unavailable for viral overlay');
    }
    ctx.fillStyle = 'rgba(15, 23, 42, 0.9)';
    ctx.fillRect(0, 0, badgeW, badgeH);
    ctx.fillStyle = '#F59E0B';
    ctx.fillRect(0, badgeH - 3, badgeW, 3);
    const fontSize = Math.max(14, Math.round((badgeW * 20) / 360));
    ctx.font = `800 ${fontSize}px system-ui, -apple-system, sans-serif`;
    ctx.fillStyle = '#FDE68A';
    ctx.textBaseline = 'middle';
    ctx.textAlign = 'center';
    ctx.fillText(text, badgeW / 2, badgeH / 2, badgeW - 16);

    const blob = await new Promise<Blob>((resolve, reject) => {
      canvas.toBlob((b) => {
        if (b) resolve(b);
        else reject(new Error('Failed to render viral badge PNG'));
      }, 'image/png');
    });
    const buf = await blob.arrayBuffer();
    return new Uint8Array(buf);
  }

  const width = Math.max(320, Math.round(targetWidth / 2) * 2);
  const height = Math.max(48, Math.round((width * (variant === 'caption' ? 72 : 58)) / 1280));
  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext('2d');
  if (!ctx) {
    throw new Error('Canvas 2D context unavailable for overlay');
  }

  if (variant === 'caption') {
    // Auto-Caption with solid black background pill/bar for clear legibility
    ctx.clearRect(0, 0, width, height);
    const fontSize = Math.max(18, Math.round((width * 26) / 1280));
    ctx.font = `700 ${fontSize}px system-ui, -apple-system, sans-serif`;
    const metrics = ctx.measureText(text);
    const padX = Math.round((width * 28) / 1280);
    const boxW = Math.min(width - 24, Math.round(metrics.width + padX * 2));
    const boxH = Math.round(height * 0.78);
    const boxX = Math.round((width - boxW) / 2);
    const boxY = Math.round((height - boxH) / 2);

    ctx.fillStyle = '#000000';
    ctx.fillRect(boxX, boxY, boxW, boxH);

    ctx.fillStyle = '#ffffff';
    ctx.textBaseline = 'middle';
    ctx.textAlign = 'center';
    ctx.fillText(text, width / 2, height / 2, boxW - 16);
  } else {
    // Top credit bar with black background
    ctx.fillStyle = 'rgba(0, 0, 0, 0.88)';
    ctx.fillRect(0, 0, width, height);

    ctx.fillStyle = 'rgba(244, 63, 94, 0.9)';
    ctx.fillRect(0, height - 2, width, 2);

    const fontSize = Math.max(16, Math.round((width * 24) / 1280));
    ctx.font = `700 ${fontSize}px system-ui, -apple-system, sans-serif`;
    ctx.fillStyle = '#ffffff';
    ctx.textBaseline = 'middle';
    ctx.textAlign = 'center';
    ctx.fillText(text, width / 2, height / 2, width - 32);
  }

  const blob = await new Promise<Blob>((resolve, reject) => {
    canvas.toBlob((b) => {
      if (b) resolve(b);
      else reject(new Error('Failed to render overlay PNG'));
    }, 'image/png');
  });

  const buf = await blob.arrayBuffer();
  return new Uint8Array(buf);
}

export interface TrimVideoParams {
  sourceBlob: Blob;
  sourceFileName: string;
  startSec: number;
  durationSec: number;
  videoWidth?: number;
  burnCredit: boolean;
  creditText: string;
  burnAutoCaption?: boolean;
  autoCaptionText?: string;
  burnViralScore?: boolean;
  viralScoreText?: string;
  aspectRatio?: AspectRatioOption;
  fitMode?: VideoFitMode;
  filterPreset?: VideoFilterPreset;
  effectMode?: VideoEffectMode;
  uniformSpeed?: SpeedPreset;
  onProgress?: (percent: number, stage: string) => void;
}

export interface TrimVideoResult {
  mp4Blob: Blob;
  thumbnailDataUrl?: string;
}

function buildFfmpegVisualFilters(params: {
  aspectRatio?: AspectRatioOption;
  fitMode?: VideoFitMode;
  filterPreset?: VideoFilterPreset;
  effectMode?: VideoEffectMode;
  uniformSpeed?: SpeedPreset;
  fallbackW: number;
}): { vfChain: string; targetW: number; atempoChain: string | null } {
  const { aspectRatio, fitMode = 'fill', filterPreset = 'none', effectMode = 'none', uniformSpeed = 1, fallbackW } = params;
  const parts: string[] = [];

  let targetW = fallbackW;
  let targetH = -2;
  if (aspectRatio === '9:16') {
    targetW = 720;
    targetH = 1280;
  } else if (aspectRatio === '1:1') {
    targetW = 720;
    targetH = 720;
  } else if (aspectRatio === '4:5') {
    targetW = 720;
    targetH = 900;
  } else if (aspectRatio === '16:9') {
    targetW = 1280;
    targetH = 720;
  }

  if (aspectRatio) {
    if (fitMode === 'fit') {
      parts.push(
        `scale=${targetW}:${targetH}:force_original_aspect_ratio=decrease,pad=${targetW}:${targetH}:(ow-iw)/2:(oh-ih)/2:black`
      );
    } else {
      parts.push(
        `scale=${targetW}:${targetH}:force_original_aspect_ratio=increase,crop=${targetW}:${targetH}`
      );
    }
  } else {
    parts.push(`scale=${targetW}:-2`);
  }

  if (filterPreset === 'cinematic') parts.push('eq=contrast=1.14:saturation=0.88:brightness=-0.03');
  else if (filterPreset === 'vivid') parts.push('eq=contrast=1.12:saturation=1.42:brightness=0.02');
  else if (filterPreset === 'warm') parts.push('colorbalance=rs=0.08:gs=0.02:bs=-0.08,eq=saturation=1.18');
  else if (filterPreset === 'cool') parts.push('colorbalance=rs=-0.07:gs=0.01:bs=0.1,eq=contrast=1.06');
  else if (filterPreset === 'bw') parts.push('hue=s=0,eq=contrast=1.18');
  else if (filterPreset === 'vintage') parts.push('colorbalance=rs=0.1:gs=0.04:bs=-0.1,eq=contrast=0.94:saturation=0.82');
  else if (filterPreset === 'hdr') parts.push('eq=contrast=1.25:saturation=1.24:brightness=0.03');

  if (effectMode === 'cinematic') {
    parts.push('eq=contrast=1.1:saturation=0.92');
    parts.push('drawbox=x=0:y=0:w=iw:h=ih*0.12:color=black:t=fill');
    parts.push('drawbox=x=0:y=ih*0.88:w=iw:h=ih*0.12:color=black:t=fill');
  } else if (effectMode === 'gaming') {
    parts.push('eq=contrast=1.22:saturation=1.25:brightness=0.03');
  } else if (effectMode === 'vlog') {
    parts.push('eq=brightness=0.08:contrast=0.96:saturation=1.1');
  } else if (effectMode === 'night') {
    parts.push('eq=brightness=0.18:contrast=1.08:saturation=1.06');
  }

  let atempoChain: string | null = null;
  if (uniformSpeed && uniformSpeed !== 1) {
    parts.push(`setpts=${(1 / uniformSpeed).toFixed(4)}*PTS`);
    if (uniformSpeed === 0.25) atempoChain = 'atempo=0.5,atempo=0.5';
    else if (uniformSpeed === 0.5) atempoChain = 'atempo=0.5';
    else if (uniformSpeed === 1.5) atempoChain = 'atempo=1.5';
    else if (uniformSpeed === 2) atempoChain = 'atempo=2.0';
  }

  return { vfChain: parts.join(','), targetW, atempoChain };
}

export async function trimVideoWithFFmpeg(params: TrimVideoParams): Promise<TrimVideoResult> {
  const {
    sourceBlob,
    sourceFileName,
    startSec,
    durationSec,
    videoWidth,
    burnCredit,
    creditText,
    burnAutoCaption = false,
    autoCaptionText = '',
    burnViralScore = false,
    viralScoreText = '',
    aspectRatio,
    fitMode,
    filterPreset,
    effectMode,
    uniformSpeed,
    onProgress,
  } = params;

  onProgress?.(5, 'Loading FFmpeg engine…');
  const ffmpeg = await getLoadedFFmpeg((msg) => onProgress?.(10, msg));

  const extMatch = sourceFileName.match(/\.([a-z0-9]+)$/i);
  const inputExt = extMatch
    ? extMatch[1].toLowerCase()
    : sourceBlob.type.includes('mp4')
      ? 'mp4'
      : 'webm';
  const ts = Date.now();
  const inputFile = `input_${ts}.${inputExt}`;
  const creditOverlayFile = `credit_${ts}.png`;
  const captionOverlayFile = `caption_${ts}.png`;
  const viralOverlayFile = `viral_${ts}.png`;
  const outputFile = `output_${ts}.mp4`;

  const hasCreditOverlay = burnCredit && creditText.trim().length > 0;
  const hasCaptionOverlay = burnAutoCaption && autoCaptionText.trim().length > 0;
  const hasViralOverlay = burnViralScore && viralScoreText.trim().length > 0;

  const progressHandler = ({ progress }: { progress: number }) => {
    const safePct = Math.max(15, Math.min(96, 15 + Math.round((progress || 0) * 80)));
    onProgress?.(
      safePct,
      hasCreditOverlay || hasCaptionOverlay || hasViralOverlay
        ? 'Trimming & burning overlays onto MP4…'
        : 'Cutting MP4 video…'
    );
  };

  ffmpeg.on('progress', progressHandler);

  try {
    onProgress?.(12, 'Preparing video file…');
    await ffmpeg.writeFile(inputFile, await fetchFile(sourceBlob));

    const safeStart = Math.max(0, startSec).toFixed(2);
    const safeDur = Math.max(1, durationSec).toFixed(2);
    const fallbackW = Math.max(320, Math.round((videoWidth || 1280) / 2) * 2);
    const { vfChain, targetW, atempoChain } = buildFfmpegVisualFilters({
      aspectRatio,
      fitMode,
      filterPreset,
      effectMode,
      uniformSpeed,
      fallbackW,
    });

    const args: string[] = ['-ss', safeStart, '-t', safeDur, '-i', inputFile];

    let nextInputIdx = 1;
    let creditIdx = -1;
    let captionIdx = -1;
    let viralIdx = -1;

    if (hasCreditOverlay) {
      const creditPng = await createTextBarPng(creditText.trim(), targetW, 'credit');
      await ffmpeg.writeFile(creditOverlayFile, creditPng);
      args.push('-i', creditOverlayFile);
      creditIdx = nextInputIdx++;
    }

    if (hasCaptionOverlay) {
      const captionPng = await createTextBarPng(autoCaptionText.trim(), targetW, 'caption');
      await ffmpeg.writeFile(captionOverlayFile, captionPng);
      args.push('-i', captionOverlayFile);
      captionIdx = nextInputIdx++;
    }

    if (hasViralOverlay) {
      const viralPng = await createTextBarPng(viralScoreText.trim(), targetW, 'viral');
      await ffmpeg.writeFile(viralOverlayFile, viralPng);
      args.push('-i', viralOverlayFile);
      viralIdx = nextInputIdx++;
    }

    if (creditIdx !== -1 || captionIdx !== -1 || viralIdx !== -1) {
      const chains: string[] = [`[0:v]${vfChain}[v0]`];
      let prev = 'v0';
      let step = 1;
      if (creditIdx !== -1) {
        const out = `v${step++}`;
        chains.push(`[${prev}][${creditIdx}:v]overlay=0:0[${out}]`);
        prev = out;
      }
      if (captionIdx !== -1) {
        const out = `v${step++}`;
        chains.push(`[${prev}][${captionIdx}:v]overlay=0:H-h-16[${out}]`);
        prev = out;
      }
      if (viralIdx !== -1) {
        const out = `v${step++}`;
        chains.push(`[${prev}][${viralIdx}:v]overlay=W-w-16:16[${out}]`);
        prev = out;
      }
      args.push('-filter_complex', chains.join(';'), '-map', `[${prev}]`, '-map', '0:a?');
    } else {
      args.push('-vf', vfChain, '-map', '0:v:0', '-map', '0:a?');
    }

    if (atempoChain) {
      args.push('-af', atempoChain);
    }

    const outDur =
      uniformSpeed && uniformSpeed !== 1
        ? Math.max(0.5, Number(safeDur) / uniformSpeed).toFixed(2)
        : safeDur;

    args.push(
      '-c:v',
      'libx264',
      '-preset',
      'ultrafast',
      '-crf',
      '23',
      '-pix_fmt',
      'yuv420p',
      '-c:a',
      'aac',
      '-b:a',
      '128k',
      '-movflags',
      '+faststart',
      '-t',
      outDur,
      outputFile
    );

    const exitCode = await ffmpeg.exec(args);

    if (exitCode !== 0) {
      throw new Error(`FFmpeg exited with code ${exitCode}`);
    }

    onProgress?.(98, 'Finalizing MP4 clip…');
    const outputData = await ffmpeg.readFile(outputFile);
    if (typeof outputData === 'string') {
      throw new Error('Unexpected string output from FFmpeg');
    }

    const copiedBytes = new Uint8Array(outputData.byteLength);
    copiedBytes.set(outputData);
    const mp4Blob = new Blob([copiedBytes.buffer], { type: 'video/mp4' });
    onProgress?.(100, 'Complete');

    return { mp4Blob };
  } finally {
    ffmpeg.off('progress', progressHandler);
    await ffmpeg.deleteFile(inputFile).catch(() => undefined);
    await ffmpeg.deleteFile(creditOverlayFile).catch(() => undefined);
    await ffmpeg.deleteFile(captionOverlayFile).catch(() => undefined);
    await ffmpeg.deleteFile(viralOverlayFile).catch(() => undefined);
    await ffmpeg.deleteFile(outputFile).catch(() => undefined);
  }
}

import { RoyaltyFreeTrack } from '../types/clipkaro';

export const ROYALTY_FREE_TRACKS: RoyaltyFreeTrack[] = [
  {
    id: 'lofi-studio',
    title: 'Lo-Fi Studio Beat',
    mood: 'Chill / Stream Commentary',
    bpm: 84,
    durationSec: 12,
    license: 'ClipKaro Safe License (CC0)',
  },
  {
    id: 'night-drive',
    title: 'Night Drive Synth',
    mood: 'Electronic / Highlight Reel',
    bpm: 112,
    durationSec: 12,
    license: 'ClipKaro Safe License (CC0)',
  },
  {
    id: 'acoustic-chill',
    title: 'Acoustic Stream Warmth',
    mood: 'Warm / Podcast & IRL',
    bpm: 92,
    durationSec: 12,
    license: 'ClipKaro Safe License (CC0)',
  },
  {
    id: 'tournament-hype',
    title: 'Tournament Hype Loop',
    mood: 'Energetic / Clutch Moments',
    bpm: 128,
    durationSec: 12,
    license: 'ClipKaro Safe License (CC0)',
  },
];

function encodeWavFromFloat32(samples: Float32Array, sampleRate: number): Blob {
  const buffer = new ArrayBuffer(44 + samples.length * 2);
  const view = new DataView(buffer);

  const writeString = (offset: number, str: string) => {
    for (let i = 0; i < str.length; i += 1) {
      view.setUint8(offset + i, str.charCodeAt(i));
    }
  };

  writeString(0, 'RIFF');
  view.setUint32(4, 36 + samples.length * 2, true);
  writeString(8, 'WAVE');
  writeString(12, 'fmt ');
  view.setUint32(16, 16, true);
  view.setUint16(20, 1, true);
  view.setUint16(22, 1, true);
  view.setUint32(24, sampleRate, true);
  view.setUint32(28, sampleRate * 2, true);
  view.setUint16(32, 2, true);
  view.setUint16(34, 16, true);
  writeString(36, 'data');
  view.setUint32(40, samples.length * 2, true);

  let offset = 44;
  for (let i = 0; i < samples.length; i += 1) {
    const clamped = Math.max(-1, Math.min(1, samples[i]));
    view.setInt16(offset, clamped < 0 ? clamped * 0x8000 : clamped * 0x7fff, true);
    offset += 2;
  }

  return new Blob([buffer], { type: 'audio/wav' });
}

export function generateRoyaltyFreeWavBlob(trackId: string): Blob {
  const sampleRate = 22050;
  const track = ROYALTY_FREE_TRACKS.find((t) => t.id === trackId) ?? ROYALTY_FREE_TRACKS[0];
  const length = sampleRate * track.durationSec;
  const samples = new Float32Array(length);

  const chordsByTrack: Record<string, number[][]> = {
    'lofi-studio': [
      [220, 261.63, 329.63],
      [174.61, 220, 261.63],
      [196, 246.94, 293.66],
      [164.81, 196, 246.94],
    ],
    'night-drive': [
      [146.83, 220, 293.66],
      [130.81, 196, 261.63],
      [116.54, 174.61, 233.08],
      [130.81, 196, 261.63],
    ],
    'acoustic-chill': [
      [196, 246.94, 293.66],
      [164.81, 207.65, 246.94],
      [146.83, 220, 293.66],
      [130.81, 196, 261.63],
    ],
    'tournament-hype': [
      [110, 164.81, 220],
      [130.81, 196, 261.63],
      [146.83, 220, 293.66],
      [164.81, 246.94, 329.63],
    ],
  };

  const chords = chordsByTrack[track.id] ?? chordsByTrack['lofi-studio'];
  const beatDur = 60 / track.bpm;

  for (let i = 0; i < length; i += 1) {
    const t = i / sampleRate;
    const barIndex = Math.floor(t / (beatDur * 2)) % chords.length;
    const chord = chords[barIndex];
    const beatPos = (t % beatDur) / beatDur;

    // Warm harmonic pad
    let pad = 0;
    for (const freq of chord) {
      pad += Math.sin(2 * Math.PI * freq * t) * 0.11;
    }

    // Gentle rhythmic pulse / kick envelope
    const kickEnv = Math.exp(-beatPos * 12);
    const kickFreq = 55 + 90 * Math.exp(-beatPos * 24);
    const kick = Math.sin(2 * Math.PI * kickFreq * t) * kickEnv * (track.id === 'tournament-hype' ? 0.35 : 0.22);

    // Subtle arpeggio pluck on half-beats
    const eighthPos = ((t * 2) % beatDur) / beatDur;
    const arpFreq = chord[Math.floor((t * 2) / beatDur) % chord.length] * 2;
    const arp = Math.sin(2 * Math.PI * arpFreq * t) * Math.exp(-eighthPos * 8) * 0.1;

    // Smooth fade in/out at loop boundary
    const fadeIn = Math.min(1, t / 0.15);
    const fadeOut = Math.min(1, (track.durationSec - t) / 0.25);
    samples[i] = (pad + kick + arp) * fadeIn * fadeOut;
  }

  return encodeWavFromFloat32(samples, sampleRate);
}

export function formatSeconds(totalSeconds: number): string {
  const safe = Math.max(0, Math.floor(totalSeconds));
  const mins = Math.floor(safe / 60);
  const secs = safe % 60;
  return `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
}

export async function captureVideoThumbnail(videoEl: HTMLVideoElement): Promise<string | undefined> {
  try {
    const width = videoEl.videoWidth || 640;
    const height = videoEl.videoHeight || 360;
    const canvas = document.createElement('canvas');
    canvas.width = 480;
    canvas.height = Math.max(270, Math.round((480 * height) / width));
    const ctx = canvas.getContext('2d');
    if (!ctx) return undefined;
    ctx.drawImage(videoEl, 0, 0, canvas.width, canvas.height);
    return canvas.toDataURL('image/jpeg', 0.8);
  } catch {
    return undefined;
  }
}

export interface SampleVideoOptions {
  durationSec: number;
  title: string;
  creditLine: string;
  onProgress?: (pct: number) => void;
}

export function generateSampleStreamVideoBlob(options: SampleVideoOptions): Promise<Blob> {
  const { durationSec, title, creditLine, onProgress } = options;
  return new Promise((resolve, reject) => {
    const canvas = document.createElement('canvas');
    canvas.width = 854;
    canvas.height = 480;
    const ctx = canvas.getContext('2d');
    if (!ctx) {
      reject(new Error('Canvas context unavailable'));
      return;
    }

    const canvasStream = canvas.captureStream(30);
    let audioCtx: AudioContext | null = null;
    let combinedStream = canvasStream;
    let soundTimer: number | null = null;

    try {
      audioCtx = new AudioContext();
      if (audioCtx.state === 'suspended') {
        audioCtx.resume().catch(() => undefined);
      }
      const dest = audioCtx.createMediaStreamDestination();
      const masterGain = audioCtx.createGain();
      masterGain.gain.value = 0.28;
      masterGain.connect(dest);

      // Warm ambient chord bed + rhythmic game synth pulses so sample video has clear audible sound
      const notes = [261.63, 329.63, 392.0, 523.25];
      let step = 0;

      const triggerNote = () => {
        if (!audioCtx || audioCtx.state === 'closed') return;
        const now = audioCtx.currentTime;
        const osc = audioCtx.createOscillator();
        const env = audioCtx.createGain();
        osc.type = step % 2 === 0 ? 'triangle' : 'sine';
        osc.frequency.setValueAtTime(notes[step % notes.length], now);
        env.gain.setValueAtTime(0.001, now);
        env.gain.exponentialRampToValueAtTime(0.35, now + 0.04);
        env.gain.exponentialRampToValueAtTime(0.001, now + 0.42);
        osc.connect(env);
        env.connect(masterGain);
        osc.start(now);
        osc.stop(now + 0.45);

        // Subtle bass pulse every 2 steps
        if (step % 2 === 0) {
          const bass = audioCtx.createOscillator();
          const bassEnv = audioCtx.createGain();
          bass.type = 'sine';
          bass.frequency.setValueAtTime(130.81, now);
          bass.frequency.exponentialRampToValueAtTime(65.41, now + 0.18);
          bassEnv.gain.setValueAtTime(0.45, now);
          bassEnv.gain.exponentialRampToValueAtTime(0.001, now + 0.22);
          bass.connect(bassEnv);
          bassEnv.connect(masterGain);
          bass.start(now);
          bass.stop(now + 0.24);
        }
        step += 1;
      };

      triggerNote();
      soundTimer = window.setInterval(triggerNote, 450);

      combinedStream = new MediaStream([
        ...canvasStream.getVideoTracks(),
        ...dest.stream.getAudioTracks(),
      ]);
    } catch {
      // Fallback to video-only stream if AudioContext is blocked
    }

    const mimeType = MediaRecorder.isTypeSupported('video/webm;codecs=vp8,opus')
      ? 'video/webm;codecs=vp8,opus'
      : MediaRecorder.isTypeSupported('video/webm;codecs=vp9,opus')
        ? 'video/webm;codecs=vp9,opus'
        : MediaRecorder.isTypeSupported('video/webm')
          ? 'video/webm'
          : '';

    const recorder = mimeType
      ? new MediaRecorder(combinedStream, { mimeType, videoBitsPerSecond: 2_500_000 })
      : new MediaRecorder(combinedStream);

    const chunks: BlobPart[] = [];
    recorder.ondataavailable = (ev) => {
      if (ev.data && ev.data.size > 0) chunks.push(ev.data);
    };

    const startTime = performance.now();
    const totalMs = Math.max(3000, durationSec * 1000);
    let rafId = 0;

    const drawFrame = () => {
      const elapsedMs = performance.now() - startTime;
      const t = elapsedMs / 1000;
      const progress = Math.min(1, elapsedMs / totalMs);
      onProgress?.(Math.round(progress * 100));

      // 1. Sunset / Twilight Arena Sky Backdrop
      const skyGrad = ctx.createLinearGradient(0, 0, 0, canvas.height * 0.62);
      skyGrad.addColorStop(0, '#0b1120');
      skyGrad.addColorStop(0.55, '#1e293b');
      skyGrad.addColorStop(1, '#3b1d3a');
      ctx.fillStyle = skyGrad;
      ctx.fillRect(0, 0, canvas.width, canvas.height * 0.62);

      // Sun / horizon glow
      const sunX = canvas.width * 0.5 + Math.sin(t * 0.35) * 40;
      const sunY = canvas.height * 0.44;
      const sunGrad = ctx.createRadialGradient(sunX, sunY, 12, sunX, sunY, 140);
      sunGrad.addColorStop(0, 'rgba(251, 146, 60, 0.9)');
      sunGrad.addColorStop(0.4, 'rgba(244, 63, 94, 0.35)');
      sunGrad.addColorStop(1, 'rgba(244, 63, 94, 0)');
      ctx.fillStyle = sunGrad;
      ctx.beginPath();
      ctx.arc(sunX, sunY, 140, 0, Math.PI * 2);
      ctx.fill();

      // Distant mountain silhouettes
      ctx.fillStyle = '#0f172a';
      ctx.beginPath();
      ctx.moveTo(0, canvas.height * 0.62);
      for (let x = 0; x <= canvas.width; x += 60) {
        const ridge = Math.sin(x * 0.012 + 1.2) * 34 + Math.cos(x * 0.025) * 18;
        ctx.lineTo(x, canvas.height * 0.55 - ridge);
      }
      ctx.lineTo(canvas.width, canvas.height * 0.62);
      ctx.closePath();
      ctx.fill();

      // 2. Ground / 3D Perspective Arena Floor
      const floorTop = canvas.height * 0.62;
      const floorGrad = ctx.createLinearGradient(0, floorTop, 0, canvas.height);
      floorGrad.addColorStop(0, '#111827');
      floorGrad.addColorStop(1, '#05080f');
      ctx.fillStyle = floorGrad;
      ctx.fillRect(0, floorTop, canvas.width, canvas.height - floorTop);

      // Perspective lanes moving toward camera
      ctx.strokeStyle = 'rgba(56, 189, 248, 0.28)';
      ctx.lineWidth = 1.5;
      const vanishX = canvas.width / 2;
      for (let lane = -8; lane <= 8; lane += 1) {
        ctx.beginPath();
        ctx.moveTo(vanishX + lane * 24, floorTop);
        ctx.lineTo(vanishX + lane * 135, canvas.height);
        ctx.stroke();
      }
      for (let row = 0; row < 7; row += 1) {
        const z = ((row / 7 + t * 0.55) % 1);
        const y = floorTop + Math.pow(z, 1.8) * (canvas.height - floorTop);
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(canvas.width, y);
        ctx.stroke();
      }

      // 3. Moving Player Target / Action Drone in Arena
      const targetX = canvas.width * 0.5 + Math.sin(t * 1.6) * 190;
      const targetY = canvas.height * 0.52 + Math.cos(t * 2.2) * 42;
      ctx.fillStyle = '#38bdf8';
      ctx.beginPath();
      ctx.arc(targetX, targetY, 16, 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = '#ffffff';
      ctx.lineWidth = 2.5;
      ctx.beginPath();
      ctx.arc(targetX, targetY, 26 + Math.sin(t * 6) * 4, 0, Math.PI * 2);
      ctx.stroke();

      // Smooth tracking crosshair reticle
      const aimX = canvas.width * 0.5 + Math.sin(t * 1.6 - 0.18) * 180;
      const aimY = canvas.height * 0.52 + Math.cos(t * 2.2 - 0.18) * 38;
      ctx.strokeStyle = '#f43f5e';
      ctx.lineWidth = 2.5;
      ctx.beginPath();
      ctx.arc(aimX, aimY, 22, 0, Math.PI * 2);
      ctx.stroke();
      ctx.beginPath();
      ctx.moveTo(aimX - 32, aimY);
      ctx.lineTo(aimX - 12, aimY);
      ctx.moveTo(aimX + 12, aimY);
      ctx.lineTo(aimX + 32, aimY);
      ctx.moveTo(aimX, aimY - 32);
      ctx.lineTo(aimX, aimY - 12);
      ctx.moveTo(aimX, aimY + 12);
      ctx.lineTo(aimX, aimY + 32);
      ctx.stroke();

      // 4. Streamer Facecam Picture-in-Picture Frame (Bottom-Right)
      const camW = 152;
      const camH = 104;
      const camX = canvas.width - camW - 24;
      const camY = canvas.height - camH - 24;
      ctx.fillStyle = '#1e293b';
      ctx.fillRect(camX, camY, camW, camH);
      ctx.strokeStyle = '#f43f5e';
      ctx.lineWidth = 2.5;
      ctx.strokeRect(camX, camY, camW, camH);
      // Stylized streamer silhouette in facecam
      ctx.fillStyle = '#94a3b8';
      ctx.beginPath();
      ctx.arc(camX + camW / 2, camY + 38, 18, 0, Math.PI * 2);
      ctx.fill();
      ctx.beginPath();
      ctx.arc(camX + camW / 2, camY + 92, 34, Math.PI, 0);
      ctx.fill();
      ctx.fillStyle = '#f8fafc';
      ctx.font = '600 11px system-ui, sans-serif';
      ctx.fillText('STREAM CAM', camX + 10, camY + 18);

      // 5. Stream Title & Match HUD Overlay (Top-Left)
      ctx.fillStyle = 'rgba(11, 14, 20, 0.78)';
      ctx.fillRect(24, 22, 390, 68);
      ctx.fillStyle = '#f8fafc';
      ctx.font = '700 22px system-ui, sans-serif';
      ctx.fillText(title || 'Sample Gameplay Stream', 40, 52);
      ctx.fillStyle = '#cbd5e1';
      ctx.font = '500 14px system-ui, sans-serif';
      ctx.fillText(creditLine || 'Credit: @StreamerName', 40, 76);

      // Live Clock HUD (Bottom-Left)
      ctx.fillStyle = 'rgba(11, 14, 20, 0.82)';
      ctx.fillRect(24, canvas.height - 62, 150, 38);
      ctx.fillStyle = '#f43f5e';
      ctx.font = '700 16px monospace';
      ctx.fillText(`LIVE ${t.toFixed(1)}s`, 38, canvas.height - 37);

      if (elapsedMs < totalMs) {
        rafId = requestAnimationFrame(drawFrame);
      } else if (recorder.state === 'recording') {
        recorder.stop();
      }
    };

    recorder.onstop = () => {
      cancelAnimationFrame(rafId);
      if (soundTimer !== null) window.clearInterval(soundTimer);
      audioCtx?.close().catch(() => undefined);
      const blob = new Blob(chunks, { type: mimeType || 'video/webm' });
      resolve(blob);
    };

    recorder.onerror = (err) => {
      cancelAnimationFrame(rafId);
      if (soundTimer !== null) window.clearInterval(soundTimer);
      audioCtx?.close().catch(() => undefined);
      reject(err);
    };

    recorder.start(250);
    rafId = requestAnimationFrame(drawFrame);
  });
}

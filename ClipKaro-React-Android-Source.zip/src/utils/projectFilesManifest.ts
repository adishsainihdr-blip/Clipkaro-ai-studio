export type ProjectFileCategory = 'react' | 'android' | 'build';

export interface ProjectSourceFile {
  path: string;
  category: ProjectFileCategory;
  content: string;
  sizeBytes: number;
}

const rawFiles = import.meta.glob<string>(
  [
    '/package.json',
    '/index.html',
    '/vite.config.ts',
    '/tsconfig.json',
    '/capacitor.config.json',
    '/metadata.json',
    '/.env.example',
    '/.gitignore',
    '/BUILD_APK_ON_MOBILE.md',
    '/scripts/*.mjs',
    '/.github/workflows/*.yml',
    '/src/**/*.{ts,tsx,css}',
    '/android/build.gradle',
    '/android/settings.gradle',
    '/android/gradle.properties',
    '/android/app/build.gradle',
    '/android/app/proguard-rules.pro',
    '/android/app/src/main/AndroidManifest.xml',
    '/android/app/src/main/java/**/*.java',
    '/android/app/src/main/res/**/*.xml',
  ],
  {
    query: '?raw',
    import: 'default',
    eager: true,
  }
);

export const ASSET_IMAGE_PATHS = [
  'src/assets/images/game_tactical_arena_1795269900712.jpg',
  'src/assets/images/game_coastal_highway_1795269900686.jpg',
  'src/assets/images/game_voxel_valley_1795269899720.jpg',
  'src/assets/images/game_stadium_floodlights_1795269900819.jpg',
];

function classifyPath(cleanPath: string): ProjectFileCategory {
  if (cleanPath.startsWith('android/')) return 'android';
  if (
    cleanPath.startsWith('.github/') ||
    cleanPath.startsWith('scripts/') ||
    cleanPath === 'BUILD_APK_ON_MOBILE.md' ||
    cleanPath === 'capacitor.config.json'
  ) {
    return 'build';
  }
  return 'react';
}

const encoder = new TextEncoder();

export const PROJECT_SOURCE_FILES: ProjectSourceFile[] = Object.entries(rawFiles)
  .map(([key, content]) => {
    const cleanPath = key.replace(/^\/+/, '');
    return {
      path: cleanPath,
      category: classifyPath(cleanPath),
      content,
      sizeBytes: encoder.encode(content).byteLength,
    };
  })
  .sort((a, b) => {
    const order: Record<ProjectFileCategory, number> = { android: 0, react: 1, build: 2 };
    if (order[a.category] !== order[b.category]) {
      return order[a.category] - order[b.category];
    }
    return a.path.localeCompare(b.path);
  });

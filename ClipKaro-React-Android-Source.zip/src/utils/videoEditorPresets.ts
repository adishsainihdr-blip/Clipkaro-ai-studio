import {
  AspectRatioOption,
  SpeedPreset,
  SpeedSegment,
  VideoEffectMode,
  VideoFilterPreset,
} from '../types/clipkaro';

export const ASPECT_RATIO_OPTIONS: {
  id: AspectRatioOption;
  label: string;
  platformHint: string;
}[] = [
  { id: '16:9', label: '16:9', platformHint: 'YouTube Horizontal' },
  { id: '9:16', label: '9:16', platformHint: 'Shorts / Reels Vertical' },
  { id: '1:1', label: '1:1', platformHint: 'IG / FB Square' },
  { id: '4:5', label: '4:5', platformHint: 'Instagram Portrait' },
];

export const FILTER_PRESETS: {
  id: VideoFilterPreset;
  label: string;
  cssFilter: string;
}[] = [
  { id: 'none', label: 'Original', cssFilter: '' },
  {
    id: 'cinematic',
    label: 'Cinematic',
    cssFilter: 'contrast(1.14) saturate(0.88) brightness(0.95) sepia(0.08)',
  },
  {
    id: 'vivid',
    label: 'Vivid',
    cssFilter: 'saturate(1.42) contrast(1.12) brightness(1.03)',
  },
  {
    id: 'warm',
    label: 'Warm',
    cssFilter: 'sepia(0.24) saturate(1.22) brightness(1.03)',
  },
  {
    id: 'cool',
    label: 'Cool',
    cssFilter: 'saturate(0.95) contrast(1.06) brightness(1.02) hue-rotate(-14deg)',
  },
  {
    id: 'bw',
    label: 'Black & White',
    cssFilter: 'grayscale(1) contrast(1.18)',
  },
  {
    id: 'vintage',
    label: 'Vintage',
    cssFilter: 'sepia(0.42) contrast(0.94) brightness(0.96) saturate(0.85)',
  },
  {
    id: 'hdr',
    label: 'HDR Look',
    cssFilter: 'contrast(1.28) saturate(1.26) brightness(1.04)',
  },
];

export const EFFECT_MODES: {
  id: VideoEffectMode;
  label: string;
  description: string;
  cssFilter: string;
}[] = [
  { id: 'none', label: 'Standard', description: 'Original look', cssFilter: '' },
  {
    id: 'cinematic',
    label: 'Cinematic',
    description: '2.35:1 black bars + film look',
    cssFilter: 'contrast(1.12) saturate(0.9) brightness(0.96)',
  },
  {
    id: 'gaming',
    label: 'Gaming',
    description: 'Sharp + High Contrast',
    cssFilter: 'contrast(1.25) saturate(1.28) brightness(1.04)',
  },
  {
    id: 'vlog',
    label: 'Vlog',
    description: 'Bright + Soft',
    cssFilter: 'brightness(1.1) contrast(0.95) saturate(1.12)',
  },
  {
    id: 'night',
    label: 'Night',
    description: 'Low light boost',
    cssFilter: 'brightness(1.28) contrast(1.1) saturate(1.08)',
  },
];

export const SPEED_OPTIONS: SpeedPreset[] = [0.25, 0.5, 1, 1.5, 2];

export function combineCssFilters(
  filterPreset: VideoFilterPreset = 'none',
  effectMode: VideoEffectMode = 'none'
): string {
  const f = FILTER_PRESETS.find((x) => x.id === filterPreset)?.cssFilter ?? '';
  const m = EFFECT_MODES.find((x) => x.id === effectMode)?.cssFilter ?? '';
  return [f, m].filter(Boolean).join(' ') || 'none';
}

export function getAspectContainerClass(ratio: AspectRatioOption = '16:9'): string {
  switch (ratio) {
    case '9:16':
      return 'aspect-[9/16] max-h-[360px] mx-auto';
    case '1:1':
      return 'aspect-square max-h-[340px] mx-auto';
    case '4:5':
      return 'aspect-[4/5] max-h-[360px] mx-auto';
    case '16:9':
    default:
      return 'aspect-video w-full';
  }
}

export function getSpeedAtTime(segments: SpeedSegment[] | undefined, timeSec: number): SpeedPreset {
  if (!segments || segments.length === 0) return 1;
  const match = segments.find((seg) => timeSec >= seg.startSec && timeSec <= seg.endSec);
  if (match) return match.speed;
  if (timeSec < segments[0].startSec) return segments[0].speed;
  return segments[segments.length - 1].speed;
}

export function getSpeedSegmentClasses(speed: SpeedPreset): {
  barClass: string;
  badgeClass: string;
  tag: string;
} {
  if (speed < 1) {
    return {
      barClass: 'bg-sky-500/80 hover:bg-sky-400',
      badgeClass: 'border-sky-500/50 bg-sky-950/50 text-sky-200',
      tag: 'Slow-Mo',
    };
  }
  if (speed > 1) {
    return {
      barClass: 'bg-rose-500/85 hover:bg-rose-400',
      badgeClass: 'border-rose-500/50 bg-rose-950/50 text-rose-200',
      tag: 'Fast',
    };
  }
  return {
    barClass: 'bg-emerald-500/75 hover:bg-emerald-400',
    badgeClass: 'border-emerald-500/50 bg-emerald-950/40 text-emerald-200',
    tag: 'Normal',
  };
}

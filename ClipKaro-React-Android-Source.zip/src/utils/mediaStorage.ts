import { ClipItem, GameItem } from '../types/clipkaro';

const DB_NAME = 'clipkaro_studio_db';
const DB_VERSION = 1;
const CLIPS_STORE = 'clips';
const GAMES_STORE = 'games';
const COPYRIGHT_MODE_KEY = 'clipkaro_copyright_safe_mode';

export const DEFAULT_GAMES: GameItem[] = [
  {
    id: 'game-bgmi',
    name: 'BGMI',
    genre: 'Battle Royale',
    coverUrl: '/src/assets/images/game_tactical_arena_1795269900712.jpg',
    androidPackage: 'com.pubg.imobile',
    iconKey: 'bgmi',
  },
  {
    id: 'game-free-fire-max',
    name: 'Free Fire MAX',
    genre: 'Battle Royale',
    coverUrl: '/src/assets/images/game_tactical_arena_1795269900712.jpg',
    androidPackage: 'com.dts.freefiremax',
    iconKey: 'freefire',
  },
  {
    id: 'game-gta-v',
    name: 'GTA V',
    genre: 'Open World Action',
    coverUrl: '/src/assets/images/game_coastal_highway_1795269900686.jpg',
    androidPackage: 'com.rockstargames.gtav',
    iconKey: 'gtav',
  },
  {
    id: 'game-minecraft',
    name: 'Minecraft',
    genre: 'Sandbox Survival',
    coverUrl: '/src/assets/images/game_voxel_valley_1795269899720.jpg',
    androidPackage: 'com.mojang.minecraftpe',
    iconKey: 'minecraft',
  },
  {
    id: 'game-valorant',
    name: 'Valorant',
    genre: 'Tactical Shooter',
    coverUrl: '/src/assets/images/game_tactical_arena_1795269900712.jpg',
    androidPackage: 'com.riotgames.valorant',
    iconKey: 'valorant',
  },
  {
    id: 'game-cod-mobile',
    name: 'Call of Duty Mobile',
    genre: 'Multiplayer FPS',
    coverUrl: '/src/assets/images/game_stadium_floodlights_1795269900819.jpg',
    androidPackage: 'com.activision.callofduty.shooter',
    iconKey: 'codm',
  },
];

function openDatabase(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);
    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains(CLIPS_STORE)) {
        const clipStore = db.createObjectStore(CLIPS_STORE, { keyPath: 'id' });
        clipStore.createIndex('createdAt', 'createdAt', { unique: false });
      }
      if (!db.objectStoreNames.contains(GAMES_STORE)) {
        db.createObjectStore(GAMES_STORE, { keyPath: 'id' });
      }
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

export async function getAllClips(): Promise<ClipItem[]> {
  const db = await openDatabase();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(CLIPS_STORE, 'readonly');
    const store = tx.objectStore(CLIPS_STORE);
    const req = store.getAll();
    req.onsuccess = () => {
      const items = (req.result as ClipItem[]).sort((a, b) => b.createdAt - a.createdAt);
      resolve(items);
    };
    req.onerror = () => reject(req.error);
  });
}

export async function saveClipToDb(clip: ClipItem): Promise<void> {
  const db = await openDatabase();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(CLIPS_STORE, 'readwrite');
    const store = tx.objectStore(CLIPS_STORE);
    const req = store.put(clip);
    req.onsuccess = () => resolve();
    req.onerror = () => reject(req.error);
  });
}

export async function deleteClipFromDb(id: string): Promise<void> {
  const db = await openDatabase();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(CLIPS_STORE, 'readwrite');
    const store = tx.objectStore(CLIPS_STORE);
    const req = store.delete(id);
    req.onsuccess = () => resolve();
    req.onerror = () => reject(req.error);
  });
}

export async function getAllGames(): Promise<GameItem[]> {
  const db = await openDatabase();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(GAMES_STORE, 'readonly');
    const store = tx.objectStore(GAMES_STORE);
    const req = store.getAll();
    req.onsuccess = () => {
      const customGames = req.result as GameItem[];
      resolve([...DEFAULT_GAMES, ...customGames]);
    };
    req.onerror = () => reject(req.error);
  });
}

export async function addCustomGameToDb(game: GameItem): Promise<void> {
  const db = await openDatabase();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(GAMES_STORE, 'readwrite');
    const store = tx.objectStore(GAMES_STORE);
    const req = store.put({ ...game, isCustom: true });
    req.onsuccess = () => resolve();
    req.onerror = () => reject(req.error);
  });
}

export async function deleteCustomGameFromDb(id: string): Promise<void> {
  const db = await openDatabase();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(GAMES_STORE, 'readwrite');
    const store = tx.objectStore(GAMES_STORE);
    const req = store.delete(id);
    req.onsuccess = () => resolve();
    req.onerror = () => reject(req.error);
  });
}

export function getStoredCopyrightSafeMode(): boolean {
  try {
    const stored = localStorage.getItem(COPYRIGHT_MODE_KEY);
    if (stored === null) return true; // Default ON as required
    return stored === 'true';
  } catch {
    return true;
  }
}

export function setStoredCopyrightSafeMode(enabled: boolean): void {
  try {
    localStorage.setItem(COPYRIGHT_MODE_KEY, String(enabled));
  } catch {
    // ignore storage errors
  }
}

import { ClipItem, GameItem } from '../types/clipkaro';

const DB_NAME = 'clipkaro_studio_db';
const DB_VERSION = 1;
const CLIPS_STORE = 'clips';
const GAMES_STORE = 'games';
const COPYRIGHT_MODE_KEY = 'clipkaro_copyright_safe_mode';

export const DEFAULT_GAMES: GameItem[] = [
  {
    id: 'game-bgmi',
    name: 'BGMI',
    genre: 'Battle Royale',
    coverUrl: '/src/assets/images/game_tactical_arena_1795269900712.jpg',
    androidPackage: 'com.pubg.imobile',
    iconKey: 'bgmi',
  },
  {
    id: 'game-free-fire-max',
    name: 'Free Fire MAX',
    genre: 'Battle Royale',
    coverUrl: '/src/assets/images/game_tactical_arena_1795269900712.jpg',
    androidPackage: 'com.dts.freefiremax',
    iconKey: 'freefire',
  },
  {
    id: 'game-gta-v',
    name: 'GTA V',
    genre: 'Open World Action',
    coverUrl: '/src/assets/images/game_coastal_highway_1795269900686.jpg',
    androidPackage: 'com.rockstargames.gtav',
    iconKey: 'gtav',
  },
  {
    id: 'game-minecraft',
    name: 'Minecraft',
    genre: 'Sandbox Survival',
    coverUrl: '/src/assets/images/game_voxel_valley_1795269899720.jpg',
    androidPackage: 'com.mojang.minecraftpe',
    iconKey: 'minecraft',
  },
  {
    id: 'game-valorant',
    name: 'Valorant',
    genre: 'Tactical Shooter',
    coverUrl: '/src/assets/images/game_tactical_arena_1795269900712.jpg',
    androidPackage: 'com.riotgames.valorant',
    iconKey: 'valorant',
  },
  {
    id: 'game-cod-mobile',
    name: 'Call of Duty Mobile',
    genre: 'Multiplayer FPS',
    coverUrl: '/src/assets/images/game_stadium_floodlights_1795269900819.jpg',
    androidPackage: 'com.activision.callofduty.shooter',
    iconKey: 'codm',
  },
];

function openDatabase(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);
    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains(CLIPS_STORE)) {
        const clipStore = db.createObjectStore(CLIPS_STORE, { keyPath: 'id' });
        clipStore.createIndex('createdAt', 'createdAt', { unique: false });
      }
      if (!db.objectStoreNames.contains(GAMES_STORE)) {
        db.createObjectStore(GAMES_STORE, { keyPath: 'id' });
      }
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

export async function getAllClips(): Promise<ClipItem[]> {
  const db = await openDatabase();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(CLIPS_STORE, 'readonly');
    const store = tx.objectStore(CLIPS_STORE);
    const req = store.getAll();
    req.onsuccess = () => {
      const items = (req.result as ClipItem[]).sort((a, b) => b.createdAt - a.createdAt);
      resolve(items);
    };
    req.onerror = () => reject(req.error);
  });
}

export async function saveClipToDb(clip: ClipItem): Promise<void> {
  const db = await openDatabase();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(CLIPS_STORE, 'readwrite');
    const store = tx.objectStore(CLIPS_STORE);
    const req = store.put(clip);
    req.onsuccess = () => resolve();
    req.onerror = () => reject(req.error);
  });
}

export async function deleteClipFromDb(id: string): Promise<void> {
  const db = await openDatabase();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(CLIPS_STORE, 'readwrite');
    const store = tx.objectStore(CLIPS_STORE);
    const req = store.delete(id);
    req.onsuccess = () => resolve();
    req.onerror = () => reject(req.error);
  });
}

export async function getAllGames(): Promise<GameItem[]> {
  const db = await openDatabase();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(GAMES_STORE, 'readonly');
    const store = tx.objectStore(GAMES_STORE);
    const req = store.getAll();
    req.onsuccess = () => {
      const customGames = req.result as GameItem[];
      resolve([...DEFAULT_GAMES, ...customGames]);
    };
    req.onerror = () => reject(req.error);
  });
}

export async function addCustomGameToDb(game: GameItem): Promise<void> {
  const db = await openDatabase();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(GAMES_STORE, 'readwrite');
    const store = tx.objectStore(GAMES_STORE);
    const req = store.put({ ...game, isCustom: true });
    req.onsuccess = () => resolve();
    req.onerror = () => reject(req.error);
  });
}

export async function deleteCustomGameFromDb(id: string): Promise<void> {
  const db = await openDatabase();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(GAMES_STORE, 'readwrite');
    const store = tx.objectStore(GAMES_STORE);
    const req = store.delete(id);
    req.onsuccess = () => resolve();
    req.onerror = () => reject(req.error);
  });
}

export function getStoredCopyrightSafeMode(): boolean {
  try {
    const stored = localStorage.getItem(COPYRIGHT_MODE_KEY);
    if (stored === null) return true; // Default ON as required
    return stored === 'true';
  } catch {
    return true;
  }
}

export function setStoredCopyrightSafeMode(enabled: boolean): void {
  try {
    localStorage.setItem(COPYRIGHT_MODE_KEY, String(enabled));
  } catch {
    // ignore storage errors
  }
}

const AUTO_DELETE_7D_KEY = 'clipkaro_auto_delete_7days';
const KEEP_BEST_CLIPS_KEY = 'clipkaro_keep_best_clips';
const REACTION_MODE_KEY = 'clipkaro_reaction_mode_enabled';
const FACECAM_ENABLED_KEY = 'clipkaro_facecam_enabled';
const VOICE_CHANGER_KEY = 'clipkaro_voice_changer_preset';
const SHOW_VIRAL_SCORE_KEY = 'clipkaro_show_viral_score_in_app';

export function getStoredShowViralScoreInApp(): boolean {
  try {
    const val = localStorage.getItem(SHOW_VIRAL_SCORE_KEY);
    return val === null ? true : val === 'true';
  } catch {
    return true;
  }
}

export function setStoredShowViralScoreInApp(enabled: boolean): void {
  try {
    localStorage.setItem(SHOW_VIRAL_SCORE_KEY, String(enabled));
  } catch {
    // ignore
  }
}

export function getStoredAutoDelete7Days(): boolean {
  try {
    return localStorage.getItem(AUTO_DELETE_7D_KEY) === 'true';
  } catch {
    return false;
  }
}

export function setStoredAutoDelete7Days(enabled: boolean): void {
  try {
    localStorage.setItem(AUTO_DELETE_7D_KEY, String(enabled));
  } catch {
    // ignore
  }
}

export function getStoredKeepBestClips(): boolean {
  try {
    const val = localStorage.getItem(KEEP_BEST_CLIPS_KEY);
    return val === null ? true : val === 'true';
  } catch {
    return true;
  }
}

export function setStoredKeepBestClips(enabled: boolean): void {
  try {
    localStorage.setItem(KEEP_BEST_CLIPS_KEY, String(enabled));
  } catch {
    // ignore
  }
}

export function getStoredReactionOptions(): {
  reactionMode: boolean;
  facecamEnabled: boolean;
  voiceChanger: 'normal' | 'funny' | 'robot' | 'deep';
} {
  try {
    const reactionMode = localStorage.getItem(REACTION_MODE_KEY) === 'true';
    const facecamEnabled = localStorage.getItem(FACECAM_ENABLED_KEY) === 'true';
    const vc = localStorage.getItem(VOICE_CHANGER_KEY);
    const voiceChanger =
      vc === 'funny' || vc === 'robot' || vc === 'deep' ? vc : 'normal';
    return { reactionMode, facecamEnabled, voiceChanger };
  } catch {
    return { reactionMode: false, facecamEnabled: false, voiceChanger: 'normal' };
  }
}

export function setStoredReactionOptions(opts: {
  reactionMode?: boolean;
  facecamEnabled?: boolean;
  voiceChanger?: 'normal' | 'funny' | 'robot' | 'deep';
}): void {
  try {
    if (opts.reactionMode !== undefined) {
      localStorage.setItem(REACTION_MODE_KEY, String(opts.reactionMode));
    }
    if (opts.facecamEnabled !== undefined) {
      localStorage.setItem(FACECAM_ENABLED_KEY, String(opts.facecamEnabled));
    }
    if (opts.voiceChanger !== undefined) {
      localStorage.setItem(VOICE_CHANGER_KEY, opts.voiceChanger);
    }
  } catch {
    // ignore
  }
}

export function calculateClipsStorageBytes(clips: ClipItem[]): number {
  return clips.reduce((acc, clip) => {
    const vSize = clip.videoBlob?.size || 0;
    const voSize = clip.voiceBlob?.size || 0;
    const muSize = clip.musicBlob?.size || 0;
    const prSize = clip.permission?.proofBlob?.size || 0;
    return acc + vSize + voSize + muSize + prSize;
  }, 0);
}

export function formatStorageBytes(bytes: number): string {
  if (bytes <= 0) return '0 MB used';
  const kb = bytes / 1024;
  if (kb < 1024) return `${Math.max(1, Math.round(kb))} KB used`;
  const mb = kb / 1024;
  if (mb < 1024) return `${mb.toFixed(1)} MB used`;
  const gb = mb / 1024;
  return `${gb.toFixed(2)} GB used`;
}

export function findExpiredClips(
  clips: ClipItem[],
  keepBestClips: boolean,
  nowMs = Date.now()
): ClipItem[] {
  const sevenDaysMs = 7 * 24 * 60 * 60 * 1000;
  return clips.filter((clip) => {
    if (keepBestClips && clip.isFavourite) return false;
    return nowMs - (clip.createdAt || nowMs) > sevenDaysMs;
  });
}

export function selectTodaysBestClip(clips: ClipItem[]): {
  clip: ClipItem;
  reason: string;
  isFromToday: boolean;
} | null {
  if (!clips.length) return null;

  const startOfToday = new Date();
  startOfToday.setHours(0, 0, 0, 0);
  const todayCutoff = startOfToday.getTime();
  const todaysClips = clips.filter((c) => c.createdAt >= todayCutoff);
  const pool = todaysClips.length > 0 ? todaysClips : clips;
  const isFromToday = todaysClips.length > 0;

  let best = pool[0];
  let bestScore = -1;
  let bestReason = 'Longest recording';

  for (const clip of pool) {
    const titleLower = clip.title.toLowerCase();
    const isHighlight =
      titleLower.includes('headshot') ||
      titleLower.includes('kill') ||
      titleLower.includes('clutch') ||
      titleLower.includes('highlight') ||
      Boolean(clip.autoCaption?.toLowerCase().includes('headshot'));
    const kills = clip.killCount ?? (isHighlight ? 2 : 0);

    let score = Math.min(clip.durationSec || 0, 600);
    if (clip.isFavourite) score += 2000;
    if (kills > 0) score += kills * 300;
    if (isHighlight) score += 250;

    if (score > bestScore) {
      bestScore = score;
      best = clip;
      if (clip.isFavourite) {
        bestReason = 'Marked Favourite / Best';
      } else if (kills > 0 || isHighlight) {
        bestReason = kills > 1 ? `${kills} Kills / Highlight` : 'Auto Highlight Moment';
      } else {
        bestReason = `Longest (${clip.durationSec}s)`;
      }
    }
  }

  return { clip: best, reason: bestReason, isFromToday };
}


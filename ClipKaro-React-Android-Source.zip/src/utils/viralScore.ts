import { ClipItem } from '../types/clipkaro';
import { trimVideoWithFFmpeg } from './ffmpegCutter';

export interface ViralScoreResult {
  score: number;
  verdict: string;
  label: string;
  tip: string;
  tier: 'high' | 'medium' | 'low';
}

export function calculateViralScore(clip: ClipItem): ViralScoreResult {
  const dur = Math.max(0, clip.trimEnd > clip.trimStart ? clip.trimEnd - clip.trimStart : clip.durationSec);

  // 1. Length score (15-30 sec = highest)
  let lengthPts = 10;
  if (dur >= 15 && dur <= 30) {
    lengthPts = 35;
  } else if ((dur >= 10 && dur < 15) || (dur > 30 && dur <= 45)) {
    lengthPts = 22;
  } else if (dur > 45 && dur <= 60) {
    lengthPts = 15;
  }

  // 2. Music used
  const hasMusic = Boolean(clip.musicBlob || clip.musicName);
  const musicPts = hasMusic ? 22 : 0;

  // 3. Caption used
  const hasCaption = Boolean(clip.autoCaption && clip.autoCaption.trim().length > 0);
  const captionPts = hasCaption ? 20 : 0;

  // 4. Filter / Mode used
  const hasFilter = Boolean(
    (clip.filterPreset && clip.filterPreset !== 'none') ||
      (clip.effectMode && clip.effectMode !== 'none')
  );
  const filterPts = hasFilter ? 15 : 0;

  // 5. Bonus: Thumbnail + Vertical Ratio
  const hasThumb = Boolean(clip.thumbnailDataUrl);
  const isVertical = clip.aspectRatio === '9:16' || clip.aspectRatio === '4:5';
  const bonusPts = (hasThumb ? 4 : 0) + (isVertical ? 4 : 0);

  const score = Math.min(100, Math.max(15, lengthPts + musicPts + captionPts + filterPts + bonusPts));

  let verdict = 'Thoda aur edit karo';
  let tier: ViralScoreResult['tier'] = 'low';
  if (score >= 80) {
    verdict = 'Ye Reels par chalegi!';
    tier = 'high';
  } else if (score >= 55) {
    verdict = 'Achhi reach aa sakti hai!';
    tier = 'medium';
  }

  let tip = 'Score top par hai — Shorts & Reels par post karo!';
  if (!hasMusic) {
    tip = 'Score badhane ke liye Music lagao';
  } else if (!hasCaption) {
    tip = 'Score badhane ke liye Auto Caption lagao';
  } else if (!hasFilter) {
    tip = 'Score badhane ke liye Cinematic Filter lagao';
  } else if (!hasThumb) {
    tip = 'Score badhane ke liye Thumbnail lagao';
  } else if (dur < 15 || dur > 30) {
    tip = '15-30 sec cut karne par aur zyada Viral Score milega';
  }

  return {
    score,
    verdict,
    label: `Viral Score: ${score}/100 - ${verdict}`,
    tip,
    tier,
  };
}

export async function prepareExportVideoBlobWithViralScore(
  clip: ClipItem,
  includeViralScore: boolean
): Promise<{ blob: Blob; mimeType: string; nativeUri?: string; scoreBadgeText?: string }> {
  if (!includeViralScore) {
    return {
      blob: clip.videoBlob,
      mimeType: clip.videoMimeType,
      nativeUri: clip.nativeUri,
    };
  }

  const viral = calculateViralScore(clip);
  const badgeText = `Viral Score: ${viral.score}/100`;
  const dur = Math.max(1, clip.trimEnd > clip.trimStart ? clip.trimEnd - clip.trimStart : clip.durationSec);

  try {
    const rendered = await trimVideoWithFFmpeg({
      sourceBlob: clip.videoBlob,
      sourceFileName: clip.nativeFileName || `${clip.title}.mp4`,
      startSec: Math.max(0, clip.trimStart || 0),
      durationSec: dur,
      burnCredit: false,
      creditText: clip.permission.creditText,
      burnViralScore: true,
      viralScoreText: badgeText,
      aspectRatio: clip.aspectRatio,
      fitMode: clip.fitMode,
      filterPreset: clip.filterPreset,
      effectMode: clip.effectMode,
    });
    return {
      blob: rendered.mp4Blob,
      mimeType: 'video/mp4',
      nativeUri: undefined,
      scoreBadgeText: badgeText,
    };
  } catch {
    // Offline fallback if FFmpeg WASM is not cached
    return {
      blob: clip.videoBlob,
      mimeType: clip.videoMimeType,
      nativeUri: clip.nativeUri,
      scoreBadgeText: badgeText,
    };
  }
}

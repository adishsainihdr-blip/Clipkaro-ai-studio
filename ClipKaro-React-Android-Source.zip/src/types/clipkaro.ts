export type SocialPlatform = 'youtube' | 'instagram' | 'facebook';

export type WorkspaceTab = 'home' | 'cut' | 'voice' | 'music' | 'clips' | 'games';

export type ClipLengthOption = 10 | 20 | 30 | 40 | 50 | 60;

export const CLIP_LENGTH_OPTIONS: ClipLengthOption[] = [10, 20, 30, 40, 50, 60];

export interface PermissionInfo {
  hasPermission: boolean;
  streamerName: string;
  proofFileName?: string;
  proofMimeType?: string;
  proofBlob?: Blob;
  originalVideoLink: string;
  creditText: string;
}

export interface ClipItem {
  id: string;
  title: string;
  platform: SocialPlatform | 'upload' | 'studio';
  gameTag: string;
  durationSec: number;
  trimStart: number;
  trimEnd: number;
  createdAt: number;
  copyrightSafe: boolean;
  permission: PermissionInfo;
  videoBlob: Blob;
  videoMimeType: string;
  thumbnailDataUrl?: string;
  autoCaption?: string;
  voiceBlob?: Blob;
  voiceName?: string;
  voiceVolume: number;
  musicBlob?: Blob;
  musicName?: string;
  musicVolume: number;
  originalVolume: number;
}

export interface GameItem {
  id: string;
  name: string;
  genre: string;
  coverUrl: string;
  androidPackage?: string;
  launchUrl?: string;
  iconKey?: 'bgmi' | 'freefire' | 'gtav' | 'minecraft' | 'valorant' | 'codm' | 'custom';
  isCustom?: boolean;
}

export interface RoyaltyFreeTrack {
  id: string;
  title: string;
  mood: string;
  bpm: number;
  durationSec: number;
  license: string;
}

export type SocialPlatform = 'youtube' | 'instagram' | 'facebook';

export type WorkspaceTab = 'home' | 'cut' | 'voice' | 'music' | 'clips' | 'games' | 'apps';

export type ClipLengthOption = 10 | 20 | 30 | 40 | 50 | 60;

export type AudioSourceMode = 'game' | 'mic' | 'both';

export interface UniversalAppItem {
  id: string;
  name: string;
  category: string;
  androidPackage: string;
  webFallbackUrl: string;
  accentColor: 'red' | 'fuchsia' | 'sky' | 'emerald' | 'amber' | 'violet';
  iconKey: 'youtube' | 'instagram' | 'facebook' | 'whatsapp' | 'bgmi' | 'custom';
  isCustom?: boolean;
}

export const CLIP_LENGTH_OPTIONS: ClipLengthOption[] = [10, 20, 30, 40, 50, 60];

export interface PermissionInfo {
  hasPermission: boolean;
  streamerName: string;
  proofFileName?: string;
  proofMimeType?: string;
  proofBlob?: Blob;
  originalVideoLink: string;
  creditText: string;
}

export type AspectRatioOption = '16:9' | '9:16' | '1:1' | '4:5';
export type VideoFitMode = 'fill' | 'fit';
export type VideoFilterPreset =
  | 'none'
  | 'cinematic'
  | 'vivid'
  | 'warm'
  | 'cool'
  | 'bw'
  | 'vintage'
  | 'hdr';
export type VideoEffectMode = 'none' | 'cinematic' | 'gaming' | 'vlog' | 'night';
export type SpeedPreset = 0.25 | 0.5 | 1 | 1.5 | 2;

export interface SpeedSegment {
  id: string;
  startSec: number;
  endSec: number;
  speed: SpeedPreset;
}

export interface ClipItem {
  id: string;
  title: string;
  platform: SocialPlatform | 'upload' | 'studio';
  gameTag: string;
  durationSec: number;
  trimStart: number;
  trimEnd: number;
  createdAt: number;
  copyrightSafe: boolean;
  permission: PermissionInfo;
  videoBlob: Blob;
  videoMimeType: string;
  thumbnailDataUrl?: string;
  autoCaption?: string;
  voiceBlob?: Blob;
  voiceName?: string;
  voiceVolume: number;
  musicBlob?: Blob;
  musicName?: string;
  musicVolume: number;
  originalVolume: number;
  nativeUri?: string;
  nativeFileName?: string;
  audioSourceMode?: AudioSourceMode;
  aspectRatio?: AspectRatioOption;
  fitMode?: VideoFitMode;
  filterPreset?: VideoFilterPreset;
  effectMode?: VideoEffectMode;
  speedSegments?: SpeedSegment[];
}

export interface GameItem {
  id: string;
  name: string;
  genre: string;
  coverUrl: string;
  androidPackage?: string;
  launchUrl?: string;
  iconKey?: 'bgmi' | 'freefire' | 'gtav' | 'minecraft' | 'valorant' | 'codm' | 'custom';
  isCustom?: boolean;
}

export interface RoyaltyFreeTrack {
  id: string;
  title: string;
  mood: string;
  bpm: number;
  durationSec: number;
  license: string;
}

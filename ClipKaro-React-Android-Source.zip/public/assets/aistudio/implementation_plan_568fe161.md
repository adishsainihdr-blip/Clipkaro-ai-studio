# ClipKaro — Implementation Plan & Release Blueprint

**ClipKaro** is an English-language creator video clipping studio and Android mobile wrapper built with React, TypeScript, Tailwind CSS, IndexedDB, Web Audio API, and FFmpeg WebAssembly. It lets creators browse social streams inside the app, verify streamer permission with automated attribution, cut 10–60 second MP4 clips with burned-in credits and black-background auto-captions, mix voiceovers and copyright-safe music, launch installed Android games, and capture HD gameplay via a draggable floating **CLIP** button.

---

## 1. Core Features & Functional Specification

### A. Home & Open Inside Viewer
- **Quick Actions Grid**:
  - **Cut Video**: Opens the video cutter and trimmer workspace.
  - **Add Voice**: Opens the microphone voiceover and audio upload studio.
  - **Add Music**: Opens the copyright-safe royalty-free track library and mixer.
  - **My Clips**: Opens the persistent clip gallery showing saved clip count.
  - **My Games**: Opens the game launcher library and Clip Timing Mini-Game.
  - **Copyright-Safe Mode (Default ON)**: Interactive toggle persisted in `localStorage` that enforces streamer permission and attribution before saving clips, and verifies music licensing.
- **Open Inside Viewer**:
  - Segmented platform tabs for **YouTube**, **Instagram**, and **Facebook**.
  - URL input bar with **Open Inside** embedded iframe preview, quick example presets, external source link fallback, and **Cut This Link** handoff that pre-fills Cut Video's `Original Video Link` and streamer name.

### B. Cut Video (FFmpeg MP4 Trimming & Permission Clip)
- **Permission Clip Section (Top)**:
  - Toggle: **I have permission from streamer**.
  - Fields: **Streamer Channel Name**, **Permission Proof Upload** (image/PDF/txt with live thumbnail preview), and **Original Video Link**.
  - Live auto-generated attribution text: **`Credit: @StreamerName`** with a one-click **Copy Credit** button.
- **Video Source & Audio/Video Preview**:
  - **My Gallery** button at the top (plus **Upload Video File**) opening the device media picker (`accept="video/*"`) with full video + audio playback.
  - **Generate Sample Stream** creating a 720p animated gameplay/stream WebM video with multi-note synth soundtrack and bass audio.
  - Interactive HTML5 `<video>` preview with WebM duration resolution, timeline start slider, and **Preview 10s–60s Segment** button playing both video and audio.
- **Clip Length Chips & Auto-Caption**:
  - Interactive duration chips: **10 sec** (default), **20 sec**, **30 sec**, **40 sec**, **50 sec**, **60 sec**.
  - **Auto-Caption (Black Background)** toggle and text input rendered with a solid `#000000` background in both live preview and FFmpeg output.
- **Real FFmpeg Trimming**:
  - Uses `@ffmpeg/ffmpeg` and `@ffmpeg/core` (`/ffmpeg/ffmpeg-core.js` + `ffmpeg-core.wasm`) to trim the selected start time and duration (`10–60 sec`) into a new `.mp4` (`libx264` + `aac`) file.
  - Burns **`Credit: @StreamerName`** on top when **Permission Clip** is ON, burns **Auto-Caption** with a black background on the bottom when enabled, displays a live **0%–100% progress bar**, and saves the `.mp4` clip into **My Clips**.

### C. Add Voice & Add Music
- **Add Voice**: Live microphone recording (`MediaRecorder` + real-time `<canvas>` waveform via `AnalyserNode`) or audio file upload, independent **Voiceover Volume** and **Original Video Audio** sliders, and attachment to any saved clip.
- **Add Music**: Four built-in **CC0 Copyright-Safe** WAV tracks synthesized cleanly in-browser (**Lo-Fi Studio Beat**, **Night Drive Synth**, **Acoustic Stream Warmth**, **Tournament Hype Loop**) with live preview, custom audio upload with Copyright-Safe license confirmation, and mix sliders.

### D. My Clips Gallery
- Persistent **IndexedDB** (`clipkaro_studio_db`) storage retaining actual `.mp4`/`.webm` video blobs, thumbnails, permission proof blobs, voiceover blobs, and music blobs across sessions.
- Search by title/`@streamer`/game and filter by **All**, **Permission Verified**, **With Voice**, or **With Music**.
- **Play**: Opens the Clip Player modal playing the actual video file synced with attached voice and music audio tracks, displaying `Credit: @StreamerName`, black-background Auto-Caption, permission proof preview, Original Video Link, and `.mp4`/`.webm` **Download File**.
- **Delete**: Opens an explicit **Delete this clip?** confirmation modal before permanently removing the clip from IndexedDB.

### E. My Games & In-Game Floating CLIP Button
- **My Games Library**:
  - Built-in English game list with dedicated icons and **Open Game** action: **BGMI** (`com.pubg.imobile`), **Free Fire MAX** (`com.dts.freefiremax`), **GTA V** (`com.rockstargames.gtav`), **Minecraft** (`com.mojang.minecraftpe`), **Valorant** (`com.riotgames.valorant`), **Call of Duty Mobile** (`com.activision.callofduty.shooter`), and **Custom Game** (plus ability to add/remove custom games and play the **Clip Timing Mini-Game**).
  - **Launch Game**: Uses Android App Intent (`intent:#Intent;action=android.intent.action.MAIN;category=android.intent.category.LAUNCHER;package=...;S.browser_fallback_url=...;end`) or the native `window.Android.launchApp` bridge to open the installed game directly and fall back to its Google Play Store page if not installed. In web preview, shows `"Install ClipKaro APK to launch game directly, preview cannot open game app"` while keeping the floating **CLIP** button visible.
- **Draggable In-Game Floating CLIP Button**:
  - Pointer/touch-draggable circular **CLIP** button clamped to viewport boundaries.
  - Tap menu in English: **Clip 10 sec**, **Clip 20 sec**, **Clip 30 sec**, **Clip 40 sec**, **Clip 50 sec**, **Clip 60 sec**, **Record Full Gameplay**, and **Stop**.
  - Records HD video (`4 Mbps` WebM) mixing in-game/display sound and microphone game chat (with a 1280×720 HD demo stream fallback in web preview), saving directly to **My Clips**.

---

## 2. System Architecture

```text
┌───────────────────────────────────────────────────────────────────────────┐
│                          ClipKaro Studio (App.tsx)                        │
│  ┌──────────┐  ┌───────────┐  ┌───────────┐  ┌───────────┐  ┌──────────┐  │
│  │ HomeView │  │ CutVideo  │  │ AddVoice  │  │ AddMusic  │  │ MyClips  │  │
│  │ (Viewer) │  │ (FFmpeg)  │  │ (Mic/WAV) │  │ (CC0 WAV) │  │ (Player) │  │
│  └────┬─────┘  └─────┬─────┘  └─────┬─────┘  └─────┬─────┘  └────┬─────┘  │
│       │              │              │              │             │        │
│       │        ┌─────▼──────────────▼──────────────▼─────────────▼─────┐  │
│       │        │          IndexedDB Media Store (mediaStorage.ts)      │  │
│       │        │  clips (videoBlob, voiceBlob, musicBlob, proofBlob)   │  │
│       │        └───────────────────────────────────────────────────────┘  │
│  ┌────▼──────────────┐       ┌─────────────────────────────────────────┐  │
│  │    MyGamesView    │──────▶│      InGameFloatingButton (CLIP)        │  │
│  │ (Intent Launcher) │       │  HD Capture (Game Audio + Chat) -> DB   │  │
│  └───────────────────┘       └─────────────────────────────────────────┘  │
└────────────────────────────────────┬──────────────────────────────────────┘
                                     │
                 ┌───────────────────▼───────────────────┐
                 │  Android APK Bridge (MainActivity.java)│
                 │  - Package Launcher & Play Store URI   │
                 │  - RECORD_AUDIO / MEDIA_PROJECTION     │
                 │  - SYSTEM_ALERT_WINDOW / Storage       │
                 └───────────────────────────────────────┘
```

---

## 3. Complete Project Files List

### Root & Web Configuration
- `index.html` — HTML entry point, SEO/OpenGraph metadata, Google Fonts (`Plus Jakarta Sans`, `DM Sans`, `JetBrains Mono`).
- `metadata.json` — App manifest (`name: "ClipKaro"`, microphone frame permission).
- `package.json` — Scripts (`dev`, `build`, `preview`, `lint`) and dependencies (`react`, `@ffmpeg/ffmpeg`, `@ffmpeg/util`, `@ffmpeg/core`, `lucide-react`, `tailwindcss`).
- `tsconfig.json` — TypeScript compiler configuration (`ES2022`, `react-jsx`, strict module resolution).
- `vite.config.ts` — Vite bundler config with `@tailwindcss/vite`, asset copying, and `optimizeDeps.exclude` for `@ffmpeg/ffmpeg` and `@ffmpeg/util`.
- `capacitor.config.json` — Capacitor/Android wrapper configuration (`appId: "com.clipkaro.app"`, `webDir: "dist"`).
- `.env.example` — Environment template (`GEMINI_API_KEY`, `APP_URL`).
- `.gitignore` — Git ignore patterns.

### Web Application Source (`src/` & `public/`)
- `src/main.tsx` — React 19 root mount.
- `src/index.css` — Tailwind CSS v4 import, studio palette variables, `tabular-nums`, and reduced-motion rules.
- `src/App.tsx` — Root workspace navigation, IndexedDB hydration, Copyright-Safe state, and Floating CLIP button host.
- `src/types/clipkaro.ts` — TypeScript interfaces (`ClipItem`, `PermissionInfo`, `GameItem`, `RoyaltyFreeTrack`, `CLIP_LENGTH_OPTIONS`).
- `src/components/TopNav.tsx` — 3-zone top navigation bar (`ClipKaro`, 5 nav links, `New Clip` action, compact mobile nav).
- `src/components/HomeView.tsx` — Quick Actions grid and YouTube/Instagram/Facebook Open Inside viewer.
- `src/components/CutVideoView.tsx` — **My Gallery** button, **Permission Clip** top section, `10–60 sec` duration chips, video + audio preview, **Auto-Caption (Black Background)**, FFmpeg progress bar, and MP4 export.
- `src/components/AddVoiceView.tsx` — Live microphone recorder with waveform canvas, audio file upload, and volume mixer.
- `src/components/AddMusicView.tsx` — Built-in CC0 WAV track library, custom audio upload, Copyright-Safe confirmation, and volume mixer.
- `src/components/MyClipsView.tsx` — Persistent clip gallery, search/filters, actual file **Play** modal with synced audio and Auto-Caption bar, `.mp4`/`.webm` download, and **Delete** confirmation dialog.
- `src/components/MyGamesView.tsx` — Real games grid (`BGMI`, `Free Fire MAX`, `GTA V`, `Minecraft`, `Valorant`, `Call of Duty Mobile`, `Custom Game`), Android intent **Launch Game** modal, and **Clip Timing Mini-Game**.
- `src/components/InGameFloatingButton.tsx` — Draggable **CLIP** floating button, `10–60 sec` + **Record Full Gameplay** + **Stop** menu, HD game sound + chat mixer, and My Clips save.
- `src/utils/embedUrl.ts` — YouTube, Instagram, and Facebook URL parser and `@StreamerName` credit formatter.
- `src/utils/ffmpegCutter.ts` — Lazy-loaded FFmpeg WASM trimmer, MP4 H.264/AAC encoder, top credit overlay, and black-background Auto-Caption burn-in.
- `src/utils/mediaGenerators.ts` — Procedural CC0 WAV music synthesizer, thumbnail extractor, and HD gameplay sample stream generator.
- `src/utils/mediaStorage.ts` — IndexedDB persistence (`clipkaro_studio_db`) and default games/packages list.
- `src/assets/images/game_tactical_arena_1795269900712.jpg` — Tactical arena game artwork.
- `src/assets/images/game_voxel_valley_1795269899720.jpg` — Voxel sandbox game artwork.
- `src/assets/images/game_coastal_highway_1795269900686.jpg` — Coastal highway game artwork.
- `src/assets/images/game_stadium_floodlights_1795269900819.jpg` — Stadium sports game artwork.
- `public/ffmpeg/ffmpeg-core.js` — Local FFmpeg WASM loader script.
- `public/ffmpeg/ffmpeg-core.wasm` — Local FFmpeg WebAssembly binary.

### Android Play Store Project (`android/`)
- `android/settings.gradle` — Root Gradle module registration (`ClipKaro`, `:app`).
- `android/build.gradle` — Android Gradle Plugin `8.7.2` configuration.
- `android/gradle.properties` — AndroidX and JVM build settings.
- `android/app/build.gradle` — App module (`com.clipkaro.app`, `minSdk 24`, `targetSdk 35`, `compileSdk 35`, release minification).
- `android/app/proguard-rules.pro` — ProGuard rules preserving `@JavascriptInterface` bridge methods.
- `android/app/src/main/AndroidManifest.xml` — Play Store permissions (`RECORD_AUDIO`, `MODIFY_AUDIO_SETTINGS`, `FOREGROUND_SERVICE`, `FOREGROUND_SERVICE_MEDIA_PROJECTION`, `FOREGROUND_SERVICE_MICROPHONE`, `SYSTEM_ALERT_WINDOW`, `READ_MEDIA_VIDEO`, `READ_MEDIA_AUDIO`, `READ_MEDIA_IMAGES`, `READ_EXTERNAL_STORAGE`, `WRITE_EXTERNAL_STORAGE`, `INTERNET`) and `<queries>` for installed game packages.
- `android/app/src/main/java/com/clipkaro/app/MainActivity.java` — WebView host, gallery file chooser, runtime permission requests, overlay permission bridge, and `launchApp(packageName, playStoreUrl)` native launcher.
- `android/app/src/main/res/values/strings.xml` — App display name (`ClipKaro`).
- `android/app/src/main/res/values/styles.xml` — Dark studio splash/status bar theme (`#0B0E14`).

---

## 4. Build & Deployment Steps

### Step 1: Web Development & Verification
1. Install dependencies:
   ```bash
   npm install
   ```
2. Start the development server on port `3000`:
   ```bash
   npm run dev
   ```
3. Run TypeScript static verification:
   ```bash
   npm run lint
   ```
4. Build the production web bundle (`dist/`):
   ```bash
   npm run build
   ```
   Verify `dist/index.html`, `dist/ffmpeg/ffmpeg-core.js`, `dist/ffmpeg/ffmpeg-core.wasm`, and `dist/src/assets/images/` are present.

### Step 2: Android APK & Google Play Store Bundle (AAB)
1. Ensure the production web build is fresh:
   ```bash
   npm run build
   ```
2. Copy the compiled `dist/` bundle into the Android WebView assets folder:
   ```bash
   mkdir -p android/app/src/main/assets/public
   cp -r dist/* android/app/src/main/assets/public/
   ```
3. Open the `android/` directory in **Android Studio** (or build via Gradle wrapper):
   - **Debug APK (direct device testing)**:
     ```bash
     cd android && ./gradlew assembleDebug
     ```
     Output: `android/app/build/outputs/apk/debug/app-debug.apk`
   - **Signed Play Store Release Bundle (`.aab`)**:
     In Android Studio, go to **Build > Generate Signed Bundle / APK**, choose **Android App Bundle**, select your upload keystore, and build `release` (`android/app/build/outputs/bundle/release/app-release.aab`).
4. Before Play Store submission, declare the use of **MediaProjection** (screen recording), **Microphone** (voiceover & game chat), **Display Over Other Apps** (in-game floating **CLIP** button), and **Photo/Video Picker** in the Google Play Console App Content declarations.

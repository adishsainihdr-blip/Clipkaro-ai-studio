-keepclassmembers class com.clipkaro.app.MainActivity$ClipKaroAndroidBridge {
    @android.webkit.JavascriptInterface <methods>;
}

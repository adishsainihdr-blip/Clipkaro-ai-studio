var e=Object.assign({"/BUILD_APK_ON_MOBILE.md":"# Build ClipKaro APK on Mobile (No Laptop Required)\n\nYou can compile `ClipKaro` into an installable Android `.apk` using only your smartphone in two ways:\n\n---\n\n## Method 1: Cloud Build via GitHub Browser (Easiest, Recommended)\n\nThis uses the included `.github/workflows/build-android-apk.yml` file to compile the APK on GitHub's cloud servers for free in ~2 minutes.\n\n1. **Download & extract the project code on your phone**:\n   - Tap **Download React + Android Code** inside ClipKaro to open the Project Files exporter.\n   - Tap **Download Source + Android ZIP (Recommended)** to get `ClipKaro-React-Android-Source.zip` (~3.8 MB, fast on mobile — `npm install` auto-installs FFmpeg WASM), OR download `ClipKaro-complete-code.zip` if you want the offline FFmpeg WASM already bundled. You can also download or copy any React/Android file individually inside the exporter.\n   - Open your phone's **Files** app (or **ZArchiver**) and extract the ZIP into a folder named `ClipKaro`.\n2. **Create a GitHub repository in your mobile browser**:\n   - Open Chrome on your phone and go to `https://github.com/new`.\n   - Name the repository `ClipKaro`, keep it Public or Private, and tap **Create repository**.\n3. **Upload the extracted files**:\n   - On the empty repository page, tap **uploading an existing file**.\n   - Select the files and folders from your extracted `ClipKaro` folder (including `.github`, `android`, `scripts`, `public`, `src`, `package.json`, `index.html`, `vite.config.ts`, `tsconfig.json`, `capacitor.config.json`, `metadata.json`).\n   - Tap **Commit changes**.\n4. **Run the APK build**:\n   - Tap the **Actions** tab at the top of your GitHub repository.\n   - Tap **Build ClipKaro Android APK** -> **Run workflow** (if it hasn't started automatically on push).\n5. **Download & Install the APK**:\n   - Once the workflow turns green (~2 minutes), scroll down to **Artifacts** and tap **ClipKaro-Debug-APK** to download the ZIP containing `app-debug.apk`.\n   - Unzip it on your phone, tap `app-debug.apk`, allow **Install unknown apps** if prompted, and install **ClipKaro**.\n\n---\n\n## Method 2: Offline On-Device Build with Termux (Android)\n\nIf you want to build the APK directly on your Android phone offline:\n\n1. Install **Termux** (from F-Droid) on your Android device.\n2. Run these commands inside Termux:\n   ```bash\n   pkg update && pkg upgrade -y\n   pkg install -y nodejs-lts openjdk-17 gradle unzip wget\n   ```\n3. Copy or extract `ClipKaro-complete-code.zip` into `~/ClipKaro`:\n   ```bash\n   mkdir -p ~/ClipKaro\n   cd ~/ClipKaro\n   unzip /sdcard/Download/ClipKaro-complete-code.zip -d .\n   ```\n4. Build the web bundle and sync it to Android assets:\n   ```bash\n   npm install\n   npm run build\n   mkdir -p android/app/src/main/assets/public\n   cp -r dist/* android/app/src/main/assets/public/\n   ```\n5. Install Android SDK Command-Line Tools (`platform-tools`, `platforms;android-35`, `build-tools;35.0.0`) via `sdkmanager`, set `ANDROID_HOME`, then compile the APK:\n   ```bash\n   cd ~/ClipKaro/android\n   gradle assembleDebug\n   ```\n6. Copy the built APK to your Downloads folder and tap it to install:\n   ```bash\n   cp app/build/outputs/apk/debug/app-debug.apk /sdcard/Download/ClipKaro.apk\n   ```\n\n---\n\n## Permissions Included in `AndroidManifest.xml`\n- **Record Audio**: `RECORD_AUDIO`, `MODIFY_AUDIO_SETTINGS`, `FOREGROUND_SERVICE_MICROPHONE`\n- **Record Screen**: `FOREGROUND_SERVICE`, `FOREGROUND_SERVICE_MEDIA_PROJECTION`\n- **Display Over Other Apps**: `SYSTEM_ALERT_WINDOW`\n- **Storage**: `READ_MEDIA_VIDEO`, `READ_MEDIA_AUDIO`, `READ_MEDIA_IMAGES`, `READ_EXTERNAL_STORAGE`, `WRITE_EXTERNAL_STORAGE`\n- **Installed Game Launching**: Package `<queries>` for `com.pubg.imobile` (BGMI), `com.dts.freefiremax` (Free Fire MAX), `com.rockstargames.gtav` (GTA V), `com.mojang.minecraftpe` (Minecraft), `com.riotgames.valorant` (Valorant), and `com.activision.callofduty.shooter` (Call of Duty Mobile).\n","/android/app/build.gradle":`plugins {
    id 'com.android.application'
}

android {
    namespace "com.clipkaro.app"
    compileSdk 35

    defaultConfig {
        applicationId "com.clipkaro.app"
        minSdk 24
        targetSdk 35
        versionCode 1
        versionName "1.0.0"
    }

    buildTypes {
        release {
            minifyEnabled true
            shrinkResources true
            proguardFiles getDefaultProguardFile('proguard-android-optimize.txt'), 'proguard-rules.pro'
        }
        debug {
            minifyEnabled false
        }
    }

    compileOptions {
        sourceCompatibility JavaVersion.VERSION_17
        targetCompatibility JavaVersion.VERSION_17
    }
}

dependencies {
    implementation 'androidx.appcompat:appcompat:1.7.0'
    implementation 'androidx.activity:activity:1.9.3'
    implementation 'androidx.webkit:webkit:1.12.1'
}
`,"/android/app/proguard-rules.pro":`-keepclassmembers class com.clipkaro.app.MainActivity$ClipKaroAndroidBridge {
    @android.webkit.JavascriptInterface <methods>;
}
`,"/android/app/src/main/AndroidManifest.xml":`<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:tools="http://schemas.android.com/tools">

    <!-- Network access for YouTube, Instagram, Facebook viewer and Play Store fallback -->
    <uses-permission android:name="android.permission.INTERNET" />

    <!-- Record Audio & Facecam (Voiceover, Voice Changer & Front Camera Overlay) -->
    <uses-permission android:name="android.permission.RECORD_AUDIO" />
    <uses-permission android:name="android.permission.MODIFY_AUDIO_SETTINGS" />
    <uses-permission android:name="android.permission.CAMERA" />
    <uses-feature android:name="android.hardware.camera.any" android:required="false" />

    <!-- Record Screen (MediaProjection, Camera, Microphone & Special-Use Foreground Service) -->
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE" />
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE_MEDIA_PROJECTION" />
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE_MICROPHONE" />
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE_CAMERA" />
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE_SPECIAL_USE" />
    <uses-permission android:name="android.permission.POST_NOTIFICATIONS" />

    <!-- Display Over Other Apps, Background Keep-Alive & Foreground App Auto-Hide Monitor -->
    <uses-permission android:name="android.permission.SYSTEM_ALERT_WINDOW" />
    <uses-permission android:name="android.permission.REQUEST_IGNORE_BATTERY_OPTIMIZATIONS" />
    <uses-permission android:name="android.permission.REORDER_TASKS" />
    <uses-permission
        android:name="android.permission.PACKAGE_USAGE_STATS"
        tools:ignore="ProtectedPermissions" />

    <!-- Storage (Scoped Media for Android 13+ & Legacy External Storage for Android 12 and below) -->
    <uses-permission android:name="android.permission.READ_MEDIA_VIDEO" />
    <uses-permission android:name="android.permission.READ_MEDIA_AUDIO" />
    <uses-permission android:name="android.permission.READ_MEDIA_IMAGES" />
    <uses-permission
        android:name="android.permission.READ_EXTERNAL_STORAGE"
        android:maxSdkVersion="32" />
    <uses-permission
        android:name="android.permission.WRITE_EXTERNAL_STORAGE"
        android:maxSdkVersion="29" />

    <!-- Android 11+ Package Visibility to launch installed games directly -->
    <queries>
        <package android:name="com.pubg.imobile" />
        <package android:name="com.dts.freefiremax" />
        <package android:name="com.rockstargames.gtav" />
        <package android:name="com.mojang.minecraftpe" />
        <package android:name="com.riotgames.valorant" />
        <package android:name="com.activision.callofduty.shooter" />
        <package android:name="com.google.android.youtube" />
        <package android:name="com.instagram.android" />
        <package android:name="com.facebook.katana" />
        <package android:name="com.whatsapp" />
        <intent>
            <action android:name="android.intent.action.MAIN" />
            <category android:name="android.intent.category.LAUNCHER" />
        </intent>
    </queries>

    <application
        android:allowBackup="true"
        android:hardwareAccelerated="true"
        android:icon="@mipmap/ic_launcher"
        android:label="@string/app_name"
        android:roundIcon="@mipmap/ic_launcher_round"
        android:supportsRtl="true"
        android:theme="@style/AppTheme"
        android:usesCleartextTraffic="false">

        <activity
            android:name=".MainActivity"
            android:configChanges="orientation|keyboardHidden|keyboard|screenSize|locale|smallestScreenSize|screenLayout|uiMode"
            android:exported="true"
            android:launchMode="singleTask">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>

        <service
            android:name=".FloatingClipService"
            android:enabled="true"
            android:exported="false"
            android:foregroundServiceType="specialUse|mediaProjection|microphone|camera">
            <property
                android:name="android.app.PROPERTY_SPECIAL_USE_FGS_SUBTYPE"
                android:value="Floating clip overlay bubble for instant BGMI and gameplay clipping" />
        </service>

        <provider
            android:name="androidx.core.content.FileProvider"
            android:authorities="\${applicationId}.fileprovider"
            android:exported="false"
            android:grantUriPermissions="true">
            <meta-data
                android:name="android.support.FILE_PROVIDER_PATHS"
                android:resource="@xml/file_paths" />
        </provider>

    </application>
</manifest>
`,"/android/app/src/main/java/com/clipkaro/app/FloatingClipService.java":`package com.clipkaro.app;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.app.usage.UsageEvents;
import android.app.usage.UsageStatsManager;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ServiceInfo;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Outline;
import android.graphics.PixelFormat;
import android.graphics.SurfaceTexture;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.hardware.camera2.CameraCaptureSession;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraDevice;
import android.hardware.camera2.CameraManager;
import android.hardware.camera2.CaptureRequest;
import android.hardware.camera2.params.StreamConfigurationMap;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioPlaybackCaptureConfiguration;
import android.media.AudioRecord;
import android.media.MediaCodec;
import android.media.MediaCodecInfo;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.media.MediaMuxer;
import android.media.MediaRecorder;
import android.media.MediaScannerConnection;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.Looper;
import android.provider.MediaStore;
import android.util.DisplayMetrics;
import android.util.Size;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.HapticFeedbackConstants;
import android.view.MotionEvent;
import android.view.Surface;
import android.view.TextureView;
import android.view.View;
import android.view.ViewOutlineProvider;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;
import androidx.core.content.ContextCompat;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

public class FloatingClipService extends Service {

    public static volatile boolean isServiceRunning = false;

    public static final String ACTION_START = "com.clipkaro.app.action.START_FLOATING";
    public static final String ACTION_PREPARE_PROJECTION = "com.clipkaro.app.action.PREPARE_PROJECTION";
    public static final String ACTION_HIDE_BUBBLE = "com.clipkaro.app.action.HIDE_BUBBLE";
    public static final String ACTION_CLIPKARO_RESUMED = "com.clipkaro.app.action.CLIPKARO_RESUMED";
    public static final String ACTION_CLIPKARO_BACKGROUND = "com.clipkaro.app.action.CLIPKARO_BACKGROUND";
    public static final String ACTION_STOP = "com.clipkaro.app.action.STOP_FLOATING";
    public static final String ACTION_QUICK_CLIP_10 = "com.clipkaro.app.action.QUICK_CLIP_10";
    public static final String ACTION_QUICK_CLIP_30 = "com.clipkaro.app.action.QUICK_CLIP_30";
    public static final String ACTION_TOGGLE_FULL = "com.clipkaro.app.action.TOGGLE_FULL";
    public static final String ACTION_STOP_RECORDING = "com.clipkaro.app.action.STOP_RECORDING";
    public static final String ACTION_PAUSE_RECORDING = "com.clipkaro.app.action.PAUSE_RECORDING";
    public static final String ACTION_RESUME_RECORDING = "com.clipkaro.app.action.RESUME_RECORDING";
    public static final String ACTION_SET_OPTIONS = "com.clipkaro.app.action.SET_OPTIONS";
    public static final String ACTION_SAVE_REACTION_CLIP = "com.clipkaro.app.action.SAVE_REACTION_CLIP";
    public static final String ACTION_NATIVE_CLIP_SAVED = "com.clipkaro.app.NATIVE_CLIP_SAVED";

    public static final String EXTRA_RESULT_CODE = "result_code";
    public static final String EXTRA_RESULT_DATA = "result_data";
    public static final String EXTRA_GAME_NAME = "game_name";
    public static final String EXTRA_TARGET_PACKAGE = "target_package";
    public static final String EXTRA_PENDING_DURATION = "pending_duration";
    public static final String EXTRA_PENDING_FULL = "pending_full";
    public static final String EXTRA_REACTION_MODE = "reaction_mode";
    public static final String EXTRA_FACECAM_ENABLED = "facecam_enabled";
    public static final String EXTRA_VOICE_EFFECT = "voice_effect";
    public static final String EXTRA_SAVED_FILE_NAME = "saved_file_name";
    public static final String EXTRA_SAVED_URI = "saved_uri";

    // Per-app MediaProjection cache (asked ONLY on recording start per target app, reused until phone restart)
    public static class PerAppProjectionEntry {
        public final int resultCode;
        public final Intent resultData;
        @Nullable
        public MediaProjection mediaProjection;

        public PerAppProjectionEntry(int resultCode, Intent resultData) {
            this.resultCode = resultCode;
            this.resultData = resultData;
        }
    }

    private static final ConcurrentHashMap<String, PerAppProjectionEntry> perAppProjectionMap =
        new ConcurrentHashMap<>();

    public static String resolveAppKey(@Nullable String pkg, @Nullable String gameName) {
        if (pkg != null && !pkg.trim().isEmpty()) {
            return pkg.trim().toLowerCase(Locale.US);
        }
        if (gameName != null && !gameName.trim().isEmpty()) {
            return "app:" + gameName.trim().toLowerCase(Locale.US);
        }
        return "default";
    }

    public static boolean hasCachedProjectionForApp(@Nullable String appKey) {
        if (appKey == null || appKey.isEmpty()) return false;
        PerAppProjectionEntry entry = perAppProjectionMap.get(appKey);
        if (entry == null) return false;
        return entry.mediaProjection != null
            || (entry.resultCode == Activity.RESULT_OK && entry.resultData != null);
    }

    public static void cacheProjectionForApp(
        @Nullable String appKey,
        int resultCode,
        @Nullable Intent data
    ) {
        if (appKey == null || appKey.isEmpty()) return;
        if (resultCode == Activity.RESULT_OK && data != null) {
            PerAppProjectionEntry existing = perAppProjectionMap.get(appKey);
            if (existing != null && existing.mediaProjection != null) {
                try {
                    existing.mediaProjection.stop();
                } catch (Exception ignored) {
                }
            }
            perAppProjectionMap.put(
                appKey,
                new PerAppProjectionEntry(resultCode, (Intent) data.clone())
            );
        }
    }

    @Nullable
    public static PerAppProjectionEntry getCachedProjectionForApp(@Nullable String appKey) {
        return appKey != null ? perAppProjectionMap.get(appKey) : null;
    }

    public static final String AUDIO_MODE_GAME = "game";
    public static final String AUDIO_MODE_MIC = "mic";
    public static final String AUDIO_MODE_BOTH = "both";

    public static final String VOICE_NORMAL = "normal";
    public static final String VOICE_FUNNY = "funny";
    public static final String VOICE_ROBOT = "robot";
    public static final String VOICE_DEEP = "deep";

    public static String normalizeVoiceEffect(@Nullable String effect) {
        if (VOICE_FUNNY.equalsIgnoreCase(effect)) return VOICE_FUNNY;
        if (VOICE_ROBOT.equalsIgnoreCase(effect)) return VOICE_ROBOT;
        if (VOICE_DEEP.equalsIgnoreCase(effect)) return VOICE_DEEP;
        return VOICE_NORMAL;
    }

    private static final String PREFS_NAME = "clipkaro_prefs";
    private static final String KEY_AUDIO_MODE = "floating_audio_mode";
    private static final String KEY_AUTO_CONTINUOUS = "floating_auto_continuous";
    private static final String KEY_AUTO_HIGHLIGHT = "floating_auto_highlight";
    public static final String KEY_REACTION_MODE = "floating_reaction_mode";
    public static final String KEY_FACECAM_ENABLED = "floating_facecam_enabled";
    private static final String KEY_FACECAM_MANUAL_OFF = "floating_facecam_manual_off";
    public static final String KEY_VOICE_EFFECT = "floating_voice_effect";

    private static final String CHANNEL_ID = "clipkaro_floating_channel";
    private static final String ALERT_CHANNEL_ID = "clipkaro_status_alerts";
    private static final int NOTIFICATION_ID = 7001;
    private static final int STATUS_NOTIFICATION_ID = 7002;

    private static final int HIGHLIGHT_SEGMENT_DURATION_MS = 5000;
    private static final int MAX_HIGHLIGHT_SEGMENTS = 4;
    private static final long HIGHLIGHT_COOLDOWN_MS = 18_000L;
    private static final int VIDEO_BITRATE = 4_000_000;
    private static final int VIDEO_FPS = 30;
    private static final int AUDIO_SAMPLE_RATE = 44100;
    private static final int AUDIO_BITRATE = 128_000;

    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final ExecutorService exportExecutor = Executors.newSingleThreadExecutor();
    private final Object muxerLock = new Object();

    private WindowManager windowManager;
    private FrameLayout bubbleView;
    private LinearLayout bubbleIdleBox;
    private LinearLayout bubbleRecordingBox;
    private View bubbleRedDot;
    private TextView bubbleTimerTv;

    private FrameLayout menuView;
    private LinearLayout idleMenuContainer;
    private LinearLayout recordingMenuContainer;
    private WindowManager.LayoutParams bubbleParams;
    private WindowManager.LayoutParams menuParams;
    private boolean isMenuVisible = false;

    // 500ms Long-press popup menu (Hide Button / Stop Recording + Hide / Stop)
    private LinearLayout longPressMenuView;
    private WindowManager.LayoutParams longPressMenuParams;
    private boolean isLongPressMenuVisible = false;

    // Target foreground app monitoring (> 3 seconds auto-hide / auto-stop)
    private String targetPackageName = "";
    private boolean bubbleSuppressed = true;
    private volatile boolean awaitingProjectionPrompt = false;
    private long targetLaunchGraceUntilMs = 0L;
    private long outOfTargetSinceMs = 0L;
    private String lastKnownForegroundPackage = null;

    private TextView recMenuTimerTv;
    private View recMenuRedDot;
    private TextView recMenuSubTv;
    private Button pauseRecBtn;
    private Button resumeRecBtn;
    private Button saveReactionRecBtn;
    private Button recFacecamToggleBtn;
    private Button stopRecBigBtn;
    private Button idleStopBtn;
    private Button audioCycleBtn;
    private Button autoContinuousBtn;
    private Button autoHighlightBtn;
    private Button facecamToggleBtn;
    private Button voiceEffectBtn;
    private Button reactionToggleBtn;

    // Draggable, resizable 120dp circular Facecam Overlay + Camera2 pipeline
    private LinearLayout facecamRootView;
    private FrameLayout facecamCircleFrame;
    private TextureView facecamTextureView;
    private View facecamRedDot;
    private TextView facecamPausedTv;
    private Button facecamSaveClipBtn;
    private WindowManager.LayoutParams facecamParams;
    private int facecamSizeDp = 120;
    private boolean facecamPausedState = false;
    private CameraDevice cameraDevice;
    private CameraCaptureSession cameraCaptureSession;
    private HandlerThread cameraBgThread;
    private Handler cameraBgHandler;
    private Size cameraPreviewSize = new Size(640, 480);

    // Top 2-second notification popup overlay
    private LinearLayout topBannerView;
    private View topBannerDot;
    private TextView topBannerTitleTv;
    private TextView topBannerSubTv;
    private final Runnable hideTopBannerRunnable = this::hideTopNotificationPopup;

    private String activeGameName = "BGMI";
    private String capturingForAppKey = "";
    private String selectedAudioMode = AUDIO_MODE_BOTH;
    private boolean autoContinuousEnabled = true;
    private boolean autoHighlightEnabled = true;
    private boolean facecamEnabled = false;
    private boolean facecamManualOff = false;
    private boolean reactionModeEnabled = false;
    private String selectedVoiceEffect = VOICE_NORMAL;
    private double voiceRobotPhaseRad = 0.0;
    private float voiceDeepLpState = 0f;

    // MediaProjection & Encoding State
    private MediaProjection mediaProjection;
    private VirtualDisplay virtualDisplay;
    private Surface encoderSurface;
    private MediaCodec videoEncoder;
    private MediaCodec audioEncoder;
    private AudioRecord gameAudioRecord;
    private AudioRecord micAudioRecord;

    private final AtomicBoolean isCapturing = new AtomicBoolean(false);
    private final AtomicBoolean isRecordingTimed = new AtomicBoolean(false);
    private final AtomicBoolean isRecordingFull = new AtomicBoolean(false);
    private final AtomicBoolean isRecordingPaused = new AtomicBoolean(false);
    private final AtomicBoolean audioLoopRunning = new AtomicBoolean(false);

    private Thread videoThread;
    private Thread audioThread;

    private MediaFormat latestVideoFormat;
    private MediaFormat latestAudioFormat;

    // Pause timing & monotonic PTS tracking for Pause/Resume
    private long pauseStartedMs = 0L;
    private long totalPausedMs = 0L;
    private long lastRawVideoPtsUs = 0L;
    private long pausedVideoPtsOffsetUs = 0L;
    private boolean videoJustResumed = false;
    private long lastRawAudioPtsUs = 0L;
    private long pausedAudioPtsOffsetUs = 0L;
    private boolean audioJustResumed = false;

    // Active Timed Clip Recording (Continuous until STOP)
    private File timedTempFile;
    private MediaMuxer timedMuxer;
    private int timedVideoTrack = -1;
    private int timedAudioTrack = -1;
    private boolean timedMuxerStarted = false;
    private boolean timedWaitingForKeyframe = false;
    private int activeTimedDurationSec = 10;
    private int currentClipSequence = 1;
    private long timedStartMs = 0L;

    // Active Full Gameplay Continuous Recording
    private File fullTempFile;
    private MediaMuxer fullMuxer;
    private int fullVideoTrack = -1;
    private int fullAudioTrack = -1;
    private boolean fullMuxerStarted = false;
    private boolean fullWaitingForKeyframe = false;
    private long fullStartMs = 0L;

    // Auto Highlight Rolling 15s Ring + Kill / Headshot / Knock Spike State
    private File highlightBufferDir;
    private final List<File> completedHighlightSegments = new ArrayList<>();
    private File currentHighlightSegmentFile;
    private MediaMuxer highlightMuxer;
    private int hlVideoTrack = -1;
    private int hlAudioTrack = -1;
    private boolean hlMuxerStarted = false;
    private long currentHlSegmentStartUs = -1L;
    private int hlSegmentIndex = 0;
    private long captureStartedAtMs = 0L;
    private long lastAudioCombatPeakMs = 0L;
    private long lastAutoHighlightSavedMs = 0L;
    private double avgPFrameBytes = 14000.0;
    private int highlightSequence = 1;

    private int pendingDurationAfterProjection = 0;
    private boolean pendingFullAfterProjection = false;

    private long getCurrentActiveElapsedSec() {
        long now = isRecordingPaused.get() ? pauseStartedMs : System.currentTimeMillis();
        if (isRecordingTimed.get()) {
            return Math.max(0L, (now - timedStartMs - totalPausedMs) / 1000L);
        }
        if (isRecordingFull.get()) {
            return Math.max(0L, (now - fullStartMs - totalPausedMs) / 1000L);
        }
        return 0L;
    }

    private final Runnable uiTickerRunnable = new Runnable() {
        private boolean dotBright = true;

        @Override
        public void run() {
            if (!isRecordingTimed.get() && !isRecordingFull.get()) {
                updateBubbleVisuals(false, 0L, false);
                return;
            }

            if (isRecordingPaused.get()) {
                long pausedSec = getCurrentActiveElapsedSec();
                updateBubbleVisuals(true, pausedSec, true);
                updateExpandedRecordingTimer(pausedSec, true);
                updateNotificationOnly();
                mainHandler.postDelayed(this, 500);
                return;
            }

            long elapsedSec = getCurrentActiveElapsedSec();
            if (isRecordingTimed.get() && elapsedSec >= activeTimedDurationSec) {
                onTimedClipDurationReached();
                elapsedSec = 0L;
            }

            dotBright = !dotBright;
            updateBubbleVisuals(true, elapsedSec, dotBright);
            updateExpandedRecordingTimer(elapsedSec, dotBright);
            updateNotificationOnly();
            if (isMenuVisible) {
                updateMenuStatusText();
            }
            mainHandler.postDelayed(this, 500);
        }
    };

    private final Runnable foregroundMonitorRunnable = new Runnable() {
        @Override
        public void run() {
            if (bubbleSuppressed || bubbleView == null) {
                return;
            }
            checkTargetForegroundState();
            if (!bubbleSuppressed && bubbleView != null) {
                mainHandler.postDelayed(this, 1000L);
            }
        }
    };

    @Override
    public void onCreate() {
        super.onCreate();
        isServiceRunning = true;
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        selectedAudioMode = prefs.getString(KEY_AUDIO_MODE, AUDIO_MODE_BOTH);
        autoContinuousEnabled = prefs.getBoolean(KEY_AUTO_CONTINUOUS, true);
        autoHighlightEnabled = prefs.getBoolean(KEY_AUTO_HIGHLIGHT, true);
        reactionModeEnabled = prefs.getBoolean(KEY_REACTION_MODE, false);
        facecamEnabled = prefs.getBoolean(KEY_FACECAM_ENABLED, false);
        facecamManualOff = prefs.getBoolean(KEY_FACECAM_MANUAL_OFF, false);
        selectedVoiceEffect = normalizeVoiceEffect(prefs.getString(KEY_VOICE_EFFECT, VOICE_NORMAL));
        highlightBufferDir = new File(getCacheDir(), "clipkaro_hl_buffer");
        if (!highlightBufferDir.exists()) {
            //noinspection ResultOfMethodCallIgnored
            highlightBufferDir.mkdirs();
        }
        createNotificationChannel();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent != null ? intent.getAction() : ACTION_START;

        if (ACTION_STOP.equals(action)) {
            stopEverythingAndSelf();
            return START_NOT_STICKY;
        }

        if (ACTION_HIDE_BUBBLE.equals(action)) {
            hideFloatingBubbleOnly();
            return START_STICKY;
        }

        if (ACTION_CLIPKARO_BACKGROUND.equals(action)) {
            if (!bubbleSuppressed && targetPackageName != null && !targetPackageName.isEmpty()) {
                lastKnownForegroundPackage = targetPackageName;
                outOfTargetSinceMs = 0L;
                targetLaunchGraceUntilMs = System.currentTimeMillis() + 3000L;
            }
            return START_STICKY;
        }

        if (ACTION_CLIPKARO_RESUMED.equals(action)) {
            lastKnownForegroundPackage = getPackageName();
            return START_STICKY;
        }

        String incomingAppKey = resolveAppKey(targetPackageName, activeGameName);

        if (intent != null) {
            String game = intent.getStringExtra(EXTRA_GAME_NAME);
            if (game != null && !game.trim().isEmpty()) {
                activeGameName = game.trim();
            }
            String pkg = intent.getStringExtra(EXTRA_TARGET_PACKAGE);
            if (pkg != null && !pkg.trim().isEmpty()) {
                targetPackageName = pkg.trim();
            }
            incomingAppKey = resolveAppKey(targetPackageName, activeGameName);

            boolean prevReaction = reactionModeEnabled;
            boolean prevFacecam = facecamEnabled;
            if (intent.hasExtra(EXTRA_REACTION_MODE)) {
                reactionModeEnabled = intent.getBooleanExtra(EXTRA_REACTION_MODE, false);
            }
            if (intent.hasExtra(EXTRA_FACECAM_ENABLED)) {
                facecamEnabled = intent.getBooleanExtra(EXTRA_FACECAM_ENABLED, false);
            }
            if (intent.hasExtra(EXTRA_VOICE_EFFECT)) {
                selectedVoiceEffect = normalizeVoiceEffect(intent.getStringExtra(EXTRA_VOICE_EFFECT));
            }
            if (!prevReaction && reactionModeEnabled) {
                facecamEnabled = true;
                facecamManualOff = false;
                getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
                    .edit()
                    .putBoolean(KEY_FACECAM_MANUAL_OFF, false)
                    .apply();
            } else if (!prevFacecam && facecamEnabled) {
                facecamManualOff = false;
                getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
                    .edit()
                    .putBoolean(KEY_FACECAM_MANUAL_OFF, false)
                    .apply();
            } else if (intent.hasExtra(EXTRA_FACECAM_ENABLED) && !facecamEnabled && prevFacecam) {
                facecamManualOff = true;
                getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
                    .edit()
                    .putBoolean(KEY_FACECAM_MANUAL_OFF, true)
                    .apply();
            }

            if (intent.hasExtra(EXTRA_RESULT_CODE) && intent.hasExtra(EXTRA_RESULT_DATA)) {
                int code = intent.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED);
                Intent data = getParcelableIntentExtra(intent, EXTRA_RESULT_DATA);
                if (code == Activity.RESULT_OK && data != null) {
                    cacheProjectionForApp(incomingAppKey, code, data);
                }
            }
            if (intent.hasExtra(EXTRA_PENDING_DURATION)) {
                pendingDurationAfterProjection = intent.getIntExtra(EXTRA_PENDING_DURATION, 0);
            }
            if (intent.hasExtra(EXTRA_PENDING_FULL)) {
                pendingFullAfterProjection = intent.getBooleanExtra(EXTRA_PENDING_FULL, false);
            }
        }

        if (ACTION_SET_OPTIONS.equals(action)) {
            syncFacecamOverlayState();
            updateMenuStatusText();
            updateNotificationOnly();
            return START_STICKY;
        }

        if (ACTION_SAVE_REACTION_CLIP.equals(action)) {
            saveReactionSelectedPart();
            return START_STICKY;
        }

        boolean recordingActionPending = pendingFullAfterProjection
            || pendingDurationAfterProjection > 0
            || ACTION_QUICK_CLIP_10.equals(action)
            || ACTION_QUICK_CLIP_30.equals(action)
            || ACTION_TOGGLE_FULL.equals(action)
            || isRecordingTimed.get()
            || isRecordingFull.get();
        boolean hasProjForCurrentApp = hasCachedProjectionForApp(incomingAppKey);
        startForegroundWithType((recordingActionPending && hasProjForCurrentApp) || isCapturing.get());

        // Only show floating bubble when a target app is explicitly opened from ClipKaro (NO projection prompt here!)
        if (ACTION_START.equals(action)) {
            awaitingProjectionPrompt = false;
            if (targetPackageName == null || targetPackageName.isEmpty()) {
                bubbleSuppressed = true;
                hideFloatingBubbleOnly();
                updateNotificationOnly();
                return START_STICKY;
            }
            // If switching to a different app, release previous app's encoder/virtualDisplay while keeping per-app tokens intact
            if (isCapturing.get() && !incomingAppKey.equals(capturingForAppKey)) {
                stopCapturePipelineKeepProjection();
            }
            bubbleSuppressed = false;
            outOfTargetSinceMs = 0L;
            lastKnownForegroundPackage = targetPackageName;
            targetLaunchGraceUntilMs = System.currentTimeMillis() + 3500L;
            ensureOverlayBubbleShown();
            syncFacecamOverlayState();
            startForegroundMonitor();
        } else if (!bubbleSuppressed) {
            ensureOverlayBubbleShown();
            syncFacecamOverlayState();
            startForegroundMonitor();
        }

        if (ACTION_QUICK_CLIP_10.equals(action)) {
            onClipDurationTapped(10);
        } else if (ACTION_QUICK_CLIP_30.equals(action)) {
            onClipDurationTapped(30);
        } else if (ACTION_TOGGLE_FULL.equals(action)) {
            onToggleFullGameplay();
        } else if (ACTION_PAUSE_RECORDING.equals(action)) {
            pauseActiveRecording();
        } else if (ACTION_RESUME_RECORDING.equals(action)) {
            resumeActiveRecording();
        } else if (ACTION_STOP_RECORDING.equals(action)) {
            stopActiveRecordingOnly();
        } else if (pendingFullAfterProjection) {
            pendingFullAfterProjection = false;
            pendingDurationAfterProjection = 0;
            if ((!isCapturing.get() || !incomingAppKey.equals(capturingForAppKey)) && hasCachedProjectionForApp(incomingAppKey)) {
                startForegroundWithType(true);
                startCapturePipelineForApp(incomingAppKey);
            }
            if (isCapturing.get() && incomingAppKey.equals(capturingForAppKey)) {
                startFullGameplayRecording();
            }
        } else if (pendingDurationAfterProjection > 0) {
            int dur = pendingDurationAfterProjection;
            pendingDurationAfterProjection = 0;
            if ((!isCapturing.get() || !incomingAppKey.equals(capturingForAppKey)) && hasCachedProjectionForApp(incomingAppKey)) {
                startForegroundWithType(true);
                startCapturePipelineForApp(incomingAppKey);
            }
            if (isCapturing.get() && incomingAppKey.equals(capturingForAppKey)) {
                startTimedClipRecording(dur, true);
            }
        }

        updateMenuStatusText();
        return START_STICKY;
    }

    @SuppressWarnings("deprecation")
    private Intent getParcelableIntentExtra(Intent source, String key) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            return source.getParcelableExtra(key, Intent.class);
        }
        return source.getParcelableExtra(key);
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm == null) return;

            NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID,
                "ClipKaro Floating CLIP",
                NotificationManager.IMPORTANCE_LOW
            );
            channel.setDescription("Floating CLIP controls & notification recording options");
            nm.createNotificationChannel(channel);

            NotificationChannel alertChannel = new NotificationChannel(
                ALERT_CHANNEL_ID,
                "ClipKaro Recording Alerts",
                NotificationManager.IMPORTANCE_HIGH
            );
            alertChannel.setDescription("Alerts when clipping starts, pauses, resumes, or saves");
            nm.createNotificationChannel(alertChannel);
        }
    }

    private Notification buildServiceNotification() {
        Intent openIntent = new Intent(this, MainActivity.class);
        openIntent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
        int piFlags = PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE;
        PendingIntent contentIntent = PendingIntent.getActivity(this, 0, openIntent, piFlags);

        PendingIntent stopServicePending = PendingIntent.getService(
            this, 1, new Intent(this, FloatingClipService.class).setAction(ACTION_STOP), piFlags
        );
        PendingIntent clip10Pending = PendingIntent.getService(
            this, 2, new Intent(this, FloatingClipService.class).setAction(ACTION_QUICK_CLIP_10), piFlags
        );
        PendingIntent clip30Pending = PendingIntent.getService(
            this, 3, new Intent(this, FloatingClipService.class).setAction(ACTION_QUICK_CLIP_30), piFlags
        );
        PendingIntent fullPending = PendingIntent.getService(
            this, 4, new Intent(this, FloatingClipService.class).setAction(ACTION_TOGGLE_FULL), piFlags
        );
        PendingIntent stopRecPending = PendingIntent.getService(
            this, 5, new Intent(this, FloatingClipService.class).setAction(ACTION_STOP_RECORDING), piFlags
        );
        PendingIntent pausePending = PendingIntent.getService(
            this, 6, new Intent(this, FloatingClipService.class).setAction(ACTION_PAUSE_RECORDING), piFlags
        );
        PendingIntent resumePending = PendingIntent.getService(
            this, 7, new Intent(this, FloatingClipService.class).setAction(ACTION_RESUME_RECORDING), piFlags
        );

        boolean recordingNow = isRecordingTimed.get() || isRecordingFull.get();
        boolean pausedNow = isRecordingPaused.get();
        String title;
        String subtitle;
        if (isRecordingTimed.get()) {
            long sec = getCurrentActiveElapsedSec();
            title = pausedNow
                ? String.format(Locale.US, "Recording Paused (%02d:%02d · %d sec Clip)", sec / 60, sec % 60, activeTimedDurationSec)
                : String.format(Locale.US, "Clipping Started - %d sec Clip · %02d:%02d", activeTimedDurationSec, sec / 60, sec % 60);
            subtitle = "● " + activeTimedDurationSec + " sec Clip · Tap CLIP button to Stop (Clip #" + currentClipSequence + ")";
        } else if (isRecordingFull.get()) {
            long sec = getCurrentActiveElapsedSec();
            title = pausedNow
                ? String.format(Locale.US, "Recording Paused (%02d:%02d · Full Video)", sec / 60, sec % 60)
                : String.format(Locale.US, "Clipping Started - Full Video · %02d:%02d", sec / 60, sec % 60);
            subtitle = "● Full Video · Tap CLIP button to Stop";
        } else {
            title = "ClipKaro Floating CLIP Ready";
            subtitle = activeGameName + " · Audio: " + getAudioModeLabel() + " · Record from Notification or Bubble";
        }

        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(title)
            .setContentText(subtitle)
            .setSmallIcon(R.drawable.ic_clip_scissors)
            .setContentIntent(contentIntent)
            .setOnlyAlertOnce(true)
            .setOngoing(true);

        if (recordingNow) {
            if (pausedNow) {
                builder.addAction(0, "Resume", resumePending);
            } else {
                builder.addAction(0, "Pause", pausePending);
            }
            builder.addAction(0, "Stop", stopRecPending);
            builder.addAction(0, "Close", stopServicePending);
        } else {
            builder.addAction(0, "10s Clip", clip10Pending);
            builder.addAction(0, "30s Clip", clip30Pending);
            builder.addAction(0, "Full Record", fullPending);
        }

        return builder.build();
    }

    private void updateNotificationOnly() {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (nm != null) {
            nm.notify(NOTIFICATION_ID, buildServiceNotification());
        }
    }

    private void postStatusNotification(String title, String body, boolean withRedDot, boolean showTopPopup) {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (nm != null) {
            Intent openIntent = new Intent(this, MainActivity.class);
            openIntent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
            PendingIntent pi = PendingIntent.getActivity(
                this, 20, openIntent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
            );
            NotificationCompat.Builder b = new NotificationCompat.Builder(this, ALERT_CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_clip_scissors)
                .setContentTitle(title)
                .setContentText(body)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setAutoCancel(true)
                .setContentIntent(pi);
            nm.notify(STATUS_NOTIFICATION_ID, b.build());
        }
        updateNotificationOnly();
        if (showTopPopup) {
            showTopNotificationPopup(title, body, withRedDot);
        }
        showToast(title);
    }

    private void showTopNotificationPopup(String title, String subtitle, boolean showRedDot) {
        mainHandler.post(() -> {
            if (windowManager == null) return;
            hideTopNotificationPopup();

            int overlayType = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;

            WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                overlayType,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                    | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                    | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT
            );
            lp.gravity = Gravity.TOP | Gravity.CENTER_HORIZONTAL;
            lp.y = dp(26);

            topBannerView = new LinearLayout(this);
            topBannerView.setOrientation(LinearLayout.HORIZONTAL);
            topBannerView.setGravity(Gravity.CENTER_VERTICAL);
            topBannerView.setPadding(dp(12), dp(8), dp(14), dp(8));

            GradientDrawable bg = new GradientDrawable();
            bg.setColor(Color.parseColor("#E60B0E14"));
            bg.setCornerRadius(dp(20));
            bg.setStroke(dp(1), Color.parseColor(showRedDot ? "#EF4444" : "#34D399"));
            topBannerView.setBackground(bg);
            topBannerView.setElevation(dp(12));

            topBannerDot = new View(this);
            GradientDrawable dBg = new GradientDrawable();
            dBg.setShape(GradientDrawable.OVAL);
            dBg.setColor(Color.parseColor(showRedDot ? "#FF1E2D" : "#22C55E"));
            topBannerDot.setBackground(dBg);
            LinearLayout.LayoutParams dLp = new LinearLayout.LayoutParams(dp(9), dp(9));
            dLp.rightMargin = dp(8);
            topBannerView.addView(topBannerDot, dLp);

            LinearLayout textCol = new LinearLayout(this);
            textCol.setOrientation(LinearLayout.VERTICAL);

            topBannerTitleTv = new TextView(this);
            topBannerTitleTv.setText(title);
            topBannerTitleTv.setTextColor(Color.WHITE);
            topBannerTitleTv.setTextSize(12);
            topBannerTitleTv.setTypeface(Typeface.DEFAULT_BOLD);
            textCol.addView(topBannerTitleTv);

            topBannerSubTv = new TextView(this);
            topBannerSubTv.setText(subtitle);
            topBannerSubTv.setTextColor(Color.parseColor("#CBD5E1"));
            topBannerSubTv.setTextSize(10);
            textCol.addView(topBannerSubTv);

            topBannerView.addView(textCol);

            try {
                windowManager.addView(topBannerView, lp);
                mainHandler.removeCallbacks(hideTopBannerRunnable);
                mainHandler.postDelayed(hideTopBannerRunnable, 2000L);
            } catch (Exception ignored) {
                topBannerView = null;
            }
        });
    }

    private void hideTopNotificationPopup() {
        mainHandler.removeCallbacks(hideTopBannerRunnable);
        if (topBannerView != null && windowManager != null) {
            try {
                windowManager.removeView(topBannerView);
            } catch (IllegalArgumentException ignored) {
            }
            topBannerView = null;
        }
    }

    private void startForegroundWithType(boolean hasMediaProjection) {
        Notification notification = buildServiceNotification();
        boolean cameraPermGranted = ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
            == PackageManager.PERMISSION_GRANTED;
        boolean cameraAllowed = cameraPermGranted && (hasMediaProjection || isFacecamActiveSelected());

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            int fgsType;
            if (hasMediaProjection) {
                fgsType = ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION;
                if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
                    == PackageManager.PERMISSION_GRANTED) {
                    fgsType |= ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE;
                }
                if (cameraAllowed) {
                    fgsType |= ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA;
                }
            } else {
                fgsType = ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE;
                if (cameraAllowed) {
                    fgsType |= ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA;
                }
            }
            startForeground(NOTIFICATION_ID, notification, fgsType);
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q && hasMediaProjection) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            );
        } else {
            startForeground(NOTIFICATION_ID, notification);
        }
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    @SuppressLint("ClickableViewAccessibility")
    private void ensureOverlayBubbleShown() {
        if (bubbleView != null || windowManager == null) {
            return;
        }

        int overlayType = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
            ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            : WindowManager.LayoutParams.TYPE_PHONE;

        // SMALL MODE: 32dp small circle with 60% transparency (alpha = 0.40)
        int bubbleSize = dp(32);
        bubbleParams = new WindowManager.LayoutParams(
            bubbleSize,
            bubbleSize,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        );
        bubbleParams.gravity = Gravity.TOP | Gravity.START;
        bubbleParams.x = dp(14);
        bubbleParams.y = dp(160);

        bubbleView = new FrameLayout(this);
        bubbleView.setAlpha(0.40f); // 60% transparent
        applyBubbleBackground(false);
        bubbleView.setElevation(dp(6));

        // Idle UI inside 32dp circle: Scissors + CLIP micro label
        bubbleIdleBox = new LinearLayout(this);
        bubbleIdleBox.setOrientation(LinearLayout.VERTICAL);
        bubbleIdleBox.setGravity(Gravity.CENTER);

        ImageView scissorsIv = new ImageView(this);
        scissorsIv.setImageResource(R.drawable.ic_clip_scissors);
        LinearLayout.LayoutParams iconLp = new LinearLayout.LayoutParams(dp(13), dp(13));
        bubbleIdleBox.addView(scissorsIv, iconLp);

        TextView clipLabelTv = new TextView(this);
        clipLabelTv.setText("CLIP");
        clipLabelTv.setTextColor(Color.WHITE);
        clipLabelTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 6);
        clipLabelTv.setTypeface(Typeface.DEFAULT_BOLD);
        clipLabelTv.setIncludeFontPadding(false);
        clipLabelTv.setGravity(Gravity.CENTER);
        bubbleIdleBox.addView(clipLabelTv);

        FrameLayout.LayoutParams idleLp = new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT,
            FrameLayout.LayoutParams.WRAP_CONTENT
        );
        idleLp.gravity = Gravity.CENTER;
        bubbleView.addView(bubbleIdleBox, idleLp);

        // Recording state UI inside the 32dp circle: RED dot + timer (00:12)
        bubbleRecordingBox = new LinearLayout(this);
        bubbleRecordingBox.setOrientation(LinearLayout.VERTICAL);
        bubbleRecordingBox.setGravity(Gravity.CENTER);
        bubbleRecordingBox.setVisibility(View.GONE);

        bubbleRedDot = new View(this);
        GradientDrawable dotBg = new GradientDrawable();
        dotBg.setShape(GradientDrawable.OVAL);
        dotBg.setColor(Color.parseColor("#FF1E2D"));
        bubbleRedDot.setBackground(dotBg);
        LinearLayout.LayoutParams dotLp = new LinearLayout.LayoutParams(dp(6), dp(6));
        dotLp.bottomMargin = dp(1);
        bubbleRecordingBox.addView(bubbleRedDot, dotLp);

        bubbleTimerTv = new TextView(this);
        bubbleTimerTv.setTextColor(Color.WHITE);
        bubbleTimerTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 7);
        bubbleTimerTv.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        bubbleTimerTv.setIncludeFontPadding(false);
        bubbleTimerTv.setGravity(Gravity.CENTER);
        bubbleTimerTv.setText("00:00");
        bubbleRecordingBox.addView(bubbleTimerTv);

        FrameLayout.LayoutParams recLp = new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT,
            FrameLayout.LayoutParams.WRAP_CONTENT
        );
        recLp.gravity = Gravity.CENTER;
        bubbleView.addView(bubbleRecordingBox, recLp);

        bubbleView.setOnTouchListener(new View.OnTouchListener() {
            private int initialX;
            private int initialY;
            private float downRawX;
            private float downRawY;
            private boolean isDragging;
            private boolean longPressTriggered;
            private final Runnable longPressRunnable = () -> {
                if (!isDragging) {
                    longPressTriggered = true;
                    bubbleView.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
                    showLongPressPopupMenu();
                }
            };

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                DisplayMetrics dm = getResources().getDisplayMetrics();
                switch (event.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        initialX = bubbleParams.x;
                        initialY = bubbleParams.y;
                        downRawX = event.getRawX();
                        downRawY = event.getRawY();
                        isDragging = false;
                        longPressTriggered = false;
                        mainHandler.removeCallbacks(longPressRunnable);
                        mainHandler.postDelayed(longPressRunnable, 500L);
                        return true;

                    case MotionEvent.ACTION_MOVE:
                        float dx = event.getRawX() - downRawX;
                        float dy = event.getRawY() - downRawY;
                        if (Math.hypot(dx, dy) > dp(6)) {
                            isDragging = true;
                            mainHandler.removeCallbacks(longPressRunnable);
                        }
                        if (isDragging) {
                            int maxX = Math.max(0, dm.widthPixels - bubbleSize);
                            int maxY = Math.max(0, dm.heightPixels - bubbleSize);
                            bubbleParams.x = Math.max(0, Math.min(maxX, Math.round(initialX + dx)));
                            bubbleParams.y = Math.max(dp(20), Math.min(maxY, Math.round(initialY + dy)));
                            windowManager.updateViewLayout(bubbleView, bubbleParams);
                        }
                        return true;

                    case MotionEvent.ACTION_UP:
                        mainHandler.removeCallbacks(longPressRunnable);
                        if (!isDragging && !longPressTriggered) {
                            showFloatingMenu();
                        }
                        return true;

                    case MotionEvent.ACTION_CANCEL:
                        mainHandler.removeCallbacks(longPressRunnable);
                        return true;

                    default:
                        return false;
                }
            }
        });

        windowManager.addView(bubbleView, bubbleParams);
    }

    @SuppressLint("ClickableViewAccessibility")
    private void showLongPressPopupMenu() {
        if (windowManager == null || bubbleParams == null) return;
        hideLongPressPopupMenu();
        hideFloatingMenu();

        int overlayType = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
            ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            : WindowManager.LayoutParams.TYPE_PHONE;

        int menuW = dp(188);
        DisplayMetrics dm = getResources().getDisplayMetrics();
        longPressMenuParams = new WindowManager.LayoutParams(
            menuW,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                | WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH
                | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        );
        longPressMenuParams.gravity = Gravity.TOP | Gravity.START;
        int maxX = Math.max(dp(8), dm.widthPixels - menuW - dp(8));
        int desiredX = bubbleParams.x + dp(38);
        if (desiredX > maxX) {
            desiredX = Math.max(dp(8), bubbleParams.x - menuW - dp(6));
        }
        longPressMenuParams.x = Math.max(dp(8), Math.min(maxX, desiredX));
        longPressMenuParams.y = Math.max(dp(24), Math.min(dm.heightPixels - dp(160), bubbleParams.y));

        longPressMenuView = new LinearLayout(this);
        longPressMenuView.setOrientation(LinearLayout.VERTICAL);
        longPressMenuView.setPadding(dp(10), dp(10), dp(10), dp(10));
        longPressMenuView.setElevation(dp(16));

        GradientDrawable cardBg = new GradientDrawable();
        cardBg.setColor(Color.parseColor("#EE0B0E14"));
        cardBg.setCornerRadius(dp(14));
        cardBg.setStroke(dp(1), Color.parseColor("#475569"));
        longPressMenuView.setBackground(cardBg);

        longPressMenuView.setOnTouchListener((v, ev) -> {
            if (ev.getAction() == MotionEvent.ACTION_OUTSIDE) {
                hideLongPressPopupMenu();
                return true;
            }
            return false;
        });

        TextView header = new TextView(this);
        header.setText("CLIP Options");
        header.setTextColor(Color.parseColor("#94A3B8"));
        header.setTextSize(10);
        header.setTypeface(Typeface.DEFAULT_BOLD);
        header.setPadding(dp(4), 0, dp(4), dp(6));
        longPressMenuView.addView(header);

        Button hideBtn = createCircularGridButton("Hide Button", "#1E293B", "#F8FAFC");
        LinearLayout.LayoutParams hLp = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, dp(34)
        );
        hLp.bottomMargin = dp(6);
        hideBtn.setOnClickListener(v -> {
            hideLongPressPopupMenu();
            hideFloatingBubbleOnly();
            showToast("Floating CLIP hidden");
        });
        longPressMenuView.addView(hideBtn, hLp);

        Button stopAndHideBtn = createCircularGridButton("Stop Recording + Hide", "#B45309", "#FFFFFF");
        LinearLayout.LayoutParams shLp = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, dp(34)
        );
        shLp.bottomMargin = dp(6);
        stopAndHideBtn.setOnClickListener(v -> {
            hideLongPressPopupMenu();
            stopActiveRecordingOnly();
            hideFloatingBubbleOnly();
        });
        longPressMenuView.addView(stopAndHideBtn, shLp);

        Button stopServiceBtn = createCircularGridButton("Stop", "#DC2626", "#FFFFFF");
        LinearLayout.LayoutParams sLp = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, dp(34)
        );
        stopServiceBtn.setOnClickListener(v -> {
            hideLongPressPopupMenu();
            stopEverythingAndSelf();
        });
        longPressMenuView.addView(stopServiceBtn, sLp);

        try {
            windowManager.addView(longPressMenuView, longPressMenuParams);
            isLongPressMenuVisible = true;
        } catch (Exception ignored) {
            longPressMenuView = null;
            isLongPressMenuVisible = false;
        }
    }

    private void hideLongPressPopupMenu() {
        if (isLongPressMenuVisible && longPressMenuView != null && windowManager != null) {
            try {
                windowManager.removeView(longPressMenuView);
            } catch (IllegalArgumentException ignored) {
            }
            longPressMenuView = null;
            isLongPressMenuVisible = false;
        }
    }

    private void startForegroundMonitor() {
        mainHandler.removeCallbacks(foregroundMonitorRunnable);
        mainHandler.postDelayed(foregroundMonitorRunnable, 1200L);
    }

    private void stopForegroundMonitor() {
        mainHandler.removeCallbacks(foregroundMonitorRunnable);
        outOfTargetSinceMs = 0L;
    }

    private boolean isTransientSystemPackage(String pkg) {
        return "com.android.permissioncontroller".equals(pkg)
            || "com.google.android.permissioncontroller".equals(pkg)
            || "com.google.android.packageinstaller".equals(pkg);
    }

    private void checkTargetForegroundState() {
        if (bubbleSuppressed || awaitingProjectionPrompt || targetPackageName == null || targetPackageName.isEmpty()) {
            outOfTargetSinceMs = 0L;
            return;
        }
        long now = System.currentTimeMillis();
        if (now < targetLaunchGraceUntilMs) {
            outOfTargetSinceMs = 0L;
            return;
        }

        // Update latest foreground package from UsageStatsManager when available
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP_MR1) {
            try {
                UsageStatsManager usm = (UsageStatsManager) getSystemService(Context.USAGE_STATS_SERVICE);
                if (usm != null) {
                    UsageEvents events = usm.queryEvents(now - 15_000L, now);
                    UsageEvents.Event ev = new UsageEvents.Event();
                    long latestTs = 0L;
                    String latestPkg = null;
                    while (events.hasNextEvent()) {
                        events.getNextEvent(ev);
                        int type = ev.getEventType();
                        boolean isResumed = (type == UsageEvents.Event.MOVE_TO_FOREGROUND)
                            || (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q
                                && type == UsageEvents.Event.ACTIVITY_RESUMED);
                        if (isResumed && ev.getTimeStamp() >= latestTs && ev.getPackageName() != null) {
                            latestTs = ev.getTimeStamp();
                            latestPkg = ev.getPackageName();
                        }
                    }
                    if (latestPkg != null) {
                        lastKnownForegroundPackage = latestPkg;
                    }
                }
            } catch (Exception ignored) {
            }
        }

        boolean clipKaroFront = MainActivity.isActivityInForeground;
        boolean notInTarget = clipKaroFront
            || (lastKnownForegroundPackage != null
                && !lastKnownForegroundPackage.equals(targetPackageName)
                && !isTransientSystemPackage(lastKnownForegroundPackage));

        if (notInTarget) {
            if (outOfTargetSinceMs == 0L) {
                outOfTargetSinceMs = now;
            } else if (now - outOfTargetSinceMs > 3000L) {
                boolean wasRecording = isRecordingTimed.get() || isRecordingFull.get();
                if (wasRecording) {
                    stopActiveRecordingOnlyWithMessage(
                        "Game closed, Clipping Saved",
                        activeGameName + " closed · Saved to Movies/ClipKaro & My Clips"
                    );
                }
                hideFloatingBubbleOnly();
            }
        } else {
            outOfTargetSinceMs = 0L;
        }
    }

    private void hideFloatingBubbleOnly() {
        bubbleSuppressed = true;
        stopForegroundMonitor();
        hideLongPressPopupMenu();
        hideFloatingMenu();
        hideFacecamOverlay();
        if (bubbleView != null && windowManager != null) {
            try {
                windowManager.removeView(bubbleView);
            } catch (IllegalArgumentException ignored) {
            }
            bubbleView = null;
        }
        // Stop capture encoders while preserving cachedMediaProjection for instant reuse on next game open
        stopCapturePipelineKeepProjection();
        updateNotificationOnly();
    }

    private void applyBubbleBackground(boolean recording) {
        if (bubbleView == null) return;
        boolean pausedNow = recording && isRecordingPaused.get();
        GradientDrawable bg = new GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            recording
                ? new int[]{Color.parseColor("#1E293B"), Color.parseColor("#0F172A")}
                : new int[]{Color.parseColor("#F43F5E"), Color.parseColor("#BE123C")}
        );
        bg.setShape(GradientDrawable.OVAL);
        bg.setStroke(dp(1), Color.parseColor(pausedNow ? "#FACC15" : (recording ? "#FF1E2D" : "#FFFFFF")));
        bubbleView.setBackground(bg);
        bubbleView.setAlpha(0.40f); // Keep 60% transparent
    }

    private void updateBubbleVisuals(boolean recording, long elapsedSec, boolean dotBright) {
        if (bubbleView == null) return;
        applyBubbleBackground(recording);
        if (recording) {
            if (bubbleIdleBox != null) bubbleIdleBox.setVisibility(View.GONE);
            if (bubbleRecordingBox != null) bubbleRecordingBox.setVisibility(View.VISIBLE);
            if (bubbleRedDot != null) {
                GradientDrawable dBg = new GradientDrawable();
                dBg.setShape(GradientDrawable.OVAL);
                dBg.setColor(Color.parseColor(isRecordingPaused.get() ? "#FACC15" : "#FF1E2D"));
                bubbleRedDot.setBackground(dBg);
                bubbleRedDot.setAlpha(isRecordingPaused.get() ? 1.0f : (dotBright ? 1.0f : 0.30f));
            }
            if (bubbleTimerTv != null) {
                bubbleTimerTv.setText(String.format(Locale.US, "%02d:%02d", elapsedSec / 60, elapsedSec % 60));
            }
        } else {
            if (bubbleIdleBox != null) bubbleIdleBox.setVisibility(View.VISIBLE);
            if (bubbleRecordingBox != null) bubbleRecordingBox.setVisibility(View.GONE);
        }
    }

    private void updateExpandedRecordingTimer(long elapsedSec, boolean dotBright) {
        boolean pausedNow = isRecordingPaused.get();
        if (recMenuRedDot != null) {
            GradientDrawable dBg = new GradientDrawable();
            dBg.setShape(GradientDrawable.OVAL);
            dBg.setColor(Color.parseColor(pausedNow ? "#FACC15" : "#FF1E2D"));
            recMenuRedDot.setBackground(dBg);
            recMenuRedDot.setAlpha(pausedNow ? 1.0f : (dotBright ? 1.0f : 0.30f));
        }
        if (recMenuTimerTv != null) {
            recMenuTimerTv.setText(String.format(Locale.US, "%02d:%02d", elapsedSec / 60, elapsedSec % 60));
        }
        if (recMenuSubTv != null) {
            String base = isRecordingTimed.get()
                ? (activeTimedDurationSec + " sec · Clip #" + currentClipSequence)
                : (activeGameName + " · Full Video");
            recMenuSubTv.setText(pausedNow ? "PAUSED · " + base : base);
            recMenuSubTv.setTextColor(Color.parseColor(pausedNow ? "#FDE047" : "#CBD5E1"));
        }
        if (pauseRecBtn != null) {
            pauseRecBtn.setEnabled(!pausedNow);
            pauseRecBtn.setAlpha(pausedNow ? 0.45f : 1.0f);
        }
        if (resumeRecBtn != null) {
            resumeRecBtn.setEnabled(pausedNow);
            resumeRecBtn.setAlpha(pausedNow ? 1.0f : 0.45f);
        }
    }

    private void positionMenuNearBubble(int menuSizeDp) {
        if (menuParams == null || bubbleParams == null) return;
        DisplayMetrics dm = getResources().getDisplayMetrics();
        int menuPx = dp(menuSizeDp);
        menuParams.width = menuPx;
        menuParams.height = menuPx;

        // Expand around small bubble center and clamp cleanly inside screen
        int bubbleCenterX = bubbleParams.x + dp(16);
        int bubbleCenterY = bubbleParams.y + dp(16);
        int targetX = bubbleCenterX - (menuPx / 2);
        int targetY = bubbleCenterY - (menuPx / 2);

        int maxX = Math.max(dp(8), dm.widthPixels - menuPx - dp(8));
        int maxY = Math.max(dp(20), dm.heightPixels - menuPx - dp(16));
        menuParams.x = Math.max(dp(8), Math.min(maxX, targetX));
        menuParams.y = Math.max(dp(20), Math.min(maxY, targetY));
    }

    private void showFloatingMenu() {
        if (windowManager == null) return;
        if (menuView == null) {
            buildFloatingMenu();
        }
        boolean recordingAny = isRecordingTimed.get() || isRecordingFull.get();
        int targetSizeDp = recordingAny ? 246 : 254;
        if (idleMenuContainer != null) {
            idleMenuContainer.setVisibility(recordingAny ? View.GONE : View.VISIBLE);
        }
        if (recordingMenuContainer != null) {
            recordingMenuContainer.setVisibility(recordingAny ? View.VISIBLE : View.GONE);
        }
        applyMenuBackground(recordingAny);
        positionMenuNearBubble(targetSizeDp);
        if (recordingAny) {
            updateExpandedRecordingTimer(getCurrentActiveElapsedSec(), true);
        }
        updateMenuStatusText();

        if (bubbleView != null) {
            bubbleView.setVisibility(View.GONE);
        }
        if (!isMenuVisible) {
            windowManager.addView(menuView, menuParams);
            isMenuVisible = true;
        } else {
            windowManager.updateViewLayout(menuView, menuParams);
        }
    }

    private void hideFloatingMenu() {
        if (isMenuVisible && menuView != null && windowManager != null) {
            try {
                windowManager.removeView(menuView);
            } catch (IllegalArgumentException ignored) {
            }
            isMenuVisible = false;
        }
        if (bubbleView != null && !bubbleSuppressed) {
            bubbleView.setVisibility(View.VISIBLE);
        }
    }

    private void applyMenuBackground(boolean recordingMode) {
        if (menuView == null) return;
        GradientDrawable circleBg = new GradientDrawable();
        circleBg.setShape(GradientDrawable.OVAL);
        circleBg.setColor(Color.parseColor("#D90B0E14")); // Semi-transparent dark background
        circleBg.setStroke(dp(2), Color.parseColor(recordingMode ? "#EF4444" : "#475569"));
        menuView.setBackground(circleBg);
    }

    @SuppressLint("ClickableViewAccessibility")
    private void buildFloatingMenu() {
        int overlayType = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
            ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            : WindowManager.LayoutParams.TYPE_PHONE;

        menuParams = new WindowManager.LayoutParams(
            dp(232),
            dp(232),
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                | WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH
                | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        );
        menuParams.gravity = Gravity.TOP | Gravity.START;

        menuView = new FrameLayout(this);
        menuView.setElevation(dp(14));
        applyMenuBackground(false);

        // Auto-collapse back to small 32dp button when user taps outside expanded menu
        menuView.setOnTouchListener((v, event) -> {
            if (event.getAction() == MotionEvent.ACTION_OUTSIDE) {
                hideFloatingMenu();
                return true;
            }
            return false;
        });

        // 1) IDLE EXPANDED CIRCLE MENU (232dp semi-transparent dark circle)
        idleMenuContainer = new LinearLayout(this);
        idleMenuContainer.setOrientation(LinearLayout.VERTICAL);
        idleMenuContainer.setGravity(Gravity.CENTER_HORIZONTAL);
        idleMenuContainer.setPadding(dp(16), dp(14), dp(16), dp(12));

        // Top Row: CLIP title + CLOSE (X) button
        LinearLayout topRow = new LinearLayout(this);
        topRow.setOrientation(LinearLayout.HORIZONTAL);
        topRow.setGravity(Gravity.CENTER);
        topRow.setPadding(dp(20), 0, dp(20), dp(4));

        TextView titleTv = new TextView(this);
        titleTv.setText("CLIP");
        titleTv.setTextColor(Color.WHITE);
        titleTv.setTextSize(12);
        titleTv.setTypeface(Typeface.DEFAULT_BOLD);
        topRow.addView(titleTv, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

        Button closeXBtn = createCircleIconBtn("X", "#334155", "#F8FAFC", 24);
        closeXBtn.setOnClickListener(v -> hideFloatingMenu());
        topRow.addView(closeXBtn);
        idleMenuContainer.addView(topRow, new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ));

        // Compact Toggle Row: Audio Cycler + Auto Loop + Auto Highlight (keeps all features accessible)
        LinearLayout toggleRow = new LinearLayout(this);
        toggleRow.setOrientation(LinearLayout.HORIZONTAL);
        toggleRow.setGravity(Gravity.CENTER);
        toggleRow.setPadding(dp(14), 0, dp(14), dp(5));

        audioCycleBtn = createCompactToggleBtn("Game+Mic");
        autoContinuousBtn = createCompactToggleBtn("Loop:ON");
        autoHighlightBtn = createCompactToggleBtn("15sHL:ON");

        LinearLayout.LayoutParams tLp1 = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.2f);
        tLp1.rightMargin = dp(3);
        LinearLayout.LayoutParams tLp2 = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        tLp2.rightMargin = dp(3);
        LinearLayout.LayoutParams tLp3 = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);

        audioCycleBtn.setOnClickListener(v -> cycleAudioMode());
        autoContinuousBtn.setOnClickListener(v -> toggleAutoContinuous());
        autoHighlightBtn.setOnClickListener(v -> toggleAutoHighlight());

        toggleRow.addView(audioCycleBtn, tLp1);
        toggleRow.addView(autoContinuousBtn, tLp2);
        toggleRow.addView(autoHighlightBtn, tLp3);
        idleMenuContainer.addView(toggleRow, new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ));

        // Second Compact Row: Facecam + Voice Changer + Reaction Mode
        LinearLayout fxRow = new LinearLayout(this);
        fxRow.setOrientation(LinearLayout.HORIZONTAL);
        fxRow.setGravity(Gravity.CENTER);
        fxRow.setPadding(dp(12), 0, dp(12), dp(4));

        facecamToggleBtn = createCompactToggleBtn("Cam:OFF");
        voiceEffectBtn = createCompactToggleBtn("Voice:Norm");
        reactionToggleBtn = createCompactToggleBtn("React:OFF");

        LinearLayout.LayoutParams fxLp1 = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        fxLp1.rightMargin = dp(3);
        LinearLayout.LayoutParams fxLp2 = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.15f);
        fxLp2.rightMargin = dp(3);
        LinearLayout.LayoutParams fxLp3 = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);

        facecamToggleBtn.setOnClickListener(v -> toggleFacecamBeforeRecording());
        voiceEffectBtn.setOnClickListener(v -> cycleVoiceEffect());
        reactionToggleBtn.setOnClickListener(v -> toggleReactionMode());

        fxRow.addView(facecamToggleBtn, fxLp1);
        fxRow.addView(voiceEffectBtn, fxLp2);
        fxRow.addView(reactionToggleBtn, fxLp3);
        idleMenuContainer.addView(fxRow, new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ));

        // Row 1: 10 sec / 20 sec / 30 sec
        LinearLayout row1 = new LinearLayout(this);
        row1.setOrientation(LinearLayout.HORIZONTAL);
        row1.setGravity(Gravity.CENTER);
        for (int sec : new int[]{10, 20, 30}) {
            Button btn = createCircularGridButton(sec + " sec", "#1E293B", "#FFFFFF");
            LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(0, dp(30), 1f);
            bp.setMargins(dp(2), dp(1), dp(2), dp(1));
            btn.setOnClickListener(v -> onClipDurationTapped(sec));
            row1.addView(btn, bp);
        }
        idleMenuContainer.addView(row1, new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ));

        // Row 2: 40 sec / 50 sec / 60 sec
        LinearLayout row2 = new LinearLayout(this);
        row2.setOrientation(LinearLayout.HORIZONTAL);
        row2.setGravity(Gravity.CENTER);
        for (int sec : new int[]{40, 50, 60}) {
            Button btn = createCircularGridButton(sec + " sec", "#1E293B", "#FFFFFF");
            LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(0, dp(30), 1f);
            bp.setMargins(dp(2), dp(1), dp(2), dp(1));
            btn.setOnClickListener(v -> onClipDurationTapped(sec));
            row2.addView(btn, bp);
        }
        idleMenuContainer.addView(row2, new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ));

        // Row 3: Full Video
        Button fullBtn = createCircularGridButton("Full Video", "#0F766E", "#FFFFFF");
        LinearLayout.LayoutParams fullLp = new LinearLayout.LayoutParams(dp(156), dp(28));
        fullLp.topMargin = dp(3);
        fullBtn.setOnClickListener(v -> onToggleFullGameplay());
        idleMenuContainer.addView(fullBtn, fullLp);

        // Bottom Row: STOP (RED) button
        idleStopBtn = createCircularGridButton("STOP", "#DC2626", "#FFFFFF");
        LinearLayout.LayoutParams idleStopLp = new LinearLayout.LayoutParams(dp(102), dp(28));
        idleStopLp.topMargin = dp(4);
        idleStopBtn.setOnClickListener(v -> {
            hideFloatingMenu();
            if (isRecordingTimed.get() || isRecordingFull.get()) {
                stopActiveRecordingOnly();
            } else {
                showToast("Ready — tap duration to start recording");
            }
        });
        idleMenuContainer.addView(idleStopBtn, idleStopLp);

        menuView.addView(idleMenuContainer, new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.MATCH_PARENT
        ));

        // 2) RECORDING BIG CONTROLS CIRCLE MENU (222dp semi-transparent dark circle: STOP RED, PAUSE YELLOW, RESUME GREEN, SAVE CLIP, CLOSE X)
        recordingMenuContainer = new LinearLayout(this);
        recordingMenuContainer.setOrientation(LinearLayout.VERTICAL);
        recordingMenuContainer.setGravity(Gravity.CENTER);
        recordingMenuContainer.setPadding(dp(14), dp(12), dp(14), dp(12));
        recordingMenuContainer.setVisibility(View.GONE);

        // Top close (X) row inside circle
        LinearLayout recTopRow = new LinearLayout(this);
        recTopRow.setOrientation(LinearLayout.HORIZONTAL);
        recTopRow.setGravity(Gravity.CENTER);

        recMenuRedDot = new View(this);
        GradientDrawable rDotBg = new GradientDrawable();
        rDotBg.setShape(GradientDrawable.OVAL);
        rDotBg.setColor(Color.parseColor("#FF1E2D"));
        recMenuRedDot.setBackground(rDotBg);
        LinearLayout.LayoutParams rDotLp = new LinearLayout.LayoutParams(dp(10), dp(10));
        rDotLp.rightMargin = dp(6);
        recTopRow.addView(recMenuRedDot, rDotLp);

        recMenuTimerTv = new TextView(this);
        recMenuTimerTv.setText("00:00");
        recMenuTimerTv.setTextColor(Color.WHITE);
        recMenuTimerTv.setTextSize(16);
        recMenuTimerTv.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        recTopRow.addView(recMenuTimerTv);

        Button recCloseX = createCircleIconBtn("X", "#334155", "#FFFFFF", 24);
        LinearLayout.LayoutParams rxLp = new LinearLayout.LayoutParams(dp(24), dp(24));
        rxLp.leftMargin = dp(10);
        recCloseX.setOnClickListener(v -> hideFloatingMenu());
        recTopRow.addView(recCloseX, rxLp);
        recordingMenuContainer.addView(recTopRow);

        recMenuSubTv = new TextView(this);
        recMenuSubTv.setText("Recording...");
        recMenuSubTv.setTextColor(Color.parseColor("#CBD5E1"));
        recMenuSubTv.setTextSize(10);
        recMenuSubTv.setGravity(Gravity.CENTER);
        recMenuSubTv.setPadding(0, dp(2), 0, dp(6));
        recordingMenuContainer.addView(recMenuSubTv);

        // Middle Row: PAUSE (YELLOW) + RESUME (GREEN)
        LinearLayout pauseResumeRow = new LinearLayout(this);
        pauseResumeRow.setOrientation(LinearLayout.HORIZONTAL);
        pauseResumeRow.setGravity(Gravity.CENTER);

        pauseRecBtn = createCircularGridButton("PAUSE", "#EAB308", "#0B0E14");
        LinearLayout.LayoutParams pLp = new LinearLayout.LayoutParams(dp(74), dp(30));
        pLp.rightMargin = dp(6);
        pauseRecBtn.setOnClickListener(v -> pauseActiveRecording());
        pauseResumeRow.addView(pauseRecBtn, pLp);

        resumeRecBtn = createCircularGridButton("RESUME", "#16A34A", "#FFFFFF");
        LinearLayout.LayoutParams rLp = new LinearLayout.LayoutParams(dp(74), dp(30));
        resumeRecBtn.setOnClickListener(v -> resumeActiveRecording());
        pauseResumeRow.addView(resumeRecBtn, rLp);

        recordingMenuContainer.addView(pauseResumeRow);

        // Facecam ON / OFF toggle inside Recording menu (persists last choice)
        recFacecamToggleBtn = createCircularGridButton("Facecam OFF", "#1E293B", "#CBD5E1");
        LinearLayout.LayoutParams recFcLp = new LinearLayout.LayoutParams(dp(132), dp(26));
        recFcLp.topMargin = dp(5);
        recFacecamToggleBtn.setOnClickListener(v -> toggleFacecamFromMenu());
        recordingMenuContainer.addView(recFacecamToggleBtn, recFcLp);

        // Optional Reaction Mode "Save Clip" quick capture button
        saveReactionRecBtn = createCircularGridButton("Save Clip (Part)", "#0F766E", "#FFFFFF");
        LinearLayout.LayoutParams saveReactLp = new LinearLayout.LayoutParams(dp(128), dp(24));
        saveReactLp.topMargin = dp(4);
        saveReactionRecBtn.setOnClickListener(v -> {
            hideFloatingMenu();
            saveReactionSelectedPart();
        });
        recordingMenuContainer.addView(saveReactionRecBtn, saveReactLp);

        // Bottom: BIG RED STOP button
        stopRecBigBtn = createCircularGridButton("STOP", "#DC2626", "#FFFFFF");
        stopRecBigBtn.setTextSize(13);
        LinearLayout.LayoutParams stopBigLp = new LinearLayout.LayoutParams(dp(116), dp(34));
        stopBigLp.topMargin = dp(5);
        stopRecBigBtn.setOnClickListener(v -> {
            hideFloatingMenu();
            stopActiveRecordingOnly();
        });
        recordingMenuContainer.addView(stopRecBigBtn, stopBigLp);

        menuView.addView(recordingMenuContainer, new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.MATCH_PARENT
        ));
    }

    private Button createCircleIconBtn(String label, String bgHex, String textHex, int sizeDp) {
        Button btn = new Button(this);
        btn.setText(label);
        btn.setAllCaps(false);
        btn.setTextSize(11);
        btn.setTypeface(Typeface.DEFAULT_BOLD);
        btn.setTextColor(Color.parseColor(textHex));
        btn.setPadding(0, 0, 0, 0);
        btn.setMinWidth(0);
        btn.setMinHeight(0);
        btn.setMinimumWidth(dp(sizeDp));
        btn.setMinimumHeight(dp(sizeDp));
        GradientDrawable bg = new GradientDrawable();
        bg.setShape(GradientDrawable.OVAL);
        bg.setColor(Color.parseColor(bgHex));
        bg.setStroke(dp(1), Color.parseColor("#64748B"));
        btn.setBackground(bg);
        btn.setLayoutParams(new LinearLayout.LayoutParams(dp(sizeDp), dp(sizeDp)));
        return btn;
    }

    private Button createCircularGridButton(String label, String bgHex, String textHex) {
        Button btn = new Button(this);
        btn.setText(label);
        btn.setAllCaps(false);
        btn.setTextSize(10);
        btn.setTypeface(Typeface.DEFAULT_BOLD);
        btn.setTextColor(Color.parseColor(textHex));
        btn.setPadding(dp(4), dp(2), dp(4), dp(2));
        btn.setMinHeight(0);
        btn.setMinWidth(0);
        btn.setMinimumHeight(dp(28));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.parseColor(bgHex));
        bg.setCornerRadius(dp(16));
        bg.setStroke(dp(1), Color.parseColor("#475569"));
        btn.setBackground(bg);
        return btn;
    }

    private Button createCompactToggleBtn(String label) {
        Button btn = new Button(this);
        btn.setText(label);
        btn.setAllCaps(false);
        btn.setTextSize(8);
        btn.setTypeface(Typeface.DEFAULT_BOLD);
        btn.setPadding(dp(3), dp(2), dp(3), dp(2));
        btn.setMinHeight(0);
        btn.setMinWidth(0);
        btn.setMinimumHeight(dp(22));
        return btn;
    }

    private void styleMiniToggle(Button btn, boolean highlighted, String activeBgHex) {
        if (btn == null) return;
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.parseColor(highlighted ? activeBgHex : "#1E293B"));
        bg.setCornerRadius(dp(10));
        bg.setStroke(dp(1), Color.parseColor("#475569"));
        btn.setBackground(bg);
        btn.setTextColor(Color.parseColor(highlighted ? "#FFFFFF" : "#94A3B8"));
    }

    private void cycleAudioMode() {
        String next;
        if (AUDIO_MODE_BOTH.equals(selectedAudioMode)) {
            next = AUDIO_MODE_GAME;
        } else if (AUDIO_MODE_GAME.equals(selectedAudioMode)) {
            next = AUDIO_MODE_MIC;
        } else {
            next = AUDIO_MODE_BOTH;
        }
        setAudioMode(next);
    }

    private void setAudioMode(String mode) {
        selectedAudioMode = mode;
        getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
            .edit()
            .putString(KEY_AUDIO_MODE, mode)
            .apply();
        updateMenuStatusText();
        updateNotificationOnly();

        if (isCapturing.get()) {
            restartAudioPipelineForMode();
        }
        showToast("Audio set to: " + getAudioModeLabel());
    }

    private void toggleAutoContinuous() {
        autoContinuousEnabled = true;
        getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
            .edit()
            .putBoolean(KEY_AUTO_CONTINUOUS, true)
            .apply();
        updateMenuStatusText();
        updateNotificationOnly();
        showToast("Continuous Clips ON — records until you tap STOP");
    }

    private void toggleAutoHighlight() {
        autoHighlightEnabled = !autoHighlightEnabled;
        getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
            .edit()
            .putBoolean(KEY_AUTO_HIGHLIGHT, autoHighlightEnabled)
            .apply();
        updateMenuStatusText();
        showToast(
            autoHighlightEnabled
                ? "Auto Highlight ON: Saves 15s on Kill / Headshot / Knock"
                : "Auto Highlight OFF"
        );
    }

    private String getAudioModeLabel() {
        if (AUDIO_MODE_GAME.equals(selectedAudioMode)) return "Game/Video Only";
        if (AUDIO_MODE_MIC.equals(selectedAudioMode)) return "Mic Only";
        return "Game+Mic Both";
    }

    private boolean isFacecamActiveSelected() {
        return !facecamManualOff && (facecamEnabled || reactionModeEnabled);
    }

    private void toggleFacecamBeforeRecording() {
        toggleFacecamFromMenu();
    }

    private void toggleFacecamFromMenu() {
        boolean next = !isFacecamActiveSelected();
        if (next
            && ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
                != PackageManager.PERMISSION_GRANTED) {
            showToast("Grant Camera permission in ClipKaro App for Facecam");
            return;
        }
        facecamEnabled = next;
        facecamManualOff = !next;
        getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
            .edit()
            .putBoolean(KEY_FACECAM_ENABLED, facecamEnabled)
            .putBoolean(KEY_FACECAM_MANUAL_OFF, facecamManualOff)
            .apply();
        if (next && (isRecordingTimed.get() || isRecordingFull.get() || isCapturing.get())) {
            startForegroundWithType(true);
        }
        syncFacecamOverlayState();
        updateMenuStatusText();
        showToast(next ? "Facecam ON (120dp Circle · Draggable)" : "Facecam OFF");
    }

    private void cycleVoiceEffect() {
        String next;
        if (VOICE_NORMAL.equals(selectedVoiceEffect)) {
            next = VOICE_FUNNY;
        } else if (VOICE_FUNNY.equals(selectedVoiceEffect)) {
            next = VOICE_ROBOT;
        } else if (VOICE_ROBOT.equals(selectedVoiceEffect)) {
            next = VOICE_DEEP;
        } else {
            next = VOICE_NORMAL;
        }
        selectedVoiceEffect = next;
        getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
            .edit()
            .putString(KEY_VOICE_EFFECT, selectedVoiceEffect)
            .apply();
        updateMenuStatusText();
        showToast("Voice Changer: " + getVoiceEffectLabel());
    }

    private void toggleReactionMode() {
        reactionModeEnabled = !reactionModeEnabled;
        if (reactionModeEnabled) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
                == PackageManager.PERMISSION_GRANTED) {
                facecamEnabled = true;
                facecamManualOff = false;
            }
            if (AUDIO_MODE_GAME.equals(selectedAudioMode)) {
                setAudioMode(AUDIO_MODE_BOTH);
            }
        }
        getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
            .edit()
            .putBoolean(KEY_REACTION_MODE, reactionModeEnabled)
            .putBoolean(KEY_FACECAM_ENABLED, facecamEnabled)
            .putBoolean(KEY_FACECAM_MANUAL_OFF, facecamManualOff)
            .apply();
        syncFacecamOverlayState();
        updateMenuStatusText();
        showToast(reactionModeEnabled
            ? "Reaction Mode ON (Video + Facecam + Mic)"
            : "Reaction Mode OFF");
    }

    private String getVoiceEffectLabel() {
        if (VOICE_FUNNY.equals(selectedVoiceEffect)) return "Funny";
        if (VOICE_ROBOT.equals(selectedVoiceEffect)) return "Robot";
        if (VOICE_DEEP.equals(selectedVoiceEffect)) return "Deep";
        return "Normal";
    }

    private void updateMenuStatusText() {
        mainHandler.post(() -> {
            if (audioCycleBtn != null) {
                String shortAudio = AUDIO_MODE_GAME.equals(selectedAudioMode)
                    ? "Game"
                    : AUDIO_MODE_MIC.equals(selectedAudioMode)
                        ? "Mic"
                        : "Game+Mic";
                audioCycleBtn.setText(shortAudio);
                styleMiniToggle(audioCycleBtn, true, "#E11D48");
            }
            if (autoContinuousBtn != null) {
                autoContinuousBtn.setText("Loop:ON");
                styleMiniToggle(autoContinuousBtn, true, "#065F46");
            }
            if (autoHighlightBtn != null) {
                autoHighlightBtn.setText(autoHighlightEnabled ? "15sHL:ON" : "15sHL:OFF");
                styleMiniToggle(autoHighlightBtn, autoHighlightEnabled, "#92400E");
            }
            boolean camOn = isFacecamActiveSelected();
            if (facecamToggleBtn != null) {
                facecamToggleBtn.setText(camOn ? "Cam:" + facecamSizeDp : "Facecam OFF");
                styleMiniToggle(facecamToggleBtn, camOn, "#0F766E");
            }
            if (recFacecamToggleBtn != null) {
                recFacecamToggleBtn.setText(camOn ? "● Facecam ON" : "Facecam OFF");
                styleMiniToggle(recFacecamToggleBtn, camOn, "#0F766E");
            }
            if (voiceEffectBtn != null) {
                String shortVoice = VOICE_NORMAL.equals(selectedVoiceEffect)
                    ? "V:Norm"
                    : "V:" + getVoiceEffectLabel();
                voiceEffectBtn.setText(shortVoice);
                styleMiniToggle(voiceEffectBtn, !VOICE_NORMAL.equals(selectedVoiceEffect), "#7C3AED");
            }
            if (reactionToggleBtn != null) {
                reactionToggleBtn.setText(reactionModeEnabled ? "React:ON" : "React:OFF");
                styleMiniToggle(reactionToggleBtn, reactionModeEnabled, "#BE123C");
            }
            if (saveReactionRecBtn != null) {
                saveReactionRecBtn.setVisibility(reactionModeEnabled ? View.VISIBLE : View.GONE);
            }
            if (facecamSaveClipBtn != null) {
                facecamSaveClipBtn.setVisibility(
                    (reactionModeEnabled && (isRecordingTimed.get() || isRecordingFull.get()))
                        ? View.VISIBLE
                        : View.GONE
                );
            }
        });
    }

    private void onClipDurationTapped(int seconds) {
        hideFloatingMenu();
        String appKey = resolveAppKey(targetPackageName, activeGameName);
        if (!isCapturing.get() || !appKey.equals(capturingForAppKey)) {
            if (isCapturing.get()) {
                stopCapturePipelineKeepProjection();
            }
            if (hasCachedProjectionForApp(appKey)) {
                startForegroundWithType(true);
                startCapturePipelineForApp(appKey);
            }
            if (!isCapturing.get() || !appKey.equals(capturingForAppKey)) {
                pendingDurationAfterProjection = seconds;
                pendingFullAfterProjection = false;
                promptMainForScreenCapture(seconds, false);
                return;
            }
        }
        startTimedClipRecording(seconds, true);
    }

    private void onToggleFullGameplay() {
        hideFloatingMenu();
        String appKey = resolveAppKey(targetPackageName, activeGameName);
        if (!isCapturing.get() || !appKey.equals(capturingForAppKey)) {
            if (isCapturing.get()) {
                stopCapturePipelineKeepProjection();
            }
            if (hasCachedProjectionForApp(appKey)) {
                startForegroundWithType(true);
                startCapturePipelineForApp(appKey);
            }
            if (!isCapturing.get() || !appKey.equals(capturingForAppKey)) {
                pendingFullAfterProjection = true;
                pendingDurationAfterProjection = 0;
                promptMainForScreenCapture(0, true);
                return;
            }
        }
        if (isRecordingFull.get()) {
            stopActiveRecordingOnly();
        } else {
            startFullGameplayRecording();
        }
    }

    private void promptMainForScreenCapture(int durationSec, boolean isFull) {
        awaitingProjectionPrompt = true;
        outOfTargetSinceMs = 0L;
        Intent intent = new Intent(this, MainActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        intent.putExtra(MainActivity.EXTRA_REQUEST_PROJECTION_GAME, activeGameName);
        if (targetPackageName != null && !targetPackageName.isEmpty()) {
            intent.putExtra(EXTRA_TARGET_PACKAGE, targetPackageName);
        }
        if (durationSec > 0) {
            intent.putExtra(EXTRA_PENDING_DURATION, durationSec);
        }
        if (isFull) {
            intent.putExtra(EXTRA_PENDING_FULL, true);
        }
        startActivity(intent);
        showToast("Allow screen capture once for " + activeGameName);
    }

    private void ensureMediaProjectionInitializedForApp(String appKey) {
        PerAppProjectionEntry entry = perAppProjectionMap.get(appKey);
        if (entry == null) {
            mediaProjection = null;
            return;
        }
        if (entry.mediaProjection != null) {
            mediaProjection = entry.mediaProjection;
            return;
        }
        if (entry.resultCode != Activity.RESULT_OK || entry.resultData == null) {
            perAppProjectionMap.remove(appKey);
            mediaProjection = null;
            return;
        }

        MediaProjectionManager mpm =
            (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);
        if (mpm == null) {
            mediaProjection = null;
            return;
        }

        try {
            mediaProjection = mpm.getMediaProjection(entry.resultCode, entry.resultData);
        } catch (SecurityException e) {
            mediaProjection = null;
            perAppProjectionMap.remove(appKey);
            return;
        }
        if (mediaProjection == null) {
            perAppProjectionMap.remove(appKey);
            return;
        }

        entry.mediaProjection = mediaProjection;
        final PerAppProjectionEntry registeredEntry = entry;
        mediaProjection.registerCallback(new MediaProjection.Callback() {
            @Override
            public void onStop() {
                mainHandler.post(() -> {
                    PerAppProjectionEntry cur = perAppProjectionMap.get(appKey);
                    if (cur == registeredEntry) {
                        perAppProjectionMap.remove(appKey);
                    }
                    if (appKey.equals(capturingForAppKey)) {
                        mediaProjection = null;
                        stopCapturePipelineKeepProjection();
                        updateBubbleVisuals(false, 0L, false);
                        updateMenuStatusText();
                        updateNotificationOnly();
                    }
                });
            }
        }, mainHandler);
    }

    private boolean startCapturePipelineForApp(String appKey) {
        if (isCapturing.get() && appKey.equals(capturingForAppKey)) {
            return true;
        }
        if (isCapturing.get()) {
            stopCapturePipelineKeepProjection();
        }
        ensureMediaProjectionInitializedForApp(appKey);
        if (mediaProjection == null) {
            return false;
        }

        DisplayMetrics dm = getResources().getDisplayMetrics();
        int rawW = Math.max(720, dm.widthPixels);
        int rawH = Math.max(720, dm.heightPixels);
        int maxDim = Math.max(rawW, rawH);
        double scale = maxDim > 1280 ? (1280.0 / maxDim) : 1.0;
        int encW = Math.max(320, ((int) Math.round(rawW * scale) / 16) * 16);
        int encH = Math.max(320, ((int) Math.round(rawH * scale) / 16) * 16);

        try {
            MediaFormat videoFormat = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, encW, encH);
            videoFormat.setInteger(
                MediaFormat.KEY_COLOR_FORMAT,
                MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface
            );
            videoFormat.setInteger(MediaFormat.KEY_BIT_RATE, VIDEO_BITRATE);
            videoFormat.setInteger(MediaFormat.KEY_FRAME_RATE, VIDEO_FPS);
            videoFormat.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1);

            videoEncoder = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC);
            videoEncoder.configure(videoFormat, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE);
            encoderSurface = videoEncoder.createInputSurface();
            videoEncoder.start();

            virtualDisplay = mediaProjection.createVirtualDisplay(
                "ClipKaroCapture",
                encW,
                encH,
                dm.densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                encoderSurface,
                null,
                null
            );

            capturingForAppKey = appKey;
            isCapturing.set(true);
            captureStartedAtMs = System.currentTimeMillis();
            videoThread = new Thread(this::runVideoDrainLoop, "ClipKaroVideoDrain");
            videoThread.start();

            startAudioPipeline();
            updateMenuStatusText();
            updateNotificationOnly();
            return true;
        } catch (SecurityException se) {
            perAppProjectionMap.remove(appKey);
            mediaProjection = null;
            stopCapturePipelineKeepProjection();
            return false;
        } catch (Exception e) {
            stopCapturePipelineKeepProjection();
            showToast("Screen capture setup failed: " + e.getMessage());
            return false;
        }
    }

    @SuppressLint("MissingPermission")
    private void startAudioPipeline() {
        stopAudioPipelineOnly();
        if (!isCapturing.get()) return;

        try {
            int minBuf = AudioRecord.getMinBufferSize(
                AUDIO_SAMPLE_RATE,
                AudioFormat.CHANNEL_IN_STEREO,
                AudioFormat.ENCODING_PCM_16BIT
            );
            int bufSize = Math.max(minBuf * 2, 8192);

            AudioFormat audioFormat = new AudioFormat.Builder()
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setSampleRate(AUDIO_SAMPLE_RATE)
                .setChannelMask(AudioFormat.CHANNEL_IN_STEREO)
                .build();

            boolean wantGame = AUDIO_MODE_GAME.equals(selectedAudioMode) || AUDIO_MODE_BOTH.equals(selectedAudioMode);
            boolean wantMic = AUDIO_MODE_MIC.equals(selectedAudioMode) || AUDIO_MODE_BOTH.equals(selectedAudioMode);
            boolean micPermGranted = ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
                == PackageManager.PERMISSION_GRANTED;

            if (wantGame && Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q && mediaProjection != null) {
                AudioPlaybackCaptureConfiguration config =
                    new AudioPlaybackCaptureConfiguration.Builder(mediaProjection)
                        .addMatchingUsage(AudioAttributes.USAGE_GAME)
                        .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
                        .build();
                AudioRecord rec = new AudioRecord.Builder()
                    .setAudioPlaybackCaptureConfig(config)
                    .setAudioFormat(audioFormat)
                    .setBufferSizeInBytes(bufSize)
                    .build();
                if (rec.getState() == AudioRecord.STATE_INITIALIZED) {
                    gameAudioRecord = rec;
                } else {
                    rec.release();
                }
            }

            if (wantMic && micPermGranted) {
                AudioRecord rec = new AudioRecord.Builder()
                    .setAudioSource(MediaRecorder.AudioSource.MIC)
                    .setAudioFormat(audioFormat)
                    .setBufferSizeInBytes(bufSize)
                    .build();
                if (rec.getState() == AudioRecord.STATE_INITIALIZED) {
                    micAudioRecord = rec;
                } else {
                    rec.release();
                }
            }

            // Fallback to mic on Android < 10 if Game Only selected without AudioPlaybackCapture support
            if (gameAudioRecord == null && micAudioRecord == null && micPermGranted) {
                AudioRecord rec = new AudioRecord.Builder()
                    .setAudioSource(MediaRecorder.AudioSource.MIC)
                    .setAudioFormat(audioFormat)
                    .setBufferSizeInBytes(bufSize)
                    .build();
                if (rec.getState() == AudioRecord.STATE_INITIALIZED) {
                    micAudioRecord = rec;
                } else {
                    rec.release();
                }
            }

            if (gameAudioRecord != null || micAudioRecord != null) {
                MediaFormat encFormat = MediaFormat.createAudioFormat(
                    MediaFormat.MIMETYPE_AUDIO_AAC,
                    AUDIO_SAMPLE_RATE,
                    2
                );
                encFormat.setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC);
                encFormat.setInteger(MediaFormat.KEY_BIT_RATE, AUDIO_BITRATE);
                encFormat.setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, bufSize);

                audioEncoder = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC);
                audioEncoder.configure(encFormat, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE);
                audioEncoder.start();

                if (gameAudioRecord != null) gameAudioRecord.startRecording();
                if (micAudioRecord != null) micAudioRecord.startRecording();

                audioLoopRunning.set(true);
                audioThread = new Thread(this::runAudioCaptureLoop, "ClipKaroAudioLoop");
                audioThread.start();
            }
        } catch (Exception ignored) {
            stopAudioPipelineOnly();
        }
    }

    private void restartAudioPipelineForMode() {
        exportExecutor.execute(() -> {
            startAudioPipeline();
        });
    }

    private void stopAudioPipelineOnly() {
        audioLoopRunning.set(false);
        if (audioThread != null) {
            try {
                audioThread.join(350);
            } catch (InterruptedException ignored) {
            }
            audioThread = null;
        }
        if (gameAudioRecord != null) {
            try {
                gameAudioRecord.stop();
            } catch (Exception ignored) {
            }
            try {
                gameAudioRecord.release();
            } catch (Exception ignored) {
            }
            gameAudioRecord = null;
        }
        if (micAudioRecord != null) {
            try {
                micAudioRecord.stop();
            } catch (Exception ignored) {
            }
            try {
                micAudioRecord.release();
            } catch (Exception ignored) {
            }
            micAudioRecord = null;
        }
        if (audioEncoder != null) {
            try {
                audioEncoder.stop();
            } catch (Exception ignored) {
            }
            try {
                audioEncoder.release();
            } catch (Exception ignored) {
            }
            audioEncoder = null;
        }
    }

    private void resetPauseTracking() {
        isRecordingPaused.set(false);
        pauseStartedMs = 0L;
        totalPausedMs = 0L;
        pausedVideoPtsOffsetUs = 0L;
        videoJustResumed = false;
        pausedAudioPtsOffsetUs = 0L;
        audioJustResumed = false;
    }

    private void startTimedClipRecording(int durationSec, boolean resetSequence) {
        if (isRecordingFull.get()) {
            finishFullGameplayRecording(true);
        }
        synchronized (muxerLock) {
            if (isRecordingTimed.get()) {
                closeTimedMuxerAndEnqueueSaveLocked(false);
            }
            resetPauseTracking();
            activeTimedDurationSec = Math.max(5, durationSec);
            if (resetSequence) {
                currentClipSequence = 1;
            }
            openNewTimedMuxerLocked();
            isRecordingTimed.set(true);
        }

        facecamPausedState = false;
        requestSyncFrame();
        mainHandler.removeCallbacks(uiTickerRunnable);
        mainHandler.post(uiTickerRunnable);
        updateBubbleVisuals(true, 0L, true);
        syncFacecamOverlayState();
        postStatusNotification(
            "Clipping Started - " + activeTimedDurationSec + " sec Clip",
            "● " + activeTimedDurationSec + " sec Clip · Tap CLIP button to Stop",
            true,
            true
        );
    }

    private void openNewTimedMuxerLocked() {
        String safeGame = activeGameName.replaceAll("[^A-Za-z0-9_]+", "_");
        timedTempFile = new File(
            getCacheDir(),
            String.format(
                Locale.US,
                "ClipKaro_%s_%ds_Clip%d_%d.mp4",
                safeGame, activeTimedDurationSec, currentClipSequence, System.currentTimeMillis()
            )
        );
        try {
            timedMuxer = new MediaMuxer(timedTempFile.getAbsolutePath(), MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);
            timedMuxerStarted = false;
            timedWaitingForKeyframe = true;
            timedVideoTrack = -1;
            timedAudioTrack = -1;
            timedStartMs = System.currentTimeMillis();
        } catch (IOException e) {
            timedMuxer = null;
            isRecordingTimed.set(false);
        }
    }

    private void closeTimedMuxerAndEnqueueSaveLocked(boolean saveToGallery) {
        if (timedMuxer != null) {
            try {
                if (timedMuxerStarted) timedMuxer.stop();
            } catch (Exception ignored) {
            }
            try {
                timedMuxer.release();
            } catch (Exception ignored) {
            }
            timedMuxer = null;
            timedMuxerStarted = false;
        }
        File finishedFile = timedTempFile;
        int clipNum = currentClipSequence;
        int durSec = activeTimedDurationSec;
        timedTempFile = null;

        if (finishedFile != null && finishedFile.exists()) {
            if (saveToGallery && finishedFile.length() > 2048) {
                exportExecutor.execute(() -> saveClipFileAndBroadcast(finishedFile, "Saved Clip #" + clipNum + " (" + durSec + "s)"));
            } else {
                //noinspection ResultOfMethodCallIgnored
                finishedFile.delete();
            }
        }
    }

    private void onTimedClipDurationReached() {
        if (!isRecordingTimed.get()) return;
        // Recording should NEVER stop automatically: save finished clip and immediately start next clip until STOP
        synchronized (muxerLock) {
            closeTimedMuxerAndEnqueueSaveLocked(true);
            currentClipSequence += 1;
            totalPausedMs = 0L;
            pausedVideoPtsOffsetUs = 0L;
            pausedAudioPtsOffsetUs = 0L;
            openNewTimedMuxerLocked();
            requestSyncFrame();
        }
    }

    private void startFullGameplayRecording() {
        if (isRecordingTimed.get()) {
            synchronized (muxerLock) {
                isRecordingTimed.set(false);
                closeTimedMuxerAndEnqueueSaveLocked(true);
            }
        }
        synchronized (muxerLock) {
            if (isRecordingFull.get()) return;
            resetPauseTracking();
            String safeGame = activeGameName.replaceAll("[^A-Za-z0-9_]+", "_");
            fullTempFile = new File(
                getCacheDir(),
                "ClipKaro_Full_" + safeGame + "_" + System.currentTimeMillis() + ".mp4"
            );
            try {
                fullMuxer = new MediaMuxer(fullTempFile.getAbsolutePath(), MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);
                fullMuxerStarted = false;
                fullWaitingForKeyframe = true;
                fullVideoTrack = -1;
                fullAudioTrack = -1;
                fullStartMs = System.currentTimeMillis();
                isRecordingFull.set(true);
                requestSyncFrame();
            } catch (IOException e) {
                fullMuxer = null;
                isRecordingFull.set(false);
            }
        }
        facecamPausedState = false;
        mainHandler.removeCallbacks(uiTickerRunnable);
        mainHandler.post(uiTickerRunnable);
        updateBubbleVisuals(true, 0L, true);
        syncFacecamOverlayState();
        postStatusNotification(
            "Clipping Started - Full Video",
            "● Full Video · Tap CLIP button to Stop",
            true,
            true
        );
    }

    private void finishFullGameplayRecording(boolean saveFile) {
        File finishedFile;
        synchronized (muxerLock) {
            if (!isRecordingFull.get()) return;
            isRecordingFull.set(false);
            if (fullMuxer != null) {
                try {
                    if (fullMuxerStarted) fullMuxer.stop();
                } catch (Exception ignored) {
                }
                try {
                    fullMuxer.release();
                } catch (Exception ignored) {
                }
                fullMuxer = null;
                fullMuxerStarted = false;
            }
            finishedFile = fullTempFile;
            fullTempFile = null;
        }

        if (finishedFile != null && finishedFile.exists()) {
            if (saveFile && finishedFile.length() > 2048) {
                exportExecutor.execute(() -> saveClipFileAndBroadcast(finishedFile, "Saved Full " + activeGameName + " gameplay"));
            } else {
                //noinspection ResultOfMethodCallIgnored
                finishedFile.delete();
            }
        }
    }

    private void pauseActiveRecording() {
        if ((!isRecordingTimed.get() && !isRecordingFull.get()) || isRecordingPaused.get()) {
            return;
        }
        pauseStartedMs = System.currentTimeMillis();
        isRecordingPaused.set(true);
        pauseFacecamOverlay();
        long frozenSec = getCurrentActiveElapsedSec();
        updateBubbleVisuals(true, frozenSec, true);
        updateExpandedRecordingTimer(frozenSec, true);
        postStatusNotification(
            "Recording Paused",
            String.format(Locale.US, "Paused at %02d:%02d · Tap Resume to continue", frozenSec / 60, frozenSec % 60),
            false,
            true
        );
    }

    private void resumeActiveRecording() {
        if ((!isRecordingTimed.get() && !isRecordingFull.get()) || !isRecordingPaused.get()) {
            return;
        }
        if (pauseStartedMs > 0L) {
            totalPausedMs += Math.max(0L, System.currentTimeMillis() - pauseStartedMs);
        }
        pauseStartedMs = 0L;
        videoJustResumed = true;
        audioJustResumed = true;
        isRecordingPaused.set(false);
        requestSyncFrame();
        resumeFacecamOverlay();
        long currentSec = getCurrentActiveElapsedSec();
        updateBubbleVisuals(true, currentSec, true);
        updateExpandedRecordingTimer(currentSec, true);
        postStatusNotification(
            "Recording Resumed",
            "● Continuing from " + String.format(Locale.US, "%02d:%02d", currentSec / 60, currentSec % 60),
            true,
            true
        );
    }

    private void stopActiveRecordingOnly() {
        stopActiveRecordingOnlyWithMessage(
            "Clipping Saved - My Clips me save ho gayi",
            "Saved to Movies/ClipKaro & My Clips"
        );
    }

    private void stopActiveRecordingOnlyWithMessage(String notifyTitle, String notifyBody) {
        boolean wasTimed = isRecordingTimed.get();
        boolean wasFull = isRecordingFull.get();
        resetPauseTracking();
        facecamPausedState = false;
        if (wasTimed) {
            synchronized (muxerLock) {
                isRecordingTimed.set(false);
                closeTimedMuxerAndEnqueueSaveLocked(true);
            }
        }
        if (wasFull) {
            finishFullGameplayRecording(true);
        }
        mainHandler.removeCallbacks(uiTickerRunnable);
        mainHandler.post(this::hideFacecamOverlay);
        updateBubbleVisuals(false, 0L, false);
        updateMenuStatusText();
        updateNotificationOnly();
        if (wasTimed || wasFull) {
            postStatusNotification(
                notifyTitle,
                notifyBody,
                false,
                true
            );
        }
    }

    private void requestSyncFrame() {
        if (videoEncoder != null) {
            try {
                Bundle sync = new Bundle();
                sync.putInt(MediaCodec.PARAMETER_KEY_REQUEST_SYNC_FRAME, 0);
                videoEncoder.setParameters(sync);
            } catch (Exception ignored) {
            }
        }
    }

    private void saveClipFileAndBroadcast(File tempFile, String toastLabel) {
        try {
            Uri savedUri = saveMp4ToMoviesGallery(tempFile, tempFile.getName());
            showToast(toastLabel + " → Movies/ClipKaro");
            Intent savedBroadcast = new Intent(ACTION_NATIVE_CLIP_SAVED);
            savedBroadcast.setPackage(getPackageName());
            savedBroadcast.putExtra(EXTRA_SAVED_FILE_NAME, tempFile.getName());
            if (savedUri != null) {
                savedBroadcast.putExtra(EXTRA_SAVED_URI, savedUri.toString());
            }
            sendBroadcast(savedBroadcast);
        } catch (IOException e) {
            showToast("Save failed: " + e.getMessage());
        } finally {
            //noinspection ResultOfMethodCallIgnored
            tempFile.delete();
        }
    }

    private void openNextHighlightSegmentLocked(long firstPtsUs) {
        closeCurrentHighlightSegmentLocked(true);
        if (latestVideoFormat == null || highlightBufferDir == null) return;
        try {
            File nextFile = new File(highlightBufferDir, "hl_" + (hlSegmentIndex++) + ".mp4");
            MediaMuxer muxer = new MediaMuxer(nextFile.getAbsolutePath(), MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);
            hlVideoTrack = muxer.addTrack(latestVideoFormat);
            hlAudioTrack = latestAudioFormat != null ? muxer.addTrack(latestAudioFormat) : -1;
            muxer.start();
            currentHighlightSegmentFile = nextFile;
            highlightMuxer = muxer;
            hlMuxerStarted = true;
            currentHlSegmentStartUs = firstPtsUs;
        } catch (IOException ignored) {
            highlightMuxer = null;
            hlMuxerStarted = false;
        }
    }

    private void closeCurrentHighlightSegmentLocked(boolean keepFile) {
        if (highlightMuxer != null) {
            try {
                if (hlMuxerStarted) highlightMuxer.stop();
            } catch (Exception ignored) {
            }
            try {
                highlightMuxer.release();
            } catch (Exception ignored) {
            }
            highlightMuxer = null;
            hlMuxerStarted = false;
        }
        if (currentHighlightSegmentFile != null) {
            if (keepFile && currentHighlightSegmentFile.exists() && currentHighlightSegmentFile.length() > 1024) {
                completedHighlightSegments.add(currentHighlightSegmentFile);
                while (completedHighlightSegments.size() > MAX_HIGHLIGHT_SEGMENTS) {
                    File oldest = completedHighlightSegments.remove(0);
                    //noinspection ResultOfMethodCallIgnored
                    oldest.delete();
                }
            } else {
                //noinspection ResultOfMethodCallIgnored
                currentHighlightSegmentFile.delete();
            }
            currentHighlightSegmentFile = null;
        }
        currentHlSegmentStartUs = -1L;
    }

    private void maybeTriggerAutoHighlight(String eventLabel) {
        if (!autoHighlightEnabled || !isCapturing.get()) return;
        long now = System.currentTimeMillis();
        if (now - captureStartedAtMs < 7000L) return;
        if (now - lastAutoHighlightSavedMs < HIGHLIGHT_COOLDOWN_MS) return;
        lastAutoHighlightSavedMs = now;
        exportExecutor.execute(() -> exportAutoHighlight15s(eventLabel));
    }

    private void exportAutoHighlight15s(String eventLabel) {
        try {
            requestSyncFrame();
            try {
                Thread.sleep(250);
            } catch (InterruptedException ignored) {
            }
            List<File> sourceFiles;
            synchronized (muxerLock) {
                closeCurrentHighlightSegmentLocked(true);
                int count = completedHighlightSegments.size();
                if (count == 0) return;
                int start = Math.max(0, count - 3);
                sourceFiles = new ArrayList<>(completedHighlightSegments.subList(start, count));
            }
            if (sourceFiles.isEmpty()) return;

            String safeGame = activeGameName.replaceAll("[^A-Za-z0-9_]+", "_");
            String fileName = String.format(
                Locale.US,
                "ClipKaro_AutoHighlight_%s_%s_15s_%d_%d.mp4",
                safeGame, eventLabel, highlightSequence++, System.currentTimeMillis()
            );
            File tempOut = new File(getCacheDir(), fileName);
            stitchHighlightSegments(sourceFiles, tempOut);
            if (tempOut.exists() && tempOut.length() > 2048) {
                saveClipFileAndBroadcast(tempOut, "Auto Highlight (" + eventLabel + " · 15s)");
            } else {
                //noinspection ResultOfMethodCallIgnored
                tempOut.delete();
            }
        } catch (Exception ignored) {
        }
    }

    private void saveReactionSelectedPart() {
        if (!isCapturing.get()) {
            showToast("Start recording first to save a Reaction Clip");
            return;
        }
        showToast("Saving selected Reaction Clip…");
        exportExecutor.execute(this::exportReactionSelectedPart);
    }

    private void exportReactionSelectedPart() {
        try {
            requestSyncFrame();
            try {
                Thread.sleep(300);
            } catch (InterruptedException ignored) {
            }
            List<File> sourceFiles;
            synchronized (muxerLock) {
                closeCurrentHighlightSegmentLocked(true);
                int count = completedHighlightSegments.size();
                if (count == 0) {
                    showToast("Keep recording a few seconds then tap Save Clip");
                    return;
                }
                int start = Math.max(0, count - 3);
                sourceFiles = new ArrayList<>(completedHighlightSegments.subList(start, count));
            }
            if (sourceFiles.isEmpty()) return;

            String safeGame = activeGameName.replaceAll("[^A-Za-z0-9_]+", "_");
            String fileName = String.format(
                Locale.US,
                "ClipKaro_Reaction_%s_Part_%d_%d.mp4",
                safeGame, highlightSequence++, System.currentTimeMillis()
            );
            File tempOut = new File(getCacheDir(), fileName);
            stitchHighlightSegments(sourceFiles, tempOut);
            if (tempOut.exists() && tempOut.length() > 2048) {
                saveClipFileAndBroadcast(tempOut, "Saved Reaction Clip (" + activeGameName + ")");
                postStatusNotification(
                    "Reaction Clip Saved!",
                    "Saved selected part with Facecam → Movies/ClipKaro",
                    false,
                    true
                );
            } else {
                //noinspection ResultOfMethodCallIgnored
                tempOut.delete();
            }
        } catch (Exception e) {
            showToast("Reaction save failed: " + e.getMessage());
        }
    }

    private void stitchHighlightSegments(List<File> segments, File outFile) throws IOException {
        MediaMuxer outMuxer = new MediaMuxer(outFile.getAbsolutePath(), MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);
        int outVideoTrack = -1;
        int outAudioTrack = -1;
        boolean muxerStarted = false;
        long totalVideoOffsetUs = 0L;
        long totalAudioOffsetUs = 0L;
        ByteBuffer buffer = ByteBuffer.allocate(1024 * 1024);
        MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();

        try {
            for (File seg : segments) {
                MediaExtractor extractor = new MediaExtractor();
                try {
                    extractor.setDataSource(seg.getAbsolutePath());
                    int srcVideo = -1;
                    int srcAudio = -1;
                    MediaFormat vFmt = null;
                    MediaFormat aFmt = null;
                    for (int i = 0; i < extractor.getTrackCount(); i++) {
                        MediaFormat fmt = extractor.getTrackFormat(i);
                        String mime = fmt.getString(MediaFormat.KEY_MIME);
                        if (mime != null && mime.startsWith("video/") && srcVideo < 0) {
                            srcVideo = i;
                            vFmt = fmt;
                        } else if (mime != null && mime.startsWith("audio/") && srcAudio < 0) {
                            srcAudio = i;
                            aFmt = fmt;
                        }
                    }
                    if (!muxerStarted) {
                        if (vFmt != null) outVideoTrack = outMuxer.addTrack(vFmt);
                        if (aFmt != null) outAudioTrack = outMuxer.addTrack(aFmt);
                        if (outVideoTrack >= 0 || outAudioTrack >= 0) {
                            outMuxer.start();
                            muxerStarted = true;
                        }
                    }
                    if (!muxerStarted) continue;

                    long segMaxVideoUs = 0L;
                    long segFirstVideoUs = -1L;
                    if (srcVideo >= 0 && outVideoTrack >= 0) {
                        extractor.selectTrack(srcVideo);
                        while (true) {
                            int size = extractor.readSampleData(buffer, 0);
                            if (size < 0) break;
                            long sampleTime = extractor.getSampleTime();
                            if (segFirstVideoUs < 0) segFirstVideoUs = sampleTime;
                            long relUs = Math.max(0L, sampleTime - segFirstVideoUs);
                            info.offset = 0;
                            info.size = size;
                            info.presentationTimeUs = totalVideoOffsetUs + relUs;
                            //noinspection WrongConstant
                            info.flags = extractor.getSampleFlags();
                            outMuxer.writeSampleData(outVideoTrack, buffer, info);
                            segMaxVideoUs = Math.max(segMaxVideoUs, relUs);
                            extractor.advance();
                        }
                        extractor.unselectTrack(srcVideo);
                    }

                    long segMaxAudioUs = 0L;
                    long segFirstAudioUs = -1L;
                    if (srcAudio >= 0 && outAudioTrack >= 0) {
                        extractor.selectTrack(srcAudio);
                        while (true) {
                            int size = extractor.readSampleData(buffer, 0);
                            if (size < 0) break;
                            long sampleTime = extractor.getSampleTime();
                            if (segFirstAudioUs < 0) segFirstAudioUs = sampleTime;
                            long relUs = Math.max(0L, sampleTime - segFirstAudioUs);
                            info.offset = 0;
                            info.size = size;
                            info.presentationTimeUs = totalAudioOffsetUs + relUs;
                            //noinspection WrongConstant
                            info.flags = extractor.getSampleFlags();
                            outMuxer.writeSampleData(outAudioTrack, buffer, info);
                            segMaxAudioUs = Math.max(segMaxAudioUs, relUs);
                            extractor.advance();
                        }
                        extractor.unselectTrack(srcAudio);
                    }

                    totalVideoOffsetUs += segMaxVideoUs + 33_333L;
                    totalAudioOffsetUs += Math.max(segMaxAudioUs, segMaxVideoUs) + 23_220L;
                } finally {
                    extractor.release();
                }
            }
        } finally {
            try {
                if (muxerStarted) outMuxer.stop();
            } catch (Exception ignored) {
            }
            outMuxer.release();
        }
    }

    private void runVideoDrainLoop() {
        MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
        while (isCapturing.get()) {
            try {
                int outIndex = videoEncoder.dequeueOutputBuffer(info, 10_000);
                if (outIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    synchronized (muxerLock) {
                        latestVideoFormat = videoEncoder.getOutputFormat();
                    }
                } else if (outIndex >= 0) {
                    ByteBuffer outBuf = videoEncoder.getOutputBuffer(outIndex);
                    if (outBuf != null && (info.flags & MediaCodec.BUFFER_FLAG_CODEC_CONFIG) == 0 && info.size > 0) {
                        boolean isKeyFrame = (info.flags & MediaCodec.BUFFER_FLAG_KEY_FRAME) != 0;
                        if (!isKeyFrame) {
                            avgPFrameBytes = avgPFrameBytes * 0.95 + info.size * 0.05;
                            long nowMs = System.currentTimeMillis();
                            if (autoHighlightEnabled
                                && (nowMs - lastAudioCombatPeakMs) <= 2200L
                                && info.size > avgPFrameBytes * 2.15) {
                                maybeTriggerAutoHighlight("Headshot");
                            }
                        }

                        synchronized (muxerLock) {
                            if (autoHighlightEnabled || reactionModeEnabled) {
                                if (currentHlSegmentStartUs > 0
                                    && (info.presentationTimeUs - currentHlSegmentStartUs) >= HIGHLIGHT_SEGMENT_DURATION_MS * 1000L
                                    && isKeyFrame) {
                                    openNextHighlightSegmentLocked(info.presentationTimeUs);
                                } else if (!hlMuxerStarted && isKeyFrame) {
                                    openNextHighlightSegmentLocked(info.presentationTimeUs);
                                }
                                if (hlMuxerStarted && highlightMuxer != null && hlVideoTrack >= 0) {
                                    outBuf.position(info.offset);
                                    outBuf.limit(info.offset + info.size);
                                    highlightMuxer.writeSampleData(hlVideoTrack, outBuf, info);
                                }
                            }

                            if (!isRecordingPaused.get()) {
                                if (videoJustResumed && lastRawVideoPtsUs > 0L) {
                                    pausedVideoPtsOffsetUs += Math.max(0L, info.presentationTimeUs - lastRawVideoPtsUs - 33_333L);
                                    videoJustResumed = false;
                                }
                                lastRawVideoPtsUs = info.presentationTimeUs;
                                MediaCodec.BufferInfo adjInfo = new MediaCodec.BufferInfo();
                                adjInfo.set(
                                    info.offset,
                                    info.size,
                                    Math.max(0L, info.presentationTimeUs - pausedVideoPtsOffsetUs),
                                    info.flags
                                );

                                if (isRecordingTimed.get() && timedMuxer != null) {
                                    if (!timedMuxerStarted && isKeyFrame && latestVideoFormat != null) {
                                        timedVideoTrack = timedMuxer.addTrack(latestVideoFormat);
                                        timedAudioTrack = latestAudioFormat != null ? timedMuxer.addTrack(latestAudioFormat) : -1;
                                        timedMuxer.start();
                                        timedMuxerStarted = true;
                                        timedWaitingForKeyframe = false;
                                    }
                                    if (timedMuxerStarted && !timedWaitingForKeyframe && timedVideoTrack >= 0) {
                                        outBuf.position(adjInfo.offset);
                                        outBuf.limit(adjInfo.offset + adjInfo.size);
                                        timedMuxer.writeSampleData(timedVideoTrack, outBuf, adjInfo);
                                    }
                                }

                                if (isRecordingFull.get() && fullMuxer != null) {
                                    if (!fullMuxerStarted && isKeyFrame && latestVideoFormat != null) {
                                        fullVideoTrack = fullMuxer.addTrack(latestVideoFormat);
                                        fullAudioTrack = latestAudioFormat != null ? fullMuxer.addTrack(latestAudioFormat) : -1;
                                        fullMuxer.start();
                                        fullMuxerStarted = true;
                                        fullWaitingForKeyframe = false;
                                    }
                                    if (fullMuxerStarted && !fullWaitingForKeyframe && fullVideoTrack >= 0) {
                                        outBuf.position(adjInfo.offset);
                                        outBuf.limit(adjInfo.offset + adjInfo.size);
                                        fullMuxer.writeSampleData(fullVideoTrack, outBuf, adjInfo);
                                    }
                                }
                            }
                        }
                    }
                    videoEncoder.releaseOutputBuffer(outIndex, false);
                }
            } catch (Exception e) {
                if (!isCapturing.get()) break;
            }
        }
    }

    private void runAudioCaptureLoop() {
        final int frameBytes = 4096;
        byte[] gamePcm = new byte[frameBytes];
        byte[] micPcm = new byte[frameBytes];
        byte[] mixedPcm = new byte[frameBytes];
        MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
        long startNano = System.nanoTime();

        while (isCapturing.get() && audioLoopRunning.get() && audioEncoder != null) {
            try {
                int readGame = (gameAudioRecord != null) ? gameAudioRecord.read(gamePcm, 0, frameBytes) : 0;
                int readMic = (micAudioRecord != null) ? micAudioRecord.read(micPcm, 0, frameBytes) : 0;
                if (readMic > 0 && !VOICE_NORMAL.equals(selectedVoiceEffect)) {
                    applyVoiceChangerToMicPcm(micPcm, readMic, selectedVoiceEffect);
                }
                int bytesToEncode = Math.max(readGame, readMic);

                if (bytesToEncode > 0) {
                    byte[] payload;
                    if (readGame > 0 && readMic > 0) {
                        // Mix 16-bit PCM game audio + microphone voice cleanly
                        int minLen = Math.min(readGame, readMic);
                        for (int i = 0; i + 1 < bytesToEncode; i += 2) {
                            int g = (i < minLen || i + 1 < readGame)
                                ? (short) ((gamePcm[i] & 0xff) | (gamePcm[i + 1] << 8))
                                : 0;
                            int m = (i + 1 < readMic)
                                ? (short) ((micPcm[i] & 0xff) | (micPcm[i + 1] << 8))
                                : 0;
                            int sum = Math.max(-32768, Math.min(32767, g + m));
                            mixedPcm[i] = (byte) (sum & 0xff);
                            mixedPcm[i + 1] = (byte) ((sum >> 8) & 0xff);
                        }
                        payload = mixedPcm;
                    } else if (readGame > 0) {
                        payload = gamePcm;
                    } else {
                        payload = micPcm;
                    }

                    // Measure gunfire / knock / kill sound impact peak for Auto Highlight (15s)
                    if (autoHighlightEnabled) {
                        int peak = 0;
                        for (int i = 0; i + 1 < bytesToEncode; i += 8) {
                            int sample = Math.abs((short) ((payload[i] & 0xff) | (payload[i + 1] << 8)));
                            if (sample > peak) peak = sample;
                        }
                        if (peak > 22000) {
                            lastAudioCombatPeakMs = System.currentTimeMillis();
                        }
                    }

                    int inIndex = audioEncoder.dequeueInputBuffer(5000);
                    if (inIndex >= 0) {
                        ByteBuffer inBuf = audioEncoder.getInputBuffer(inIndex);
                        if (inBuf != null) {
                            inBuf.clear();
                            int count = Math.min(bytesToEncode, inBuf.capacity());
                            inBuf.put(payload, 0, count);
                            long ptsUs = (System.nanoTime() - startNano) / 1000L;
                            audioEncoder.queueInputBuffer(inIndex, 0, count, ptsUs, 0);
                        }
                    }
                }

                int outIndex = audioEncoder.dequeueOutputBuffer(info, 0);
                while (outIndex >= 0 || outIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    if (outIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                        synchronized (muxerLock) {
                            latestAudioFormat = audioEncoder.getOutputFormat();
                        }
                    } else if (outIndex >= 0) {
                        ByteBuffer outBuf = audioEncoder.getOutputBuffer(outIndex);
                        if (outBuf != null && (info.flags & MediaCodec.BUFFER_FLAG_CODEC_CONFIG) == 0 && info.size > 0) {
                            synchronized (muxerLock) {
                                if ((autoHighlightEnabled || reactionModeEnabled)
                                    && hlMuxerStarted && highlightMuxer != null && hlAudioTrack >= 0) {
                                    outBuf.position(info.offset);
                                    outBuf.limit(info.offset + info.size);
                                    highlightMuxer.writeSampleData(hlAudioTrack, outBuf, info);
                                }
                                if (!isRecordingPaused.get()) {
                                    if (audioJustResumed && lastRawAudioPtsUs > 0L) {
                                        pausedAudioPtsOffsetUs += Math.max(0L, info.presentationTimeUs - lastRawAudioPtsUs - 23_220L);
                                        audioJustResumed = false;
                                    }
                                    lastRawAudioPtsUs = info.presentationTimeUs;
                                    MediaCodec.BufferInfo adjAudio = new MediaCodec.BufferInfo();
                                    adjAudio.set(
                                        info.offset,
                                        info.size,
                                        Math.max(0L, info.presentationTimeUs - pausedAudioPtsOffsetUs),
                                        info.flags
                                    );
                                    if (isRecordingTimed.get() && timedMuxerStarted && timedMuxer != null && timedAudioTrack >= 0) {
                                        outBuf.position(adjAudio.offset);
                                        outBuf.limit(adjAudio.offset + adjAudio.size);
                                        timedMuxer.writeSampleData(timedAudioTrack, outBuf, adjAudio);
                                    }
                                    if (isRecordingFull.get() && fullMuxerStarted && fullMuxer != null && fullAudioTrack >= 0) {
                                        outBuf.position(adjAudio.offset);
                                        outBuf.limit(adjAudio.offset + adjAudio.size);
                                        fullMuxer.writeSampleData(fullAudioTrack, outBuf, adjAudio);
                                    }
                                }
                            }
                        }
                        audioEncoder.releaseOutputBuffer(outIndex, false);
                    }
                    outIndex = audioEncoder.dequeueOutputBuffer(info, 0);
                }
            } catch (Exception e) {
                if (!audioLoopRunning.get() || !isCapturing.get()) break;
            }
        }
    }

    @Nullable
    private Uri saveMp4ToMoviesGallery(File sourceFile, String displayName) throws IOException {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            ContentResolver resolver = getContentResolver();
            ContentValues values = new ContentValues();
            values.put(MediaStore.Video.Media.DISPLAY_NAME, displayName);
            values.put(MediaStore.Video.Media.MIME_TYPE, "video/mp4");
            values.put(
                MediaStore.Video.Media.RELATIVE_PATH,
                Environment.DIRECTORY_MOVIES + "/ClipKaro"
            );
            values.put(MediaStore.Video.Media.IS_PENDING, 1);

            Uri uri = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values);
            if (uri == null) {
                throw new IOException("MediaStore insert failed");
            }

            try (OutputStream out = resolver.openOutputStream(uri);
                 FileInputStream in = new FileInputStream(sourceFile)) {
                if (out == null) throw new IOException("Output stream unavailable");
                byte[] buf = new byte[16384];
                int n;
                while ((n = in.read(buf)) != -1) {
                    out.write(buf, 0, n);
                }
            }

            values.clear();
            values.put(MediaStore.Video.Media.IS_PENDING, 0);
            resolver.update(uri, values, null, null);
            return uri;
        } else {
            File moviesDir = new File(
                Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES),
                "ClipKaro"
            );
            if (!moviesDir.exists()) {
                //noinspection ResultOfMethodCallIgnored
                moviesDir.mkdirs();
            }
            File dest = new File(moviesDir, displayName);
            try (FileInputStream in = new FileInputStream(sourceFile);
                 OutputStream out = new java.io.FileOutputStream(dest)) {
                byte[] buf = new byte[16384];
                int n;
                while ((n = in.read(buf)) != -1) {
                    out.write(buf, 0, n);
                }
            }
            MediaScannerConnection.scanFile(
                this,
                new String[]{dest.getAbsolutePath()},
                new String[]{"video/mp4"},
                null
            );
            return Uri.fromFile(dest);
        }
    }

    private void stopCapturePipelineKeepProjection() {
        stopActiveRecordingOnly();
        isCapturing.set(false);
        capturingForAppKey = "";
        stopAudioPipelineOnly();
        synchronized (muxerLock) {
            closeCurrentHighlightSegmentLocked(false);
            for (File seg : completedHighlightSegments) {
                //noinspection ResultOfMethodCallIgnored
                seg.delete();
            }
            completedHighlightSegments.clear();
        }

        if (virtualDisplay != null) {
            virtualDisplay.release();
            virtualDisplay = null;
        }
        if (encoderSurface != null) {
            encoderSurface.release();
            encoderSurface = null;
        }
        if (videoEncoder != null) {
            try {
                videoEncoder.stop();
            } catch (Exception ignored) {
            }
            try {
                videoEncoder.release();
            } catch (Exception ignored) {
            }
            videoEncoder = null;
        }
    }

    private void applyVoiceChangerToMicPcm(byte[] micPcm, int byteCount, String preset) {
        int stereoFrames = byteCount / 4;
        if (stereoFrames <= 2) return;

        if (VOICE_ROBOT.equals(preset)) {
            double stepRad = (2.0 * Math.PI * 58.0) / AUDIO_SAMPLE_RATE;
            for (int f = 0; f < stereoFrames; f++) {
                float mod = (float) (0.58 + 0.42 * Math.sin(voiceRobotPhaseRad));
                voiceRobotPhaseRad += stepRad;
                if (voiceRobotPhaseRad > Math.PI * 2.0) {
                    voiceRobotPhaseRad -= Math.PI * 2.0;
                }
                int idx = f * 4;
                short l = (short) ((micPcm[idx] & 0xff) | (micPcm[idx + 1] << 8));
                short r = (short) ((micPcm[idx + 2] & 0xff) | (micPcm[idx + 3] << 8));
                int ql = (Math.round(l * mod) >> 9) << 9;
                int qr = (Math.round(r * mod) >> 9) << 9;
                ql = Math.max(-32768, Math.min(32767, ql));
                qr = Math.max(-32768, Math.min(32767, qr));
                micPcm[idx] = (byte) (ql & 0xff);
                micPcm[idx + 1] = (byte) ((ql >> 8) & 0xff);
                micPcm[idx + 2] = (byte) (qr & 0xff);
                micPcm[idx + 3] = (byte) ((qr >> 8) & 0xff);
            }
            return;
        }

        // Pitch-shift resampling for Funny (1.38x) and Deep (0.72x + lowpass warmth)
        float ratio = VOICE_FUNNY.equals(preset) ? 1.38f : 0.72f;
        short[] monoIn = new short[stereoFrames];
        for (int f = 0; f < stereoFrames; f++) {
            int idx = f * 4;
            int l = (short) ((micPcm[idx] & 0xff) | (micPcm[idx + 1] << 8));
            int r = (short) ((micPcm[idx + 2] & 0xff) | (micPcm[idx + 3] << 8));
            monoIn[f] = (short) ((l + r) / 2);
        }
        int windowLen = Math.max(16, stereoFrames / 2);
        for (int f = 0; f < stereoFrames; f++) {
            float pos = (f * ratio) % stereoFrames;
            int i0 = Math.max(0, Math.min(stereoFrames - 1, (int) pos));
            int i1 = Math.min(stereoFrames - 1, i0 + 1);
            float frac = pos - (int) pos;
            float val = monoIn[i0] * (1f - frac) + monoIn[i1] * frac;
            if (VOICE_DEEP.equals(preset)) {
                voiceDeepLpState = voiceDeepLpState * 0.42f + val * 0.58f;
                val = voiceDeepLpState * 1.15f;
            }
            int edge = Math.min(f, stereoFrames - 1 - f);
            if (edge < 8 && windowLen > 16) {
                float fade = edge / 8f;
                val = val * fade + monoIn[f] * (1f - fade);
            }
            int sample = Math.max(-32768, Math.min(32767, Math.round(val)));
            int idx = f * 4;
            byte lo = (byte) (sample & 0xff);
            byte hi = (byte) ((sample >> 8) & 0xff);
            micPcm[idx] = lo;
            micPcm[idx + 1] = hi;
            micPcm[idx + 2] = lo;
            micPcm[idx + 3] = hi;
        }
    }

    private void syncFacecamOverlayState() {
        mainHandler.post(() -> {
            boolean activelyRecording = isRecordingTimed.get() || isRecordingFull.get();
            if (!bubbleSuppressed && activelyRecording && isFacecamActiveSelected()) {
                showFacecamOverlay();
            } else {
                hideFacecamOverlay();
            }
        });
    }

    private void pauseFacecamOverlay() {
        facecamPausedState = true;
        mainHandler.post(() -> {
            if (facecamRedDot != null) {
                GradientDrawable dBg = new GradientDrawable();
                dBg.setShape(GradientDrawable.OVAL);
                dBg.setColor(Color.parseColor("#FACC15"));
                facecamRedDot.setBackground(dBg);
            }
            if (facecamPausedTv != null) {
                facecamPausedTv.setVisibility(View.VISIBLE);
            }
            if (cameraCaptureSession != null) {
                try {
                    cameraCaptureSession.stopRepeating();
                } catch (Exception ignored) {
                }
            }
        });
    }

    private void resumeFacecamOverlay() {
        facecamPausedState = false;
        mainHandler.post(() -> {
            if (!isFacecamActiveSelected() || (!isRecordingTimed.get() && !isRecordingFull.get())) {
                hideFacecamOverlay();
                return;
            }
            if (facecamRootView == null) {
                showFacecamOverlay();
                return;
            }
            if (facecamRedDot != null) {
                GradientDrawable dBg = new GradientDrawable();
                dBg.setShape(GradientDrawable.OVAL);
                dBg.setColor(Color.parseColor("#FF1E2D"));
                facecamRedDot.setBackground(dBg);
            }
            if (facecamPausedTv != null) {
                facecamPausedTv.setVisibility(View.GONE);
            }
            if (cameraDevice != null && cameraCaptureSession != null
                && facecamTextureView != null && facecamTextureView.isAvailable()) {
                try {
                    Surface previewSurface = new Surface(facecamTextureView.getSurfaceTexture());
                    CaptureRequest.Builder builder =
                        cameraDevice.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW);
                    builder.addTarget(previewSurface);
                    builder.set(
                        CaptureRequest.CONTROL_AF_MODE,
                        CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_VIDEO
                    );
                    cameraCaptureSession.setRepeatingRequest(builder.build(), null, cameraBgHandler);
                } catch (Exception ignored) {
                    openFrontCameraPreview(
                        facecamTextureView.getSurfaceTexture(),
                        facecamTextureView.getWidth(),
                        facecamTextureView.getHeight()
                    );
                }
            } else if (facecamTextureView != null && facecamTextureView.isAvailable()) {
                openFrontCameraPreview(
                    facecamTextureView.getSurfaceTexture(),
                    facecamTextureView.getWidth(),
                    facecamTextureView.getHeight()
                );
            }
        });
    }

    @SuppressLint("ClickableViewAccessibility")
    private void showFacecamOverlay() {
        if (windowManager == null) return;
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
            != PackageManager.PERMISSION_GRANTED) {
            return;
        }
        if (facecamRootView != null) {
            if (facecamSaveClipBtn != null) {
                facecamSaveClipBtn.setVisibility(
                    (reactionModeEnabled && (isRecordingTimed.get() || isRecordingFull.get()))
                        ? View.VISIBLE
                        : View.GONE
                );
            }
            return;
        }

        int overlayType = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
            ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            : WindowManager.LayoutParams.TYPE_PHONE;

        DisplayMetrics dm = getResources().getDisplayMetrics();
        int circlePx = dp(facecamSizeDp);

        facecamParams = new WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        );
        facecamParams.gravity = Gravity.TOP | Gravity.START;
        facecamParams.x = Math.max(dp(12), dm.widthPixels - circlePx - dp(16));
        facecamParams.y = dp(90);

        facecamRootView = new LinearLayout(this);
        facecamRootView.setOrientation(LinearLayout.VERTICAL);
        facecamRootView.setGravity(Gravity.CENTER_HORIZONTAL);

        facecamCircleFrame = new FrameLayout(this);
        facecamCircleFrame.setElevation(dp(10));
        facecamCircleFrame.setOutlineProvider(new ViewOutlineProvider() {
            @Override
            public void getOutline(View view, Outline outline) {
                outline.setOval(0, 0, view.getWidth(), view.getHeight());
            }
        });
        facecamCircleFrame.setClipToOutline(true);

        facecamTextureView = new TextureView(this);
        facecamCircleFrame.addView(facecamTextureView, new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.MATCH_PARENT
        ));

        // Circular accent border ring
        View borderRing = new View(this);
        GradientDrawable ringBg = new GradientDrawable();
        ringBg.setShape(GradientDrawable.OVAL);
        ringBg.setColor(Color.TRANSPARENT);
        ringBg.setStroke(dp(3), Color.parseColor(reactionModeEnabled ? "#F43F5E" : "#34D399"));
        borderRing.setBackground(ringBg);
        facecamCircleFrame.addView(borderRing, new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.MATCH_PARENT
        ));

        // RED dot on Facecam while recording (turns yellow when paused)
        facecamRedDot = new View(this);
        GradientDrawable recDotBg = new GradientDrawable();
        recDotBg.setShape(GradientDrawable.OVAL);
        recDotBg.setColor(Color.parseColor(facecamPausedState ? "#FACC15" : "#FF1E2D"));
        recDotBg.setStroke(dp(1), Color.WHITE);
        facecamRedDot.setBackground(recDotBg);
        FrameLayout.LayoutParams dotOverlayLp = new FrameLayout.LayoutParams(dp(10), dp(10));
        dotOverlayLp.gravity = Gravity.TOP | Gravity.CENTER_HORIZONTAL;
        dotOverlayLp.topMargin = dp(6);
        facecamCircleFrame.addView(facecamRedDot, dotOverlayLp);

        // PAUSED badge shown on Facecam when recording is paused
        facecamPausedTv = new TextView(this);
        facecamPausedTv.setText("PAUSED");
        facecamPausedTv.setTextColor(Color.parseColor("#0B0E14"));
        facecamPausedTv.setTextSize(9);
        facecamPausedTv.setTypeface(Typeface.DEFAULT_BOLD);
        facecamPausedTv.setPadding(dp(6), dp(2), dp(6), dp(2));
        GradientDrawable pausedBg = new GradientDrawable();
        pausedBg.setColor(Color.parseColor("#FACC15"));
        pausedBg.setCornerRadius(dp(8));
        facecamPausedTv.setBackground(pausedBg);
        facecamPausedTv.setVisibility(facecamPausedState ? View.VISIBLE : View.GONE);
        FrameLayout.LayoutParams pausedLp = new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT,
            FrameLayout.LayoutParams.WRAP_CONTENT
        );
        pausedLp.gravity = Gravity.CENTER;
        facecamCircleFrame.addView(facecamPausedTv, pausedLp);

        // Tap-to-resize corner badge (96dp -> 120dp -> 156dp)
        TextView resizeBadge = new TextView(this);
        resizeBadge.setText("⤢");
        resizeBadge.setTextColor(Color.WHITE);
        resizeBadge.setTextSize(10);
        resizeBadge.setGravity(Gravity.CENTER);
        GradientDrawable badgeBg = new GradientDrawable();
        badgeBg.setShape(GradientDrawable.OVAL);
        badgeBg.setColor(Color.parseColor("#CC0F172A"));
        badgeBg.setStroke(dp(1), Color.parseColor("#94A3B8"));
        resizeBadge.setBackground(badgeBg);
        FrameLayout.LayoutParams rLp = new FrameLayout.LayoutParams(dp(22), dp(22));
        rLp.gravity = Gravity.BOTTOM | Gravity.END;
        rLp.setMargins(0, 0, dp(6), dp(6));
        resizeBadge.setOnClickListener(v -> cycleFacecamSize());
        facecamCircleFrame.addView(resizeBadge, rLp);

        facecamRootView.addView(facecamCircleFrame, new LinearLayout.LayoutParams(circlePx, circlePx));

        // Draggable touch listener on circular Facecam frame
        facecamCircleFrame.setOnTouchListener(new View.OnTouchListener() {
            private int initialX;
            private int initialY;
            private float downX;
            private float downY;

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                DisplayMetrics metrics = getResources().getDisplayMetrics();
                switch (event.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        initialX = facecamParams.x;
                        initialY = facecamParams.y;
                        downX = event.getRawX();
                        downY = event.getRawY();
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        float dx = event.getRawX() - downX;
                        float dy = event.getRawY() - downY;
                        int curPx = dp(facecamSizeDp);
                        int maxX = Math.max(0, metrics.widthPixels - curPx);
                        int maxY = Math.max(0, metrics.heightPixels - curPx);
                        facecamParams.x = Math.max(0, Math.min(maxX, Math.round(initialX + dx)));
                        facecamParams.y = Math.max(dp(20), Math.min(maxY, Math.round(initialY + dy)));
                        if (facecamRootView != null && windowManager != null) {
                            windowManager.updateViewLayout(facecamRootView, facecamParams);
                        }
                        return true;
                    default:
                        return false;
                }
            }
        });

        // Reaction Mode quick "Save Clip" chip right under the Facecam circle
        facecamSaveClipBtn = createCircularGridButton("Save Clip", "#E11D48", "#FFFFFF");
        LinearLayout.LayoutParams saveLp = new LinearLayout.LayoutParams(dp(86), dp(26));
        saveLp.topMargin = dp(4);
        facecamSaveClipBtn.setVisibility(
            (reactionModeEnabled && (isRecordingTimed.get() || isRecordingFull.get() || isCapturing.get()))
                ? View.VISIBLE
                : View.GONE
        );
        facecamSaveClipBtn.setOnClickListener(v -> saveReactionSelectedPart());
        facecamRootView.addView(facecamSaveClipBtn, saveLp);

        facecamTextureView.setSurfaceTextureListener(new TextureView.SurfaceTextureListener() {
            @Override
            public void onSurfaceTextureAvailable(@NonNull SurfaceTexture surface, int width, int height) {
                openFrontCameraPreview(surface, width, height);
            }

            @Override
            public void onSurfaceTextureSizeChanged(@NonNull SurfaceTexture surface, int width, int height) {
                configureFacecamTransform(width, height);
            }

            @Override
            public boolean onSurfaceTextureDestroyed(@NonNull SurfaceTexture surface) {
                closeCameraOnly();
                return true;
            }

            @Override
            public void onSurfaceTextureUpdated(@NonNull SurfaceTexture surface) {
            }
        });

        try {
            windowManager.addView(facecamRootView, facecamParams);
        } catch (Exception ignored) {
            facecamRootView = null;
        }
    }

    private void cycleFacecamSize() {
        if (facecamSizeDp == 120) {
            facecamSizeDp = 156;
        } else if (facecamSizeDp == 156) {
            facecamSizeDp = 96;
        } else {
            facecamSizeDp = 120;
        }
        if (facecamCircleFrame != null) {
            int px = dp(facecamSizeDp);
            LinearLayout.LayoutParams lp = (LinearLayout.LayoutParams) facecamCircleFrame.getLayoutParams();
            lp.width = px;
            lp.height = px;
            facecamCircleFrame.setLayoutParams(lp);
            facecamCircleFrame.invalidateOutline();
        }
        updateMenuStatusText();
        showToast("Facecam size: " + facecamSizeDp + "dp");
    }

    private void configureFacecamTransform(int viewW, int viewH) {
        if (facecamTextureView == null || viewW <= 0 || viewH <= 0) return;
        Matrix matrix = new Matrix();
        float cx = viewW / 2f;
        float cy = viewH / 2f;
        float previewW = cameraPreviewSize.getHeight();
        float previewH = cameraPreviewSize.getWidth();
        if (previewW > 0f && previewH > 0f) {
            float scale = Math.max(viewW / previewW, viewH / previewH);
            float sx = (scale * previewW) / viewW;
            float sy = (scale * previewH) / viewH;
            matrix.setScale(sx, sy, cx, cy);
        }
        facecamTextureView.setTransform(matrix);
    }

    @SuppressLint("MissingPermission")
    private void openFrontCameraPreview(SurfaceTexture surfaceTexture, int viewW, int viewH) {
        closeCameraOnly();
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
            != PackageManager.PERMISSION_GRANTED) {
            return;
        }
        try {
            cameraBgThread = new HandlerThread("ClipKaroFacecamThread");
            cameraBgThread.start();
            cameraBgHandler = new Handler(cameraBgThread.getLooper());

            CameraManager cm = (CameraManager) getSystemService(Context.CAMERA_SERVICE);
            if (cm == null) return;

            String chosenId = null;
            for (String id : cm.getCameraIdList()) {
                CameraCharacteristics chars = cm.getCameraCharacteristics(id);
                Integer facing = chars.get(CameraCharacteristics.LENS_FACING);
                if (facing != null && facing == CameraCharacteristics.LENS_FACING_FRONT) {
                    chosenId = id;
                    break;
                }
            }
            if (chosenId == null && cm.getCameraIdList().length > 0) {
                chosenId = cm.getCameraIdList()[0];
            }
            if (chosenId == null) return;

            CameraCharacteristics chars = cm.getCameraCharacteristics(chosenId);
            StreamConfigurationMap map = chars.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP);
            if (map != null) {
                Size[] choices = map.getOutputSizes(SurfaceTexture.class);
                if (choices != null && choices.length > 0) {
                    Size best = choices[0];
                    for (Size s : choices) {
                        if (s.getWidth() >= 320 && s.getWidth() <= 720) {
                            best = s;
                            break;
                        }
                    }
                    cameraPreviewSize = best;
                }
            }
            surfaceTexture.setDefaultBufferSize(cameraPreviewSize.getWidth(), cameraPreviewSize.getHeight());
            mainHandler.post(() -> configureFacecamTransform(viewW, viewH));

            cm.openCamera(chosenId, new CameraDevice.StateCallback() {
                @Override
                public void onOpened(@NonNull CameraDevice camera) {
                    cameraDevice = camera;
                    try {
                        Surface previewSurface = new Surface(surfaceTexture);
                        CaptureRequest.Builder builder =
                            camera.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW);
                        builder.addTarget(previewSurface);
                        camera.createCaptureSession(
                            Collections.singletonList(previewSurface),
                            new CameraCaptureSession.StateCallback() {
                                @Override
                                public void onConfigured(@NonNull CameraCaptureSession session) {
                                    if (cameraDevice == null) return;
                                    cameraCaptureSession = session;
                                    try {
                                        builder.set(
                                            CaptureRequest.CONTROL_AF_MODE,
                                            CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_VIDEO
                                        );
                                        session.setRepeatingRequest(builder.build(), null, cameraBgHandler);
                                    } catch (Exception ignored) {
                                    }
                                }

                                @Override
                                public void onConfigureFailed(@NonNull CameraCaptureSession session) {
                                }
                            },
                            cameraBgHandler
                        );
                    } catch (Exception ignored) {
                        closeCameraOnly();
                    }
                }

                @Override
                public void onDisconnected(@NonNull CameraDevice camera) {
                    camera.close();
                    cameraDevice = null;
                }

                @Override
                public void onError(@NonNull CameraDevice camera, int error) {
                    camera.close();
                    cameraDevice = null;
                }
            }, cameraBgHandler);
        } catch (Exception ignored) {
            closeCameraOnly();
        }
    }

    private void closeCameraOnly() {
        if (cameraCaptureSession != null) {
            try {
                cameraCaptureSession.close();
            } catch (Exception ignored) {
            }
            cameraCaptureSession = null;
        }
        if (cameraDevice != null) {
            try {
                cameraDevice.close();
            } catch (Exception ignored) {
            }
            cameraDevice = null;
        }
        if (cameraBgThread != null) {
            cameraBgThread.quitSafely();
            try {
                cameraBgThread.join(250);
            } catch (InterruptedException ignored) {
            }
            cameraBgThread = null;
            cameraBgHandler = null;
        }
    }

    private void hideFacecamOverlay() {
        closeCameraOnly();
        facecamPausedState = false;
        if (facecamRootView != null && windowManager != null) {
            try {
                windowManager.removeView(facecamRootView);
            } catch (IllegalArgumentException ignored) {
            }
            facecamRootView = null;
            facecamCircleFrame = null;
            facecamTextureView = null;
            facecamRedDot = null;
            facecamPausedTv = null;
            facecamSaveClipBtn = null;
        }
    }

    private void stopCapturePipeline() {
        stopCapturePipelineKeepProjection();
        mediaProjection = null;
    }

    private void stopEverythingAndSelf() {
        bubbleSuppressed = true;
        stopForegroundMonitor();
        mainHandler.removeCallbacks(uiTickerRunnable);
        hideTopNotificationPopup();
        hideLongPressPopupMenu();
        hideFloatingMenu();
        hideFacecamOverlay();
        if (bubbleView != null && windowManager != null) {
            try {
                windowManager.removeView(bubbleView);
            } catch (IllegalArgumentException ignored) {
            }
            bubbleView = null;
        }
        stopCapturePipeline();
        stopForeground(STOP_FOREGROUND_REMOVE);
        stopSelf();
    }

    @Override
    public void onTaskRemoved(Intent rootIntent) {
        if (isRecordingTimed.get() || isRecordingFull.get()) {
            stopActiveRecordingOnlyWithMessage(
                "Clipping Saved - My Clips me save ho gayi",
                "ClipKaro closed · Saved to Movies/ClipKaro & My Clips"
            );
        }
        stopEverythingAndSelf();
        super.onTaskRemoved(rootIntent);
    }

    private void showToast(String message) {
        mainHandler.post(() -> Toast.makeText(getApplicationContext(), message, Toast.LENGTH_SHORT).show());
    }

    @Override
    public void onDestroy() {
        isServiceRunning = false;
        stopForegroundMonitor();
        mainHandler.removeCallbacks(uiTickerRunnable);
        hideTopNotificationPopup();
        hideLongPressPopupMenu();
        hideFloatingMenu();
        hideFacecamOverlay();
        if (bubbleView != null && windowManager != null) {
            try {
                windowManager.removeView(bubbleView);
            } catch (IllegalArgumentException ignored) {
            }
            bubbleView = null;
        }
        stopCapturePipeline();
        for (PerAppProjectionEntry entry : perAppProjectionMap.values()) {
            if (entry != null && entry.mediaProjection != null) {
                try {
                    entry.mediaProjection.stop();
                } catch (Exception ignored) {
                }
            }
        }
        perAppProjectionMap.clear();
        exportExecutor.shutdown();
        super.onDestroy();
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
`,"/android/app/src/main/java/com/clipkaro/app/MainActivity.java":`package com.clipkaro.app;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AppOpsManager;
import android.app.usage.UsageEvents;
import android.app.usage.UsageStatsManager;
import android.content.BroadcastReceiver;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Color;
import android.media.MediaScannerConnection;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.PowerManager;
import android.provider.MediaStore;
import android.provider.Settings;
import android.util.Base64;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import androidx.webkit.WebViewAssetLoader;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    public static final String EXTRA_REQUEST_PROJECTION_GAME = "request_projection_game";
    public static volatile boolean isActivityInForeground = false;

    private static final String PREFS_NAME = "clipkaro_prefs";
    private static final String KEY_PERMISSION_DONE = "permission_screen_done";
    private static final String CHROME_MOBILE_UA =
        "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36";

    private FrameLayout rootContainer;
    private WebView webView;
    private ValueCallback<Uri[]> filePathCallback;

    // Native In-App WebView overlay for "Open Inside" (YouTube / Instagram / Facebook)
    private LinearLayout inAppOverlay;
    private WebView inAppWebView;
    private String inAppCurrentUrl = "";
    private String inAppFallbackPkg = "";
    private String inAppPlatformLabel = "";
    private boolean inAppFallbackTriggered = false;

    private String pendingLaunchPackage = null;
    private String pendingLaunchPlayStore = null;
    private String pendingLaunchGameName = "BGMI";
    private int pendingDurationAfterProjection = 0;
    private boolean pendingFullAfterProjection = false;

    private final BroadcastReceiver nativeClipSavedReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            notifyNativeClipsUpdated();
        }
    };

    private final ActivityResultLauncher<Intent> fileChooserLauncher =
        registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result -> {
            if (filePathCallback == null) return;
            Uri[] results = WebChromeClient.FileChooserParams.parseResult(
                result.getResultCode(),
                result.getData()
            );
            filePathCallback.onReceiveValue(results);
            filePathCallback = null;
        });

    private final ActivityResultLauncher<String> micPermissionLauncher =
        registerForActivityResult(new ActivityResultContracts.RequestPermission(), granted -> {
            if (Boolean.TRUE.equals(granted)) {
                notifyPermissionsUpdated();
            } else {
                openAppDetailsSettings();
            }
        });

    private final ActivityResultLauncher<String> cameraPermissionLauncher =
        registerForActivityResult(new ActivityResultContracts.RequestPermission(), granted -> {
            if (Boolean.TRUE.equals(granted)) {
                notifyPermissionsUpdated();
            } else {
                openAppDetailsSettings();
            }
        });

    private final ActivityResultLauncher<Intent> settingsDeepLinkLauncher =
        registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result -> {
            notifyPermissionsUpdated();
        });

    private final ActivityResultLauncher<Intent> overlayPermissionLauncher =
        registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result -> {
            notifyPermissionsUpdated();
        });

    private final ActivityResultLauncher<Intent> mediaProjectionLauncher =
        registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result -> {
            int code = result.getResultCode();
            Intent data = result.getData();

            String pkg = pendingLaunchPackage;
            String gameName = pendingLaunchGameName;
            pendingLaunchPackage = null;
            pendingLaunchPlayStore = null;

            String appKey = FloatingClipService.resolveAppKey(pkg, gameName);
            if (code == Activity.RESULT_OK && data != null) {
                FloatingClipService.cacheProjectionForApp(appKey, code, data);
                startFloatingClipService(code, data, gameName, pkg);
            } else {
                pendingDurationAfterProjection = 0;
                pendingFullAfterProjection = false;
                startFloatingClipService(Activity.RESULT_CANCELED, null, gameName, pkg);
                Toast.makeText(
                    this,
                    "Screen capture cancelled for " + (gameName != null ? gameName : "App"),
                    Toast.LENGTH_SHORT
                ).show();
            }

            // Return straight back to the target app without relaunching it
            moveTaskToBack(true);
        });

    @SuppressLint({"SetJavaScriptEnabled", "JavascriptInterface"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        rootContainer = new FrameLayout(this);
        webView = new WebView(this);
        rootContainer.addView(
            webView,
            new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        );
        setContentView(rootContainer);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setJavaScriptCanOpenWindowsAutomatically(true);
        settings.setUserAgentString(CHROME_MOBILE_UA);

        CookieManager.getInstance().setAcceptCookie(true);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true);
        }

        final WebViewAssetLoader.AssetsPathHandler assetsHandler =
            new WebViewAssetLoader.AssetsPathHandler(this);

        final WebViewAssetLoader assetLoader = new WebViewAssetLoader.Builder()
            .addPathHandler("/", path -> {
                String cleanPath = path.startsWith("/") ? path.substring(1) : path;
                if (cleanPath.isEmpty()) {
                    cleanPath = "index.html";
                }
                WebResourceResponse response = assetsHandler.handle("public/" + cleanPath);
                if (response != null && response.getData() != null) {
                    return response;
                }
                return assetsHandler.handle(cleanPath);
            })
            .build();

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                Uri url = request.getUrl();
                if (url != null && "/native-clip".equals(url.getPath())) {
                    String uriParam = url.getQueryParameter("uri");
                    if (uriParam != null && !uriParam.isEmpty()) {
                        try {
                            Uri targetUri = Uri.parse(uriParam);
                            InputStream stream = "file".equalsIgnoreCase(targetUri.getScheme()) && targetUri.getPath() != null
                                ? new FileInputStream(new File(targetUri.getPath()))
                                : getContentResolver().openInputStream(targetUri);
                            if (stream != null) {
                                Map<String, String> headers = new HashMap<>();
                                headers.put("Access-Control-Allow-Origin", "*");
                                return new WebResourceResponse("video/mp4", null, 200, "OK", headers, stream);
                            }
                        } catch (Exception ignored) {
                        }
                    }
                    return new WebResourceResponse(
                        "text/plain",
                        "UTF-8",
                        404,
                        "Not Found",
                        new HashMap<>(),
                        new ByteArrayInputStream(new byte[0])
                    );
                }
                return assetLoader.shouldInterceptRequest(url);
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                String scheme = uri.getScheme();
                if ("intent".equalsIgnoreCase(scheme) || "market".equalsIgnoreCase(scheme)) {
                    try {
                        Intent intent = Intent.parseUri(uri.toString(), Intent.URI_INTENT_SCHEME);
                        if (intent.resolveActivity(getPackageManager()) != null) {
                            startActivity(intent);
                        } else {
                            String fallback = intent.getStringExtra("browser_fallback_url");
                            if (fallback != null) {
                                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(fallback)));
                            }
                        }
                        return true;
                    } catch (Exception ignored) {
                        return true;
                    }
                }
                return false;
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onPermissionRequest(final PermissionRequest request) {
                runOnUiThread(() -> request.grant(request.getResources()));
            }

            @Override
            public boolean onShowFileChooser(
                WebView webView,
                ValueCallback<Uri[]> filePathCallback,
                FileChooserParams fileChooserParams
            ) {
                if (MainActivity.this.filePathCallback != null) {
                    MainActivity.this.filePathCallback.onReceiveValue(null);
                }
                MainActivity.this.filePathCallback = filePathCallback;
                Intent intent = fileChooserParams.createIntent();
                fileChooserLauncher.launch(intent);
                return true;
            }
        });

        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                if (inAppOverlay != null) {
                    if (inAppWebView != null && inAppWebView.canGoBack()) {
                        inAppWebView.goBack();
                    } else {
                        closeInAppWebViewOverlay();
                    }
                    return;
                }
                if (webView != null && webView.canGoBack()) {
                    webView.goBack();
                } else {
                    setEnabled(false);
                    getOnBackPressedDispatcher().onBackPressed();
                }
            }
        });

        webView.addJavascriptInterface(new ClipKaroAndroidBridge(), "Android");
        webView.loadUrl("https://appassets.androidplatform.net/index.html");
        handleProjectionPromptIntent(getIntent());

        IntentFilter filter = new IntentFilter(FloatingClipService.ACTION_NATIVE_CLIP_SAVED);
        ContextCompat.registerReceiver(this, nativeClipSavedReceiver, filter, ContextCompat.RECEIVER_NOT_EXPORTED);
    }

    @Override
    protected void onDestroy() {
        isActivityInForeground = false;
        closeInAppWebViewOverlay();
        try {
            unregisterReceiver(nativeClipSavedReceiver);
        } catch (IllegalArgumentException ignored) {
        }
        super.onDestroy();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleProjectionPromptIntent(intent);
    }

    private void handleProjectionPromptIntent(Intent intent) {
        if (intent != null && intent.hasExtra(EXTRA_REQUEST_PROJECTION_GAME)) {
            String game = intent.getStringExtra(EXTRA_REQUEST_PROJECTION_GAME);
            String pkg = intent.getStringExtra(FloatingClipService.EXTRA_TARGET_PACKAGE);
            pendingLaunchGameName = (game != null && !game.isEmpty()) ? game : "BGMI";
            pendingDurationAfterProjection = intent.getIntExtra(FloatingClipService.EXTRA_PENDING_DURATION, 0);
            pendingFullAfterProjection = intent.getBooleanExtra(FloatingClipService.EXTRA_PENDING_FULL, false);
            pendingLaunchPackage = (pkg != null && !pkg.isEmpty()) ? pkg : null;
            pendingLaunchPlayStore = null;

            String appKey = FloatingClipService.resolveAppKey(pendingLaunchPackage, pendingLaunchGameName);
            FloatingClipService.PerAppProjectionEntry cached =
                FloatingClipService.getCachedProjectionForApp(appKey);
            if (cached != null && cached.resultCode == Activity.RESULT_OK && cached.resultData != null) {
                startFloatingClipService(
                    cached.resultCode,
                    cached.resultData,
                    pendingLaunchGameName,
                    pendingLaunchPackage
                );
                moveTaskToBack(true);
            } else {
                requestMediaProjectionCapture();
            }
        }
    }

    private void requestMediaProjectionCapture() {
        MediaProjectionManager mpm =
            (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);
        if (mpm != null) {
            mediaProjectionLauncher.launch(mpm.createScreenCaptureIntent());
        } else {
            pendingDurationAfterProjection = 0;
            pendingFullAfterProjection = false;
            moveTaskToBack(true);
        }
    }

    private void startFloatingClipService(int resultCode, Intent resultData, String gameName, String targetPackage) {
        Intent serviceIntent = new Intent(this, FloatingClipService.class);
        serviceIntent.setAction(FloatingClipService.ACTION_START);
        serviceIntent.putExtra(FloatingClipService.EXTRA_GAME_NAME, gameName != null ? gameName : "BGMI");
        if (targetPackage != null && !targetPackage.trim().isEmpty()) {
            serviceIntent.putExtra(FloatingClipService.EXTRA_TARGET_PACKAGE, targetPackage.trim());
        }
        if (pendingDurationAfterProjection > 0) {
            serviceIntent.putExtra(FloatingClipService.EXTRA_PENDING_DURATION, pendingDurationAfterProjection);
            pendingDurationAfterProjection = 0;
        }
        if (pendingFullAfterProjection) {
            serviceIntent.putExtra(FloatingClipService.EXTRA_PENDING_FULL, true);
            pendingFullAfterProjection = false;
        }
        if (resultCode == Activity.RESULT_OK && resultData != null) {
            serviceIntent.putExtra(FloatingClipService.EXTRA_RESULT_CODE, resultCode);
            serviceIntent.putExtra(FloatingClipService.EXTRA_RESULT_DATA, resultData);
        }
        ContextCompat.startForegroundService(this, serviceIntent);
    }

    private boolean isPackageCurrentlyForeground(String packageName) {
        if (packageName == null || packageName.isEmpty() || Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP_MR1) {
            return false;
        }
        try {
            UsageStatsManager usm = (UsageStatsManager) getSystemService(Context.USAGE_STATS_SERVICE);
            if (usm == null) return false;
            long now = System.currentTimeMillis();
            UsageEvents events = usm.queryEvents(now - 10_000L, now);
            UsageEvents.Event ev = new UsageEvents.Event();
            long latestTs = 0L;
            String latestPkg = null;
            while (events.hasNextEvent()) {
                events.getNextEvent(ev);
                int type = ev.getEventType();
                boolean isResumed = (type == UsageEvents.Event.MOVE_TO_FOREGROUND)
                    || (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q
                        && type == UsageEvents.Event.ACTIVITY_RESUMED);
                if (isResumed && ev.getTimeStamp() >= latestTs && ev.getPackageName() != null) {
                    latestTs = ev.getTimeStamp();
                    latestPkg = ev.getPackageName();
                }
            }
            return packageName.equals(latestPkg);
        } catch (Exception ignored) {
            return false;
        }
    }

    private boolean launchInstalledPackageOrPlayStore(String packageName, String playStoreUrl) {
        if (isPackageCurrentlyForeground(packageName)) {
            moveTaskToBack(true);
            return true;
        }
        PackageManager pm = getPackageManager();
        Intent launchIntent = pm.getLaunchIntentForPackage(packageName);
        if (launchIntent != null) {
            launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
            startActivity(launchIntent);
            return true;
        }
        try {
            Intent marketIntent = new Intent(
                Intent.ACTION_VIEW,
                Uri.parse("market://details?id=" + packageName)
            );
            marketIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(marketIntent);
        } catch (Exception e) {
            if (playStoreUrl != null && !playStoreUrl.isEmpty()) {
                Intent webIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(playStoreUrl));
                webIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(webIntent);
            }
        }
        return false;
    }

    private void openNativeAppOrBrowserFallback(String packageName, String targetUrl) {
        if (packageName != null && !packageName.trim().isEmpty()) {
            try {
                Intent appIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(targetUrl));
                appIntent.setPackage(packageName.trim());
                appIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                if (appIntent.resolveActivity(getPackageManager()) != null) {
                    startActivity(appIntent);
                    return;
                }
                Intent launcher = getPackageManager().getLaunchIntentForPackage(packageName.trim());
                if (launcher != null) {
                    launcher.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(launcher);
                    return;
                }
            } catch (Exception ignored) {
            }
        }
        try {
            Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(targetUrl));
            browserIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(browserIntent);
        } catch (Exception ignored) {
            Toast.makeText(this, "Could not open link", Toast.LENGTH_SHORT).show();
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private void showInAppWebViewOverlay(String url, String platformLabel, String fallbackPackage) {
        closeInAppWebViewOverlay();
        inAppCurrentUrl = url;
        inAppFallbackPkg = fallbackPackage != null ? fallbackPackage : "";
        inAppPlatformLabel = (platformLabel != null && !platformLabel.isEmpty()) ? platformLabel : "Viewer";
        inAppFallbackTriggered = false;

        int pad = Math.round(12 * getResources().getDisplayMetrics().density);

        inAppOverlay = new LinearLayout(this);
        inAppOverlay.setOrientation(LinearLayout.VERTICAL);
        inAppOverlay.setBackgroundColor(Color.parseColor("#0B0E14"));

        // Top Header Bar
        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(pad, pad, pad, pad);
        header.setBackgroundColor(Color.parseColor("#121722"));

        TextView titleTv = new TextView(this);
        titleTv.setText(inAppPlatformLabel + " · Inside ClipKaro");
        titleTv.setTextColor(Color.WHITE);
        titleTv.setTextSize(14);
        header.addView(titleTv, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        Button openAppBtn = new Button(this);
        openAppBtn.setText("Open in App");
        openAppBtn.setAllCaps(false);
        openAppBtn.setTextSize(12);
        openAppBtn.setTextColor(Color.WHITE);
        openAppBtn.setBackgroundColor(Color.parseColor("#E11D48"));
        LinearLayout.LayoutParams appLp = new LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
        );
        appLp.rightMargin = pad / 2;
        openAppBtn.setOnClickListener(v -> {
            String curUrl = (inAppWebView != null && inAppWebView.getUrl() != null)
                ? inAppWebView.getUrl()
                : inAppCurrentUrl;
            closeInAppWebViewOverlay();
            openNativeAppOrBrowserFallback(inAppFallbackPkg, curUrl);
        });
        header.addView(openAppBtn, appLp);

        Button closeBtn = new Button(this);
        closeBtn.setText("Close");
        closeBtn.setAllCaps(false);
        closeBtn.setTextSize(12);
        closeBtn.setTextColor(Color.WHITE);
        closeBtn.setBackgroundColor(Color.parseColor("#334155"));
        closeBtn.setOnClickListener(v -> closeInAppWebViewOverlay());
        header.addView(closeBtn);

        inAppOverlay.addView(header, new LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ));

        inAppWebView = new WebView(this);
        WebSettings ws = inAppWebView.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setDomStorageEnabled(true);
        ws.setDatabaseEnabled(true);
        ws.setMediaPlaybackRequiresUserGesture(false);
        ws.setJavaScriptCanOpenWindowsAutomatically(true);
        ws.setLoadWithOverviewMode(true);
        ws.setUseWideViewPort(true);
        ws.setUserAgentString(CHROME_MOBILE_UA);

        CookieManager.getInstance().setAcceptCookie(true);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            CookieManager.getInstance().setAcceptThirdPartyCookies(inAppWebView, true);
        }

        inAppWebView.setWebChromeClient(new WebChromeClient());
        inAppWebView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                String scheme = uri.getScheme();
                if (!"http".equalsIgnoreCase(scheme) && !"https".equalsIgnoreCase(scheme)) {
                    try {
                        Intent intent = "intent".equalsIgnoreCase(scheme)
                            ? Intent.parseUri(uri.toString(), Intent.URI_INTENT_SCHEME)
                            : new Intent(Intent.ACTION_VIEW, uri);
                        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        if (intent.resolveActivity(getPackageManager()) != null) {
                            startActivity(intent);
                            return true;
                        }
                    } catch (Exception ignored) {
                    }
                    triggerInAppFallback(url);
                    return true;
                }
                return false;
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                if (request.isForMainFrame()) {
                    triggerInAppFallback(request.getUrl().toString());
                }
            }

            @Override
            public void onReceivedHttpError(
                WebView view,
                WebResourceRequest request,
                WebResourceResponse errorResponse
            ) {
                if (request.isForMainFrame() && errorResponse.getStatusCode() >= 400) {
                    triggerInAppFallback(request.getUrl().toString());
                }
            }

            @Override
            public void onPageFinished(WebView view, String finishedUrl) {
                // Guard against blank blocked pages (X-Frame-Options / CSP / failed hydration)
                view.postDelayed(() -> {
                    if (inAppWebView == null || inAppFallbackTriggered) return;
                    inAppWebView.evaluateJavascript(
                        "(function(){var t=(document.body&&document.body.innerText||'').trim();var v=document.querySelector('video,iframe');return t.length===0&&!v?'BLANK':'OK';})()",
                        value -> {
                            if (value != null && value.contains("BLANK")) {
                                triggerInAppFallback(finishedUrl != null ? finishedUrl : inAppCurrentUrl);
                            }
                        }
                    );
                }, 2600L);
            }
        });

        inAppOverlay.addView(inAppWebView, new LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f
        ));

        rootContainer.addView(inAppOverlay, new FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
        ));
        inAppWebView.loadUrl(url);
    }

    private void triggerInAppFallback(String targetUrl) {
        if (inAppFallbackTriggered) return;
        inAppFallbackTriggered = true;
        String pkg = inAppFallbackPkg;
        String label = inAppPlatformLabel;
        closeInAppWebViewOverlay();
        Toast.makeText(
            this,
            "Opening " + label + " in app/browser…",
            Toast.LENGTH_SHORT
        ).show();
        openNativeAppOrBrowserFallback(pkg, targetUrl != null ? targetUrl : inAppCurrentUrl);
    }

    private void closeInAppWebViewOverlay() {
        if (inAppWebView != null) {
            try {
                inAppWebView.stopLoading();
                inAppWebView.destroy();
            } catch (Exception ignored) {
            }
            inAppWebView = null;
        }
        if (inAppOverlay != null && rootContainer != null) {
            rootContainer.removeView(inAppOverlay);
            inAppOverlay = null;
        }
    }

    private void openAppDetailsSettings() {
        Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
        intent.setData(Uri.parse("package:" + getPackageName()));
        runOnUiThread(() -> settingsDeepLinkLauncher.launch(intent));
    }

    private void openOverlaySettingsDeepLink() {
        Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION);
        intent.setData(Uri.parse("package:" + getPackageName()));
        runOnUiThread(() -> overlayPermissionLauncher.launch(intent));
    }

    @SuppressLint("BatteryLife")
    private void openBatteryOptimizationDeepLink() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Intent intent = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS);
            intent.setData(Uri.parse("package:" + getPackageName()));
            runOnUiThread(() -> {
                try {
                    settingsDeepLinkLauncher.launch(intent);
                } catch (Exception e) {
                    openAppDetailsSettings();
                }
            });
        } else {
            notifyPermissionsUpdated();
        }
    }

    private void openUsageAccessDeepLink() {
        runOnUiThread(() -> {
            try {
                Intent intent = new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS);
                intent.setData(Uri.parse("package:" + getPackageName()));
                settingsDeepLinkLauncher.launch(intent);
            } catch (Exception e) {
                try {
                    settingsDeepLinkLauncher.launch(new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS));
                } catch (Exception ignored) {
                    openAppDetailsSettings();
                }
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        isActivityInForeground = true;
        Intent i = new Intent(this, FloatingClipService.class);
        i.setAction(FloatingClipService.ACTION_CLIPKARO_RESUMED);
        try {
            startService(i);
        } catch (Exception ignored) {
        }
        notifyPermissionsUpdated();
        notifyNativeClipsUpdated();
    }

    @Override
    protected void onPause() {
        isActivityInForeground = false;
        super.onPause();
    }

    private void notifyPermissionsUpdated() {
        if (webView != null) {
            Runnable emit = () -> {
                if (webView != null) {
                    webView.evaluateJavascript(
                        "window.dispatchEvent(new CustomEvent('clipkaro-permissions-updated'))",
                        null
                    );
                }
            };
            webView.post(emit);
            webView.postDelayed(emit, 250);
        }
    }

    private void notifyNativeClipsUpdated() {
        if (webView != null) {
            webView.post(() -> {
                if (webView != null) {
                    webView.evaluateJavascript(
                        "window.dispatchEvent(new CustomEvent('clipkaro-native-clips-updated'))",
                        null
                    );
                }
            });
        }
    }

    private boolean checkOverlayGranted() {
        return Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(this);
    }

    private boolean checkStorageGranted() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            return ContextCompat.checkSelfPermission(this, Manifest.permission.READ_MEDIA_VIDEO)
                == PackageManager.PERMISSION_GRANTED
                && ContextCompat.checkSelfPermission(this, Manifest.permission.READ_MEDIA_IMAGES)
                == PackageManager.PERMISSION_GRANTED;
        }
        return ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE)
            == PackageManager.PERMISSION_GRANTED;
    }

    private boolean checkMicrophoneGranted() {
        return ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            == PackageManager.PERMISSION_GRANTED;
    }

    private boolean checkCameraGranted() {
        return ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
            == PackageManager.PERMISSION_GRANTED;
    }

    private boolean checkBatteryOptimizationIgnored() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
            return pm == null || pm.isIgnoringBatteryOptimizations(getPackageName());
        }
        return true;
    }

    private boolean checkUsageAccessGranted() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP) return true;
        try {
            AppOpsManager appOps = (AppOpsManager) getSystemService(Context.APP_OPS_SERVICE);
            if (appOps == null) return false;
            int mode = Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q
                ? appOps.unsafeCheckOpNoThrow(
                    AppOpsManager.OPSTR_GET_USAGE_STATS,
                    android.os.Process.myUid(),
                    getPackageName()
                )
                : appOps.checkOpNoThrow(
                    AppOpsManager.OPSTR_GET_USAGE_STATS,
                    android.os.Process.myUid(),
                    getPackageName()
                );
            return mode == AppOpsManager.MODE_ALLOWED;
        } catch (Exception ignored) {
            return false;
        }
    }

    public class ClipKaroAndroidBridge {
        @JavascriptInterface
        public boolean launchApp(String packageName, String playStoreUrl) {
            return launchInstalledPackageOrPlayStore(packageName, playStoreUrl);
        }

        @JavascriptInterface
        public void openUrlInsideWebView(String url, String platformLabel, String fallbackPackage) {
            if (url == null || url.trim().isEmpty()) return;
            runOnUiThread(() -> showInAppWebViewOverlay(url.trim(), platformLabel, fallbackPackage));
        }

        @JavascriptInterface
        public String startFloatingAndLaunchGame(String packageName, String playStoreUrl, String gameName) {
            SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
            boolean reactionMode = prefs.getBoolean(FloatingClipService.KEY_REACTION_MODE, false);
            boolean facecamEnabled = prefs.getBoolean(FloatingClipService.KEY_FACECAM_ENABLED, false);
            String voiceEffect = prefs.getString(FloatingClipService.KEY_VOICE_EFFECT, FloatingClipService.VOICE_NORMAL);
            return startFloatingWithOptions(
                packageName,
                playStoreUrl,
                gameName,
                reactionMode,
                facecamEnabled,
                voiceEffect
            );
        }

        @JavascriptInterface
        public String startFloatingWithOptions(
            String packageName,
            String playStoreUrl,
            String gameName,
            boolean reactionMode,
            boolean facecamEnabled,
            String voiceEffect
        ) {
            if (!checkOverlayGranted()) {
                openOverlaySettingsDeepLink();
                return "overlay_required";
            }

            String normalizedVoice = FloatingClipService.normalizeVoiceEffect(voiceEffect);
            getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
                .edit()
                .putBoolean(FloatingClipService.KEY_REACTION_MODE, reactionMode)
                .putBoolean(FloatingClipService.KEY_FACECAM_ENABLED, facecamEnabled)
                .putString(FloatingClipService.KEY_VOICE_EFFECT, normalizedVoice)
                .apply();

            String targetTitle = (gameName != null && !gameName.trim().isEmpty()) ? gameName.trim() : "BGMI";
            String cleanPkg = packageName != null ? packageName.trim() : "";

            // Never ask Screen Capture on game/app launch — only start floating CLIP bubble.
            // MediaProjection is requested per-app ONLY when user taps a Record Start button.
            pendingDurationAfterProjection = 0;
            pendingFullAfterProjection = false;

            Intent serviceIntent = new Intent(MainActivity.this, FloatingClipService.class);
            serviceIntent.setAction(FloatingClipService.ACTION_START);
            serviceIntent.putExtra(FloatingClipService.EXTRA_GAME_NAME, targetTitle);
            if (!cleanPkg.isEmpty()) {
                serviceIntent.putExtra(FloatingClipService.EXTRA_TARGET_PACKAGE, cleanPkg);
            }
            serviceIntent.putExtra(FloatingClipService.EXTRA_REACTION_MODE, reactionMode);
            serviceIntent.putExtra(FloatingClipService.EXTRA_FACECAM_ENABLED, facecamEnabled);
            serviceIntent.putExtra(FloatingClipService.EXTRA_VOICE_EFFECT, normalizedVoice);
            ContextCompat.startForegroundService(MainActivity.this, serviceIntent);

            if (!cleanPkg.isEmpty()) {
                launchInstalledPackageOrPlayStore(cleanPkg, playStoreUrl);
            }
            return "started";
        }

        @JavascriptInterface
        public void setFloatingRecordingOptions(
            boolean facecamEnabled,
            String voiceEffect,
            boolean reactionMode
        ) {
            String normalizedVoice = FloatingClipService.normalizeVoiceEffect(voiceEffect);
            getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
                .edit()
                .putBoolean(FloatingClipService.KEY_REACTION_MODE, reactionMode)
                .putBoolean(FloatingClipService.KEY_FACECAM_ENABLED, facecamEnabled)
                .putString(FloatingClipService.KEY_VOICE_EFFECT, normalizedVoice)
                .apply();

            if (FloatingClipService.isServiceRunning) {
                Intent optsIntent = new Intent(MainActivity.this, FloatingClipService.class);
                optsIntent.setAction(FloatingClipService.ACTION_SET_OPTIONS);
                optsIntent.putExtra(FloatingClipService.EXTRA_FACECAM_ENABLED, facecamEnabled);
                optsIntent.putExtra(FloatingClipService.EXTRA_VOICE_EFFECT, normalizedVoice);
                optsIntent.putExtra(FloatingClipService.EXTRA_REACTION_MODE, reactionMode);
                startService(optsIntent);
            }
        }

        @JavascriptInterface
        public boolean hasCameraPermission() {
            return checkCameraGranted();
        }

        @JavascriptInterface
        public void requestCameraPermission() {
            if (!checkCameraGranted()) {
                runOnUiThread(() -> cameraPermissionLauncher.launch(Manifest.permission.CAMERA));
            } else {
                notifyPermissionsUpdated();
            }
        }

        @JavascriptInterface
        public boolean deleteNativeClipFile(String uriStr) {
            if (uriStr == null || uriStr.trim().isEmpty()) return false;
            try {
                Uri parsed = Uri.parse(uriStr.trim());
                if ("content".equalsIgnoreCase(parsed.getScheme())) {
                    return getContentResolver().delete(parsed, null, null) > 0;
                } else if ("file".equalsIgnoreCase(parsed.getScheme()) && parsed.getPath() != null) {
                    File f = new File(parsed.getPath());
                    return !f.exists() || f.delete();
                }
            } catch (Exception ignored) {
            }
            return false;
        }

        @JavascriptInterface
        public void stopFloatingService() {
            Intent stopIntent = new Intent(MainActivity.this, FloatingClipService.class);
            stopIntent.setAction(FloatingClipService.ACTION_STOP);
            startService(stopIntent);
        }

        @JavascriptInterface
        public boolean hasUsageAccessPermission() {
            return checkUsageAccessGranted();
        }

        @JavascriptInterface
        public void requestUsageAccessPermission() {
            if (!checkUsageAccessGranted()) {
                openUsageAccessDeepLink();
            } else {
                notifyPermissionsUpdated();
            }
        }

        @JavascriptInterface
        public boolean canDrawOverlays() {
            return checkOverlayGranted();
        }

        @JavascriptInterface
        public void requestOverlayPermission() {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(MainActivity.this)) {
                openOverlaySettingsDeepLink();
            } else {
                notifyPermissionsUpdated();
            }
        }

        @JavascriptInterface
        public boolean hasStoragePermission() {
            return checkStorageGranted();
        }

        @JavascriptInterface
        public void requestStoragePermission() {
            if (!checkStorageGranted()) {
                openAppDetailsSettings();
            } else {
                notifyPermissionsUpdated();
            }
        }

        @JavascriptInterface
        public boolean hasMicrophonePermission() {
            return checkMicrophoneGranted();
        }

        @JavascriptInterface
        public void requestMicrophonePermission() {
            if (!checkMicrophoneGranted()) {
                runOnUiThread(() -> micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO));
            } else {
                notifyPermissionsUpdated();
            }
        }

        @JavascriptInterface
        public void openMicrophoneSettings() {
            if (!checkMicrophoneGranted()) {
                openAppDetailsSettings();
            } else {
                notifyPermissionsUpdated();
            }
        }

        @JavascriptInterface
        public boolean hasBatteryPermission() {
            return checkBatteryOptimizationIgnored();
        }

        @JavascriptInterface
        public void requestBatteryPermission() {
            if (!checkBatteryOptimizationIgnored()) {
                openBatteryOptimizationDeepLink();
            } else {
                notifyPermissionsUpdated();
            }
        }

        @JavascriptInterface
        public boolean isPermissionSetupDone() {
            SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
            return prefs.getBoolean(KEY_PERMISSION_DONE, false);
        }

        @JavascriptInterface
        public void setPermissionSetupDone(boolean done) {
            SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
            prefs.edit().putBoolean(KEY_PERMISSION_DONE, done).apply();
        }

        @JavascriptInterface
        public String getPermissionStatusJson() {
            return "{"
                + "\\"overlay\\":" + checkOverlayGranted() + ","
                + "\\"storage\\":" + checkStorageGranted() + ","
                + "\\"microphone\\":" + checkMicrophoneGranted() + ","
                + "\\"battery\\":" + checkBatteryOptimizationIgnored() + ","
                + "\\"usageAccess\\":" + checkUsageAccessGranted() + ","
                + "\\"setupDone\\":" + isPermissionSetupDone()
                + "}";
        }

        @JavascriptInterface
        public String listNativeClipKaroVideosJson() {
            JSONArray result = new JSONArray();
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    String[] projection = new String[]{
                        MediaStore.Video.Media._ID,
                        MediaStore.Video.Media.DISPLAY_NAME,
                        MediaStore.Video.Media.DURATION,
                        MediaStore.Video.Media.DATE_ADDED
                    };
                    String selection = MediaStore.Video.Media.RELATIVE_PATH + " LIKE ?";
                    String[] selectionArgs = new String[]{"%ClipKaro%"};
                    String sortOrder = MediaStore.Video.Media.DATE_ADDED + " DESC";
                    try (Cursor cursor = getContentResolver().query(
                        MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
                        projection,
                        selection,
                        selectionArgs,
                        sortOrder
                    )) {
                        if (cursor != null) {
                            int idCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media._ID);
                            int nameCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME);
                            int durCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DURATION);
                            int dateCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DATE_ADDED);
                            int count = 0;
                            while (cursor.moveToNext() && count < 40) {
                                long id = cursor.getLong(idCol);
                                String name = cursor.getString(nameCol);
                                long durMs = cursor.getLong(durCol);
                                long dateSec = cursor.getLong(dateCol);
                                Uri contentUri = Uri.withAppendedPath(
                                    MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
                                    String.valueOf(id)
                                );
                                JSONObject obj = new JSONObject();
                                obj.put("uri", contentUri.toString());
                                obj.put("fileName", name != null ? name : ("Clip_" + id + ".mp4"));
                                obj.put("durationSec", Math.max(1, Math.round(durMs / 1000.0)));
                                obj.put("createdAtMs", dateSec * 1000L);
                                result.put(obj);
                                count++;
                            }
                        }
                    }
                } else {
                    File dir = new File(
                        Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES),
                        "ClipKaro"
                    );
                    File[] files = dir.exists() ? dir.listFiles() : null;
                    if (files != null) {
                        for (File f : files) {
                            if (f.isFile() && f.getName().endsWith(".mp4")) {
                                JSONObject obj = new JSONObject();
                                obj.put("uri", Uri.fromFile(f).toString());
                                obj.put("fileName", f.getName());
                                obj.put("durationSec", 10);
                                obj.put("createdAtMs", f.lastModified());
                                result.put(obj);
                            }
                        }
                    }
                }
            } catch (Exception ignored) {
            }
            return result.toString();
        }

        @JavascriptInterface
        public boolean saveVideoFileToClipKaroFolder(String fileName, String base64Video) {
            if (base64Video == null || base64Video.isEmpty()) return false;
            try {
                byte[] bytes = Base64.decode(base64Video, Base64.DEFAULT);
                String safeName = (fileName != null && !fileName.trim().isEmpty())
                    ? fileName.replaceAll("[^A-Za-z0-9._-]+", "_")
                    : ("ClipKaro_Edited_" + System.currentTimeMillis() + ".mp4");
                if (!safeName.endsWith(".mp4") && !safeName.endsWith(".webm")) {
                    safeName += ".mp4";
                }
                String mime = safeName.endsWith(".webm") ? "video/webm" : "video/mp4";

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    ContentResolver resolver = getContentResolver();
                    ContentValues values = new ContentValues();
                    values.put(MediaStore.Video.Media.DISPLAY_NAME, safeName);
                    values.put(MediaStore.Video.Media.MIME_TYPE, mime);
                    values.put(
                        MediaStore.Video.Media.RELATIVE_PATH,
                        Environment.DIRECTORY_MOVIES + "/ClipKaro"
                    );
                    values.put(MediaStore.Video.Media.IS_PENDING, 1);

                    Uri uri = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values);
                    if (uri == null) return false;
                    try (OutputStream out = resolver.openOutputStream(uri)) {
                        if (out == null) return false;
                        out.write(bytes);
                    }
                    values.clear();
                    values.put(MediaStore.Video.Media.IS_PENDING, 0);
                    resolver.update(uri, values, null, null);
                    return true;
                } else {
                    File moviesDir = new File(
                        Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES),
                        "ClipKaro"
                    );
                    if (!moviesDir.exists()) {
                        //noinspection ResultOfMethodCallIgnored
                        moviesDir.mkdirs();
                    }
                    File dest = new File(moviesDir, safeName);
                    try (FileOutputStream fos = new FileOutputStream(dest)) {
                        fos.write(bytes);
                    }
                    MediaScannerConnection.scanFile(
                        MainActivity.this,
                        new String[]{dest.getAbsolutePath()},
                        new String[]{mime},
                        null
                    );
                    return true;
                }
            } catch (Exception ignored) {
                return false;
            }
        }

        @JavascriptInterface
        public boolean shareVideoToPlatform(
            String targetPlatform,
            String fileName,
            String base64Video,
            String nativeUriStr,
            String captionText
        ) {
            try {
                Uri shareUri = null;
                if (nativeUriStr != null && !nativeUriStr.trim().isEmpty()) {
                    Uri parsed = Uri.parse(nativeUriStr.trim());
                    if ("content".equalsIgnoreCase(parsed.getScheme())) {
                        shareUri = parsed;
                    } else if ("file".equalsIgnoreCase(parsed.getScheme()) && parsed.getPath() != null) {
                        File f = new File(parsed.getPath());
                        if (f.exists()) {
                            shareUri = FileProvider.getUriForFile(
                                MainActivity.this,
                                getPackageName() + ".fileprovider",
                                f
                            );
                        }
                    }
                }

                if (shareUri == null && base64Video != null && !base64Video.isEmpty()) {
                    File shareDir = new File(getCacheDir(), "shared_clips");
                    if (!shareDir.exists()) {
                        //noinspection ResultOfMethodCallIgnored
                        shareDir.mkdirs();
                    }
                    String safeName = (fileName != null && !fileName.trim().isEmpty())
                        ? fileName.replaceAll("[^A-Za-z0-9._-]+", "_")
                        : ("ClipKaro_Share_" + System.currentTimeMillis() + ".mp4");
                    if (!safeName.endsWith(".mp4") && !safeName.endsWith(".webm")) {
                        safeName += ".mp4";
                    }
                    File outFile = new File(shareDir, safeName);
                    byte[] bytes = Base64.decode(base64Video, Base64.DEFAULT);
                    try (FileOutputStream fos = new FileOutputStream(outFile)) {
                        fos.write(bytes);
                    }
                    shareUri = FileProvider.getUriForFile(
                        MainActivity.this,
                        getPackageName() + ".fileprovider",
                        outFile
                    );
                }

                if (shareUri == null) return false;

                String pkg = null;
                if ("youtube".equalsIgnoreCase(targetPlatform)) {
                    pkg = "com.google.android.youtube";
                } else if ("instagram".equalsIgnoreCase(targetPlatform)) {
                    pkg = "com.instagram.android";
                } else if ("whatsapp".equalsIgnoreCase(targetPlatform)) {
                    pkg = "com.whatsapp";
                }

                String shareText = (captionText != null && !captionText.trim().isEmpty())
                    ? captionText.trim()
                    : "BGMI Highlight #BGMI #ClipKaro";

                Intent shareIntent = new Intent(Intent.ACTION_SEND);
                shareIntent.setType("video/*");
                shareIntent.putExtra(Intent.EXTRA_STREAM, shareUri);
                shareIntent.putExtra(Intent.EXTRA_TEXT, shareText);
                shareIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);

                if (pkg != null) {
                    shareIntent.setPackage(pkg);
                    if (shareIntent.resolveActivity(getPackageManager()) != null) {
                        Intent finalTargeted = shareIntent;
                        runOnUiThread(() -> startActivity(finalTargeted));
                        return true;
                    }
                    shareIntent.setPackage(null);
                }

                Intent chooser = Intent.createChooser(shareIntent, "Share ClipKaro Highlight");
                chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                runOnUiThread(() -> startActivity(chooser));
                return true;
            } catch (Exception ignored) {
                return false;
            }
        }
    }
}
`,"/android/app/src/main/res/drawable/ic_clip_scissors.xml":`<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="28dp"
    android:height="28dp"
    android:viewportWidth="24"
    android:viewportHeight="24">
    <path
        android:fillColor="#00000000"
        android:strokeColor="#FFFFFF"
        android:strokeWidth="2.2"
        android:strokeLineCap="round"
        android:strokeLineJoin="round"
        android:pathData="M6,9 A3,3 0 1,0 6,3 A3,3 0 1,0 6,9 Z" />
    <path
        android:fillColor="#00000000"
        android:strokeColor="#FFFFFF"
        android:strokeWidth="2.2"
        android:strokeLineCap="round"
        android:strokeLineJoin="round"
        android:pathData="M6,21 A3,3 0 1,0 6,15 A3,3 0 1,0 6,21 Z" />
    <path
        android:fillColor="#00000000"
        android:strokeColor="#FFFFFF"
        android:strokeWidth="2.2"
        android:strokeLineCap="round"
        android:strokeLineJoin="round"
        android:pathData="M20,4 L8.12,15.88" />
    <path
        android:fillColor="#00000000"
        android:strokeColor="#FFFFFF"
        android:strokeWidth="2.2"
        android:strokeLineCap="round"
        android:strokeLineJoin="round"
        android:pathData="M14.47,14.48 L20,20" />
    <path
        android:fillColor="#00000000"
        android:strokeColor="#FFFFFF"
        android:strokeWidth="2.2"
        android:strokeLineCap="round"
        android:strokeLineJoin="round"
        android:pathData="M8.12,8.12 L12,12" />
</vector>
`,"/android/app/src/main/res/mipmap-anydpi-v26/ic_launcher.xml":`<?xml version="1.0" encoding="utf-8"?>
<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">
    <background android:drawable="@color/ic_launcher_background" />
    <foreground android:drawable="@mipmap/ic_launcher_foreground" />
</adaptive-icon>
`,"/android/app/src/main/res/mipmap-anydpi-v26/ic_launcher_round.xml":`<?xml version="1.0" encoding="utf-8"?>
<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">
    <background android:drawable="@color/ic_launcher_background" />
    <foreground android:drawable="@mipmap/ic_launcher_foreground" />
</adaptive-icon>
`,"/android/app/src/main/res/values/ic_launcher_background.xml":`<?xml version="1.0" encoding="utf-8"?>
<resources>
    <color name="ic_launcher_background">#020409</color>
</resources>
`,"/android/app/src/main/res/values/strings.xml":`<?xml version="1.0" encoding="utf-8"?>
<resources>
    <string name="app_name">ClipKaro</string>
</resources>
`,"/android/app/src/main/res/values/styles.xml":`<?xml version="1.0" encoding="utf-8"?>
<resources>
    <style name="AppTheme" parent="Theme.AppCompat.DayNight.NoActionBar">
        <item name="android:windowBackground">#0B0E14</item>
        <item name="android:statusBarColor">#0B0E14</item>
        <item name="android:navigationBarColor">#0B0E14</item>
    </style>
</resources>
`,"/android/app/src/main/res/xml/file_paths.xml":`<?xml version="1.0" encoding="utf-8"?>
<paths xmlns:android="http://schemas.android.com/apk/res/android">
    <cache-path name="shared_clips" path="shared_clips/" />
    <external-path name="external_movies" path="Movies/ClipKaro/" />
</paths>
`,"/android/build.gradle":`buildscript {
    repositories {
        google()
        mavenCentral()
    }
    dependencies {
        classpath 'com.android.tools.build:gradle:8.7.2'
    }
}

allprojects {
    repositories {
        google()
        mavenCentral()
    }
}
`,"/android/gradle.properties":`org.gradle.jvmargs=-Xmx2048m -Dfile.encoding=UTF-8
android.useAndroidX=true
android.enableJetifier=true
android.nonTransitiveRClass=true
`,"/android/settings.gradle":`rootProject.name = "ClipKaro"
include ':app'
`,"/capacitor.config.json":`{
  "appId": "com.clipkaro.app",
  "appName": "ClipKaro",
  "webDir": "dist",
  "server": {
    "androidScheme": "https"
  },
  "android": {
    "allowMixedContent": false,
    "webContentsDebuggingEnabled": false
  }
}
`,"/index.html":`<!doctype html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>ClipKaro — Creator Video Clipping Studio</title>
    <link rel="icon" type="image/png" href="/icon-512.png" />
    <link rel="apple-touch-icon" href="/icon-512.png" />
    <meta
      name="description"
      content="ClipKaro creator studio with in-app YouTube, Instagram, and Facebook viewer, permission tracking, voiceover and music mixing, and clip gallery."
    />
    <meta property="og:title" content="ClipKaro — Creator Video Clipping Studio" />
    <meta
      property="og:description"
      content="ClipKaro creator studio with in-app YouTube, Instagram, and Facebook viewer, permission tracking, voiceover and music mixing, and clip gallery."
    />
    <meta property="og:type" content="website" />
    <meta name="twitter:card" content="summary_large_image" />
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link
      href="https://fonts.googleapis.com/css2?family=DM+Sans:ital,opsz,wght@0,9..40,400..700;1,9..40,400..700&family=JetBrains+Mono:wght@400;500;600&family=Plus+Jakarta+Sans:wght@500;600;700;800&display=swap"
      rel="stylesheet"
    />
  </head>
  <body class="bg-[#0B0E14] text-slate-100 antialiased selection:bg-rose-500/30 selection:text-white">
    <div id="root"></div>
    <script type="module" src="/src/main.tsx"><\/script>
  </body>
</html>
`,"/metadata.json":`{
  "name": "ClipKaro",
  "description": "Creator video clipping studio with in-app YouTube, Instagram, and Facebook viewer, streamer permission attribution, voiceover and music mixing, and clip gallery.",
  "requestFramePermissions": ["microphone"],
  "majorCapabilities": ["MAJOR_CAPABILITY_SERVER_SIDE_GEMINI_API"]
}
`,"/package.json":`{
  "name": "react-example",
  "private": true,
  "version": "0.0.0",
  "type": "module",
  "scripts": {
    "dev": "vite --port=3000 --host=0.0.0.0",
    "build": "vite build",
    "preview": "vite preview",
    "clean": "rm -rf dist server.js",
    "lint": "tsc --noEmit",
    "postinstall": "node scripts/copy-ffmpeg.mjs"
  },
  "dependencies": {
    "@ffmpeg/core": "^0.12.10",
    "@ffmpeg/ffmpeg": "^0.12.15",
    "@ffmpeg/util": "^0.12.2",
    "@google/genai": "^2.4.0",
    "@tailwindcss/vite": "^4.3.3",
    "@vitejs/plugin-react": "^6.1.1",
    "dotenv": "^17.2.3",
    "express": "^4.21.2",
    "lucide-react": "^0.546.0",
    "motion": "^12.23.24",
    "react": "^19.0.1",
    "react-dom": "^19.0.1",
    "vite": "^8.3.0"
  },
  "devDependencies": {
    "@types/node": "^22.14.0",
    "@types/react": "^19.3.0",
    "@types/react-dom": "^19.3.0",
    "autoprefixer": "^10.4.21",
    "esbuild": "^0.25.0",
    "tailwindcss": "^4.3.3",
    "tsx": "^4.21.0",
    "typescript": "^7.0.2",
    "@types/express": "^4.17.21"
  }
}
`,"/scripts/copy-ffmpeg.mjs":`import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const projectRoot = path.resolve(__dirname, '..');

const sourceDir = path.join(projectRoot, 'node_modules', '@ffmpeg', 'core', 'dist', 'esm');
const targetDir = path.join(projectRoot, 'public', 'ffmpeg');

const files = ['ffmpeg-core.js', 'ffmpeg-core.wasm'];

if (!fs.existsSync(sourceDir)) {
  console.log('[copy-ffmpeg] @ffmpeg/core is not installed yet; skipping copy.');
  process.exit(0);
}

fs.mkdirSync(targetDir, { recursive: true });

for (const file of files) {
  const src = path.join(sourceDir, file);
  const dest = path.join(targetDir, file);
  if (fs.existsSync(src)) {
    fs.copyFileSync(src, dest);
    console.log(\`[copy-ffmpeg] Copied \${file} -> public/ffmpeg/\${file}\`);
  }
}
`,"/src/App.tsx":`import { useCallback, useEffect, useMemo, useState } from 'react';
import { Layers, RefreshCw, ShieldAlert } from 'lucide-react';
import { AddMusicView } from './components/AddMusicView';
import { AddVoiceView } from './components/AddVoiceView';
import { CutVideoView } from './components/CutVideoView';
import { HomeView } from './components/HomeView';
import { InGameFloatingButton } from './components/InGameFloatingButton';
import { MyAppsView } from './components/MyAppsView';
import { MyClipsView } from './components/MyClipsView';
import { MyGamesView } from './components/MyGamesView';
import { TopNav } from './components/TopNav';
import { WelcomePermissionScreen } from './components/WelcomePermissionScreen';
import {
  ClipItem,
  GameItem,
  SocialPlatform,
  VoiceChangerPreset,
  WorkspaceTab,
} from './types/clipkaro';
import {
  ClipKaroPermissionState,
  deleteNativeClipKaroVideo,
  fetchNativeClipBlob,
  getPermissionState,
  listNativeClipKaroVideos,
  requestOverlayPermission,
  syncNativeFloatingOptions,
} from './utils/androidPermissions';
import {
  addCustomGameToDb,
  DEFAULT_GAMES,
  deleteClipFromDb,
  deleteCustomGameFromDb,
  findExpiredClips,
  getAllClips,
  getAllGames,
  getStoredAutoDelete7Days,
  getStoredCopyrightSafeMode,
  getStoredKeepBestClips,
  getStoredReactionOptions,
  getStoredShowViralScoreInApp,
  saveClipToDb,
  selectTodaysBestClip,
  setStoredAutoDelete7Days,
  setStoredCopyrightSafeMode,
  setStoredKeepBestClips,
  setStoredReactionOptions,
  setStoredShowViralScoreInApp,
} from './utils/mediaStorage';

export default function App() {
  const [activeTab, setActiveTab] = useState<WorkspaceTab>('home');
  const [clips, setClips] = useState<ClipItem[]>([]);
  const [games, setGames] = useState<GameItem[]>(DEFAULT_GAMES);
  const [isLoadingStore, setIsLoadingStore] = useState<boolean>(true);
  const [copyrightSafeMode, setCopyrightSafeMode] = useState<boolean>(() =>
    getStoredCopyrightSafeMode()
  );
  const [autoDelete7Days, setAutoDelete7Days] = useState<boolean>(() =>
    getStoredAutoDelete7Days()
  );
  const [keepBestClips, setKeepBestClips] = useState<boolean>(() =>
    getStoredKeepBestClips()
  );
  const [showViralScoreInApp, setShowViralScoreInApp] = useState<boolean>(() =>
    getStoredShowViralScoreInApp()
  );
  const [reactionOptions, setReactionOptions] = useState<{
    reactionMode: boolean;
    facecamEnabled: boolean;
    voiceChanger: VoiceChangerPreset;
  }>(() => getStoredReactionOptions());

  // First-Launch Welcome Permission State (persisted via SharedPreferences on Android)
  const [permissionState, setPermissionState] = useState<ClipKaroPermissionState>(() =>
    getPermissionState()
  );
  const [showOverlayBlockedModal, setShowOverlayBlockedModal] = useState<boolean>(false);
  const [overlayBlockedRetryShown, setOverlayBlockedRetryShown] = useState<boolean>(false);
  const [awaitingOverlayFromGames, setAwaitingOverlayFromGames] = useState<boolean>(false);

  // Cross-view contextual handoffs
  const [cutLinkPrefill, setCutLinkPrefill] = useState<string>('');
  const [cutPlatformPrefill, setCutPlatformPrefill] = useState<
    SocialPlatform | 'upload' | 'studio'
  >('youtube');
  const [cutStreamerPrefill, setCutStreamerPrefill] = useState<string>('');
  const [cutGamePrefill, setCutGamePrefill] = useState<string>('');
  const [clipsGameFilter, setClipsGameFilter] = useState<string>('all');
  const [clipToOpenFromHomeId, setClipToOpenFromHomeId] = useState<string | null>(null);

  // In-Game Floating Button state (demo visible by default only in web preview, never inside native Android APK)
  const isWebPreview = !permissionState.isNativeAndroid;
  const [floatingVisible, setFloatingVisible] = useState<boolean>(isWebPreview);
  const [floatingGameName, setFloatingGameName] = useState<string>('BGMI');
  const [isFloatingDemo, setIsFloatingDemo] = useState<boolean>(isWebPreview);

  const syncPermissionState = useCallback(() => {
    const latest = getPermissionState();
    setPermissionState(latest);
    return latest;
  }, []);

  useEffect(() => {
    const handleSync = () => {
      const latest = syncPermissionState();
      if (awaitingOverlayFromGames) {
        setAwaitingOverlayFromGames(false);
        if (latest.overlay) {
          setShowOverlayBlockedModal(false);
          setOverlayBlockedRetryShown(false);
          setActiveTab('games');
        } else {
          setOverlayBlockedRetryShown(true);
        }
      }
    };

    const handleVisibility = () => {
      if (document.visibilityState === 'visible') {
        handleSync();
      }
    };

    window.addEventListener('clipkaro-permissions-updated', handleSync);
    window.addEventListener('focus', handleSync);
    document.addEventListener('visibilitychange', handleVisibility);
    return () => {
      window.removeEventListener('clipkaro-permissions-updated', handleSync);
      window.removeEventListener('focus', handleSync);
      document.removeEventListener('visibilitychange', handleVisibility);
    };
  }, [awaitingOverlayFromGames, syncPermissionState]);

  const navigateWithGuard = useCallback(
    (tab: WorkspaceTab) => {
      if (tab === 'games') {
        const latest = syncPermissionState();
        if (!latest.overlay) {
          setShowOverlayBlockedModal(true);
          return;
        }
      }
      if (tab === 'clips') setClipsGameFilter('all');
      setActiveTab(tab);
    },
    [syncPermissionState]
  );

  const applySmartStorageCleanup = useCallback(
    async (loadedClips: ClipItem[], shouldAutoDelete: boolean, shouldKeepBest: boolean) => {
      if (!shouldAutoDelete) return loadedClips;
      const expired = findExpiredClips(loadedClips, shouldKeepBest);
      if (expired.length === 0) return loadedClips;
      for (const exp of expired) {
        await deleteClipFromDb(exp.id);
        if (exp.nativeUri) {
          deleteNativeClipKaroVideo(exp.nativeUri);
        }
      }
      return getAllClips();
    },
    []
  );

  const refreshStore = useCallback(async () => {
    try {
      const [rawClips, loadedGames] = await Promise.all([getAllClips(), getAllGames()]);
      const finalClips = await applySmartStorageCleanup(
        rawClips,
        autoDelete7Days,
        keepBestClips
      );
      setClips(finalClips);
      setGames(loadedGames);
      return finalClips;
    } finally {
      setIsLoadingStore(false);
    }
  }, [applySmartStorageCleanup, autoDelete7Days, keepBestClips]);

  const syncNativeClipKaroFolder = useCallback(async (): Promise<number> => {
    if (!permissionState.isNativeAndroid) return 0;
    const nativeEntries = listNativeClipKaroVideos();
    if (nativeEntries.length === 0) return 0;

    const existing = await getAllClips();
    const knownUris = new Set(existing.map((c) => c.nativeUri).filter(Boolean));
    const knownNames = new Set(existing.map((c) => c.nativeFileName).filter(Boolean));

    let importedCount = 0;
    for (const entry of nativeEntries) {
      if (knownUris.has(entry.uri) || knownNames.has(entry.fileName)) {
        continue;
      }
      const blob = await fetchNativeClipBlob(entry.uri);
      if (!blob || blob.size < 1024) continue;

      const lowerName = entry.fileName.toLowerCase();
      const gameGuess = lowerName.includes('youtube')
        ? 'YouTube'
        : lowerName.includes('instagram')
          ? 'Instagram'
          : lowerName.includes('facebook')
            ? 'Facebook'
            : lowerName.includes('whatsapp')
              ? 'WhatsApp'
              : lowerName.includes('free_fire')
                ? 'Free Fire MAX'
                : 'BGMI';
      const isReaction = lowerName.includes('reaction');
      const cleanTitle = entry.fileName
        .replace(/\\.mp4$/i, '')
        .replace(/_/g, ' ')
        .trim();

      await saveClipToDb({
        id: \`native-\${Date.now()}-\${Math.random().toString(36).slice(2, 7)}\`,
        title: cleanTitle || 'ClipKaro Recording',
        platform: 'studio',
        gameTag: gameGuess,
        durationSec: Math.max(1, entry.durationSec || 10),
        trimStart: 0,
        trimEnd: Math.max(1, entry.durationSec || 10),
        createdAt: entry.createdAtMs || Date.now(),
        copyrightSafe: true,
        isReaction,
        hasFacecam: isReaction,
        permission: {
          hasPermission: true,
          streamerName: 'MyGameplay',
          originalVideoLink: '',
          creditText: 'Credit: @MyGameplay',
        },
        videoBlob: blob,
        videoMimeType: blob.type || 'video/mp4',
        nativeUri: entry.uri,
        nativeFileName: entry.fileName,
        voiceVolume: 1,
        musicVolume: 0.45,
        originalVolume: 1,
      });
      importedCount += 1;
    }

    if (importedCount > 0) {
      const rawUpdated = await getAllClips();
      const cleaned = await applySmartStorageCleanup(rawUpdated, autoDelete7Days, keepBestClips);
      setClips(cleaned);
    }
    return importedCount;
  }, [applySmartStorageCleanup, autoDelete7Days, keepBestClips, permissionState.isNativeAndroid]);

  useEffect(() => {
    refreshStore().then(() => {
      syncNativeClipKaroFolder();
    });
  }, [refreshStore, syncNativeClipKaroFolder]);

  useEffect(() => {
    const onNativeClipSaved = () => {
      syncNativeClipKaroFolder();
    };
    window.addEventListener('clipkaro-native-clips-updated', onNativeClipSaved);
    return () => {
      window.removeEventListener('clipkaro-native-clips-updated', onNativeClipSaved);
    };
  }, [syncNativeClipKaroFolder]);

  const handleToggleCopyrightSafeMode = () => {
    setCopyrightSafeMode((prev) => {
      const next = !prev;
      setStoredCopyrightSafeMode(next);
      return next;
    });
  };

  const handleToggleAutoDelete7Days = async () => {
    const next = !autoDelete7Days;
    setAutoDelete7Days(next);
    setStoredAutoDelete7Days(next);
    if (next) {
      const cleaned = await applySmartStorageCleanup(clips, true, keepBestClips);
      setClips(cleaned);
    }
  };

  const handleToggleKeepBestClips = () => {
    const next = !keepBestClips;
    setKeepBestClips(next);
    setStoredKeepBestClips(next);
  };

  const handleRunSmartCleanupNow = async (): Promise<number> => {
    const expired = findExpiredClips(clips, keepBestClips);
    if (expired.length === 0) return 0;
    for (const exp of expired) {
      await deleteClipFromDb(exp.id);
      if (exp.nativeUri) {
        deleteNativeClipKaroVideo(exp.nativeUri);
      }
    }
    const updated = await getAllClips();
    setClips(updated);
    return expired.length;
  };

  const handleUpdateReactionOptions = (partial: {
    reactionMode?: boolean;
    facecamEnabled?: boolean;
    voiceChanger?: VoiceChangerPreset;
  }) => {
    setReactionOptions((prev) => {
      const next = {
        reactionMode: partial.reactionMode ?? prev.reactionMode,
        facecamEnabled: partial.facecamEnabled ?? prev.facecamEnabled,
        voiceChanger: partial.voiceChanger ?? prev.voiceChanger,
      };
      setStoredReactionOptions(next);
      syncNativeFloatingOptions(next.facecamEnabled, next.voiceChanger, next.reactionMode);
      return next;
    });
  };

  const handleSaveClip = async (clip: ClipItem) => {
    await saveClipToDb(clip);
    const updated = await getAllClips();
    setClips(updated);
  };

  const handleDeleteClip = async (id: string) => {
    const target = clips.find((c) => c.id === id);
    await deleteClipFromDb(id);
    if (target?.nativeUri) {
      deleteNativeClipKaroVideo(target.nativeUri);
    }
    const updated = await getAllClips();
    setClips(updated);
  };

  const handleToggleFavouriteClip = async (clip: ClipItem) => {
    await saveClipToDb({
      ...clip,
      isFavourite: !clip.isFavourite,
    });
    const updated = await getAllClips();
    setClips(updated);
  };

  const handleToggleShowViralScoreInApp = () => {
    setShowViralScoreInApp((prev) => {
      const next = !prev;
      setStoredShowViralScoreInApp(next);
      return next;
    });
  };

  const handleToggleClipHideScore = async (clip: ClipItem) => {
    await saveClipToDb({
      ...clip,
      hideViralScore: !clip.hideViralScore,
    });
    const updated = await getAllClips();
    setClips(updated);
  };

  const todaysBestClip = useMemo(() => selectTodaysBestClip(clips), [clips]);

  const handleAddGame = async (name: string, genre: string) => {
    const coverPool = DEFAULT_GAMES.map((g) => g.coverUrl);
    const coverUrl = coverPool[games.length % coverPool.length];
    const newGame: GameItem = {
      id: \`game-custom-\${Date.now()}\`,
      name,
      genre,
      coverUrl,
      isCustom: true,
    };
    await addCustomGameToDb(newGame);
    const updatedGames = await getAllGames();
    setGames(updatedGames);
  };

  const handleDeleteCustomGame = async (id: string) => {
    await deleteCustomGameFromDb(id);
    const updatedGames = await getAllGames();
    setGames(updatedGames);
  };

  const handleSendLinkToCut = (
    url: string,
    platform: SocialPlatform,
    suggestedStreamer?: string
  ) => {
    setCutLinkPrefill(url);
    setCutPlatformPrefill(platform);
    setCutStreamerPrefill(suggestedStreamer ?? '');
    setActiveTab('cut');
  };

  const handleViewGameClips = (gameName: string) => {
    setClipsGameFilter(gameName);
    setActiveTab('clips');
  };

  const handleCutClipForGame = (gameName: string) => {
    setCutGamePrefill(gameName);
    setActiveTab('cut');
  };

  const handleRequestOverlayFromGate = () => {
    const { awaitingNativeSettings } = requestOverlayPermission();
    if (awaitingNativeSettings) {
      setAwaitingOverlayFromGames(true);
    } else {
      const latest = syncPermissionState();
      if (latest.overlay) {
        setShowOverlayBlockedModal(false);
        setOverlayBlockedRetryShown(false);
        setActiveTab('games');
      } else {
        setOverlayBlockedRetryShown(true);
      }
    }
  };

  // Show Welcome Permission Screen before Home Screen on first launch
  if (!permissionState.setupDone) {
    return (
      <WelcomePermissionScreen
        permissionState={permissionState}
        onRefreshPermissions={syncPermissionState}
        onComplete={() => {
          syncPermissionState();
          setActiveTab('home');
        }}
      />
    );
  }

  return (
    <div className="min-h-screen bg-[#0B0E14] text-slate-100 flex flex-col">
      <TopNav activeTab={activeTab} onNavigate={navigateWithGuard} />

      <main className="mx-auto w-full max-w-7xl flex-1 px-4 py-6 sm:px-6 sm:py-8">
        {isLoadingStore ? (
          <div className="space-y-4">
            <div className="h-8 w-64 animate-pulse rounded-lg bg-slate-800/70" />
            <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-6">
              {Array.from({ length: 6 }).map((_, idx) => (
                <div key={idx} className="h-28 animate-pulse rounded-xl bg-slate-800/50" />
              ))}
            </div>
            <div className="aspect-video w-full animate-pulse rounded-xl bg-slate-800/40" />
          </div>
        ) : (
          <>
            {activeTab === 'home' && (
              <HomeView
                clipCount={clips.length}
                gameCount={games.length}
                copyrightSafeMode={copyrightSafeMode}
                showViralScoreInApp={showViralScoreInApp}
                bestClipEntry={todaysBestClip}
                onPlayBestClip={(clip) => {
                  setClipsGameFilter('all');
                  setClipToOpenFromHomeId(clip.id);
                  setActiveTab('clips');
                }}
                onToggleCopyrightSafeMode={handleToggleCopyrightSafeMode}
                onToggleShowViralScoreInApp={handleToggleShowViralScoreInApp}
                onNavigate={navigateWithGuard}
                onSendLinkToCut={handleSendLinkToCut}
              />
            )}

            {activeTab === 'cut' && (
              <CutVideoView
                copyrightSafeMode={copyrightSafeMode}
                onToggleCopyrightSafeMode={handleToggleCopyrightSafeMode}
                games={games}
                initialOriginalLink={cutLinkPrefill}
                initialPlatform={cutPlatformPrefill}
                initialStreamerName={cutStreamerPrefill}
                initialGameTag={cutGamePrefill}
                onSaveClip={handleSaveClip}
                onGoToMyClips={() => {
                  setClipsGameFilter('all');
                  setActiveTab('clips');
                }}
              />
            )}

            {activeTab === 'voice' && (
              <AddVoiceView
                clips={clips}
                onSaveClip={handleSaveClip}
                onNavigate={navigateWithGuard}
              />
            )}

            {activeTab === 'music' && (
              <AddMusicView
                clips={clips}
                copyrightSafeMode={copyrightSafeMode}
                onSaveClip={handleSaveClip}
                onNavigate={navigateWithGuard}
              />
            )}

            {activeTab === 'clips' && (
              <MyClipsView
                clips={clips}
                games={games}
                initialGameFilter={clipsGameFilter}
                initialPlayClipId={clipToOpenFromHomeId}
                onClearInitialPlayClip={() => setClipToOpenFromHomeId(null)}
                isNativeAndroid={permissionState.isNativeAndroid}
                autoDelete7Days={autoDelete7Days}
                keepBestClips={keepBestClips}
                showViralScoreInApp={showViralScoreInApp}
                onToggleShowViralScoreInApp={handleToggleShowViralScoreInApp}
                onToggleClipHideScore={handleToggleClipHideScore}
                onToggleAutoDelete7Days={handleToggleAutoDelete7Days}
                onToggleKeepBestClips={handleToggleKeepBestClips}
                onRunSmartCleanupNow={handleRunSmartCleanupNow}
                onToggleFavouriteClip={handleToggleFavouriteClip}
                onSyncClipKaroFolder={syncNativeClipKaroFolder}
                onDeleteClip={handleDeleteClip}
                onSaveClip={handleSaveClip}
                onNavigate={navigateWithGuard}
              />
            )}

            {activeTab === 'apps' && (
              <MyAppsView
                clips={clips}
                floatingVisible={floatingVisible}
                activeFloatingTarget={floatingGameName}
                reactionMode={reactionOptions.reactionMode}
                facecamEnabled={reactionOptions.facecamEnabled}
                voiceChanger={reactionOptions.voiceChanger}
                onUpdateReactionOptions={handleUpdateReactionOptions}
                onSaveClip={handleSaveClip}
                onActivateFloatingForApp={(appName) => {
                  let latest = syncPermissionState();
                  if (!latest.overlay) {
                    const { awaitingNativeSettings } = requestOverlayPermission();
                    if (awaitingNativeSettings) {
                      setShowOverlayBlockedModal(true);
                      return;
                    }
                    latest = syncPermissionState();
                    if (!latest.overlay) {
                      setShowOverlayBlockedModal(true);
                      return;
                    }
                  }
                  setFloatingGameName(appName);
                  setIsFloatingDemo(false);
                  setFloatingVisible(true);
                }}
                onStopFloatingButton={() => setFloatingVisible(false)}
                onViewAppClips={handleViewGameClips}
              />
            )}

            {activeTab === 'games' && permissionState.overlay && (
              <MyGamesView
                games={games}
                clips={clips}
                onAddGame={handleAddGame}
                onDeleteCustomGame={handleDeleteCustomGame}
                onViewGameClips={handleViewGameClips}
                onCutClipForGame={handleCutClipForGame}
                onSaveClip={handleSaveClip}
                onActivateFloatingButton={(gameName) => {
                  setFloatingGameName(gameName);
                  setIsFloatingDemo(false);
                  setFloatingVisible(true);
                }}
              />
            )}
          </>
        )}
      </main>

      {/* Strict Guard Modal: Do not let user enter My Games without Overlay permission */}
      {showOverlayBlockedModal && (
        <div
          role="dialog"
          aria-modal="true"
          aria-labelledby="overlay-required-title"
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4 backdrop-blur-sm"
        >
          <div className="w-full max-w-md rounded-2xl border border-rose-500/40 bg-[#121722] p-6 shadow-2xl space-y-4">
            <div className="flex items-start gap-3">
              <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-rose-500/15 text-rose-400">
                <Layers className="h-5 w-5" aria-hidden="true" />
              </span>
              <div>
                <h2 id="overlay-required-title" className="font-display text-lg font-bold text-white">
                  Overlay Permission Required
                </h2>
                <p className="mt-0.5 text-xs text-slate-300">
                  Permission Required to show CLIP button in BGMI
                </p>
              </div>
            </div>

            <div className="flex items-start gap-2.5 rounded-xl border border-rose-500/60 bg-rose-950/50 p-3.5 text-xs text-rose-200">
              <ShieldAlert className="h-4 w-4 text-rose-400 shrink-0 mt-0.5" aria-hidden="true" />
              <span className="font-semibold">
                Floating button will not appear in BGMI without this permission
              </span>
            </div>

            <div className="flex flex-col gap-2 sm:flex-row sm:justify-end">
              <button
                type="button"
                onClick={() => {
                  setShowOverlayBlockedModal(false);
                  if (activeTab === 'games') setActiveTab('home');
                }}
                className="rounded-lg border border-slate-700 bg-[#0B0E14] px-4 py-2 text-xs font-semibold text-slate-300 hover:text-white"
              >
                Back to Home
              </button>
              <button
                type="button"
                onClick={handleRequestOverlayFromGate}
                className="inline-flex items-center justify-center gap-1.5 rounded-lg bg-rose-600 px-4 py-2 text-xs font-bold text-white hover:bg-rose-500"
              >
                {overlayBlockedRetryShown ? (
                  <>
                    <RefreshCw className="h-3.5 w-3.5" aria-hidden="true" />
                    <span>Open Settings Again</span>
                  </>
                ) : (
                  <span>Allow Floating Button</span>
                )}
              </button>
            </div>
          </div>
        </div>
      )}

      {!permissionState.isNativeAndroid && (
        <InGameFloatingButton
          visible={floatingVisible}
          activeGameName={floatingGameName}
          isWebPreviewDemo={isFloatingDemo}
          facecamEnabled={reactionOptions.facecamEnabled}
          voiceChanger={reactionOptions.voiceChanger}
          reactionMode={reactionOptions.reactionMode}
          onUpdateReactionOptions={handleUpdateReactionOptions}
          onSaveClip={handleSaveClip}
          onNavigateToClips={() => {
            setClipsGameFilter('all');
            setActiveTab('clips');
          }}
          onClose={() => setFloatingVisible(false)}
        />
      )}
    </div>
  );
}
`,"/src/components/AddMusicView.tsx":`import { ChangeEvent, useEffect, useMemo, useRef, useState } from 'react';
import {
  CheckCircle2,
  Film,
  Music,
  Pause,
  Play,
  Scissors,
  ShieldCheck,
  Upload,
  Volume2,
} from 'lucide-react';
import { ClipItem, WorkspaceTab } from '../types/clipkaro';
import { generateRoyaltyFreeWavBlob, ROYALTY_FREE_TRACKS } from '../utils/mediaGenerators';

interface AddMusicViewProps {
  clips: ClipItem[];
  copyrightSafeMode: boolean;
  onSaveClip: (clip: ClipItem) => Promise<void>;
  onNavigate: (tab: WorkspaceTab) => void;
}

export function AddMusicView({
  clips,
  copyrightSafeMode,
  onSaveClip,
  onNavigate,
}: AddMusicViewProps) {
  const [selectedClipId, setSelectedClipId] = useState<string>(clips[0]?.id ?? '');
  const [selectedTrackId, setSelectedTrackId] = useState<string>(ROYALTY_FREE_TRACKS[0].id);
  const [customBlob, setCustomBlob] = useState<Blob | null>(null);
  const [customName, setCustomName] = useState<string>('');
  const [customLicenseConfirmed, setCustomLicenseConfirmed] = useState<boolean>(false);

  const [musicVolume, setMusicVolume] = useState<number>(0.45);
  const [originalVolume, setOriginalVolume] = useState<number>(0.85);
  const [previewPlayingId, setPreviewPlayingId] = useState<string | null>(null);
  const [isSaving, setIsSaving] = useState<boolean>(false);
  const [savedNotice, setSavedNotice] = useState<string | null>(null);

  const previewAudioRef = useRef<HTMLAudioElement | null>(null);
  const previewUrlRef = useRef<string | null>(null);
  const customInputRef = useRef<HTMLInputElement | null>(null);

  useEffect(() => {
    if (!selectedClipId && clips.length > 0) {
      setSelectedClipId(clips[0].id);
    }
  }, [clips, selectedClipId]);

  useEffect(() => {
    return () => {
      previewAudioRef.current?.pause();
      if (previewUrlRef.current) URL.revokeObjectURL(previewUrlRef.current);
    };
  }, []);

  const builtInTrackBlobs = useMemo(() => {
    const map: Record<string, Blob> = {};
    for (const track of ROYALTY_FREE_TRACKS) {
      map[track.id] = generateRoyaltyFreeWavBlob(track.id);
    }
    return map;
  }, []);

  const handleTogglePreview = (trackId: string, blob: Blob) => {
    if (previewPlayingId === trackId) {
      previewAudioRef.current?.pause();
      setPreviewPlayingId(null);
      return;
    }

    if (previewUrlRef.current) URL.revokeObjectURL(previewUrlRef.current);
    const nextUrl = URL.createObjectURL(blob);
    previewUrlRef.current = nextUrl;

    if (!previewAudioRef.current) {
      previewAudioRef.current = new Audio();
    }
    previewAudioRef.current.src = nextUrl;
    previewAudioRef.current.volume = musicVolume;
    previewAudioRef.current.onended = () => setPreviewPlayingId(null);
    previewAudioRef.current.play().then(() => setPreviewPlayingId(trackId)).catch(() => undefined);
  };

  const handleCustomMusicUpload = (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setCustomBlob(file);
    setCustomName(file.name);
    setSelectedTrackId('custom');
    setSavedNotice(null);
  };

  const activeBlob =
    selectedTrackId === 'custom' ? customBlob : builtInTrackBlobs[selectedTrackId] ?? null;

  const activeTrackLabel =
    selectedTrackId === 'custom'
      ? customName
      : ROYALTY_FREE_TRACKS.find((t) => t.id === selectedTrackId)?.title ?? 'Music Track';

  const canAttach =
    Boolean(selectedClipId) &&
    Boolean(activeBlob) &&
    (!copyrightSafeMode || selectedTrackId !== 'custom' || customLicenseConfirmed);

  const handleAttachMusic = async () => {
    const target = clips.find((c) => c.id === selectedClipId);
    if (!target || !activeBlob) return;
    setIsSaving(true);
    setSavedNotice(null);
    try {
      await onSaveClip({
        ...target,
        musicBlob: activeBlob,
        musicName: activeTrackLabel,
        musicVolume,
        originalVolume,
      });
      setSavedNotice(\`"\${activeTrackLabel}" attached to "\${target.title}".\`);
    } finally {
      setIsSaving(false);
    }
  };

  const selectedClip = clips.find((c) => c.id === selectedClipId) ?? null;

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-2 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <h1 className="font-display text-2xl font-bold tracking-tight text-white">Add Music</h1>
          <p className="mt-1 text-sm text-slate-400">
            Select a built-in copyright-safe royalty-free track or upload licensed audio to mix under your clip.
          </p>
        </div>
        {copyrightSafeMode && (
          <span className="inline-flex items-center gap-1.5 text-xs font-semibold text-emerald-400">
            <ShieldCheck className="h-4 w-4" aria-hidden="true" />
            <span>Copyright-Safe Library Prioritized</span>
          </span>
        )}
      </div>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
        {/* Left: Royalty-Free Track List + Custom Upload */}
        <section className="space-y-4 rounded-xl border border-slate-800 bg-[#121722] p-5 sm:p-6 lg:col-span-7">
          <div className="flex items-center justify-between">
            <h2 className="font-display text-base font-bold text-white">
              Royalty-Free Music Library
            </h2>
            <span className="text-xs text-slate-400">CC0 Safe Audio</span>
          </div>

          <div className="divide-y divide-slate-800/80 rounded-xl border border-slate-800 bg-[#0B0E14]">
            {ROYALTY_FREE_TRACKS.map((track) => {
              const isSelected = selectedTrackId === track.id;
              const isPreviewing = previewPlayingId === track.id;
              const blob = builtInTrackBlobs[track.id];

              return (
                <div
                  key={track.id}
                  className={\`flex flex-wrap items-center justify-between gap-3 px-4 py-3.5 transition-colors \${
                    isSelected ? 'bg-rose-950/20' : 'hover:bg-slate-900/50'
                  }\`}
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <button
                      type="button"
                      onClick={() => handleTogglePreview(track.id, blob)}
                      aria-label={isPreviewing ? \`Pause \${track.title}\` : \`Preview \${track.title}\`}
                      className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg border border-slate-700 bg-slate-900 text-white hover:border-rose-500"
                    >
                      {isPreviewing ? (
                        <Pause className="h-4 w-4" aria-hidden="true" />
                      ) : (
                        <Play className="h-4 w-4 fill-current" aria-hidden="true" />
                      )}
                    </button>
                    <div className="min-w-0">
                      <div className="font-display text-sm font-semibold text-white truncate">
                        {track.title}
                      </div>
                      <div className="flex flex-wrap items-center gap-2 text-xs text-slate-400 tabular-nums">
                        <span>{track.mood}</span>
                        <span aria-hidden="true">·</span>
                        <span>{track.bpm} BPM</span>
                        <span aria-hidden="true">·</span>
                        <span className="text-emerald-400">{track.license}</span>
                      </div>
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={() => {
                      setSelectedTrackId(track.id);
                      setSavedNotice(null);
                    }}
                    className={\`rounded-lg px-3.5 py-1.5 text-xs font-semibold transition-colors whitespace-nowrap shrink-0 \${
                      isSelected
                        ? 'bg-rose-600 text-white'
                        : 'border border-slate-700 bg-slate-900 text-slate-300 hover:text-white'
                    }\`}
                  >
                    {isSelected ? 'Selected' : 'Use Track'}
                  </button>
                </div>
              );
            })}
          </div>

          {/* Custom Music Upload */}
          <div className="rounded-xl border border-slate-800 bg-[#0B0E14] p-4 space-y-3">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div>
                <div className="text-sm font-semibold text-white">Custom Audio Upload</div>
                <div className="text-xs text-slate-400">
                  Upload MP3, WAV, or OGG background music from your device.
                </div>
              </div>
              <input
                ref={customInputRef}
                type="file"
                accept="audio/*"
                onChange={handleCustomMusicUpload}
                className="sr-only"
              />
              <button
                type="button"
                onClick={() => customInputRef.current?.click()}
                className="inline-flex items-center gap-2 rounded-lg border border-slate-700 bg-slate-900 px-3.5 py-2 text-xs font-semibold text-white hover:border-slate-500"
              >
                <Upload className="h-3.5 w-3.5" aria-hidden="true" />
                <span>Choose Audio</span>
              </button>
            </div>

            {customBlob && (
              <div className="flex flex-wrap items-center justify-between gap-3 border-t border-slate-800 pt-3">
                <div className="flex items-center gap-2 text-xs text-slate-200 truncate">
                  <Music className="h-4 w-4 text-amber-400 shrink-0" aria-hidden="true" />
                  <span className="truncate">{customName}</span>
                </div>
                <button
                  type="button"
                  onClick={() => handleTogglePreview('custom', customBlob)}
                  className="rounded-md border border-slate-700 px-3 py-1 text-xs font-medium text-white hover:bg-slate-800"
                >
                  {previewPlayingId === 'custom' ? 'Pause' : 'Preview'}
                </button>
              </div>
            )}

            {selectedTrackId === 'custom' && copyrightSafeMode && (
              <label className="flex items-start gap-2.5 pt-1 text-xs text-amber-200 cursor-pointer">
                <input
                  type="checkbox"
                  checked={customLicenseConfirmed}
                  onChange={(e) => setCustomLicenseConfirmed(e.target.checked)}
                  className="mt-0.5 rounded border-slate-600 accent-emerald-500"
                />
                <span>
                  Copyright-Safe Mode ON: I confirm I own or have commercial license rights to use this custom music file.
                </span>
              </label>
            )}
          </div>
        </section>

        {/* Right: Mix & Save */}
        <section className="flex flex-col justify-between gap-6 rounded-xl border border-slate-800 bg-[#121722] p-5 sm:p-6 lg:col-span-5">
          <div className="space-y-5">
            <h2 className="font-display text-base font-bold text-white">Mix with Clip</h2>

            {clips.length === 0 ? (
              <div className="space-y-3 rounded-lg border border-slate-800 bg-[#0B0E14] p-4 text-xs text-slate-400">
                <p>No clips saved yet. Cut a clip first before attaching music.</p>
                <button
                  type="button"
                  onClick={() => onNavigate('cut')}
                  className="inline-flex items-center gap-2 rounded-lg bg-slate-800 px-3.5 py-2 font-semibold text-white hover:bg-slate-700"
                >
                  <Scissors className="h-3.5 w-3.5" aria-hidden="true" />
                  <span>Go to Cut Video</span>
                </button>
              </div>
            ) : (
              <>
                <div className="space-y-1.5">
                  <label htmlFor="music-target-clip" className="block text-xs font-semibold text-slate-300">
                    Target Clip
                  </label>
                  <select
                    id="music-target-clip"
                    value={selectedClipId}
                    onChange={(e) => setSelectedClipId(e.target.value)}
                    className="w-full rounded-lg border border-slate-700/80 bg-[#0B0E14] px-3.5 py-2.5 text-sm text-white focus:border-rose-500 focus:outline-none"
                  >
                    {clips.map((c) => (
                      <option key={c.id} value={c.id}>
                        {c.title} ({c.durationSec}s)
                      </option>
                    ))}
                  </select>
                </div>

                {selectedClip && (
                  <div className="rounded-lg border border-slate-800 bg-[#0B0E14] p-3 text-xs text-slate-400 space-y-1">
                    <div className="font-medium text-slate-200">{selectedClip.title}</div>
                    <div>Selected track: {activeTrackLabel}</div>
                    {selectedClip.musicName && (
                      <div className="text-amber-400">Current music: {selectedClip.musicName}</div>
                    )}
                  </div>
                )}

                <div className="space-y-3">
                  <div className="space-y-1.5">
                    <div className="flex items-center justify-between text-xs">
                      <span className="inline-flex items-center gap-1.5 text-slate-300">
                        <Volume2 className="h-3.5 w-3.5 text-amber-400" aria-hidden="true" />
                        <span>Music Volume</span>
                      </span>
                      <span className="font-mono text-slate-300 tabular-nums">
                        {Math.round(musicVolume * 100)}%
                      </span>
                    </div>
                    <input
                      type="range"
                      min={0}
                      max={1}
                      step={0.05}
                      value={musicVolume}
                      onChange={(e) => {
                        const val = parseFloat(e.target.value);
                        setMusicVolume(val);
                        if (previewAudioRef.current) previewAudioRef.current.volume = val;
                      }}
                      className="w-full accent-amber-400"
                    />
                  </div>

                  <div className="space-y-1.5">
                    <div className="flex items-center justify-between text-xs">
                      <span className="text-slate-300">Original Video Audio</span>
                      <span className="font-mono text-slate-300 tabular-nums">
                        {Math.round(originalVolume * 100)}%
                      </span>
                    </div>
                    <input
                      type="range"
                      min={0}
                      max={1}
                      step={0.05}
                      value={originalVolume}
                      onChange={(e) => setOriginalVolume(parseFloat(e.target.value))}
                      className="w-full accent-rose-500"
                    />
                  </div>
                </div>
              </>
            )}

            {savedNotice && (
              <div className="flex items-center justify-between gap-2 rounded-lg border border-emerald-500/40 bg-emerald-950/25 p-3 text-xs text-emerald-200">
                <span className="inline-flex items-center gap-1.5">
                  <CheckCircle2 className="h-4 w-4 text-emerald-400 shrink-0" aria-hidden="true" />
                  <span>{savedNotice}</span>
                </span>
                <button
                  type="button"
                  onClick={() => onNavigate('clips')}
                  className="inline-flex items-center gap-1 rounded bg-emerald-600 px-2.5 py-1 font-semibold text-white hover:bg-emerald-500 shrink-0"
                >
                  <Film className="h-3 w-3" aria-hidden="true" />
                  <span>Play</span>
                </button>
              </div>
            )}
          </div>

          <button
            type="button"
            disabled={!canAttach || isSaving}
            onClick={handleAttachMusic}
            className="inline-flex w-full items-center justify-center gap-2 rounded-lg bg-rose-600 px-4 py-3 text-sm font-bold text-white transition-colors hover:bg-rose-500 disabled:opacity-50"
          >
            <Music className="h-4 w-4" aria-hidden="true" />
            <span>{isSaving ? 'Saving…' : 'Save Music to Clip'}</span>
          </button>
        </section>
      </div>
    </div>
  );
}
`,"/src/components/AddVoiceView.tsx":`import { ChangeEvent, useEffect, useRef, useState } from 'react';
import {
  CheckCircle2,
  Film,
  Mic,
  Scissors,
  Square,
  Trash2,
  Upload,
  Volume2,
} from 'lucide-react';
import { ClipItem, WorkspaceTab } from '../types/clipkaro';
import { formatSeconds } from '../utils/mediaGenerators';

interface AddVoiceViewProps {
  clips: ClipItem[];
  onSaveClip: (clip: ClipItem) => Promise<void>;
  onNavigate: (tab: WorkspaceTab) => void;
}

export function AddVoiceView({ clips, onSaveClip, onNavigate }: AddVoiceViewProps) {
  const [selectedClipId, setSelectedClipId] = useState<string>(clips[0]?.id ?? '');
  const [voiceBlob, setVoiceBlob] = useState<Blob | null>(null);
  const [voiceUrl, setVoiceUrl] = useState<string | null>(null);
  const [voiceName, setVoiceName] = useState<string>('');
  const [voiceVolume, setVoiceVolume] = useState<number>(1);
  const [originalVolume, setOriginalVolume] = useState<number>(0.75);

  const [isRecording, setIsRecording] = useState<boolean>(false);
  const [recordSeconds, setRecordSeconds] = useState<number>(0);
  const [micError, setMicError] = useState<string | null>(null);
  const [isSaving, setIsSaving] = useState<boolean>(false);
  const [savedNotice, setSavedNotice] = useState<string | null>(null);

  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const timerRef = useRef<number | null>(null);
  const analyserRef = useRef<AnalyserNode | null>(null);
  const audioCtxRef = useRef<AudioContext | null>(null);
  const rafRef = useRef<number>(0);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  useEffect(() => {
    if (!selectedClipId && clips.length > 0) {
      setSelectedClipId(clips[0].id);
    }
  }, [clips, selectedClipId]);

  useEffect(() => {
    return () => {
      if (voiceUrl) URL.revokeObjectURL(voiceUrl);
    };
  }, [voiceUrl]);

  useEffect(() => {
    return () => {
      if (timerRef.current) window.clearInterval(timerRef.current);
      cancelAnimationFrame(rafRef.current);
      streamRef.current?.getTracks().forEach((t) => t.stop());
      audioCtxRef.current?.close().catch(() => undefined);
    };
  }, []);

  const drawWaveform = () => {
    const canvas = canvasRef.current;
    const analyser = analyserRef.current;
    if (!canvas || !analyser) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const bufferLen = analyser.frequencyBinCount;
    const dataArray = new Uint8Array(bufferLen);
    analyser.getByteTimeDomainData(dataArray);

    ctx.fillStyle = '#0B0E14';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    ctx.lineWidth = 2;
    ctx.strokeStyle = '#38bdf8';
    ctx.beginPath();

    const sliceWidth = canvas.width / bufferLen;
    let x = 0;
    for (let i = 0; i < bufferLen; i += 1) {
      const v = dataArray[i] / 128.0;
      const y = (v * canvas.height) / 2;
      if (i === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
      x += sliceWidth;
    }
    ctx.lineTo(canvas.width, canvas.height / 2);
    ctx.stroke();

    rafRef.current = requestAnimationFrame(drawWaveform);
  };

  const handleStartRecording = async () => {
    setMicError(null);
    setSavedNotice(null);
    if (!navigator.mediaDevices?.getUserMedia) {
      setMicError('Microphone recording is not supported in this browser. You can upload an audio file instead.');
      return;
    }

    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      streamRef.current = stream;

      const audioCtx = new AudioContext();
      audioCtxRef.current = audioCtx;
      const source = audioCtx.createMediaStreamSource(stream);
      const analyser = audioCtx.createAnalyser();
      analyser.fftSize = 256;
      source.connect(analyser);
      analyserRef.current = analyser;

      const recorder = new MediaRecorder(stream);
      mediaRecorderRef.current = recorder;
      const chunks: BlobPart[] = [];

      recorder.ondataavailable = (ev) => {
        if (ev.data.size > 0) chunks.push(ev.data);
      };

      recorder.onstop = () => {
        const blob = new Blob(chunks, { type: recorder.mimeType || 'audio/webm' });
        if (voiceUrl) URL.revokeObjectURL(voiceUrl);
        setVoiceBlob(blob);
        setVoiceUrl(URL.createObjectURL(blob));
        setVoiceName(\`Voiceover (\${formatSeconds(recordSeconds)})\`);
        stream.getTracks().forEach((t) => t.stop());
        audioCtx.close().catch(() => undefined);
        cancelAnimationFrame(rafRef.current);
      };

      setRecordSeconds(0);
      recorder.start(200);
      setIsRecording(true);
      timerRef.current = window.setInterval(() => {
        setRecordSeconds((prev) => prev + 1);
      }, 1000);
      rafRef.current = requestAnimationFrame(drawWaveform);
    } catch {
      setMicError(
        'Microphone access was denied or unavailable. Please allow microphone access or upload an audio file.'
      );
    }
  };

  const handleStopRecording = () => {
    if (timerRef.current) {
      window.clearInterval(timerRef.current);
      timerRef.current = null;
    }
    if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
      mediaRecorderRef.current.stop();
    }
    setIsRecording(false);
  };

  const handleVoiceUpload = (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setMicError(null);
    setSavedNotice(null);
    if (voiceUrl) URL.revokeObjectURL(voiceUrl);
    setVoiceBlob(file);
    setVoiceUrl(URL.createObjectURL(file));
    setVoiceName(file.name);
  };

  const handleAttachToClip = async () => {
    const target = clips.find((c) => c.id === selectedClipId);
    if (!target || !voiceBlob) return;
    setIsSaving(true);
    setSavedNotice(null);
    try {
      await onSaveClip({
        ...target,
        voiceBlob,
        voiceName: voiceName || 'Voiceover Track',
        voiceVolume,
        originalVolume,
      });
      setSavedNotice(\`Voiceover attached to "\${target.title}".\`);
    } finally {
      setIsSaving(false);
    }
  };

  const selectedClip = clips.find((c) => c.id === selectedClipId) ?? null;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-2xl font-bold tracking-tight text-white">Add Voice</h1>
        <p className="mt-1 text-sm text-slate-400">
          Record live commentary with your microphone or upload a voiceover file, then attach it to any saved clip.
        </p>
      </div>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
        {/* Left: Recorder & Upload */}
        <section className="space-y-5 rounded-xl border border-slate-800 bg-[#121722] p-5 sm:p-6 lg:col-span-7">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <h2 className="font-display text-base font-bold text-white">Voiceover Studio</h2>
            <span className="font-mono text-xs text-slate-400 tabular-nums">
              {isRecording ? \`Recording \${formatSeconds(recordSeconds)}\` : 'Ready'}
            </span>
          </div>

          {/* Live Waveform Canvas */}
          <div className="overflow-hidden rounded-xl border border-slate-800 bg-[#0B0E14]">
            <canvas
              ref={canvasRef}
              width={640}
              height={120}
              className="h-28 w-full block"
            />
          </div>

          <div className="flex flex-wrap items-center gap-3">
            {isRecording ? (
              <button
                type="button"
                onClick={handleStopRecording}
                className="inline-flex items-center gap-2 rounded-lg bg-rose-600 px-4 py-2.5 text-sm font-semibold text-white hover:bg-rose-500"
              >
                <Square className="h-4 w-4 fill-current" aria-hidden="true" />
                <span>Stop Recording</span>
              </button>
            ) : (
              <button
                type="button"
                onClick={handleStartRecording}
                className="inline-flex items-center gap-2 rounded-lg bg-rose-600 px-4 py-2.5 text-sm font-semibold text-white hover:bg-rose-500"
              >
                <Mic className="h-4 w-4" aria-hidden="true" />
                <span>Record Voiceover</span>
              </button>
            )}

            <input
              ref={fileInputRef}
              type="file"
              accept="audio/*"
              onChange={handleVoiceUpload}
              className="sr-only"
            />
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className="inline-flex items-center gap-2 rounded-lg border border-slate-700 bg-[#0B0E14] px-4 py-2.5 text-sm font-semibold text-slate-200 hover:border-slate-500 hover:text-white"
            >
              <Upload className="h-4 w-4" aria-hidden="true" />
              <span>Upload Audio File</span>
            </button>
          </div>

          {micError && (
            <div
              role="alert"
              className="rounded-lg border border-amber-500/40 bg-amber-950/20 p-3.5 text-xs text-amber-200"
            >
              {micError}
            </div>
          )}

          {voiceUrl && (
            <div className="space-y-3 rounded-xl border border-slate-800 bg-[#0B0E14] p-4">
              <div className="flex items-center justify-between gap-3">
                <span className="text-xs font-semibold text-slate-200 truncate">{voiceName}</span>
                <button
                  type="button"
                  onClick={() => {
                    if (voiceUrl) URL.revokeObjectURL(voiceUrl);
                    setVoiceBlob(null);
                    setVoiceUrl(null);
                    setVoiceName('');
                  }}
                  className="inline-flex items-center gap-1 text-xs text-slate-400 hover:text-rose-300"
                >
                  <Trash2 className="h-3.5 w-3.5" aria-hidden="true" />
                  <span>Clear</span>
                </button>
              </div>
              <audio src={voiceUrl} controls className="w-full" />
            </div>
          )}
        </section>

        {/* Right: Mix & Save to Clip */}
        <section className="flex flex-col justify-between gap-6 rounded-xl border border-slate-800 bg-[#121722] p-5 sm:p-6 lg:col-span-5">
          <div className="space-y-5">
            <h2 className="font-display text-base font-bold text-white">Attach to Clip</h2>

            {clips.length === 0 ? (
              <div className="space-y-3 rounded-lg border border-slate-800 bg-[#0B0E14] p-4 text-xs text-slate-400">
                <p>No clips in My Clips yet. Cut a clip first so you can attach this voiceover.</p>
                <button
                  type="button"
                  onClick={() => onNavigate('cut')}
                  className="inline-flex items-center gap-2 rounded-lg bg-slate-800 px-3.5 py-2 font-semibold text-white hover:bg-slate-700"
                >
                  <Scissors className="h-3.5 w-3.5" aria-hidden="true" />
                  <span>Go to Cut Video</span>
                </button>
              </div>
            ) : (
              <>
                <div className="space-y-1.5">
                  <label htmlFor="voice-target-clip" className="block text-xs font-semibold text-slate-300">
                    Target Clip
                  </label>
                  <select
                    id="voice-target-clip"
                    value={selectedClipId}
                    onChange={(e) => setSelectedClipId(e.target.value)}
                    className="w-full rounded-lg border border-slate-700/80 bg-[#0B0E14] px-3.5 py-2.5 text-sm text-white focus:border-rose-500 focus:outline-none"
                  >
                    {clips.map((c) => (
                      <option key={c.id} value={c.id}>
                        {c.title} ({c.durationSec}s)
                      </option>
                    ))}
                  </select>
                </div>

                {selectedClip && (
                  <div className="rounded-lg border border-slate-800 bg-[#0B0E14] p-3 text-xs text-slate-400 space-y-1">
                    <div className="font-medium text-slate-200">{selectedClip.title}</div>
                    <div>{selectedClip.permission.creditText}</div>
                    {selectedClip.voiceName && (
                      <div className="text-sky-400">Current voice: {selectedClip.voiceName}</div>
                    )}
                  </div>
                )}

                <div className="space-y-3">
                  <div className="space-y-1.5">
                    <div className="flex items-center justify-between text-xs">
                      <span className="inline-flex items-center gap-1.5 text-slate-300">
                        <Volume2 className="h-3.5 w-3.5 text-sky-400" aria-hidden="true" />
                        <span>Voiceover Volume</span>
                      </span>
                      <span className="font-mono text-slate-300 tabular-nums">
                        {Math.round(voiceVolume * 100)}%
                      </span>
                    </div>
                    <input
                      type="range"
                      min={0}
                      max={1}
                      step={0.05}
                      value={voiceVolume}
                      onChange={(e) => setVoiceVolume(parseFloat(e.target.value))}
                      className="w-full accent-sky-400"
                    />
                  </div>

                  <div className="space-y-1.5">
                    <div className="flex items-center justify-between text-xs">
                      <span className="text-slate-300">Original Video Audio</span>
                      <span className="font-mono text-slate-300 tabular-nums">
                        {Math.round(originalVolume * 100)}%
                      </span>
                    </div>
                    <input
                      type="range"
                      min={0}
                      max={1}
                      step={0.05}
                      value={originalVolume}
                      onChange={(e) => setOriginalVolume(parseFloat(e.target.value))}
                      className="w-full accent-rose-500"
                    />
                  </div>
                </div>
              </>
            )}

            {savedNotice && (
              <div className="flex items-center justify-between gap-2 rounded-lg border border-emerald-500/40 bg-emerald-950/25 p-3 text-xs text-emerald-200">
                <span className="inline-flex items-center gap-1.5">
                  <CheckCircle2 className="h-4 w-4 text-emerald-400 shrink-0" aria-hidden="true" />
                  <span>{savedNotice}</span>
                </span>
                <button
                  type="button"
                  onClick={() => onNavigate('clips')}
                  className="inline-flex items-center gap-1 rounded bg-emerald-600 px-2.5 py-1 font-semibold text-white hover:bg-emerald-500 shrink-0"
                >
                  <Film className="h-3 w-3" aria-hidden="true" />
                  <span>Play</span>
                </button>
              </div>
            )}
          </div>

          <button
            type="button"
            disabled={!selectedClip || !voiceBlob || isSaving}
            onClick={handleAttachToClip}
            className="inline-flex w-full items-center justify-center gap-2 rounded-lg bg-rose-600 px-4 py-3 text-sm font-bold text-white transition-colors hover:bg-rose-500 disabled:opacity-50"
          >
            <Mic className="h-4 w-4" aria-hidden="true" />
            <span>{isSaving ? 'Saving…' : 'Save Voice to Clip'}</span>
          </button>
        </section>
      </div>
    </div>
  );
}
`,"/src/components/AiAutoEditModal.tsx":`import { useEffect, useMemo, useRef, useState } from 'react';
import {
  CheckCircle2,
  Flame,
  Music,
  Play,
  Scissors,
  Sparkles,
  Wand2,
  X,
} from 'lucide-react';
import { ClipItem } from '../types/clipkaro';
import { AiAutoEditAnalysis } from '../utils/aiAutoEditor';
import { formatSeconds } from '../utils/mediaGenerators';
import { saveVideoToNativeClipKaroFolder } from '../utils/androidPermissions';
import { combineCssFilters, getAspectContainerClass } from '../utils/videoEditorPresets';
import { calculateViralScore } from '../utils/viralScore';

interface AiAutoEditModalProps {
  originalClip: ClipItem;
  analysis: AiAutoEditAnalysis;
  onSaveClip: (clip: ClipItem) => Promise<void>;
  onClose: () => void;
  onCompleteNotice: (message: string) => void;
}

export function AiAutoEditModal({
  originalClip,
  analysis,
  onSaveClip,
  onClose,
  onCompleteNotice,
}: AiAutoEditModalProps) {
  const [activeVersion, setActiveVersion] = useState<'ai' | 'original'>('ai');
  const [isSaving, setIsSaving] = useState<boolean>(false);

  const [origVideoUrl, setOrigVideoUrl] = useState<string>('');
  const [aiVideoUrl, setAiVideoUrl] = useState<string>('');
  const [aiMusicUrl, setAiMusicUrl] = useState<string | null>(null);

  const videoRef = useRef<HTMLVideoElement | null>(null);
  const musicAudioRef = useRef<HTMLAudioElement | null>(null);

  const activeClip = activeVersion === 'ai' ? analysis.editedClip : originalClip;

  const originalViral = useMemo(() => calculateViralScore(originalClip), [originalClip]);
  const aiViral = useMemo(() => calculateViralScore(analysis.editedClip), [analysis.editedClip]);

  useEffect(() => {
    const oUrl = URL.createObjectURL(originalClip.videoBlob);
    setOrigVideoUrl(oUrl);
    const sameBlob = analysis.editedClip.videoBlob === originalClip.videoBlob;
    const aUrl = sameBlob ? oUrl : URL.createObjectURL(analysis.editedClip.videoBlob);
    setAiVideoUrl(aUrl);
    const mUrl = analysis.editedClip.musicBlob
      ? URL.createObjectURL(analysis.editedClip.musicBlob)
      : null;
    setAiMusicUrl(mUrl);

    return () => {
      URL.revokeObjectURL(oUrl);
      if (!sameBlob) URL.revokeObjectURL(aUrl);
      if (mUrl) URL.revokeObjectURL(mUrl);
    };
  }, [originalClip, analysis]);

  useEffect(() => {
    const v = videoRef.current;
    const m = musicAudioRef.current;
    if (m) {
      m.pause();
      m.currentTime = 0;
      m.volume = analysis.editedClip.musicVolume ?? 0.45;
    }
    if (v) {
      v.volume = activeClip.originalVolume ?? 1;
      const start = Math.max(0, activeClip.trimStart || 0);
      if (v.readyState >= 1) {
        v.currentTime = start;
      }
      v.play().catch(() => undefined);
    }
  }, [activeVersion, activeClip, analysis.editedClip.musicVolume]);

  const handleLoadedMetadata = () => {
    const v = videoRef.current;
    if (!v) return;
    if (activeClip.trimStart > 0 && activeClip.trimStart < v.duration) {
      v.currentTime = activeClip.trimStart;
    }
    v.volume = activeClip.originalVolume ?? 1;
    v.play().catch(() => undefined);
  };

  const handlePlay = () => {
    const v = videoRef.current;
    if (!v) return;
    if (activeVersion === 'ai' && musicAudioRef.current) {
      const offset = Math.max(0, v.currentTime - activeClip.trimStart);
      musicAudioRef.current.currentTime =
        musicAudioRef.current.duration > 0 ? offset % musicAudioRef.current.duration : 0;
      musicAudioRef.current.play().catch(() => undefined);
    }
  };

  const handlePause = () => {
    musicAudioRef.current?.pause();
  };

  const handleTimeUpdate = () => {
    const v = videoRef.current;
    if (!v) return;
    if (activeClip.trimEnd > activeClip.trimStart && v.currentTime >= activeClip.trimEnd) {
      v.pause();
      v.currentTime = activeClip.trimStart;
      musicAudioRef.current?.pause();
    }
  };

  const handleSaveAiVersion = async (replaceOriginal: boolean) => {
    setIsSaving(true);
    try {
      const clipToSave: ClipItem = replaceOriginal
        ? {
            ...analysis.editedClip,
            id: originalClip.id,
            title: originalClip.title,
          }
        : analysis.editedClip;

      await onSaveClip(clipToSave);
      if (clipToSave.nativeFileName) {
        await saveVideoToNativeClipKaroFolder(clipToSave.nativeFileName, clipToSave.videoBlob).catch(
          () => undefined
        );
      }
      onCompleteNotice(
        replaceOriginal
          ? \`Replaced "\${originalClip.title}" with AI Edited \${analysis.cutDurationSec}s Highlight (\${aiViral.score}/100 Viral Score)!\`
          : \`Saved AI Edited \${analysis.cutDurationSec}s Highlight as new clip (Original kept safe)!\`
      );
      onClose();
    } finally {
      setIsSaving(false);
    }
  };

  const activeSrc = activeVersion === 'ai' ? aiVideoUrl : origVideoUrl;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="ai-auto-edit-title"
      className="fixed inset-0 z-[70] flex items-center justify-center bg-black/85 p-3 sm:p-4 backdrop-blur-sm"
    >
      <div className="w-full max-w-4xl max-h-[94vh] overflow-y-auto rounded-2xl border border-slate-800 bg-[#121722] shadow-2xl">
        {/* Header */}
        <div className="flex items-start justify-between gap-4 border-b border-slate-800 px-5 py-4">
          <div className="min-w-0">
            <div className="inline-flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider text-amber-400">
              <Wand2 className="h-3.5 w-3.5" aria-hidden="true" />
              <span>AI Auto Editing · Choose Version to Save</span>
            </div>
            <h2
              id="ai-auto-edit-title"
              className="mt-0.5 font-display text-lg font-bold text-white truncate"
            >
              {originalClip.title}
            </h2>
            <p className="text-xs text-slate-400">
              AI detected <span className="font-semibold text-rose-300">{analysis.detectedMoment}</span> at{' '}
              <span className="font-mono text-white">{formatSeconds(analysis.peakTimestampSec)}</span> · Auto-cut{' '}
              <span className="font-mono text-white">{analysis.cutDurationSec}s</span> ({formatSeconds(analysis.cutStartSec)}–{formatSeconds(analysis.cutEndSec)})
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close AI Auto Edit"
            className="rounded-lg p-2 text-slate-400 hover:bg-slate-800 hover:text-white shrink-0"
          >
            <X className="h-5 w-5" aria-hidden="true" />
          </button>
        </div>

        {/* Version Switcher Cards (Original vs AI Edited) */}
        <div className="grid grid-cols-1 gap-3 border-b border-slate-800 bg-[#0B0E14]/70 p-4 sm:grid-cols-2">
          <button
            type="button"
            onClick={() => setActiveVersion('original')}
            className={\`flex items-center justify-between gap-3 rounded-xl border p-3 text-left transition-colors \${
              activeVersion === 'original'
                ? 'border-sky-400 bg-sky-950/30'
                : 'border-slate-800 bg-[#121722] hover:border-slate-600'
            }\`}
          >
            <div className="min-w-0">
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold uppercase tracking-wider text-slate-300">
                  1. Original Version
                </span>
                {activeVersion === 'original' && (
                  <span className="rounded bg-sky-500/20 px-1.5 py-0.5 text-[10px] font-bold text-sky-300">
                    Playing
                  </span>
                )}
              </div>
              <div className="mt-1 text-xs text-slate-400 tabular-nums">
                {originalClip.durationSec}s · {originalClip.musicName ? 'Has Music' : 'Raw Audio'} ·{' '}
                {originalClip.filterPreset && originalClip.filterPreset !== 'none'
                  ? originalClip.filterPreset
                  : 'No Filter'}
              </div>
            </div>
            <div className="shrink-0 text-right">
              <div className="font-mono text-sm font-bold text-slate-200 tabular-nums">
                {originalViral.score}/100
              </div>
              <div className="text-[10px] text-slate-400">Viral Score</div>
            </div>
          </button>

          <button
            type="button"
            onClick={() => setActiveVersion('ai')}
            className={\`flex items-center justify-between gap-3 rounded-xl border p-3 text-left transition-colors \${
              activeVersion === 'ai'
                ? 'border-amber-400 bg-amber-950/30'
                : 'border-slate-800 bg-[#121722] hover:border-slate-600'
            }\`}
          >
            <div className="min-w-0">
              <div className="flex items-center gap-2">
                <Sparkles className="h-3.5 w-3.5 text-amber-400 shrink-0" aria-hidden="true" />
                <span className="text-xs font-bold uppercase tracking-wider text-amber-300">
                  2. AI Edited (Best {analysis.cutDurationSec}s)
                </span>
                {activeVersion === 'ai' && (
                  <span className="rounded bg-amber-500/20 px-1.5 py-0.5 text-[10px] font-bold text-amber-200">
                    Playing
                  </span>
                )}
              </div>
              <div className="mt-1 text-xs text-slate-300 truncate">
                {analysis.detectedMoment} · Cinematic + Trending Music + "{analysis.autoCaption}"
              </div>
            </div>
            <div className="shrink-0 text-right">
              <div className="font-mono text-sm font-bold text-emerald-300 tabular-nums">
                {aiViral.score}/100
              </div>
              <div className="text-[10px] text-emerald-400">Boosted</div>
            </div>
          </button>
        </div>

        {/* Live Comparison Player */}
        <div className="bg-[#06080D] p-3">
          <div
            className={\`relative overflow-hidden rounded-lg bg-black \${getAspectContainerClass(
              activeClip.aspectRatio ?? '16:9'
            )}\`}
          >
            {activeSrc && (
              <video
                key={activeVersion}
                ref={videoRef}
                src={activeSrc}
                controls
                playsInline
                onLoadedMetadata={handleLoadedMetadata}
                onPlay={handlePlay}
                onPause={handlePause}
                onTimeUpdate={handleTimeUpdate}
                style={{
                  filter: combineCssFilters(activeClip.filterPreset, activeClip.effectMode),
                }}
                className={\`h-full w-full \${
                  activeClip.fitMode === 'fit' ? 'object-contain' : 'object-cover'
                }\`}
              />
            )}

            {activeClip.effectMode === 'cinematic' && (
              <>
                <div className="pointer-events-none absolute inset-x-0 top-0 h-[10%] bg-black" />
                <div className="pointer-events-none absolute inset-x-0 bottom-0 h-[10%] bg-black" />
              </>
            )}

            {activeClip.autoCaption && (
              <div className="pointer-events-none absolute inset-x-0 bottom-12 flex justify-center px-4">
                <span className="rounded bg-black/90 px-3 py-1 text-xs font-extrabold text-white shadow-lg border border-amber-400/50">
                  {activeClip.autoCaption}
                </span>
              </div>
            )}

            <div className="pointer-events-none absolute top-3 left-3 inline-flex items-center gap-1.5 rounded-md bg-black/75 px-2.5 py-1 text-[11px] font-bold text-white">
              <Play className="h-3 w-3 fill-current text-rose-400" aria-hidden="true" />
              <span>
                {activeVersion === 'ai'
                  ? \`AI Edited · \${analysis.cutDurationSec}s Cinematic\`
                  : \`Original · \${originalClip.durationSec}s\`}
              </span>
            </div>
          </div>

          {aiMusicUrl && <audio ref={musicAudioRef} src={aiMusicUrl} loop className="hidden" />}
        </div>

        {/* AI Enhancements Summary + Choose Which Version to Save */}
        <div className="p-5 space-y-4">
          <div className="grid grid-cols-1 gap-2.5 sm:grid-cols-4 text-xs">
            <div className="rounded-lg border border-slate-800 bg-[#0B0E14] p-2.5">
              <div className="flex items-center gap-1.5 font-bold text-rose-300">
                <Scissors className="h-3.5 w-3.5" aria-hidden="true" />
                <span>Best Moment Cut</span>
              </div>
              <div className="mt-0.5 text-slate-300">
                {analysis.detectedMoment} · {analysis.cutDurationSec}s
              </div>
            </div>
            <div className="rounded-lg border border-slate-800 bg-[#0B0E14] p-2.5">
              <div className="flex items-center gap-1.5 font-bold text-amber-300">
                <Music className="h-3.5 w-3.5" aria-hidden="true" />
                <span>Trending Music</span>
              </div>
              <div className="mt-0.5 text-slate-300 truncate">{analysis.musicName}</div>
            </div>
            <div className="rounded-lg border border-slate-800 bg-[#0B0E14] p-2.5">
              <div className="flex items-center gap-1.5 font-bold text-sky-300">
                <Sparkles className="h-3.5 w-3.5" aria-hidden="true" />
                <span>Auto Caption + Filter</span>
              </div>
              <div className="mt-0.5 text-slate-300 truncate">
                "{analysis.autoCaption}" · Cinematic
              </div>
            </div>
            <div className="rounded-lg border border-emerald-500/30 bg-emerald-950/20 p-2.5">
              <div className="flex items-center gap-1.5 font-bold text-emerald-300">
                <Flame className="h-3.5 w-3.5" aria-hidden="true" />
                <span>AI Viral Score</span>
              </div>
              <div className="mt-0.5 text-emerald-200 font-semibold">
                {aiViral.score}/100 · {aiViral.verdict}
              </div>
            </div>
          </div>

          <div className="flex flex-col-reverse gap-2.5 sm:flex-row sm:items-center sm:justify-between border-t border-slate-800 pt-4">
            <button
              type="button"
              disabled={isSaving}
              onClick={() => {
                onCompleteNotice(\`Kept Original clip "\${originalClip.title}" unchanged.\`);
                onClose();
              }}
              className="rounded-lg border border-slate-700 bg-[#0B0E14] px-4 py-2.5 text-xs font-semibold text-slate-300 hover:bg-slate-800 hover:text-white"
            >
              Keep Original Only
            </button>

            <div className="flex flex-wrap items-center gap-2">
              <button
                type="button"
                disabled={isSaving}
                onClick={() => void handleSaveAiVersion(true)}
                className="rounded-lg border border-amber-500/50 bg-amber-950/30 px-4 py-2.5 text-xs font-bold text-amber-200 hover:bg-amber-900/40 disabled:opacity-60"
              >
                Replace Original with AI Edited
              </button>
              <button
                type="button"
                disabled={isSaving}
                onClick={() => void handleSaveAiVersion(false)}
                className="inline-flex items-center gap-1.5 rounded-lg bg-rose-600 px-4 py-2.5 text-xs font-bold text-white hover:bg-rose-500 disabled:opacity-60"
              >
                <CheckCircle2 className="h-4 w-4" aria-hidden="true" />
                <span>{isSaving ? 'Saving…' : 'Save AI Edited (New Clip)'}</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
`,"/src/components/ClipEditorModal.tsx":`import { ChangeEvent, useEffect, useMemo, useRef, useState } from 'react';
import {
  CheckCircle2,
  Download,
  Film,
  Gauge,
  Image as ImageIcon,
  Layers,
  Maximize2,
  Mic,
  Music,
  Pause,
  Play,
  RefreshCw,
  RotateCcw,
  Save,
  Scissors,
  Share2,
  Sparkles,
  SplitSquareHorizontal,
  Square,
  Trash2,
  Upload,
  Volume2,
  Wand2,
  X,
} from 'lucide-react';
import {
  AspectRatioOption,
  ClipItem,
  SpeedPreset,
  SpeedSegment,
  VideoEffectMode,
  VideoFilterPreset,
  VideoFitMode,
} from '../types/clipkaro';
import { trimVideoWithFFmpeg } from '../utils/ffmpegCutter';
import {
  formatSeconds,
  generateRoyaltyFreeWavBlob,
  generateStyledThumbnailDataUrl,
  ROYALTY_FREE_TRACKS,
  ThumbnailStylePreset,
} from '../utils/mediaGenerators';
import {
  saveVideoToNativeClipKaroFolder,
  shareClipToPlatform,
  ShareTargetPlatform,
} from '../utils/androidPermissions';
import {
  ASPECT_RATIO_OPTIONS,
  combineCssFilters,
  EFFECT_MODES,
  FILTER_PRESETS,
  getAspectContainerClass,
  getSpeedAtTime,
  getSpeedSegmentClasses,
  SPEED_OPTIONS,
} from '../utils/videoEditorPresets';
import { ViralScoreExportDialog } from './ViralScoreExportDialog';
import { calculateViralScore, prepareExportVideoBlobWithViralScore } from '../utils/viralScore';

export type EditorTab = 'trim' | 'ratio' | 'looks' | 'speed' | 'music' | 'voice' | 'thumbnail';

interface ClipEditorModalProps {
  clip: ClipItem;
  initialTab?: EditorTab;
  onSaveClip: (clip: ClipItem) => Promise<void>;
  onClose: () => void;
}

const CAPTION_PRESETS = [
  'What a Headshot!',
  '1 VS 4 CLUTCH!',
  'Squad Wipe!',
  'Clean Knock!',
] as const;

const THUMBNAIL_TEXT_PRESETS = [
  '1 VS 4 CLUTCH',
  'HEADSHOT KING',
  'WHAT A CLUTCH!',
  'SQUAD WIPE',
] as const;

export function ClipEditorModal({
  clip,
  initialTab = 'trim',
  onSaveClip,
  onClose,
}: ClipEditorModalProps) {
  const [editorTab, setEditorTab] = useState<EditorTab>(initialTab);
  const [title, setTitle] = useState<string>(clip.title);
  const [autoCaption, setAutoCaption] = useState<string>(clip.autoCaption ?? '');
  const [videoDuration, setVideoDuration] = useState<number>(Math.max(1, clip.durationSec));

  // Trim / Cut state
  const [trimStart, setTrimStart] = useState<number>(Math.max(0, clip.trimStart || 0));
  const [trimEnd, setTrimEnd] = useState<number>(
    clip.trimEnd > clip.trimStart ? clip.trimEnd : Math.max(1, clip.durationSec)
  );
  const [applyHardTrim, setApplyHardTrim] = useState<boolean>(false);

  // Aspect Ratio + Fit/Fill state
  const [aspectRatio, setAspectRatio] = useState<AspectRatioOption>(clip.aspectRatio ?? '16:9');
  const [fitMode, setFitMode] = useState<VideoFitMode>(clip.fitMode ?? 'fill');

  // Cinematic + Filters & Modes state
  const [filterPreset, setFilterPreset] = useState<VideoFilterPreset>(clip.filterPreset ?? 'none');
  const [effectMode, setEffectMode] = useState<VideoEffectMode>(clip.effectMode ?? 'none');

  // Speed Control + Split Speed state
  const initialSpan = Math.max(
    1,
    (clip.trimEnd > clip.trimStart ? clip.trimEnd : Math.max(1, clip.durationSec)) -
      Math.max(0, clip.trimStart || 0)
  );
  const [speedSegments, setSpeedSegments] = useState<SpeedSegment[]>(() =>
    clip.speedSegments && clip.speedSegments.length > 0
      ? clip.speedSegments
      : [{ id: 'seg-0', startSec: 0, endSec: initialSpan, speed: 1 }]
  );
  const [selectedSegmentId, setSelectedSegmentId] = useState<string>(
    clip.speedSegments?.[0]?.id ?? 'seg-0'
  );
  const [splitCursorSec, setSplitCursorSec] = useState<number>(
    Math.round((initialSpan / 2) * 10) / 10
  );
  const [livePlaybackSpeed, setLivePlaybackSpeed] = useState<SpeedPreset>(
    clip.speedSegments?.[0]?.speed ?? 1
  );

  // Audio Mix Volumes
  const [originalVolume, setOriginalVolume] = useState<number>(clip.originalVolume ?? 1);
  const [musicVolume, setMusicVolume] = useState<number>(clip.musicVolume ?? 0.45);
  const [voiceVolume, setVoiceVolume] = useState<number>(clip.voiceVolume ?? 1);

  // Music state
  const [musicBlob, setMusicBlob] = useState<Blob | undefined>(clip.musicBlob);
  const [musicName, setMusicName] = useState<string | undefined>(clip.musicName);
  const [selectedPresetId, setSelectedPresetId] = useState<string>(ROYALTY_FREE_TRACKS[0].id);
  const [previewTrackId, setPreviewTrackId] = useState<string | null>(null);

  // Voiceover state
  const [voiceBlob, setVoiceBlob] = useState<Blob | undefined>(clip.voiceBlob);
  const [voiceName, setVoiceName] = useState<string | undefined>(clip.voiceName);
  const [isRecordingVoice, setIsRecordingVoice] = useState<boolean>(false);
  const [voiceRecSeconds, setVoiceRecSeconds] = useState<number>(0);
  const [voiceError, setVoiceError] = useState<string | null>(null);

  // Thumbnail Maker state
  const [thumbnailDataUrl, setThumbnailDataUrl] = useState<string | undefined>(
    clip.thumbnailDataUrl
  );
  const [thumbHeadline, setThumbHeadline] = useState<string>('1 VS 4 CLUTCH');
  const [thumbBadge, setThumbBadge] = useState<string>('#BGMI');
  const [thumbStyle, setThumbStyle] = useState<ThumbnailStylePreset>('clutch-red-gold');
  const [isGeneratingThumb, setIsGeneratingThumb] = useState<boolean>(false);

  // Playback & Save Status
  const [videoUrl, setVideoUrl] = useState<string>('');
  const [musicUrl, setMusicUrl] = useState<string | null>(null);
  const [voiceUrl, setVoiceUrl] = useState<string | null>(null);
  const [isSaving, setIsSaving] = useState<boolean>(false);
  const [isSharing, setIsSharing] = useState<boolean>(false);
  const [saveStage, setSaveStage] = useState<string>('');
  const [saveProgress, setSaveProgress] = useState<number>(0);
  const [savedMessage, setSavedMessage] = useState<string | null>(null);
  const [viralExportPending, setViralExportPending] = useState<
    | { kind: 'share'; platform: ShareTargetPlatform }
    | { kind: 'save'; asNewVersion: boolean }
    | null
  >(null);

  const videoRef = useRef<HTMLVideoElement | null>(null);
  const musicAudioRef = useRef<HTMLAudioElement | null>(null);
  const voiceAudioRef = useRef<HTMLAudioElement | null>(null);
  const trackPreviewAudioRef = useRef<HTMLAudioElement | null>(null);
  const trackPreviewUrlRef = useRef<string | null>(null);
  const customMusicInputRef = useRef<HTMLInputElement | null>(null);
  const customVoiceInputRef = useRef<HTMLInputElement | null>(null);

  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const micStreamRef = useRef<MediaStream | null>(null);
  const recTimerRef = useRef<number | null>(null);
  const waveCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const audioCtxRef = useRef<AudioContext | null>(null);
  const analyserRef = useRef<AnalyserNode | null>(null);
  const waveRafRef = useRef<number>(0);

  const builtInTrackBlobs = useMemo(() => {
    const map: Record<string, Blob> = {};
    for (const track of ROYALTY_FREE_TRACKS) {
      map[track.id] = generateRoyaltyFreeWavBlob(track.id);
    }
    return map;
  }, []);

  useEffect(() => {
    const url = URL.createObjectURL(clip.videoBlob);
    setVideoUrl(url);
    return () => URL.revokeObjectURL(url);
  }, [clip.videoBlob]);

  useEffect(() => {
    if (!musicBlob) {
      setMusicUrl(null);
      return;
    }
    const u = URL.createObjectURL(musicBlob);
    setMusicUrl(u);
    return () => URL.revokeObjectURL(u);
  }, [musicBlob]);

  useEffect(() => {
    if (!voiceBlob) {
      setVoiceUrl(null);
      return;
    }
    const u = URL.createObjectURL(voiceBlob);
    setVoiceUrl(u);
    return () => URL.revokeObjectURL(u);
  }, [voiceBlob]);

  useEffect(() => {
    return () => {
      trackPreviewAudioRef.current?.pause();
      if (trackPreviewUrlRef.current) URL.revokeObjectURL(trackPreviewUrlRef.current);
      if (recTimerRef.current) window.clearInterval(recTimerRef.current);
      cancelAnimationFrame(waveRafRef.current);
      micStreamRef.current?.getTracks().forEach((t) => t.stop());
      audioCtxRef.current?.close().catch(() => undefined);
    };
  }, []);

  useEffect(() => {
    setEditorTab(initialTab);
  }, [initialTab]);

  useEffect(() => {
    if (videoRef.current) videoRef.current.volume = originalVolume;
    if (musicAudioRef.current) musicAudioRef.current.volume = musicVolume;
    if (voiceAudioRef.current) voiceAudioRef.current.volume = voiceVolume;
  }, [originalVolume, musicVolume, voiceVolume]);

  const handleRenderThumbnail = async (
    nextHeadline = thumbHeadline,
    nextBadge = thumbBadge,
    nextStyle = thumbStyle
  ) => {
    setIsGeneratingThumb(true);
    try {
      const rendered = await generateStyledThumbnailDataUrl({
        videoEl: videoRef.current,
        fallbackImageUrl: clip.thumbnailDataUrl,
        headline: nextHeadline,
        badgeText: nextBadge,
        stylePreset: nextStyle,
      });
      setThumbnailDataUrl(rendered);
      return rendered;
    } finally {
      setIsGeneratingThumb(false);
    }
  };

  useEffect(() => {
    if (editorTab === 'thumbnail') {
      void handleRenderThumbnail();
    }
  }, [editorTab]);

  const handleOneTapTrendingAndCaption = () => {
    const trendingTrack = ROYALTY_FREE_TRACKS[0];
    setSelectedPresetId(trendingTrack.id);
    setMusicBlob(builtInTrackBlobs[trendingTrack.id]);
    setMusicName(trendingTrack.title);
    setMusicVolume(0.45);
    setOriginalVolume(0.85);
    setAutoCaption('What a Headshot!');
    setSavedMessage('Applied Trending Music + Auto Caption: "What a Headshot!" (Click Save Clip to persist)');
  };

  const handleSaveThumbnailWithClip = async () => {
    const rendered = await handleRenderThumbnail();
    setIsSaving(true);
    try {
      await onSaveClip({
        ...clip,
        title: title.trim() || clip.title,
        autoCaption: autoCaption.trim() || undefined,
        thumbnailDataUrl: rendered,
        musicBlob,
        musicName,
        musicVolume,
        voiceBlob,
        voiceName,
        voiceVolume,
        originalVolume,
      });
      setSavedMessage('Thumbnail ("' + thumbHeadline + '") saved with clip!');
    } finally {
      setIsSaving(false);
    }
  };

  const editorViralResult = useMemo(
    () =>
      calculateViralScore({
        ...clip,
        title: title.trim() || clip.title,
        durationSec: Math.max(1, Math.round((trimEnd - trimStart) * 10) / 10),
        trimStart,
        trimEnd,
        autoCaption: autoCaption.trim() || undefined,
        thumbnailDataUrl,
        musicBlob,
        musicName,
        aspectRatio,
        fitMode,
        filterPreset,
        effectMode,
      }),
    [
      clip,
      title,
      trimStart,
      trimEnd,
      autoCaption,
      thumbnailDataUrl,
      musicBlob,
      musicName,
      aspectRatio,
      fitMode,
      filterPreset,
      effectMode,
    ]
  );

  const executeQuickShare = async (
    platform: ShareTargetPlatform,
    includeViralScore: boolean
  ) => {
    setIsSharing(true);
    try {
      const prepared = await prepareExportVideoBlobWithViralScore(
        {
          ...clip,
          title: title.trim() || clip.title,
          trimStart,
          trimEnd,
          autoCaption: autoCaption.trim() || undefined,
          aspectRatio,
          fitMode,
          filterPreset,
          effectMode,
          musicBlob,
          musicName,
          thumbnailDataUrl,
        },
        includeViralScore
      );
      const msg = await shareClipToPlatform({
        platform,
        title: title.trim() || clip.title,
        gameTag: clip.gameTag,
        autoCaption: autoCaption.trim() || 'What a Headshot!',
        videoBlob: prepared.blob,
        videoMimeType: prepared.mimeType,
        nativeUri: prepared.nativeUri,
      });
      setSavedMessage(
        includeViralScore
          ? \`\${msg} (Viral Score \${editorViralResult.score}/100 included)\`
          : \`\${msg} (Clean video — no Viral Score)\`
      );
    } finally {
      setIsSharing(false);
    }
  };

  const handleConfirmViralExport = async (showScoreOnVideo: boolean) => {
    const pending = viralExportPending;
    if (!pending) return;
    if (pending.kind === 'share') {
      await executeQuickShare(pending.platform, showScoreOnVideo);
      setViralExportPending(null);
      return;
    }
    setViralExportPending(null);
    await handleSaveEditedClip(pending.asNewVersion, showScoreOnVideo);
  };

  const clipSpanSec = Math.max(0.5, Math.round((trimEnd - trimStart) * 10) / 10);

  // Keep last speed segment end aligned with trimmed duration
  useEffect(() => {
    setSpeedSegments((prev) => {
      if (prev.length === 0) {
        return [{ id: 'seg-0', startSec: 0, endSec: clipSpanSec, speed: 1 }];
      }
      const next = prev.map((s) => ({ ...s }));
      next[0].startSec = 0;
      const filtered = next.filter((s, idx) => idx === 0 || s.startSec < clipSpanSec - 0.3);
      filtered[filtered.length - 1].endSec = clipSpanSec;
      return filtered;
    });
    setSplitCursorSec((c) => Math.min(Math.max(0.4, c), Math.max(0.5, clipSpanSec - 0.4)));
  }, [clipSpanSec]);

  const handleSplitAtPoint = () => {
    const point = Math.round(
      Math.min(Math.max(0.4, splitCursorSec), Math.max(0.5, clipSpanSec - 0.4)) * 10
    ) / 10;

    setSpeedSegments((prev) => {
      const idx = prev.findIndex((s) => point > s.startSec + 0.3 && point < s.endSec - 0.3);
      if (idx === -1) return prev;
      const target = prev[idx];
      const left: SpeedSegment = {
        id: target.id,
        startSec: target.startSec,
        endSec: point,
        speed: target.speed,
      };
      const newId = \`seg-\${Date.now().toString(36)}-\${Math.random().toString(36).slice(2, 5)}\`;
      const right: SpeedSegment = {
        id: newId,
        startSec: point,
        endSec: target.endSec,
        speed: target.speed,
      };
      const updated = [...prev.slice(0, idx), left, right, ...prev.slice(idx + 1)];
      setSelectedSegmentId(newId);
      return updated;
    });
    setSavedMessage(\`Split clip at \${point.toFixed(1)}s — tap a part below to change its speed.\`);
  };

  const handleSetSelectedSegmentSpeed = (speed: SpeedPreset) => {
    setSpeedSegments((prev) =>
      prev.map((seg) => (seg.id === selectedSegmentId ? { ...seg, speed } : seg))
    );
    setLivePlaybackSpeed(speed);
    if (videoRef.current) {
      const offset = Math.max(0, videoRef.current.currentTime - trimStart);
      const activeSeg = speedSegments.find((s) => offset >= s.startSec && offset <= s.endSec);
      if (!activeSeg || activeSeg.id === selectedSegmentId) {
        videoRef.current.playbackRate = speed;
      }
    }
  };

  const handleApplyKillSlowMoPreset = () => {
    const p1 = Math.round(clipSpanSec * 0.42 * 10) / 10;
    const p2 = Math.round(clipSpanSec * 0.74 * 10) / 10;
    if (p1 < 0.5 || p2 <= p1 + 0.5 || clipSpanSec - p2 < 0.5) {
      handleSetSelectedSegmentSpeed(0.5);
      return;
    }
    const seg1: SpeedSegment = { id: 'seg-normal', startSec: 0, endSec: p1, speed: 1 };
    const seg2: SpeedSegment = { id: 'seg-kill-slow', startSec: p1, endSec: p2, speed: 0.5 };
    const seg3: SpeedSegment = { id: 'seg-fast-outro', startSec: p2, endSec: clipSpanSec, speed: 2 };
    setSpeedSegments([seg1, seg2, seg3]);
    setSelectedSegmentId('seg-kill-slow');
    setSavedMessage('Applied Kill Slow-Mo Split: Normal 1x → Slow-Mo 0.5x → Fast 2x!');
  };

  const handleResetSpeedSplits = () => {
    setSpeedSegments([{ id: 'seg-0', startSec: 0, endSec: clipSpanSec, speed: 1 }]);
    setSelectedSegmentId('seg-0');
    setLivePlaybackSpeed(1);
    if (videoRef.current) videoRef.current.playbackRate = 1;
    setSavedMessage('Speed reset to 1x Normal.');
  };

  const handleLoadedMetadata = () => {
    const el = videoRef.current;
    if (!el || !Number.isFinite(el.duration) || el.duration <= 0) return;
    const dur = Math.max(1, Math.round(el.duration * 10) / 10);
    setVideoDuration(dur);
    if (clip.trimEnd > dur || clip.trimEnd <= clip.trimStart) {
      setTrimEnd(dur);
    }
  };

  const handleVideoPlay = () => {
    const el = videoRef.current;
    if (!el) return;
    if (el.currentTime < trimStart || el.currentTime >= trimEnd) {
      el.currentTime = trimStart;
    }
    const offset = Math.max(0, el.currentTime - trimStart);
    const activeSpd = getSpeedAtTime(speedSegments, offset);
    el.playbackRate = activeSpd;
    setLivePlaybackSpeed(activeSpd);
    if (voiceAudioRef.current) {
      voiceAudioRef.current.currentTime = Math.min(offset, voiceAudioRef.current.duration || offset);
      voiceAudioRef.current.play().catch(() => undefined);
    }
    if (musicAudioRef.current) {
      musicAudioRef.current.currentTime =
        musicAudioRef.current.duration > 0 ? offset % musicAudioRef.current.duration : 0;
      musicAudioRef.current.play().catch(() => undefined);
    }
  };

  const handleVideoPause = () => {
    voiceAudioRef.current?.pause();
    musicAudioRef.current?.pause();
  };

  const handleVideoTimeUpdate = () => {
    const el = videoRef.current;
    if (!el) return;
    const offset = Math.max(0, Math.min(clipSpanSec, el.currentTime - trimStart));
    setSplitCursorSec(Math.round(offset * 10) / 10);

    const activeSpd = getSpeedAtTime(speedSegments, offset);
    if (el.playbackRate !== activeSpd) {
      el.playbackRate = activeSpd;
    }
    if (livePlaybackSpeed !== activeSpd) {
      setLivePlaybackSpeed(activeSpd);
    }

    if (trimEnd > trimStart && el.currentTime >= trimEnd) {
      el.pause();
      el.currentTime = trimStart;
      voiceAudioRef.current?.pause();
      musicAudioRef.current?.pause();
    }
  };

  const togglePresetPreview = (trackId: string) => {
    if (previewTrackId === trackId) {
      trackPreviewAudioRef.current?.pause();
      setPreviewTrackId(null);
      return;
    }
    const blob = builtInTrackBlobs[trackId];
    if (!blob) return;
    if (trackPreviewUrlRef.current) URL.revokeObjectURL(trackPreviewUrlRef.current);
    const url = URL.createObjectURL(blob);
    trackPreviewUrlRef.current = url;
    if (!trackPreviewAudioRef.current) {
      trackPreviewAudioRef.current = new Audio();
    }
    trackPreviewAudioRef.current.src = url;
    trackPreviewAudioRef.current.volume = musicVolume;
    trackPreviewAudioRef.current.onended = () => setPreviewTrackId(null);
    trackPreviewAudioRef.current.play().then(() => setPreviewTrackId(trackId)).catch(() => undefined);
  };

  const handleSelectBuiltInMusic = (trackId: string, trackTitle: string) => {
    setSelectedPresetId(trackId);
    setMusicBlob(builtInTrackBlobs[trackId]);
    setMusicName(trackTitle);
    setSavedMessage(null);
  };

  const handleCustomMusicUpload = (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setMusicBlob(file);
    setMusicName(file.name);
    setSelectedPresetId('custom');
    setSavedMessage(null);
  };

  const handleCustomVoiceUpload = (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setVoiceBlob(file);
    setVoiceName(file.name);
    setVoiceError(null);
    setSavedMessage(null);
  };

  const drawWaveform = () => {
    const canvas = waveCanvasRef.current;
    const analyser = analyserRef.current;
    if (!canvas || !analyser) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const len = analyser.frequencyBinCount;
    const data = new Uint8Array(len);
    analyser.getByteTimeDomainData(data);

    ctx.fillStyle = '#0B0E14';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    ctx.lineWidth = 2;
    ctx.strokeStyle = '#38bdf8';
    ctx.beginPath();

    const step = canvas.width / len;
    let x = 0;
    for (let i = 0; i < len; i += 1) {
      const v = data[i] / 128.0;
      const y = (v * canvas.height) / 2;
      if (i === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
      x += step;
    }
    ctx.lineTo(canvas.width, canvas.height / 2);
    ctx.stroke();
    waveRafRef.current = requestAnimationFrame(drawWaveform);
  };

  const handleToggleVoiceRecord = async () => {
    if (isRecordingVoice) {
      mediaRecorderRef.current?.stop();
      return;
    }

    setVoiceError(null);
    setSavedMessage(null);
    if (!navigator.mediaDevices?.getUserMedia) {
      setVoiceError('Microphone is unavailable here. Upload a voiceover file instead.');
      return;
    }

    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      micStreamRef.current = stream;

      const audioCtx = new AudioContext();
      audioCtxRef.current = audioCtx;
      const src = audioCtx.createMediaStreamSource(stream);
      const analyser = audioCtx.createAnalyser();
      analyser.fftSize = 256;
      src.connect(analyser);
      analyserRef.current = analyser;

      const chunks: BlobPart[] = [];
      const recorder = new MediaRecorder(stream);
      mediaRecorderRef.current = recorder;

      recorder.ondataavailable = (ev) => {
        if (ev.data && ev.data.size > 0) chunks.push(ev.data);
      };

      recorder.onstop = () => {
        if (recTimerRef.current) {
          window.clearInterval(recTimerRef.current);
          recTimerRef.current = null;
        }
        cancelAnimationFrame(waveRafRef.current);
        stream.getTracks().forEach((t) => t.stop());
        audioCtx.close().catch(() => undefined);
        setIsRecordingVoice(false);

        const recorded = new Blob(chunks, { type: recorder.mimeType || 'audio/webm' });
        if (recorded.size > 0) {
          setVoiceBlob(recorded);
          setVoiceName(\`Voiceover_\${new Date().toLocaleTimeString()}\`);
        }
      };

      setVoiceRecSeconds(0);
      setIsRecordingVoice(true);
      recorder.start();
      drawWaveform();
      recTimerRef.current = window.setInterval(() => {
        setVoiceRecSeconds((s) => s + 1);
      }, 1000);
    } catch {
      setVoiceError('Microphone permission denied. Allow mic or upload a voice track.');
    }
  };

  const handleSaveEditedClip = async (asNewVersion = true, includeViralScore = false) => {
    setIsSaving(true);
    setSavedMessage(null);
    setSaveProgress(5);
    setSaveStage('Preparing new clip version…');

    try {
      const safeStart = Math.max(0, trimStart);
      const safeEnd = Math.max(safeStart + 0.5, trimEnd);
      const cutDuration = Math.max(1, Math.round((safeEnd - safeStart) * 10) / 10);

      let finalVideoBlob = clip.videoBlob;
      let finalVideoMime = clip.videoMimeType;
      let finalTrimStart = safeStart;
      let finalTrimEnd = safeEnd;
      let finalDuration = Math.round(cutDuration);

      const trimRangeChanged =
        safeStart > 0.2 || Math.abs(safeEnd - videoDuration) > 0.2;
      const visualChanged =
        aspectRatio !== '16:9' || filterPreset !== 'none' || effectMode !== 'none';
      const uniformSpeed =
        speedSegments.length === 1 && speedSegments[0].speed !== 1
          ? speedSegments[0].speed
          : undefined;

      const bakedWithFfmpeg = Boolean(
        (applyHardTrim && (trimRangeChanged || visualChanged || uniformSpeed)) || includeViralScore
      );

      if (bakedWithFfmpeg) {
        setSaveStage(
          includeViralScore
            ? 'Rendering edited MP4 with Viral Score…'
            : 'Rendering edited MP4 via FFmpeg…'
        );
        try {
          const trimmed = await trimVideoWithFFmpeg({
            sourceBlob: clip.videoBlob,
            sourceFileName: clip.nativeFileName || \`\${clip.title}.mp4\`,
            startSec: safeStart,
            durationSec: cutDuration,
            burnCredit: false,
            creditText: clip.permission.creditText,
            burnAutoCaption: autoCaption.trim().length > 0,
            autoCaptionText: autoCaption.trim(),
            burnViralScore: includeViralScore,
            viralScoreText: includeViralScore
              ? \`Viral Score: \${editorViralResult.score}/100\`
              : undefined,
            aspectRatio,
            fitMode,
            filterPreset,
            effectMode,
            uniformSpeed,
            onProgress: (pct, stg) => {
              setSaveProgress(pct);
              setSaveStage(stg);
            },
          });
          finalVideoBlob = trimmed.mp4Blob;
          finalVideoMime = 'video/mp4';
          finalTrimStart = 0;
          finalTrimEnd = Math.round(cutDuration);
          finalDuration = Math.round(cutDuration);
        } catch (ffmpegErr) {
          if (!applyHardTrim && includeViralScore) {
            // Offline fallback when FFmpeg WASM cannot render overlay
            finalVideoBlob = clip.videoBlob;
          } else {
            throw ffmpegErr;
          }
        }
      }

      const rawTitle = title.trim() || clip.title;
      const versionTitle = asNewVersion
        ? rawTitle === clip.title
          ? \`\${rawTitle} (Edited)\`
          : rawTitle
        : rawTitle;

      const updatedClip: ClipItem = {
        ...clip,
        id: asNewVersion
          ? \`clip-\${Date.now()}-\${Math.random().toString(36).slice(2, 6)}\`
          : clip.id,
        title: versionTitle,
        createdAt: asNewVersion ? Date.now() : clip.createdAt,
        durationSec: finalDuration,
        trimStart: finalTrimStart,
        trimEnd: finalTrimEnd,
        autoCaption: autoCaption.trim() || undefined,
        thumbnailDataUrl,
        videoBlob: finalVideoBlob,
        videoMimeType: finalVideoMime,
        musicBlob,
        musicName,
        musicVolume,
        voiceBlob,
        voiceName,
        voiceVolume,
        originalVolume,
        aspectRatio,
        fitMode,
        filterPreset: bakedWithFfmpeg ? 'none' : filterPreset,
        effectMode: bakedWithFfmpeg ? 'none' : effectMode,
        speedSegments:
          bakedWithFfmpeg && uniformSpeed
            ? [{ id: 'seg-0', startSec: 0, endSec: finalDuration, speed: 1 }]
            : speedSegments,
      };

      setSaveProgress(92);
      setSaveStage('Saving new version to My Clips…');
      await onSaveClip(updatedClip);

      // Save directly to Movies/ClipKaro folder on Android APK without removing original clip
      const cleanFileName = \`\${updatedClip.title.replace(/[^a-z0-9_-]+/gi, '_')}_\${Date.now()}.mp4\`;
      const savedNative = await saveVideoToNativeClipKaroFolder(cleanFileName, finalVideoBlob);

      setSaveProgress(100);
      setSavedMessage(
        savedNative
          ? 'Saved new version to My Clips & Movies/ClipKaro (original clip kept)!'
          : 'Saved new version to My Clips (original clip kept)!'
      );
    } catch (err) {
      setVoiceError(
        err instanceof Error ? err.message : 'Unable to save clip edits.'
      );
    } finally {
      setIsSaving(false);
    }
  };

  const selectedSegment =
    speedSegments.find((s) => s.id === selectedSegmentId) ?? speedSegments[0];
  const liveCssFilter = combineCssFilters(filterPreset, effectMode);

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="in-app-editor-title"
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 p-3 sm:p-5 backdrop-blur-sm"
    >
      <div className="flex max-h-[94vh] w-full max-w-5xl flex-col overflow-hidden rounded-2xl border border-slate-800 bg-[#121722] shadow-2xl">
        {/* Header */}
        <div className="flex items-center justify-between gap-3 border-b border-slate-800 px-5 py-3.5">
          <div className="min-w-0">
            <h2 id="in-app-editor-title" className="font-display text-lg font-bold text-white truncate">
              ClipKaro In-App Editor
            </h2>
            <p className="text-xs text-slate-400 truncate">
              Ratio · Cinematic Modes · Split Speed · Trim · Music · Voiceover · Thumbnail
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close editor"
            className="rounded-lg p-2 text-slate-400 hover:bg-slate-800 hover:text-white shrink-0"
          >
            <X className="h-5 w-5" aria-hidden="true" />
          </button>
        </div>

        {/* Body */}
        <div className="grid flex-1 grid-cols-1 gap-5 overflow-y-auto p-4 sm:p-5 lg:grid-cols-12">
          {/* Left: Video Preview + Basic Details */}
          <div className="space-y-4 lg:col-span-6">
            <div className="flex items-center justify-center rounded-xl border border-slate-800 bg-[#05070B] p-2">
              <div
                className={\`relative overflow-hidden rounded-lg bg-black \${getAspectContainerClass(
                  aspectRatio
                )}\`}
              >
                {videoUrl && (
                  <video
                    ref={videoRef}
                    src={videoUrl}
                    controls
                    playsInline
                    onLoadedMetadata={handleLoadedMetadata}
                    onPlay={handleVideoPlay}
                    onPause={handleVideoPause}
                    onTimeUpdate={handleVideoTimeUpdate}
                    style={{ filter: liveCssFilter }}
                    className={\`h-full w-full \${
                      fitMode === 'fill' ? 'object-cover' : 'object-contain'
                    }\`}
                  />
                )}
                {/* 2.35:1 Cinematic Letterbox Black Bars */}
                {effectMode === 'cinematic' && (
                  <>
                    <div className="pointer-events-none absolute inset-x-0 top-0 h-[12%] bg-black" />
                    <div className="pointer-events-none absolute inset-x-0 bottom-0 h-[12%] bg-black" />
                  </>
                )}
                {autoCaption.trim() && (
                  <div className="pointer-events-none absolute inset-x-0 bottom-12 flex justify-center px-4">
                    <span className="rounded bg-black px-3 py-1 text-xs font-bold text-white shadow">
                      {autoCaption}
                    </span>
                  </div>
                )}
                {musicUrl && <audio ref={musicAudioRef} src={musicUrl} loop className="hidden" />}
                {voiceUrl && <audio ref={voiceAudioRef} src={voiceUrl} className="hidden" />}
              </div>
            </div>

            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
              <div className="space-y-1">
                <label htmlFor="editor-clip-title" className="text-xs font-semibold text-slate-300">
                  Clip Title
                </label>
                <input
                  id="editor-clip-title"
                  type="text"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  className="w-full rounded-lg border border-slate-700 bg-[#0B0E14] px-3 py-2 text-xs text-white focus:border-rose-500 focus:outline-none"
                />
              </div>
              <div className="space-y-1.5">
                <label htmlFor="editor-clip-caption" className="text-xs font-semibold text-slate-300">
                  Auto Caption (Black Box)
                </label>
                <input
                  id="editor-clip-caption"
                  type="text"
                  value={autoCaption}
                  onChange={(e) => setAutoCaption(e.target.value)}
                  placeholder="e.g. What a Headshot!"
                  className="w-full rounded-lg border border-slate-700 bg-[#0B0E14] px-3 py-2 text-xs text-white placeholder:text-slate-500 focus:border-rose-500 focus:outline-none"
                />
                <div className="flex flex-wrap gap-1 pt-0.5">
                  {CAPTION_PRESETS.map((preset) => (
                    <button
                      key={preset}
                      type="button"
                      onClick={() => setAutoCaption(preset)}
                      className={\`rounded border px-2 py-0.5 text-[10px] font-semibold transition-colors \${
                        autoCaption === preset
                          ? 'border-rose-500 bg-rose-950/40 text-rose-200'
                          : 'border-slate-700 bg-[#0B0E14] text-slate-300 hover:border-rose-500/60'
                      }\`}
                    >
                      {preset}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Active Mix & Style Summary */}
            <div className="rounded-xl border border-slate-800 bg-[#0B0E14] p-3.5 text-xs text-slate-300 space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-semibold text-white">Timeline &amp; Style Summary</span>
                <span className="font-mono text-rose-300 tabular-nums">
                  {trimStart.toFixed(1)}s → {trimEnd.toFixed(1)}s ({clipSpanSec}s) · {livePlaybackSpeed}x
                </span>
              </div>
              <div className="flex flex-wrap items-center gap-2.5 text-[11px] text-slate-400">
                <span className="text-slate-200 font-semibold">
                  {aspectRatio} ({fitMode === 'fill' ? 'Fill' : 'Fit'})
                </span>
                <span>·</span>
                <span className="capitalize">
                  Filter: {filterPreset === 'bw' ? 'B&W' : filterPreset}
                </span>
                <span>·</span>
                <span className="capitalize">Mode: {effectMode}</span>
                <span>·</span>
                <span className={musicBlob ? 'text-amber-300' : ''}>
                  Music: {musicName ? \`\${musicName}\` : 'None'}
                </span>
                <span>·</span>
                <span className={voiceBlob ? 'text-sky-300' : ''}>
                  Voice: {voiceName ? \`\${voiceName}\` : 'None'}
                </span>
              </div>
            </div>
          </div>

          {/* Right: 4 Editor Tool Tabs + 1-Tap Trending Bar */}
          <div className="flex flex-col justify-between space-y-4 lg:col-span-6">
            <div className="space-y-4">
              {/* 1-Tap Trending Music + Auto Caption Banner */}
              <div className="flex flex-wrap items-center justify-between gap-2 rounded-xl border border-amber-500/35 bg-gradient-to-r from-amber-950/40 via-rose-950/30 to-[#0B0E14] p-3">
                <div className="min-w-0">
                  <div className="text-xs font-bold text-white">Trending Music + Auto Caption</div>
                  <div className="text-[11px] text-amber-200/90 truncate">
                    Adds Trending Phonk beat &amp; &ldquo;What a Headshot!&rdquo; caption in 1 tap
                  </div>
                </div>
                <button
                  type="button"
                  onClick={handleOneTapTrendingAndCaption}
                  className="inline-flex items-center gap-1.5 rounded-lg bg-amber-500 px-3 py-1.5 text-xs font-bold text-slate-950 hover:bg-amber-400 shrink-0"
                >
                  <Sparkles className="h-3.5 w-3.5" aria-hidden="true" />
                  <span>1-Tap Apply</span>
                </button>
              </div>

              {/* Tool Tabs (7 concise tabs covering Ratio, Cinematic, Speed + Trim, Music, Voice, Thumbnail) */}
              <div className="grid grid-cols-4 sm:grid-cols-7 gap-1 rounded-xl border border-slate-800 bg-[#0B0E14] p-1">
                {(
                  [
                    { id: 'trim', label: 'Trim', icon: Scissors },
                    { id: 'ratio', label: 'Ratio', icon: Maximize2 },
                    { id: 'looks', label: 'Cinematic', icon: Wand2 },
                    { id: 'speed', label: 'Speed', icon: Gauge },
                    { id: 'music', label: 'Music', icon: Music },
                    { id: 'voice', label: 'Voice', icon: Mic },
                    { id: 'thumbnail', label: 'Thumb', icon: ImageIcon },
                  ] as const
                ).map((t) => {
                  const Icon = t.icon;
                  const active = editorTab === t.id;
                  return (
                    <button
                      key={t.id}
                      type="button"
                      onClick={() => setEditorTab(t.id)}
                      className={\`inline-flex flex-col sm:flex-row items-center justify-center gap-1 rounded-lg px-1.5 py-2 text-[11px] font-bold transition-colors \${
                        active
                          ? 'bg-rose-600 text-white'
                          : 'text-slate-400 hover:bg-slate-800 hover:text-slate-100'
                      }\`}
                    >
                      <Icon className="h-3.5 w-3.5 shrink-0" aria-hidden="true" />
                      <span className="truncate">{t.label}</span>
                    </button>
                  );
                })}
              </div>

              {/* Tab 1: Trim / Cut */}
              {editorTab === 'trim' && (
                <div className="rounded-xl border border-slate-800 bg-[#0B0E14] p-4 space-y-4">
                  <div className="flex items-center justify-between">
                    <h3 className="text-sm font-bold text-white">Trim / Cut Clip Range</h3>
                    <span className="font-mono text-xs text-emerald-300 tabular-nums">
                      Selected: {clipSpanSec}s / {videoDuration.toFixed(1)}s
                    </span>
                  </div>

                  <div className="space-y-3">
                    <div className="space-y-1">
                      <div className="flex items-center justify-between text-xs text-slate-300">
                        <span>Start Time</span>
                        <span className="font-mono tabular-nums">{trimStart.toFixed(1)}s</span>
                      </div>
                      <input
                        type="range"
                        min={0}
                        max={Math.max(0.5, trimEnd - 0.5)}
                        step={0.5}
                        value={trimStart}
                        onChange={(e) => {
                          const v = Number(e.target.value);
                          setTrimStart(v);
                          if (videoRef.current) videoRef.current.currentTime = v;
                        }}
                        className="w-full accent-rose-500"
                      />
                    </div>

                    <div className="space-y-1">
                      <div className="flex items-center justify-between text-xs text-slate-300">
                        <span>End Time</span>
                        <span className="font-mono tabular-nums">{trimEnd.toFixed(1)}s</span>
                      </div>
                      <input
                        type="range"
                        min={Math.min(videoDuration, trimStart + 0.5)}
                        max={Math.max(1, videoDuration)}
                        step={0.5}
                        value={trimEnd}
                        onChange={(e) => {
                          const v = Number(e.target.value);
                          setTrimEnd(v);
                          if (videoRef.current) videoRef.current.currentTime = v;
                        }}
                        className="w-full accent-rose-500"
                      />
                    </div>
                  </div>

                  <label className="flex items-start gap-2.5 rounded-lg border border-slate-800 bg-[#121722] p-3 text-xs text-slate-300 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={applyHardTrim}
                      onChange={(e) => setApplyHardTrim(e.target.checked)}
                      className="mt-0.5 accent-rose-500"
                    />
                    <div>
                      <div className="font-semibold text-white">Export newly rendered MP4 via FFmpeg</div>
                      <div className="text-[11px] text-slate-400">
                        Unchecked saves instant new version with ratio, filters, speed &amp; trim; checked renders a standalone MP4 file.
                      </div>
                    </div>
                  </label>
                </div>
              )}

              {/* Tab 2: Aspect Ratio (16:9, 9:16, 1:1, 4:5 + Auto Fit/Fill) */}
              {editorTab === 'ratio' && (
                <div className="rounded-xl border border-slate-800 bg-[#0B0E14] p-4 space-y-4">
                  <div className="flex items-center justify-between gap-2">
                    <h3 className="text-sm font-bold text-white">Aspect Ratio</h3>
                    <div className="inline-flex rounded-lg border border-slate-700 bg-[#121722] p-0.5">
                      <button
                        type="button"
                        onClick={() => setFitMode('fill')}
                        className={\`rounded-md px-2.5 py-1 text-[11px] font-bold transition-colors \${
                          fitMode === 'fill'
                            ? 'bg-rose-600 text-white'
                            : 'text-slate-300 hover:text-white'
                        }\`}
                      >
                        Auto Fill (No Black Bars)
                      </button>
                      <button
                        type="button"
                        onClick={() => setFitMode('fit')}
                        className={\`rounded-md px-2.5 py-1 text-[11px] font-bold transition-colors \${
                          fitMode === 'fit'
                            ? 'bg-rose-600 text-white'
                            : 'text-slate-300 hover:text-white'
                        }\`}
                      >
                        Fit Full Video
                      </button>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-2.5">
                    {ASPECT_RATIO_OPTIONS.map((opt) => {
                      const active = aspectRatio === opt.id;
                      return (
                        <button
                          key={opt.id}
                          type="button"
                          onClick={() => setAspectRatio(opt.id)}
                          className={\`flex flex-col items-start gap-1 rounded-xl border p-3 text-left transition-colors \${
                            active
                              ? 'border-rose-500 bg-rose-950/30 text-white'
                              : 'border-slate-800 bg-[#121722] text-slate-300 hover:border-slate-600'
                          }\`}
                        >
                          <div className="flex w-full items-center justify-between">
                            <span className="font-display text-sm font-extrabold">{opt.label}</span>
                            <Layers className="h-3.5 w-3.5 text-rose-400" aria-hidden="true" />
                          </div>
                          <span className="text-[11px] text-slate-400">{opt.platformHint}</span>
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* Tab 3: Cinematic + Filters & Modes */}
              {editorTab === 'looks' && (
                <div className="rounded-xl border border-slate-800 bg-[#0B0E14] p-4 space-y-4">
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <h3 className="text-sm font-bold text-white">Pro Filters</h3>
                      <button
                        type="button"
                        onClick={() => {
                          setFilterPreset('none');
                          setEffectMode('none');
                        }}
                        className="text-[11px] font-semibold text-slate-400 hover:text-white"
                      >
                        Reset Looks
                      </button>
                    </div>
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5">
                      {FILTER_PRESETS.map((flt) => {
                        const active = filterPreset === flt.id;
                        return (
                          <button
                            key={flt.id}
                            type="button"
                            onClick={() => setFilterPreset(flt.id)}
                            className={\`rounded-lg border px-2.5 py-2 text-xs font-bold transition-colors \${
                              active
                                ? 'border-rose-500 bg-rose-600 text-white'
                                : 'border-slate-800 bg-[#121722] text-slate-300 hover:border-slate-600'
                            }\`}
                          >
                            {flt.label}
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  <div className="space-y-2 border-t border-slate-800 pt-3">
                    <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400">
                      Cinematic &amp; Scene Modes
                    </h4>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      {EFFECT_MODES.map((mode) => {
                        const active = effectMode === mode.id;
                        return (
                          <button
                            key={mode.id}
                            type="button"
                            onClick={() => setEffectMode(mode.id)}
                            className={\`flex flex-col items-start rounded-xl border px-3 py-2 text-left transition-colors \${
                              active
                                ? 'border-amber-400 bg-amber-950/30 text-white'
                                : 'border-slate-800 bg-[#121722] text-slate-300 hover:border-slate-600'
                            }\`}
                          >
                            <div className="flex items-center gap-1.5 text-xs font-bold">
                              <Film className="h-3.5 w-3.5 text-amber-400" aria-hidden="true" />
                              <span>{mode.label}</span>
                            </div>
                            <span className="mt-0.5 text-[11px] text-slate-400">
                              {mode.description}
                            </span>
                          </button>
                        );
                      })}
                    </div>
                  </div>
                </div>
              )}

              {/* Tab 4: Speed Control + Split Speed Timeline */}
              {editorTab === 'speed' && (
                <div className="rounded-xl border border-slate-800 bg-[#0B0E14] p-4 space-y-4">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <h3 className="text-sm font-bold text-white">Speed Control &amp; Split Speed</h3>
                    <div className="flex items-center gap-1.5">
                      <button
                        type="button"
                        onClick={handleApplyKillSlowMoPreset}
                        className="rounded-lg border border-sky-500/40 bg-sky-950/30 px-2.5 py-1 text-[11px] font-bold text-sky-300 hover:bg-sky-900/40"
                      >
                        1-Tap Kill Slow-Mo
                      </button>
                      <button
                        type="button"
                        onClick={handleResetSpeedSplits}
                        className="inline-flex items-center gap-1 rounded-lg border border-slate-700 bg-[#121722] px-2 py-1 text-[11px] font-semibold text-slate-300 hover:text-white"
                      >
                        <RotateCcw className="h-3 w-3" aria-hidden="true" />
                        <span>Reset</span>
                      </button>
                    </div>
                  </div>

                  {/* Color-Coded Speed Timeline */}
                  <div className="space-y-1.5">
                    <div className="flex items-center justify-between text-[11px] text-slate-400">
                      <span>Tap any part to change its speed</span>
                      <span className="flex items-center gap-2">
                        <span className="text-sky-300">■ Slow</span>
                        <span className="text-emerald-300">■ 1x</span>
                        <span className="text-rose-300">■ Fast</span>
                      </span>
                    </div>
                    <div className="flex h-10 w-full overflow-hidden rounded-lg border border-slate-700 bg-[#121722] p-0.5 gap-0.5">
                      {speedSegments.map((seg, idx) => {
                        const pct = Math.max(8, ((seg.endSec - seg.startSec) / clipSpanSec) * 100);
                        const styles = getSpeedSegmentClasses(seg.speed);
                        const isSelected = selectedSegment?.id === seg.id;
                        return (
                          <button
                            key={seg.id}
                            type="button"
                            onClick={() => {
                              setSelectedSegmentId(seg.id);
                              if (videoRef.current) {
                                videoRef.current.currentTime = trimStart + seg.startSec;
                              }
                            }}
                            style={{ width: \`\${pct}%\` }}
                            className={\`flex items-center justify-center rounded text-[11px] font-extrabold text-white transition-all \${
                              styles.barClass
                            } \${isSelected ? 'ring-2 ring-white' : 'opacity-85'}\`}
                            title={\`Part \${idx + 1}: \${seg.startSec.toFixed(1)}s–\${seg.endSec.toFixed(1)}s (\${seg.speed}x)\`}
                          >
                            {seg.speed}x
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  {/* Split Playhead Scrubber + Split Button */}
                  <div className="flex flex-col gap-2 rounded-lg border border-slate-800 bg-[#121722] p-3">
                    <div className="flex items-center justify-between text-xs text-slate-300">
                      <span>Split Position</span>
                      <span className="font-mono font-bold text-white tabular-nums">
                        {splitCursorSec.toFixed(1)}s / {clipSpanSec.toFixed(1)}s
                      </span>
                    </div>
                    <div className="flex items-center gap-2.5">
                      <input
                        type="range"
                        min={0.4}
                        max={Math.max(0.5, clipSpanSec - 0.4)}
                        step={0.1}
                        value={splitCursorSec}
                        onChange={(e) => {
                          const v = Number(e.target.value);
                          setSplitCursorSec(v);
                          if (videoRef.current) videoRef.current.currentTime = trimStart + v;
                        }}
                        className="flex-1 accent-rose-500"
                      />
                      <button
                        type="button"
                        onClick={handleSplitAtPoint}
                        className="inline-flex items-center gap-1.5 rounded-lg bg-rose-600 px-3 py-1.5 text-xs font-bold text-white hover:bg-rose-500 shrink-0"
                      >
                        <SplitSquareHorizontal className="h-3.5 w-3.5" aria-hidden="true" />
                        <span>Split</span>
                      </button>
                    </div>
                  </div>

                  {/* Speed Buttons + Slider for Selected Part */}
                  {selectedSegment && (
                    <div className="space-y-2.5 border-t border-slate-800 pt-3">
                      <div className="flex items-center justify-between text-xs">
                        <span className="font-semibold text-slate-300">
                          Part Speed ({selectedSegment.startSec.toFixed(1)}s → {selectedSegment.endSec.toFixed(1)}s)
                        </span>
                        <span className="font-mono font-bold text-amber-300">
                          {selectedSegment.speed}x
                        </span>
                      </div>
                      <div className="grid grid-cols-5 gap-1.5">
                        {SPEED_OPTIONS.map((spd) => {
                          const active = selectedSegment.speed === spd;
                          return (
                            <button
                              key={spd}
                              type="button"
                              onClick={() => handleSetSelectedSegmentSpeed(spd)}
                              className={\`rounded-lg border py-1.5 text-xs font-extrabold transition-colors \${
                                active
                                  ? 'border-rose-500 bg-rose-600 text-white'
                                  : 'border-slate-700 bg-[#121722] text-slate-300 hover:border-slate-500'
                              }\`}
                            >
                              {spd}x
                            </button>
                          );
                        })}
                      </div>
                      <input
                        type="range"
                        min={0}
                        max={SPEED_OPTIONS.length - 1}
                        step={1}
                        value={Math.max(0, SPEED_OPTIONS.indexOf(selectedSegment.speed))}
                        onChange={(e) => {
                          const idx = Number(e.target.value);
                          handleSetSelectedSegmentSpeed(SPEED_OPTIONS[idx] ?? 1);
                        }}
                        aria-label="Speed slider"
                        className="w-full accent-rose-500"
                      />
                    </div>
                  )}
                </div>
              )}

              {/* Tab 2: Add Music */}
              {editorTab === 'music' && (
                <div className="rounded-xl border border-slate-800 bg-[#0B0E14] p-4 space-y-4">
                  <div className="flex items-center justify-between gap-2">
                    <h3 className="text-sm font-bold text-white">Add Background Music</h3>
                    <div className="flex items-center gap-2">
                      <input
                        ref={customMusicInputRef}
                        type="file"
                        accept="audio/*"
                        onChange={handleCustomMusicUpload}
                        className="hidden"
                      />
                      <button
                        type="button"
                        onClick={() => customMusicInputRef.current?.click()}
                        className="inline-flex items-center gap-1.5 rounded-lg border border-slate-700 bg-[#121722] px-2.5 py-1.5 text-xs font-semibold text-slate-200 hover:border-rose-500"
                      >
                        <Upload className="h-3.5 w-3.5" aria-hidden="true" />
                        <span>Upload Audio</span>
                      </button>
                      {musicBlob && (
                        <button
                          type="button"
                          onClick={() => {
                            setMusicBlob(undefined);
                            setMusicName(undefined);
                          }}
                          className="rounded-lg border border-rose-500/40 bg-rose-950/30 p-1.5 text-rose-300 hover:bg-rose-900/40"
                          title="Remove music"
                        >
                          <Trash2 className="h-3.5 w-3.5" aria-hidden="true" />
                        </button>
                      )}
                    </div>
                  </div>

                  <div className="max-h-44 space-y-1.5 overflow-y-auto pr-1">
                    {ROYALTY_FREE_TRACKS.map((track) => {
                      const active = musicName === track.title || selectedPresetId === track.id;
                      const previewing = previewTrackId === track.id;
                      return (
                        <div
                          key={track.id}
                          className={\`flex items-center justify-between gap-2 rounded-lg border px-3 py-2 text-xs \${
                            active
                              ? 'border-rose-500/60 bg-rose-950/20 text-white'
                              : 'border-slate-800 bg-[#121722] text-slate-300'
                          }\`}
                        >
                          <button
                            type="button"
                            onClick={() => handleSelectBuiltInMusic(track.id, track.title)}
                            className="min-w-0 flex-1 text-left"
                          >
                            <div className="font-semibold truncate">{track.title}</div>
                            <div className="text-[11px] text-slate-400">
                              {track.mood} · {track.bpm} BPM
                            </div>
                          </button>
                          <button
                            type="button"
                            onClick={() => togglePresetPreview(track.id)}
                            aria-label={previewing ? 'Pause preview' : 'Preview track'}
                            className="rounded-md border border-slate-700 bg-[#0B0E14] p-1.5 text-slate-200 hover:border-rose-500"
                          >
                            {previewing ? (
                              <Pause className="h-3.5 w-3.5" aria-hidden="true" />
                            ) : (
                              <Play className="h-3.5 w-3.5" aria-hidden="true" />
                            )}
                          </button>
                        </div>
                      );
                    })}
                  </div>

                  {/* Mix Sliders */}
                  <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 border-t border-slate-800 pt-3">
                    <div className="space-y-1">
                      <div className="flex items-center justify-between text-xs text-slate-300">
                        <span className="inline-flex items-center gap-1">
                          <Volume2 className="h-3.5 w-3.5 text-amber-400" aria-hidden="true" />
                          <span>Music Volume</span>
                        </span>
                        <span className="font-mono tabular-nums">{Math.round(musicVolume * 100)}%</span>
                      </div>
                      <input
                        type="range"
                        min={0}
                        max={1}
                        step={0.05}
                        value={musicVolume}
                        onChange={(e) => setMusicVolume(Number(e.target.value))}
                        className="w-full accent-amber-400"
                      />
                    </div>
                    <div className="space-y-1">
                      <div className="flex items-center justify-between text-xs text-slate-300">
                        <span>Game Sound Volume</span>
                        <span className="font-mono tabular-nums">{Math.round(originalVolume * 100)}%</span>
                      </div>
                      <input
                        type="range"
                        min={0}
                        max={1}
                        step={0.05}
                        value={originalVolume}
                        onChange={(e) => setOriginalVolume(Number(e.target.value))}
                        className="w-full accent-rose-500"
                      />
                    </div>
                  </div>
                </div>
              )}

              {/* Tab 3: Add Voiceover */}
              {editorTab === 'voice' && (
                <div className="rounded-xl border border-slate-800 bg-[#0B0E14] p-4 space-y-4">
                  <div className="flex items-center justify-between gap-2">
                    <h3 className="text-sm font-bold text-white">Record or Upload Voiceover</h3>
                    <div className="flex items-center gap-2">
                      <input
                        ref={customVoiceInputRef}
                        type="file"
                        accept="audio/*"
                        onChange={handleCustomVoiceUpload}
                        className="hidden"
                      />
                      <button
                        type="button"
                        onClick={() => customVoiceInputRef.current?.click()}
                        className="inline-flex items-center gap-1.5 rounded-lg border border-slate-700 bg-[#121722] px-2.5 py-1.5 text-xs font-semibold text-slate-200 hover:border-sky-500"
                      >
                        <Upload className="h-3.5 w-3.5" aria-hidden="true" />
                        <span>Upload</span>
                      </button>
                      {voiceBlob && (
                        <button
                          type="button"
                          onClick={() => {
                            setVoiceBlob(undefined);
                            setVoiceName(undefined);
                          }}
                          className="rounded-lg border border-rose-500/40 bg-rose-950/30 p-1.5 text-rose-300 hover:bg-rose-900/40"
                          title="Clear voiceover"
                        >
                          <Trash2 className="h-3.5 w-3.5" aria-hidden="true" />
                        </button>
                      )}
                    </div>
                  </div>

                  <canvas
                    ref={waveCanvasRef}
                    width={420}
                    height={56}
                    className="w-full rounded-lg border border-slate-800 bg-[#0B0E14]"
                  />

                  <div className="flex items-center justify-between gap-3">
                    <button
                      type="button"
                      onClick={handleToggleVoiceRecord}
                      className={\`inline-flex items-center gap-2 rounded-lg px-4 py-2 text-xs font-bold text-white transition-colors \${
                        isRecordingVoice
                          ? 'bg-rose-600 hover:bg-rose-500'
                          : 'bg-sky-600 hover:bg-sky-500'
                      }\`}
                    >
                      {isRecordingVoice ? (
                        <>
                          <Square className="h-3.5 w-3.5 fill-current" aria-hidden="true" />
                          <span>Stop ({formatSeconds(voiceRecSeconds)})</span>
                        </>
                      ) : (
                        <>
                          <Mic className="h-3.5 w-3.5" aria-hidden="true" />
                          <span>Record Voiceover</span>
                        </>
                      )}
                    </button>

                    {voiceName && (
                      <span className="truncate text-xs font-medium text-sky-300">{voiceName}</span>
                    )}
                  </div>

                  {voiceError && (
                    <p className="text-xs text-rose-300">{voiceError}</p>
                  )}

                  <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 border-t border-slate-800 pt-3">
                    <div className="space-y-1">
                      <div className="flex items-center justify-between text-xs text-slate-300">
                        <span>Voiceover Volume</span>
                        <span className="font-mono tabular-nums">{Math.round(voiceVolume * 100)}%</span>
                      </div>
                      <input
                        type="range"
                        min={0}
                        max={1}
                        step={0.05}
                        value={voiceVolume}
                        onChange={(e) => setVoiceVolume(Number(e.target.value))}
                        className="w-full accent-sky-400"
                      />
                    </div>
                    <div className="space-y-1">
                      <div className="flex items-center justify-between text-xs text-slate-300">
                        <span>Game Sound Volume</span>
                        <span className="font-mono tabular-nums">{Math.round(originalVolume * 100)}%</span>
                      </div>
                      <input
                        type="range"
                        min={0}
                        max={1}
                        step={0.05}
                        value={originalVolume}
                        onChange={(e) => setOriginalVolume(Number(e.target.value))}
                        className="w-full accent-rose-500"
                      />
                    </div>
                  </div>
                </div>
              )}

              {/* Tab 4: Thumbnail Maker ("1 VS 4 CLUTCH") */}
              {editorTab === 'thumbnail' && (
                <div className="rounded-xl border border-slate-800 bg-[#0B0E14] p-4 space-y-3.5">
                  <div className="flex items-center justify-between gap-2">
                    <h3 className="text-sm font-bold text-white">Thumbnail Maker</h3>
                    <button
                      type="button"
                      disabled={isGeneratingThumb}
                      onClick={() => handleRenderThumbnail()}
                      className="inline-flex items-center gap-1.5 rounded-lg border border-slate-700 bg-[#121722] px-2.5 py-1.5 text-xs font-semibold text-slate-200 hover:border-rose-500 disabled:opacity-50"
                    >
                      <RefreshCw className={\`h-3.5 w-3.5 \${isGeneratingThumb ? 'animate-spin' : ''}\`} aria-hidden="true" />
                      <span>Capture Frame</span>
                    </button>
                  </div>

                  <div className="overflow-hidden rounded-lg border border-slate-800 bg-black aspect-video">
                    {thumbnailDataUrl ? (
                      <img
                        src={thumbnailDataUrl}
                        alt="Generated thumbnail preview"
                        className="h-full w-full object-cover"
                      />
                    ) : (
                      <div className="flex h-full items-center justify-center text-xs text-slate-400">
                        Rendering thumbnail preview…
                      </div>
                    )}
                  </div>

                  <div className="grid grid-cols-1 gap-2.5 sm:grid-cols-2">
                    <div className="space-y-1">
                      <label htmlFor="thumb-headline" className="text-[11px] font-semibold text-slate-300">
                        Bold Text Style
                      </label>
                      <input
                        id="thumb-headline"
                        type="text"
                        value={thumbHeadline}
                        onChange={(e) => {
                          const next = e.target.value;
                          setThumbHeadline(next);
                          void handleRenderThumbnail(next, thumbBadge, thumbStyle);
                        }}
                        className="w-full rounded-lg border border-slate-700 bg-[#121722] px-2.5 py-1.5 text-xs font-bold text-white focus:border-rose-500 focus:outline-none"
                      />
                    </div>
                    <div className="space-y-1">
                      <label htmlFor="thumb-badge" className="text-[11px] font-semibold text-slate-300">
                        Corner Tag
                      </label>
                      <input
                        id="thumb-badge"
                        type="text"
                        value={thumbBadge}
                        onChange={(e) => {
                          const next = e.target.value;
                          setThumbBadge(next);
                          void handleRenderThumbnail(thumbHeadline, next, thumbStyle);
                        }}
                        className="w-full rounded-lg border border-slate-700 bg-[#121722] px-2.5 py-1.5 text-xs font-bold text-white focus:border-rose-500 focus:outline-none"
                      />
                    </div>
                  </div>

                  <div className="flex flex-wrap gap-1.5">
                    {THUMBNAIL_TEXT_PRESETS.map((preset) => (
                      <button
                        key={preset}
                        type="button"
                        onClick={() => {
                          setThumbHeadline(preset);
                          void handleRenderThumbnail(preset, thumbBadge, thumbStyle);
                        }}
                        className={\`rounded-md border px-2 py-1 text-[11px] font-bold transition-colors \${
                          thumbHeadline === preset
                            ? 'border-amber-400 bg-amber-950/40 text-amber-200'
                            : 'border-slate-700 bg-[#121722] text-slate-300 hover:border-rose-500'
                        }\`}
                      >
                        {preset}
                      </button>
                    ))}
                  </div>

                  <div className="flex flex-wrap items-center justify-between gap-2 pt-1">
                    <div className="flex items-center gap-1.5">
                      {(
                        [
                          { id: 'clutch-red-gold', label: 'Red & Gold' },
                          { id: 'cyber-cyan', label: 'Cyber Cyan' },
                          { id: 'dark-impact', label: 'Dark Impact' },
                        ] as { id: ThumbnailStylePreset; label: string }[]
                      ).map((st) => (
                        <button
                          key={st.id}
                          type="button"
                          onClick={() => {
                            setThumbStyle(st.id);
                            void handleRenderThumbnail(thumbHeadline, thumbBadge, st.id);
                          }}
                          className={\`rounded-md px-2.5 py-1 text-[11px] font-semibold transition-colors \${
                            thumbStyle === st.id
                              ? 'bg-rose-600 text-white'
                              : 'border border-slate-700 bg-[#121722] text-slate-300 hover:text-white'
                          }\`}
                        >
                          {st.label}
                        </button>
                      ))}
                    </div>

                    <div className="flex items-center gap-2">
                      {thumbnailDataUrl && (
                        <a
                          href={thumbnailDataUrl}
                          download={\`\${title.replace(/[^a-z0-9_-]/gi, '_')}_thumbnail.jpg\`}
                          className="inline-flex items-center gap-1 rounded-lg border border-slate-700 bg-[#121722] px-2.5 py-1.5 text-xs font-semibold text-slate-200 hover:text-white"
                        >
                          <Download className="h-3.5 w-3.5" aria-hidden="true" />
                          <span>PNG/JPG</span>
                        </a>
                      )}
                      <button
                        type="button"
                        disabled={isSaving || isGeneratingThumb}
                        onClick={handleSaveThumbnailWithClip}
                        className="inline-flex items-center gap-1.5 rounded-lg bg-emerald-600 px-3 py-1.5 text-xs font-bold text-white hover:bg-emerald-500 disabled:opacity-50"
                      >
                        <Save className="h-3.5 w-3.5" aria-hidden="true" />
                        <span>Save Thumbnail with Clip</span>
                      </button>
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Save Progress, 1-Tap Share + Save Buttons */}
            <div className="space-y-3 border-t border-slate-800 pt-4">
              {isSaving && (
                <div className="space-y-1">
                  <div className="flex items-center justify-between text-xs text-slate-300">
                    <span>{saveStage}</span>
                    <span className="font-mono">{saveProgress}%</span>
                  </div>
                  <div className="h-2 w-full overflow-hidden rounded-full bg-slate-800">
                    <div
                      className="h-full bg-rose-500 transition-all"
                      style={{ width: \`\${saveProgress}%\` }}
                    />
                  </div>
                </div>
              )}

              {savedMessage && (
                <div className="flex items-center gap-2 rounded-lg border border-emerald-500/40 bg-emerald-950/30 px-3 py-2 text-xs font-semibold text-emerald-200">
                  <CheckCircle2 className="h-4 w-4 text-emerald-400 shrink-0" aria-hidden="true" />
                  <span>{savedMessage}</span>
                </div>
              )}

              {/* 1-Tap Share Strip */}
              <div className="flex flex-wrap items-center justify-between gap-2 rounded-lg border border-slate-800 bg-[#0B0E14] px-3 py-2">
                <span className="inline-flex items-center gap-1.5 text-[11px] font-semibold text-slate-300">
                  <Share2 className="h-3.5 w-3.5 text-rose-400" aria-hidden="true" />
                  <span>1-Tap Share (#BGMI #ClipKaro):</span>
                </span>
                <div className="flex flex-wrap items-center gap-1.5">
                  <button
                    type="button"
                    disabled={isSharing}
                    onClick={() => setViralExportPending({ kind: 'share', platform: 'youtube' })}
                    className="rounded-md bg-red-600 px-2.5 py-1 text-[11px] font-bold text-white hover:bg-red-500 disabled:opacity-50"
                  >
                    YouTube Shorts
                  </button>
                  <button
                    type="button"
                    disabled={isSharing}
                    onClick={() => setViralExportPending({ kind: 'share', platform: 'instagram' })}
                    className="rounded-md bg-fuchsia-600 px-2.5 py-1 text-[11px] font-bold text-white hover:bg-fuchsia-500 disabled:opacity-50"
                  >
                    Instagram Reels
                  </button>
                  <button
                    type="button"
                    disabled={isSharing}
                    onClick={() => setViralExportPending({ kind: 'share', platform: 'whatsapp' })}
                    className="rounded-md bg-emerald-600 px-2.5 py-1 text-[11px] font-bold text-white hover:bg-emerald-500 disabled:opacity-50"
                  >
                    WhatsApp
                  </button>
                </div>
              </div>

              <div className="flex flex-wrap items-center justify-end gap-2.5">
                <button
                  type="button"
                  onClick={onClose}
                  className="rounded-lg border border-slate-700 bg-[#0B0E14] px-3.5 py-2 text-xs font-semibold text-slate-300 hover:text-white"
                >
                  Close
                </button>
                <button
                  type="button"
                  disabled={isSaving}
                  onClick={() => setViralExportPending({ kind: 'save', asNewVersion: true })}
                  className="inline-flex items-center gap-1.5 rounded-lg bg-rose-600 px-4 py-2 text-xs font-bold text-white hover:bg-rose-500 disabled:opacity-50"
                >
                  <Save className="h-3.5 w-3.5" aria-hidden="true" />
                  <span>{isSaving ? 'Saving…' : 'Save New Version'}</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      <ViralScoreExportDialog
        isOpen={Boolean(viralExportPending)}
        actionLabel={
          viralExportPending?.kind === 'save'
            ? 'saving edited video'
            : \`sharing to \${viralExportPending?.platform ?? ''}\`
        }
        viralScore={editorViralResult.score}
        isProcessing={isSharing || isSaving}
        onChoose={handleConfirmViralExport}
        onCancel={() => {
          if (!isSharing && !isSaving) setViralExportPending(null);
        }}
      />
    </div>
  );
}
`,"/src/components/CutVideoView.tsx":`import { ChangeEvent, useEffect, useMemo, useRef, useState } from 'react';
import {
  Check,
  Copy,
  FileCheck2,
  Film,
  FolderOpen,
  Link2,
  Play,
  Pause,
  Scissors,
  ShieldCheck,
  ShieldAlert,
  Sparkles,
  Trash2,
  Upload,
  Video,
} from 'lucide-react';
import {
  CLIP_LENGTH_OPTIONS,
  ClipItem,
  ClipLengthOption,
  GameItem,
  SocialPlatform,
} from '../types/clipkaro';
import { formatCreditHandle } from '../utils/embedUrl';
import { trimVideoWithFFmpeg } from '../utils/ffmpegCutter';
import {
  captureVideoThumbnail,
  formatSeconds,
  generateSampleStreamVideoBlob,
} from '../utils/mediaGenerators';

interface CutVideoViewProps {
  copyrightSafeMode: boolean;
  onToggleCopyrightSafeMode: () => void;
  games: GameItem[];
  initialOriginalLink?: string;
  initialPlatform?: SocialPlatform | 'upload' | 'studio';
  initialStreamerName?: string;
  initialGameTag?: string;
  onSaveClip: (clip: ClipItem) => Promise<void>;
  onGoToMyClips: () => void;
}

export function CutVideoView({
  copyrightSafeMode,
  onToggleCopyrightSafeMode,
  games,
  initialOriginalLink = '',
  initialPlatform = 'youtube',
  initialStreamerName = '',
  initialGameTag = '',
  onSaveClip,
  onGoToMyClips,
}: CutVideoViewProps) {
  // Permission Clip Section State (Top)
  const [hasPermission, setHasPermission] = useState<boolean>(false);
  const [streamerName, setStreamerName] = useState<string>(initialStreamerName);
  const [proofFile, setProofFile] = useState<File | null>(null);
  const [proofPreviewUrl, setProofPreviewUrl] = useState<string | null>(null);
  const [originalVideoLink, setOriginalVideoLink] = useState<string>(initialOriginalLink);
  const [copiedCredit, setCopiedCredit] = useState<boolean>(false);

  // Clip Length Chips State (Default 10 sec)
  const [clipLength, setClipLength] = useState<ClipLengthOption>(10);

  // Source Video & Trimmer State
  const [videoBlob, setVideoBlob] = useState<Blob | null>(null);
  const [videoUrl, setVideoUrl] = useState<string | null>(null);
  const [videoFileName, setVideoFileName] = useState<string>('');
  const [videoDuration, setVideoDuration] = useState<number>(0);
  const [trimStart, setTrimStart] = useState<number>(0);
  const [isPlayingSegment, setIsPlayingSegment] = useState<boolean>(false);
  const [clipTitle, setClipTitle] = useState<string>('');
  const [selectedGame, setSelectedGame] = useState<string>(
    initialGameTag || games[0]?.name || 'General Stream'
  );
  const [autoCaptionEnabled, setAutoCaptionEnabled] = useState<boolean>(true);
  const [autoCaptionText, setAutoCaptionText] = useState<string>('');
  const [sourcePlatform, setSourcePlatform] = useState<SocialPlatform | 'upload' | 'studio'>(
    initialPlatform
  );

  // Generation / Saving Feedback State
  const [isGeneratingSample, setIsGeneratingSample] = useState<boolean>(false);
  const [sampleProgress, setSampleProgress] = useState<number>(0);
  const [isSaving, setIsSaving] = useState<boolean>(false);
  const [cutProgress, setCutProgress] = useState<number>(0);
  const [cutStage, setCutStage] = useState<string>('');
  const [saveError, setSaveError] = useState<string | null>(null);
  const [savedSuccessClipTitle, setSavedSuccessClipTitle] = useState<string | null>(null);

  const videoRef = useRef<HTMLVideoElement | null>(null);
  const videoInputRef = useRef<HTMLInputElement | null>(null);
  const proofInputRef = useRef<HTMLInputElement | null>(null);

  useEffect(() => {
    if (initialOriginalLink) setOriginalVideoLink(initialOriginalLink);
  }, [initialOriginalLink]);

  useEffect(() => {
    if (initialStreamerName) setStreamerName(initialStreamerName);
  }, [initialStreamerName]);

  useEffect(() => {
    if (initialPlatform) setSourcePlatform(initialPlatform);
  }, [initialPlatform]);

  useEffect(() => {
    if (initialGameTag) setSelectedGame(initialGameTag);
  }, [initialGameTag]);

  // Clean up object URLs
  useEffect(() => {
    return () => {
      if (videoUrl) URL.revokeObjectURL(videoUrl);
    };
  }, [videoUrl]);

  useEffect(() => {
    return () => {
      if (proofPreviewUrl) URL.revokeObjectURL(proofPreviewUrl);
    };
  }, [proofPreviewUrl]);

  const autoCreditText = useMemo(() => formatCreditHandle(streamerName), [streamerName]);

  const effectiveTrimEnd = useMemo(() => {
    if (videoDuration <= 0) return clipLength;
    return Math.min(videoDuration, trimStart + clipLength);
  }, [videoDuration, trimStart, clipLength]);

  const maxTrimStart = useMemo(() => {
    if (videoDuration <= clipLength) return 0;
    return Math.max(0, Math.floor((videoDuration - clipLength) * 10) / 10);
  }, [videoDuration, clipLength]);

  const handleSelectLength = (sec: ClipLengthOption) => {
    setClipLength(sec);
    if (videoDuration > 0 && trimStart + sec > videoDuration) {
      setTrimStart(Math.max(0, Math.floor((videoDuration - sec) * 10) / 10));
    }
  };

  const handleCopyCredit = async () => {
    try {
      await navigator.clipboard.writeText(autoCreditText);
      setCopiedCredit(true);
      window.setTimeout(() => setCopiedCredit(false), 1800);
    } catch {
      // Fallback ignored if clipboard blocked
    }
  };

  const handleProofUpload = (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (proofPreviewUrl) URL.revokeObjectURL(proofPreviewUrl);
    setProofFile(file);
    if (file.type.startsWith('image/')) {
      setProofPreviewUrl(URL.createObjectURL(file));
    } else {
      setProofPreviewUrl(null);
    }
  };

  const handleClearProof = () => {
    if (proofPreviewUrl) URL.revokeObjectURL(proofPreviewUrl);
    setProofFile(null);
    setProofPreviewUrl(null);
    if (proofInputRef.current) proofInputRef.current.value = '';
  };

  const loadVideoSource = (blob: Blob, name: string, platform: SocialPlatform | 'upload' | 'studio') => {
    if (videoUrl) URL.revokeObjectURL(videoUrl);
    const nextUrl = URL.createObjectURL(blob);
    setVideoBlob(blob);
    setVideoUrl(nextUrl);
    setVideoFileName(name);
    setSourcePlatform(platform);
    setVideoDuration(0);
    setTrimStart(0);
    setIsPlayingSegment(false);
    setSaveError(null);
    setSavedSuccessClipTitle(null);
    if (!clipTitle.trim()) {
      const cleanedName = name.replace(/\\.[^/.]+$/, '');
      setClipTitle(cleanedName || 'Highlight Clip');
    }
  };

  const handleVideoFileChange = (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    loadVideoSource(file, file.name, originalVideoLink ? sourcePlatform : 'upload');
    e.target.value = '';
  };

  const handleGenerateSampleVideo = async () => {
    setIsGeneratingSample(true);
    setSampleProgress(0);
    setSaveError(null);
    try {
      const sampleDur = Math.max(12, Math.min(clipLength + 2, 16));
      const blob = await generateSampleStreamVideoBlob({
        durationSec: sampleDur,
        title: clipTitle.trim() || 'Streamer Highlight Feed',
        creditLine: autoCreditText,
        onProgress: setSampleProgress,
      });
      loadVideoSource(blob, 'sample-stream-feed.webm', 'studio');
      if (!clipTitle.trim()) {
        setClipTitle(
          streamerName.trim()
            ? \`\${streamerName.trim().replace(/^@+/, '')} Highlight\`
            : 'Sample Stream Clip'
        );
      }
    } catch {
      setSaveError('Unable to generate sample stream video in this browser.');
    } finally {
      setIsGeneratingSample(false);
    }
  };

  const handleLoadedMetadata = () => {
    const el = videoRef.current;
    if (!el) return;
    el.muted = false;
    if (el.volume === 0) el.volume = 1;

    if (el.duration === Infinity || !Number.isFinite(el.duration)) {
      // Resolve actual duration for MediaRecorder WebM streams in Chromium
      const resolveDuration = () => {
        el.removeEventListener('timeupdate', resolveDuration);
        const resolvedDur = Number.isFinite(el.duration) ? el.duration : 0;
        el.currentTime = 0;
        setVideoDuration(resolvedDur);
        setTrimStart(0);
      };
      el.addEventListener('timeupdate', resolveDuration);
      el.currentTime = 1e101;
      return;
    }

    setVideoDuration(el.duration);
    setTrimStart(0);
  };

  const handleToggleSegmentPreview = () => {
    const el = videoRef.current;
    if (!el) return;
    if (isPlayingSegment) {
      el.pause();
      setIsPlayingSegment(false);
      return;
    }
    el.muted = false;
    if (el.volume === 0) el.volume = 1;
    if (Math.abs(el.currentTime - trimStart) > 0.15) {
      el.currentTime = trimStart;
    }
    setIsPlayingSegment(true);
    el.play().catch(() => {
      setIsPlayingSegment(false);
      setSaveError('Unable to start preview playback. Press Play directly on the video player.');
    });
  };

  const handleVideoTimeUpdate = () => {
    const el = videoRef.current;
    if (!el) return;
    if (isPlayingSegment && effectiveTrimEnd > trimStart && el.currentTime >= effectiveTrimEnd) {
      el.pause();
      el.currentTime = trimStart;
      setIsPlayingSegment(false);
    }
  };

  const handleSaveClip = async () => {
    setSaveError(null);
    setSavedSuccessClipTitle(null);

    if (!videoBlob) {
      setSaveError('Please upload a video file or generate a sample stream video first.');
      return;
    }

    if (copyrightSafeMode) {
      if (!hasPermission) {
        setSaveError(
          'Copyright-Safe Mode is ON. Please confirm "I have permission from streamer" in the Permission Clip section above.'
        );
        return;
      }
      if (!streamerName.trim()) {
        setSaveError(
          'Copyright-Safe Mode is ON. Please enter the Streamer Channel Name so credit can be generated.'
        );
        return;
      }
    }

    setIsSaving(true);
    setCutProgress(0);
    setCutStage('Initializing FFmpeg…');
    try {
      let thumbnailDataUrl: string | undefined;
      if (videoRef.current) {
        thumbnailDataUrl = await captureVideoThumbnail(videoRef.current);
      }

      const actualDuration =
        videoDuration > 0 ? Math.max(1, Math.round(effectiveTrimEnd - trimStart)) : clipLength;

      const finalTitle =
        clipTitle.trim() ||
        (streamerName.trim()
          ? \`\${streamerName.trim().replace(/^@+/, '')} (\${clipLength}s Clip)\`
          : \`Clip (\${clipLength}s)\`);

      const resolvedCaption = autoCaptionEnabled
        ? autoCaptionText.trim() || finalTitle
        : '';

      const { mp4Blob } = await trimVideoWithFFmpeg({
        sourceBlob: videoBlob,
        sourceFileName: videoFileName || 'source-video.mp4',
        startSec: trimStart,
        durationSec: actualDuration,
        videoWidth: videoRef.current?.videoWidth || 1280,
        burnCredit: hasPermission,
        creditText: autoCreditText,
        burnAutoCaption: autoCaptionEnabled,
        autoCaptionText: resolvedCaption,
        onProgress: (pct, stage) => {
          setCutProgress(pct);
          setCutStage(stage);
        },
      });

      const newClip: ClipItem = {
        id: \`clip-\${Date.now()}-\${Math.random().toString(36).slice(2, 7)}\`,
        title: finalTitle,
        platform: sourcePlatform,
        gameTag: selectedGame,
        durationSec: actualDuration,
        trimStart: 0,
        trimEnd: actualDuration,
        createdAt: Date.now(),
        copyrightSafe: copyrightSafeMode,
        permission: {
          hasPermission,
          streamerName: streamerName.trim().replace(/^@+/, ''),
          proofFileName: proofFile?.name,
          proofMimeType: proofFile?.type,
          proofBlob: proofFile ?? undefined,
          originalVideoLink: originalVideoLink.trim(),
          creditText: autoCreditText,
        },
        videoBlob: mp4Blob,
        videoMimeType: 'video/mp4',
        thumbnailDataUrl,
        autoCaption: resolvedCaption || undefined,
        voiceVolume: 1,
        musicVolume: 0.45,
        originalVolume: 1,
      };

      await onSaveClip(newClip);
      setSavedSuccessClipTitle(finalTitle);
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'FFmpeg failed to cut this video file.';
      setSaveError(\`Could not trim video with FFmpeg: \${msg}\`);
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <h1 className="font-display text-2xl font-bold tracking-tight text-white">
            Cut Video
          </h1>
          <p className="mt-1 text-sm text-slate-400">
            Verify streamer permission on top, pick your clip duration, and trim an authorized clip for My Clips.
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2.5 self-start sm:self-auto">
          <button
            type="button"
            onClick={() => videoInputRef.current?.click()}
            className="inline-flex items-center gap-2 rounded-lg bg-rose-600 px-3.5 py-2 text-xs font-semibold text-white transition-colors hover:bg-rose-500 whitespace-nowrap shrink-0"
          >
            <FolderOpen className="h-4 w-4" aria-hidden="true" />
            <span>My Gallery</span>
          </button>
          <button
            type="button"
            onClick={onToggleCopyrightSafeMode}
            className={\`inline-flex items-center gap-2 rounded-lg border px-3 py-2 text-xs font-semibold transition-colors whitespace-nowrap shrink-0 \${
              copyrightSafeMode
                ? 'border-emerald-500/40 bg-emerald-950/30 text-emerald-300'
                : 'border-amber-500/40 bg-amber-950/30 text-amber-300'
            }\`}
          >
            {copyrightSafeMode ? (
              <ShieldCheck className="h-4 w-4" aria-hidden="true" />
            ) : (
              <ShieldAlert className="h-4 w-4" aria-hidden="true" />
            )}
            <span>Copyright-Safe Mode {copyrightSafeMode ? 'ON' : 'OFF'}</span>
          </button>
        </div>
      </div>

      {/* SECTION 1 (TOP): Permission Clip */}
      <section
        aria-labelledby="permission-clip-heading"
        className="rounded-xl border border-slate-800 bg-[#121722] p-5 sm:p-6 space-y-5"
      >
        <div className="flex flex-col gap-4 border-b border-slate-800/80 pb-4 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h2 id="permission-clip-heading" className="font-display text-lg font-bold text-white">
              Permission Clip
            </h2>
            <p className="mt-0.5 text-xs text-slate-400">
              Attach streamer authorization, proof screenshot, original link, and automatic channel credit.
            </p>
          </div>

          {/* Toggle: I have permission from streamer */}
          <button
            type="button"
            role="switch"
            aria-checked={hasPermission}
            onClick={() => setHasPermission((prev) => !prev)}
            className={\`inline-flex items-center gap-3 rounded-lg border px-4 py-2.5 text-sm font-semibold transition-colors whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-rose-500 \${
              hasPermission
                ? 'border-emerald-500/50 bg-emerald-950/30 text-emerald-200'
                : 'border-slate-700 bg-[#0B0E14] text-slate-300 hover:border-slate-600'
            }\`}
          >
            <span
              className={\`relative inline-flex h-5 w-9 shrink-0 items-center rounded-full transition-colors \${
                hasPermission ? 'bg-emerald-500' : 'bg-slate-700'
              }\`}
            >
              <span
                className={\`inline-block h-3.5 w-3.5 rounded-full bg-white transition-transform \${
                  hasPermission ? 'translate-x-[18px]' : 'translate-x-[3px]'
                }\`}
              />
            </span>
            <span>I have permission from streamer</span>
          </button>
        </div>

        {/* Permission Fields */}
        <div className="grid grid-cols-1 gap-4 md:grid-cols-3">
          {/* Field 1: Streamer Channel Name */}
          <div className="space-y-1.5">
            <label
              htmlFor="streamer-channel-name"
              className="block text-xs font-semibold text-slate-300"
            >
              Streamer Channel Name
            </label>
            <input
              id="streamer-channel-name"
              type="text"
              value={streamerName}
              onChange={(e) => setStreamerName(e.target.value)}
              placeholder="e.g. StreamerName"
              className="w-full rounded-lg border border-slate-700/80 bg-[#0B0E14] px-3.5 py-2.5 text-sm text-white placeholder:text-slate-500 focus:border-rose-500 focus:outline-none"
            />
          </div>

          {/* Field 2: Permission Proof Upload */}
          <div className="space-y-1.5">
            <label
              htmlFor="permission-proof-upload"
              className="block text-xs font-semibold text-slate-300"
            >
              Permission Proof Upload
            </label>
            <input
              ref={proofInputRef}
              id="permission-proof-upload"
              type="file"
              accept="image/*,.pdf,.txt"
              onChange={handleProofUpload}
              className="sr-only"
            />
            {proofFile ? (
              <div className="flex items-center justify-between gap-2 rounded-lg border border-emerald-500/40 bg-emerald-950/20 px-3 py-2 text-xs text-emerald-200">
                <div className="flex items-center gap-2 min-w-0">
                  {proofPreviewUrl ? (
                    <img
                      src={proofPreviewUrl}
                      alt="Permission proof preview"
                      className="h-6 w-6 rounded object-cover shrink-0"
                      referrerPolicy="no-referrer"
                    />
                  ) : (
                    <FileCheck2 className="h-4 w-4 shrink-0 text-emerald-400" aria-hidden="true" />
                  )}
                  <span className="truncate">{proofFile.name}</span>
                </div>
                <button
                  type="button"
                  onClick={handleClearProof}
                  aria-label="Remove permission proof"
                  className="rounded p-1 text-slate-400 hover:bg-slate-800 hover:text-white shrink-0"
                >
                  <Trash2 className="h-3.5 w-3.5" aria-hidden="true" />
                </button>
              </div>
            ) : (
              <button
                type="button"
                onClick={() => proofInputRef.current?.click()}
                className="flex w-full items-center justify-center gap-2 rounded-lg border border-dashed border-slate-700 bg-[#0B0E14] px-3.5 py-2.5 text-sm text-slate-300 transition-colors hover:border-slate-500 hover:text-white"
              >
                <Upload className="h-4 w-4 text-slate-400" aria-hidden="true" />
                <span className="truncate">Upload Screenshot or PDF</span>
              </button>
            )}
          </div>

          {/* Field 3: Original Video Link */}
          <div className="space-y-1.5">
            <label
              htmlFor="original-video-link"
              className="block text-xs font-semibold text-slate-300"
            >
              Original Video Link
            </label>
            <div className="relative">
              <Link2
                className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-500"
                aria-hidden="true"
              />
              <input
                id="original-video-link"
                type="url"
                value={originalVideoLink}
                onChange={(e) => setOriginalVideoLink(e.target.value)}
                placeholder="https://youtube.com/watch?v=..."
                className="w-full rounded-lg border border-slate-700/80 bg-[#0B0E14] py-2.5 pl-9 pr-3.5 text-sm text-white placeholder:text-slate-500 focus:border-rose-500 focus:outline-none"
              />
            </div>
          </div>
        </div>

        {/* Auto Credit Display */}
        <div className="flex flex-wrap items-center justify-between gap-3 rounded-lg border border-slate-800 bg-[#0B0E14] px-4 py-3">
          <div className="flex flex-wrap items-center gap-3">
            <span className="text-xs font-medium text-slate-400">Auto-generated credit:</span>
            <span
              data-testid="auto-credit-text"
              className="font-mono text-sm font-semibold text-white"
            >
              {autoCreditText}
            </span>
          </div>
          <button
            type="button"
            onClick={handleCopyCredit}
            className="inline-flex items-center gap-1.5 rounded-md border border-slate-700 bg-slate-800/80 px-3 py-1.5 text-xs font-medium text-slate-200 transition-colors hover:bg-slate-700 whitespace-nowrap shrink-0"
          >
            {copiedCredit ? (
              <>
                <Check className="h-3.5 w-3.5 text-emerald-400" aria-hidden="true" />
                <span>Copied</span>
              </>
            ) : (
              <>
                <Copy className="h-3.5 w-3.5" aria-hidden="true" />
                <span>Copy Credit</span>
              </>
            )}
          </button>
        </div>
      </section>

      {/* SECTION 2: Clip Length Chips & Video Trimmer */}
      <section className="grid grid-cols-1 gap-6 lg:grid-cols-12">
        {/* Left: Video Player & Source Controls */}
        <div className="space-y-4 rounded-xl border border-slate-800 bg-[#121722] p-5 sm:p-6 lg:col-span-7">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <h2 className="font-display text-base font-bold text-white">Video Source & Preview</h2>
            <div className="flex flex-wrap items-center gap-2">
              <input
                ref={videoInputRef}
                type="file"
                accept="video/*"
                onChange={handleVideoFileChange}
                className="sr-only"
              />
              <button
                type="button"
                onClick={() => videoInputRef.current?.click()}
                className="inline-flex items-center gap-2 rounded-lg border border-slate-700 bg-[#0B0E14] px-3 py-2 text-xs font-semibold text-slate-200 hover:border-slate-500 hover:text-white whitespace-nowrap shrink-0"
              >
                <Upload className="h-3.5 w-3.5" aria-hidden="true" />
                <span>Upload Video File</span>
              </button>
              <button
                type="button"
                disabled={isGeneratingSample}
                onClick={handleGenerateSampleVideo}
                className="inline-flex items-center gap-2 rounded-lg border border-slate-700 bg-slate-800 px-3 py-2 text-xs font-semibold text-white hover:bg-slate-700 disabled:opacity-60 whitespace-nowrap shrink-0"
              >
                <Sparkles className="h-3.5 w-3.5 text-rose-400" aria-hidden="true" />
                <span>
                  {isGeneratingSample
                    ? \`Recording Sample (\${sampleProgress}%)\`
                    : 'Generate Sample Stream'}
                </span>
              </button>
            </div>
          </div>

          {videoUrl ? (
            <div className="space-y-4">
              <div className="relative overflow-hidden rounded-xl border border-slate-800 bg-black">
                <video
                  key={videoUrl}
                  ref={videoRef}
                  src={videoUrl}
                  controls
                  playsInline
                  preload="auto"
                  onLoadedMetadata={handleLoadedMetadata}
                  onTimeUpdate={handleVideoTimeUpdate}
                  onPlay={() => {
                    if (videoRef.current) {
                      videoRef.current.muted = false;
                      if (videoRef.current.volume === 0) videoRef.current.volume = 1;
                    }
                  }}
                  onPause={() => setIsPlayingSegment(false)}
                  onEnded={() => setIsPlayingSegment(false)}
                  onError={() =>
                    setSaveError('This video format could not be decoded in preview. Try an MP4 or WebM file.')
                  }
                  className="aspect-video w-full"
                />
                {autoCaptionEnabled && (autoCaptionText.trim() || clipTitle.trim()) && (
                  <div className="pointer-events-none absolute inset-x-0 bottom-12 flex justify-center px-4">
                    <span className="rounded bg-black px-3 py-1 text-xs font-bold text-white shadow">
                      {autoCaptionText.trim() || clipTitle.trim()}
                    </span>
                  </div>
                )}
              </div>

              {/* Timeline Start Slider */}
              <div className="space-y-2.5 rounded-lg border border-slate-800 bg-[#0B0E14] p-4">
                <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
                  <span className="font-medium text-slate-300">
                    Trim Window ({clipLength} sec chip)
                  </span>
                  <span className="font-mono text-slate-200 tabular-nums">
                    {formatSeconds(trimStart)} → {formatSeconds(effectiveTrimEnd)}
                    {videoDuration > 0 ? \` / Total \${formatSeconds(videoDuration)}\` : ''}
                  </span>
                </div>

                <input
                  type="range"
                  min={0}
                  max={maxTrimStart > 0 ? maxTrimStart : 0}
                  step={0.5}
                  value={trimStart}
                  disabled={maxTrimStart === 0}
                  onChange={(e) => {
                    const nextStart = parseFloat(e.target.value);
                    setTrimStart(nextStart);
                    if (videoRef.current) {
                      videoRef.current.currentTime = nextStart;
                    }
                  }}
                  aria-label="Clip start time"
                  className="w-full accent-rose-500"
                />

                <div className="flex flex-wrap items-center justify-between gap-3 pt-1">
                  <span className="text-xs text-slate-400 truncate max-w-[260px]">
                    Loaded: {videoFileName}
                  </span>
                  <button
                    type="button"
                    onClick={handleToggleSegmentPreview}
                    className="inline-flex items-center gap-2 rounded-lg bg-slate-800 px-3.5 py-2 text-xs font-semibold text-white hover:bg-slate-700 whitespace-nowrap shrink-0"
                  >
                    {isPlayingSegment ? (
                      <>
                        <Pause className="h-3.5 w-3.5" aria-hidden="true" />
                        <span>Pause Segment</span>
                      </>
                    ) : (
                      <>
                        <Play className="h-3.5 w-3.5" aria-hidden="true" />
                        <span>Preview {clipLength}s Segment</span>
                      </>
                    )}
                  </button>
                </div>
              </div>
            </div>
          ) : (
            <div className="flex aspect-video flex-col items-center justify-center gap-4 rounded-xl border border-dashed border-slate-700/80 bg-[#0B0E14] p-6 text-center">
              <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-slate-800/80 text-slate-300">
                <Video className="h-6 w-6" aria-hidden="true" />
              </div>
              <div className="max-w-sm space-y-1">
                <p className="font-display text-sm font-semibold text-white">
                  Load a video to cut your {clipLength}s clip
                </p>
                <p className="text-xs text-slate-400">
                  Upload any MP4, WebM, or MOV video file from your device, or click Generate Sample Stream to create a playable test stream right now.
                </p>
              </div>
              {isGeneratingSample && (
                <div className="w-full max-w-xs space-y-1.5">
                  <div className="h-2 overflow-hidden rounded-full bg-slate-800">
                    <div
                      className="h-full bg-rose-500 transition-all"
                      style={{ width: \`\${sampleProgress}%\` }}
                    />
                  </div>
                  <p className="text-xs text-slate-400 tabular-nums">
                    Creating sample WebM stream… {sampleProgress}%
                  </p>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Right: Clip Length Chips & Save Details */}
        <div className="flex flex-col justify-between gap-6 rounded-xl border border-slate-800 bg-[#121722] p-5 sm:p-6 lg:col-span-5">
          <div className="space-y-5">
            {/* Clip Length Chips */}
            <div className="space-y-2.5">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-slate-300">Clip Length</span>
                <span className="text-xs text-slate-400 tabular-nums">
                  Selected: {clipLength} sec
                </span>
              </div>
              <div className="grid grid-cols-3 gap-2">
                {CLIP_LENGTH_OPTIONS.map((sec) => {
                  const selected = clipLength === sec;
                  return (
                    <button
                      key={sec}
                      type="button"
                      onClick={() => handleSelectLength(sec)}
                      aria-pressed={selected}
                      className={\`rounded-lg border px-3 py-2.5 text-sm font-semibold tabular-nums transition-colors whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-rose-500 \${
                        selected
                          ? 'border-rose-500 bg-rose-600 text-white'
                          : 'border-slate-700/80 bg-[#0B0E14] text-slate-300 hover:border-slate-500 hover:text-white'
                      }\`}
                    >
                      {sec} sec
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Clip Title */}
            <div className="space-y-1.5">
              <label htmlFor="clip-title-input" className="block text-xs font-semibold text-slate-300">
                Clip Title
              </label>
              <input
                id="clip-title-input"
                type="text"
                value={clipTitle}
                onChange={(e) => setClipTitle(e.target.value)}
                placeholder="e.g. Final Round Clutch"
                className="w-full rounded-lg border border-slate-700/80 bg-[#0B0E14] px-3.5 py-2.5 text-sm text-white placeholder:text-slate-500 focus:border-rose-500 focus:outline-none"
              />
            </div>

            {/* Game Tag */}
            <div className="space-y-1.5">
              <label htmlFor="clip-game-select" className="block text-xs font-semibold text-slate-300">
                Game Category
              </label>
              <select
                id="clip-game-select"
                value={selectedGame}
                onChange={(e) => setSelectedGame(e.target.value)}
                className="w-full rounded-lg border border-slate-700/80 bg-[#0B0E14] px-3.5 py-2.5 text-sm text-white focus:border-rose-500 focus:outline-none"
              >
                {games.map((g) => (
                  <option key={g.id} value={g.name}>
                    {g.name}
                  </option>
                ))}
                <option value="Just Chatting & IRL">Just Chatting & IRL</option>
              </select>
            </div>

            {/* Auto-Caption (Black Background) */}
            <div className="space-y-2 rounded-lg border border-slate-800 bg-[#0B0E14] p-3">
              <div className="flex items-center justify-between gap-2">
                <label
                  htmlFor="auto-caption-input"
                  className="text-xs font-semibold text-slate-300"
                >
                  Auto-Caption (Black Background)
                </label>
                <button
                  type="button"
                  role="switch"
                  aria-checked={autoCaptionEnabled}
                  onClick={() => setAutoCaptionEnabled((prev) => !prev)}
                  className={\`rounded-md px-2.5 py-1 text-xs font-semibold transition-colors \${
                    autoCaptionEnabled
                      ? 'bg-emerald-600 text-white'
                      : 'bg-slate-800 text-slate-400'
                  }\`}
                >
                  {autoCaptionEnabled ? 'ON' : 'OFF'}
                </button>
              </div>
              {autoCaptionEnabled && (
                <input
                  id="auto-caption-input"
                  type="text"
                  value={autoCaptionText}
                  onChange={(e) => setAutoCaptionText(e.target.value)}
                  placeholder={clipTitle.trim() || 'Auto-caption text (defaults to Clip Title)'}
                  className="w-full rounded-md border border-slate-700/80 bg-black px-3 py-2 text-xs font-medium text-white placeholder:text-slate-500 focus:border-rose-500 focus:outline-none"
                />
              )}
            </div>

            {/* Copyright-Safe Notice */}
            {copyrightSafeMode && (!hasPermission || !streamerName.trim()) && (
              <div className="rounded-lg border border-amber-500/40 bg-amber-950/20 p-3.5 text-xs text-amber-200 space-y-1">
                <div className="font-semibold flex items-center gap-1.5">
                  <ShieldCheck className="h-4 w-4 text-amber-400 shrink-0" aria-hidden="true" />
                  <span>Permission Required (Copyright-Safe Mode ON)</span>
                </div>
                <p className="text-amber-200/80">
                  Enable &ldquo;I have permission from streamer&rdquo; and enter the Streamer Channel Name at the top before saving.
                </p>
              </div>
            )}

            {saveError && (
              <div
                role="alert"
                className="rounded-lg border border-rose-500/40 bg-rose-950/30 p-3.5 text-xs text-rose-200"
              >
                {saveError}
              </div>
            )}

            {isSaving && (
              <div
                aria-live="polite"
                className="rounded-lg border border-slate-700 bg-[#0B0E14] p-3.5 space-y-2"
              >
                <div className="flex items-center justify-between gap-2 text-xs">
                  <span className="font-medium text-slate-200 truncate">
                    {cutStage || 'Cutting video with FFmpeg…'}
                  </span>
                  <span className="font-mono font-semibold text-rose-400 tabular-nums shrink-0">
                    {cutProgress}%
                  </span>
                </div>
                <div className="h-2 w-full overflow-hidden rounded-full bg-slate-800">
                  <div
                    className="h-full bg-rose-500 transition-all duration-150"
                    style={{ width: \`\${cutProgress}%\` }}
                  />
                </div>
              </div>
            )}

            {savedSuccessClipTitle && (
              <div className="rounded-lg border border-emerald-500/40 bg-emerald-950/25 p-3.5 text-xs text-emerald-200 flex items-center justify-between gap-3">
                <span>
                  Saved <strong>{savedSuccessClipTitle}</strong> (.mp4) to My Clips.
                </span>
                <button
                  type="button"
                  onClick={onGoToMyClips}
                  className="inline-flex items-center gap-1.5 rounded-md bg-emerald-600 px-3 py-1.5 font-semibold text-white hover:bg-emerald-500 whitespace-nowrap shrink-0"
                >
                  <Film className="h-3.5 w-3.5" aria-hidden="true" />
                  <span>Open My Clips</span>
                </button>
              </div>
            )}
          </div>

          <button
            type="button"
            disabled={isSaving || isGeneratingSample}
            onClick={handleSaveClip}
            className="inline-flex w-full items-center justify-center gap-2 rounded-lg bg-rose-600 px-5 py-3 text-sm font-bold text-white transition-colors hover:bg-rose-500 disabled:opacity-60"
          >
            <Scissors className="h-4 w-4" aria-hidden="true" />
            <span>
              {isSaving ? \`Cutting MP4 (\${cutProgress}%)…\` : \`Cut & Save \${clipLength}s Clip\`}
            </span>
          </button>
        </div>
      </section>
    </div>
  );
}
`,"/src/components/ExportCodeModal.tsx":`import { useEffect, useMemo, useState } from 'react';
import {
  Check,
  Code2,
  Copy,
  Download,
  FileCode2,
  FolderArchive,
  Loader2,
  Search,
  Smartphone,
  X,
} from 'lucide-react';
import type { ProjectFileCategory, ProjectSourceFile } from '../utils/projectFilesManifest';
import { createZipBlob, triggerBlobDownload, type ZipInputFile } from '../utils/zipBuilder';

interface ExportCodeModalProps {
  isOpen: boolean;
  onClose: () => void;
}

function formatBytes(bytes: number): string {
  if (bytes < 1024) return \`\${bytes} B\`;
  if (bytes < 1024 * 1024) return \`\${(bytes / 1024).toFixed(1)} KB\`;
  return \`\${(bytes / (1024 * 1024)).toFixed(2)} MB\`;
}

export function ExportCodeModal({ isOpen, onClose }: ExportCodeModalProps) {
  const [files, setFiles] = useState<ProjectSourceFile[]>([]);
  const [assetPaths, setAssetPaths] = useState<string[]>([]);
  const [isLoadingFiles, setIsLoadingFiles] = useState(false);

  const [categoryFilter, setCategoryFilter] = useState<'all' | ProjectFileCategory>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedPath, setSelectedPath] = useState<string>(
    'android/app/src/main/java/com/clipkaro/app/MainActivity.java'
  );
  const [copiedPath, setCopiedPath] = useState<string | null>(null);

  const [isBuildingSourceZip, setIsBuildingSourceZip] = useState(false);
  const [isDownloadingFullZip, setIsDownloadingFullZip] = useState(false);
  const [fullZipProgress, setFullZipProgress] = useState<number>(0);
  const [statusMessage, setStatusMessage] = useState<string>('');
  const [errorMessage, setErrorMessage] = useState<string>('');

  useEffect(() => {
    if (!isOpen) return;
    let active = true;
    setIsLoadingFiles(true);
    setErrorMessage('');

    import('../utils/projectFilesManifest')
      .then((mod) => {
        if (!active) return;
        setFiles(mod.PROJECT_SOURCE_FILES);
        setAssetPaths(mod.ASSET_IMAGE_PATHS);
        if (
          mod.PROJECT_SOURCE_FILES.length > 0 &&
          !mod.PROJECT_SOURCE_FILES.some((f) => f.path === selectedPath)
        ) {
          setSelectedPath(mod.PROJECT_SOURCE_FILES[0].path);
        }
      })
      .catch((err) => {
        if (!active) return;
        setErrorMessage(
          err instanceof Error ? err.message : 'Unable to load project source files.'
        );
      })
      .finally(() => {
        if (active) setIsLoadingFiles(false);
      });

    return () => {
      active = false;
    };
  }, [isOpen, selectedPath]);

  const filteredFiles = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    return files.filter((f) => {
      if (categoryFilter !== 'all' && f.category !== categoryFilter) return false;
      if (q && !f.path.toLowerCase().includes(q)) return false;
      return true;
    });
  }, [files, categoryFilter, searchQuery]);

  const activeFile = useMemo(() => {
    return files.find((f) => f.path === selectedPath) || filteredFiles[0] || null;
  }, [files, filteredFiles, selectedPath]);

  const counts = useMemo(() => {
    return {
      all: files.length,
      android: files.filter((f) => f.category === 'android').length,
      react: files.filter((f) => f.category === 'react').length,
      build: files.filter((f) => f.category === 'build').length,
    };
  }, [files]);

  if (!isOpen) return null;

  const handleDownloadSingleFile = (file: ProjectSourceFile) => {
    const fileName = file.path.split('/').pop() || 'file.txt';
    const blob = new Blob([file.content], { type: 'text/plain;charset=utf-8' });
    triggerBlobDownload(blob, fileName);
    setStatusMessage(\`Downloaded \${file.path} (\${formatBytes(file.sizeBytes)})\`);
    setErrorMessage('');
  };

  const handleCopyFile = async (file: ProjectSourceFile) => {
    try {
      await navigator.clipboard.writeText(file.content);
      setCopiedPath(file.path);
      setStatusMessage(\`Copied \${file.path} to clipboard\`);
      setTimeout(() => setCopiedPath(null), 2000);
    } catch {
      setErrorMessage('Clipboard access was blocked; use Download File instead.');
    }
  };

  const handleDownloadSourceZip = async () => {
    if (files.length === 0 || isBuildingSourceZip) return;
    setIsBuildingSourceZip(true);
    setErrorMessage('');
    setStatusMessage('Preparing ClipKaro React + Android project ZIP...');

    try {
      try {
        const prebuiltRes = await fetch('/ClipKaro-React-Android-Source.zip');
        const contentType = (prebuiltRes.headers.get('content-type') || '').toLowerCase();
        if (prebuiltRes.ok && !contentType.includes('text/html')) {
          const zipBlob = await prebuiltRes.blob();
          triggerBlobDownload(zipBlob, 'ClipKaro-React-Android-Source.zip');
          setStatusMessage(
            \`Downloaded ClipKaro-React-Android-Source.zip (\${formatBytes(
              zipBlob.size
            )}) including all React, Android Gradle/Java, and mipmap app icons.\`
          );
          return;
        }
      } catch {
        // Fall back to in-browser ZIP builder below
      }

      const zipEntries: ZipInputFile[] = files.map((f) => ({
        path: f.path,
        content: f.content,
      }));

      // Include binary game cover images & 512px icon so npm run build works immediately
      for (const imgPath of [...assetPaths, 'icon-512.png']) {
        try {
          const res = await fetch(\`/\${imgPath}\`);
          if (res.ok) {
            const buf = await res.arrayBuffer();
            zipEntries.push({
              path: imgPath === 'icon-512.png' ? 'public/icon-512.png' : imgPath,
              content: new Uint8Array(buf),
            });
          }
        } catch {
          // Skip optional image if offline
        }
      }

      const zipBlob = createZipBlob(zipEntries);
      triggerBlobDownload(zipBlob, 'ClipKaro-React-Android-Source.zip');
      setStatusMessage(
        \`Downloaded ClipKaro-React-Android-Source.zip (\${zipEntries.length} files, \${formatBytes(
          zipBlob.size
        )}). Run npm install to auto-populate FFmpeg WASM.\`
      );
    } catch (err) {
      setErrorMessage(err instanceof Error ? err.message : 'Failed to build ZIP archive.');
    } finally {
      setIsBuildingSourceZip(false);
    }
  };

  const handleDownloadFullBundleZip = async () => {
    if (isDownloadingFullZip) return;
    setIsDownloadingFullZip(true);
    setFullZipProgress(0);
    setErrorMessage('');
    setStatusMessage('Downloading ClipKaro-complete-code.zip with FFmpeg engine...');

    try {
      const res = await fetch('/ClipKaro-complete-code.zip');
      if (!res.ok) {
        throw new Error(\`Server returned HTTP \${res.status}\`);
      }
      const contentType = (res.headers.get('content-type') || '').toLowerCase();
      if (contentType.includes('text/html')) {
        throw new Error('Complete ZIP bundle is not available on server; use Source + Android ZIP.');
      }

      const contentLengthHeader = res.headers.get('content-length');
      const totalBytes = contentLengthHeader ? parseInt(contentLengthHeader, 10) : 0;

      if (!res.body) {
        const blob = await res.blob();
        triggerBlobDownload(blob, 'ClipKaro-complete-code.zip');
        setFullZipProgress(100);
        setStatusMessage(
          \`Downloaded ClipKaro-complete-code.zip (\${formatBytes(blob.size)})\`
        );
        return;
      }

      const reader = res.body.getReader();
      const chunks: Uint8Array[] = [];
      let received = 0;

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        if (value) {
          chunks.push(value);
          received += value.byteLength;
          if (totalBytes > 0) {
            setFullZipProgress(Math.min(99, Math.round((received / totalBytes) * 100)));
          }
        }
      }

      const blob = new Blob(chunks as BlobPart[], { type: 'application/zip' });
      triggerBlobDownload(blob, 'ClipKaro-complete-code.zip');
      setFullZipProgress(100);
      setStatusMessage(
        \`Downloaded ClipKaro-complete-code.zip (\${formatBytes(blob.size)})\`
      );
    } catch (err) {
      setErrorMessage(
        err instanceof Error
          ? \`\${err.message}. Try the instant Source ZIP button instead.\`
          : 'Download failed. Try the instant Source ZIP button instead.'
      );
    } finally {
      setIsDownloadingFullZip(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-3 sm:p-5 backdrop-blur-sm"
      role="dialog"
      aria-modal="true"
      aria-labelledby="export-code-title"
    >
      <div className="flex h-[90vh] w-full max-w-6xl flex-col overflow-hidden rounded-2xl border border-slate-800 bg-[#0E131D] shadow-2xl">
        {/* Header */}
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-800 px-4 py-3.5 sm:px-6">
          <div className="flex items-center gap-3">
            <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-rose-500/15 text-rose-400">
              <FolderArchive className="h-5 w-5" aria-hidden="true" />
            </span>
            <div>
              <h2 id="export-code-title" className="font-display text-lg font-bold text-white">
                ClipKaro React + Android Project Files
              </h2>
              <p className="text-xs text-slate-400">
                Inspect, copy, or download every real source file or export a ready-to-build ZIP for Android APK.
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            aria-label="Close code export"
            className="rounded-lg border border-slate-700 bg-slate-800/80 p-2 text-slate-300 hover:bg-slate-700 hover:text-white"
          >
            <X className="h-4 w-4" aria-hidden="true" />
          </button>
        </div>

        {/* Download Action Banner */}
        <div className="border-b border-slate-800 bg-[#121722] px-4 py-3.5 sm:px-6 space-y-3">
          <div className="flex flex-col gap-2.5 lg:flex-row lg:items-center lg:justify-between">
            <div className="flex flex-wrap items-center gap-2.5">
              <button
                type="button"
                onClick={handleDownloadSourceZip}
                disabled={isBuildingSourceZip || files.length === 0}
                className="inline-flex items-center gap-2 rounded-lg bg-rose-600 px-4 py-2.5 text-sm font-semibold text-white transition-colors hover:bg-rose-500 disabled:opacity-50"
              >
                {isBuildingSourceZip ? (
                  <Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" />
                ) : (
                  <Download className="h-4 w-4" aria-hidden="true" />
                )}
                <span>Download Source + Android ZIP (Recommended)</span>
              </button>

              <button
                type="button"
                onClick={handleDownloadFullBundleZip}
                disabled={isDownloadingFullZip}
                className="inline-flex items-center gap-2 rounded-lg border border-slate-700 bg-[#0B0E14] px-4 py-2.5 text-sm font-semibold text-slate-200 transition-colors hover:border-slate-500 hover:text-white disabled:opacity-50"
              >
                {isDownloadingFullZip ? (
                  <Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" />
                ) : (
                  <FolderArchive className="h-4 w-4 text-amber-400" aria-hidden="true" />
                )}
                <span>
                  {isDownloadingFullZip
                    ? \`Downloading Full ZIP (\${fullZipProgress}%)\`
                    : 'Download Offline Bundle ZIP (with FFmpeg)'}
                </span>
              </button>

              <a
                href="/ClipKaro-React-Android-Source.zip"
                download="ClipKaro-React-Android-Source.zip"
                className="inline-flex items-center gap-1.5 rounded-lg border border-slate-800 px-3 py-2 text-xs font-medium text-slate-300 hover:border-slate-700 hover:text-white"
              >
                <Download className="h-3.5 w-3.5" aria-hidden="true" />
                <span>Direct ZIP Link</span>
              </a>
            </div>

            <div className="flex items-center gap-2 text-xs text-slate-400">
              <Smartphone className="h-4 w-4 text-emerald-400 shrink-0" aria-hidden="true" />
              <span>Includes Gradle 8.7 + SDK 35 + GitHub Mobile APK Workflow</span>
            </div>
          </div>

          {isDownloadingFullZip && (
            <div className="h-1.5 w-full overflow-hidden rounded-full bg-slate-800">
              <div
                className="h-full bg-rose-500 transition-all duration-150"
                style={{ width: \`\${fullZipProgress}%\` }}
              />
            </div>
          )}

          {statusMessage && (
            <div className="rounded-lg border border-emerald-500/30 bg-emerald-950/30 px-3 py-2 text-xs text-emerald-300">
              {statusMessage}
            </div>
          )}

          {errorMessage && (
            <div className="rounded-lg border border-rose-500/40 bg-rose-950/30 px-3 py-2 text-xs text-rose-300">
              {errorMessage}
            </div>
          )}
        </div>

        {/* File Explorer + Code Preview */}
        <div className="grid min-h-0 flex-1 grid-cols-1 lg:grid-cols-12">
          {/* Left File Tree */}
          <div className="flex min-h-0 flex-col border-b border-slate-800 lg:col-span-4 lg:border-b-0 lg:border-r">
            <div className="space-y-2.5 border-b border-slate-800 p-3">
              <div className="relative">
                <Search
                  className="pointer-events-none absolute left-3 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-slate-500"
                  aria-hidden="true"
                />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Filter files (e.g. MainActivity, CutVideo)..."
                  className="w-full rounded-lg border border-slate-800 bg-[#0B0E14] py-1.5 pl-8 pr-3 text-xs text-white placeholder:text-slate-500 focus:border-rose-500 focus:outline-none"
                />
              </div>

              <div className="flex flex-wrap gap-1.5">
                {(
                  [
                    { id: 'all', label: \`All (\${counts.all})\` },
                    { id: 'android', label: \`Android (\${counts.android})\` },
                    { id: 'react', label: \`React (\${counts.react})\` },
                    { id: 'build', label: \`APK Build (\${counts.build})\` },
                  ] as const
                ).map((tab) => (
                  <button
                    key={tab.id}
                    type="button"
                    onClick={() => setCategoryFilter(tab.id)}
                    className={\`rounded-md px-2.5 py-1 text-[11px] font-semibold transition-colors \${
                      categoryFilter === tab.id
                        ? 'bg-rose-600 text-white'
                        : 'bg-[#0B0E14] text-slate-400 hover:text-white'
                    }\`}
                  >
                    {tab.label}
                  </button>
                ))}
              </div>
            </div>

            <div className="min-h-0 flex-1 overflow-y-auto p-2 space-y-1">
              {isLoadingFiles ? (
                <div className="flex items-center justify-center py-10 text-xs text-slate-400">
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" aria-hidden="true" />
                  Loading live workspace files...
                </div>
              ) : filteredFiles.length === 0 ? (
                <div className="py-8 text-center text-xs text-slate-500">
                  No project files match that filter.
                </div>
              ) : (
                filteredFiles.map((file) => {
                  const selected = activeFile?.path === file.path;
                  return (
                    <div
                      key={file.path}
                      className={\`flex items-center justify-between gap-2 rounded-lg px-2.5 py-2 text-left transition-colors \${
                        selected
                          ? 'bg-rose-600/15 text-white border border-rose-500/40'
                          : 'text-slate-300 hover:bg-slate-800/60 border border-transparent'
                      }\`}
                    >
                      <button
                        type="button"
                        onClick={() => setSelectedPath(file.path)}
                        className="flex min-w-0 flex-1 items-center gap-2 text-left"
                      >
                        <FileCode2
                          className={\`h-4 w-4 shrink-0 \${
                            file.category === 'android'
                              ? 'text-emerald-400'
                              : file.category === 'build'
                                ? 'text-amber-400'
                                : 'text-sky-400'
                          }\`}
                          aria-hidden="true"
                        />
                        <div className="min-w-0 flex-1">
                          <div className="truncate font-mono text-[11px] font-medium">
                            {file.path}
                          </div>
                          <div className="text-[10px] text-slate-500">
                            {formatBytes(file.sizeBytes)}
                          </div>
                        </div>
                      </button>

                      <button
                        type="button"
                        onClick={() => handleDownloadSingleFile(file)}
                        title={\`Download \${file.path}\`}
                        aria-label={\`Download \${file.path}\`}
                        className="rounded-md p-1.5 text-slate-400 hover:bg-slate-700 hover:text-white shrink-0"
                      >
                        <Download className="h-3.5 w-3.5" aria-hidden="true" />
                      </button>
                    </div>
                  );
                })
              )}
            </div>
          </div>

          {/* Right Source Code Viewer */}
          <div className="flex min-h-0 flex-col bg-[#090D14] lg:col-span-8">
            {activeFile ? (
              <>
                <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-800 bg-[#111622] px-4 py-2.5">
                  <div className="flex min-w-0 items-center gap-2">
                    <Code2 className="h-4 w-4 text-rose-400 shrink-0" aria-hidden="true" />
                    <span className="truncate font-mono text-xs font-semibold text-slate-200">
                      {activeFile.path}
                    </span>
                    <span className="text-[11px] text-slate-500 shrink-0">
                      ({formatBytes(activeFile.sizeBytes)})
                    </span>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => handleCopyFile(activeFile)}
                      className="inline-flex items-center gap-1.5 rounded-lg border border-slate-700 bg-slate-800 px-3 py-1.5 text-xs font-semibold text-slate-200 hover:bg-slate-700"
                    >
                      {copiedPath === activeFile.path ? (
                        <>
                          <Check className="h-3.5 w-3.5 text-emerald-400" aria-hidden="true" />
                          <span>Copied</span>
                        </>
                      ) : (
                        <>
                          <Copy className="h-3.5 w-3.5" aria-hidden="true" />
                          <span>Copy Code</span>
                        </>
                      )}
                    </button>
                    <button
                      type="button"
                      onClick={() => handleDownloadSingleFile(activeFile)}
                      className="inline-flex items-center gap-1.5 rounded-lg bg-rose-600 px-3 py-1.5 text-xs font-semibold text-white hover:bg-rose-500"
                    >
                      <Download className="h-3.5 w-3.5" aria-hidden="true" />
                      <span>Download File</span>
                    </button>
                  </div>
                </div>

                <pre className="min-h-0 flex-1 overflow-auto p-4 font-mono text-xs leading-relaxed text-slate-200">
                  <code>{activeFile.content}</code>
                </pre>
              </>
            ) : (
              <div className="flex flex-1 items-center justify-center p-6 text-xs text-slate-500">
                Select any React or Android file on the left to inspect or download it.
              </div>
            )}

            {/* Quick Mobile APK Build Footer */}
            <div className="border-t border-slate-800 bg-[#121722] px-4 py-2.5 text-[11px] text-slate-400">
              <span className="font-semibold text-white">Build APK on Mobile:</span> Download & unzip{' '}
              <span className="font-mono text-slate-200">ClipKaro-React-Android-Source.zip</span> → upload folder to a new GitHub repo (include{' '}
              <span className="font-mono text-slate-200">.github</span>,{' '}
              <span className="font-mono text-slate-200">android</span>,{' '}
              <span className="font-mono text-slate-200">src</span>) → open{' '}
              <span className="font-semibold text-slate-200">Actions → Build ClipKaro Android APK</span> → download{' '}
              <span className="font-mono text-emerald-300">app-debug.apk</span>.
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
`,"/src/components/HomeView.tsx":`import { FormEvent, useMemo, useState } from 'react';
import {
  Scissors,
  Mic,
  Music,
  Film,
  Gamepad2,
  ShieldCheck,
  ShieldAlert,
  ExternalLink,
  ArrowRight,
  Download,
  Globe,
  Play,
  PlayCircle,
  Smartphone,
  Star,
  Trophy,
  Flame,
} from 'lucide-react';
import { ClipItem, SocialPlatform, WorkspaceTab } from '../types/clipkaro';
import {
  openUrlInsideNativeWebView,
  shareClipToPlatform,
  ShareTargetPlatform,
} from '../utils/androidPermissions';
import { PLATFORM_PRESETS, parseSocialEmbedUrl } from '../utils/embedUrl';
import { formatSeconds } from '../utils/mediaGenerators';
import {
  calculateViralScore,
  prepareExportVideoBlobWithViralScore,
} from '../utils/viralScore';

import { ExportCodeModal } from './ExportCodeModal';
import { ViralScoreExportDialog } from './ViralScoreExportDialog';

interface HomeViewProps {
  clipCount: number;
  gameCount: number;
  copyrightSafeMode: boolean;
  showViralScoreInApp?: boolean;
  bestClipEntry?: {
    clip: ClipItem;
    reason: string;
    isFromToday: boolean;
  } | null;
  onPlayBestClip?: (clip: ClipItem) => void;
  onToggleCopyrightSafeMode: () => void;
  onToggleShowViralScoreInApp?: () => void;
  onNavigate: (tab: WorkspaceTab) => void;
  onSendLinkToCut: (url: string, platform: SocialPlatform, suggestedStreamer?: string) => void;
}

const PLATFORMS: { id: SocialPlatform; label: string }[] = [
  { id: 'youtube', label: 'YouTube' },
  { id: 'instagram', label: 'Instagram' },
  { id: 'facebook', label: 'Facebook' },
];

export function HomeView({
  clipCount,
  gameCount,
  copyrightSafeMode,
  showViralScoreInApp = true,
  bestClipEntry,
  onPlayBestClip,
  onToggleCopyrightSafeMode,
  onToggleShowViralScoreInApp,
  onNavigate,
  onSendLinkToCut,
}: HomeViewProps) {
  const [activePlatform, setActivePlatform] = useState<SocialPlatform>('youtube');
  const [urlInput, setUrlInput] = useState<string>(PLATFORM_PRESETS[0].url);
  const [loadedUrl, setLoadedUrl] = useState<string>(PLATFORM_PRESETS[0].url);
  const [suggestedStreamer, setSuggestedStreamer] = useState<string>(PLATFORM_PRESETS[0].creator);
  const [exportModalOpen, setExportModalOpen] = useState<boolean>(false);
  const [bestClipShareNotice, setBestClipShareNotice] = useState<string | null>(null);
  const [pendingSharePlatform, setPendingSharePlatform] = useState<ShareTargetPlatform | null>(null);
  const [isExportingBestClip, setIsExportingBestClip] = useState<boolean>(false);

  const handleConfirmBestClipShare = async (includeScoreOnVideo: boolean) => {
    if (!bestClipEntry || !pendingSharePlatform) return;
    setIsExportingBestClip(true);
    try {
      const prepared = await prepareExportVideoBlobWithViralScore(
        bestClipEntry.clip,
        includeScoreOnVideo
      );
      const captionBase = bestClipEntry.clip.autoCaption || 'What a Headshot!';
      const msg = await shareClipToPlatform({
        platform: pendingSharePlatform,
        title: bestClipEntry.clip.title,
        gameTag: bestClipEntry.clip.gameTag,
        autoCaption:
          includeScoreOnVideo && prepared.scoreBadgeText
            ? \`\${captionBase} (\${prepared.scoreBadgeText})\`
            : captionBase,
        videoBlob: prepared.blob,
        videoMimeType: prepared.mimeType,
        nativeUri: prepared.nativeUri,
      });
      setBestClipShareNotice(
        includeScoreOnVideo ? \`\${msg} (With Viral Score)\` : \`\${msg} (Clean Video)\`
      );
      setPendingSharePlatform(null);
    } finally {
      setIsExportingBestClip(false);
    }
  };

  const parsedEmbed = useMemo(
    () => parseSocialEmbedUrl(loadedUrl, activePlatform),
    [loadedUrl, activePlatform]
  );

  const handlePlatformSwitch = (platform: SocialPlatform) => {
    setActivePlatform(platform);
    const firstPreset = PLATFORM_PRESETS.find((p) => p.platform === platform);
    if (firstPreset) {
      setUrlInput(firstPreset.url);
      setLoadedUrl(firstPreset.url);
      setSuggestedStreamer(firstPreset.creator);
    }
  };

  const getNativePackageForPlatform = (plat: SocialPlatform): string => {
    switch (plat) {
      case 'youtube':
        return 'com.google.android.youtube';
      case 'instagram':
        return 'com.instagram.android';
      case 'facebook':
        return 'com.facebook.katana';
    }
  };

  const handleOpenInside = (e: FormEvent) => {
    e.preventDefault();
    if (!urlInput.trim()) return;
    const trimmed = urlInput.trim();
    const normalized = /^https?:\\/\\//i.test(trimmed) ? trimmed : \`https://\${trimmed}\`;
    const result = parseSocialEmbedUrl(normalized, activePlatform);
    setActivePlatform(result.platform);
    setLoadedUrl(normalized);
    setSuggestedStreamer('');

    const platformLabel =
      result.platform === 'youtube'
        ? 'YouTube'
        : result.platform === 'instagram'
          ? 'Instagram'
          : 'Facebook';
    openUrlInsideNativeWebView(
      normalized,
      platformLabel,
      getNativePackageForPlatform(result.platform)
    );
  };

  const handleSelectPreset = (url: string, platform: SocialPlatform, creator: string) => {
    setActivePlatform(platform);
    setUrlInput(url);
    setLoadedUrl(url);
    setSuggestedStreamer(creator);
  };

  const platformPresets = PLATFORM_PRESETS.filter((p) => p.platform === activePlatform);

  return (
    <div className="space-y-8">
      {/* Page Intro & Workspace Summary */}
      <section className="flex flex-col gap-3 lg:flex-row lg:items-end lg:justify-between">
        <div className="space-y-1.5">
          <h1 className="font-display text-2xl font-bold tracking-tight text-white sm:text-3xl text-balance">
            ClipKaro Creator Studio
          </h1>
          <p className="max-w-2xl text-sm text-slate-400">
            Open YouTube, Instagram, or Facebook videos inside your workspace, trim 10 to 60 second permission clips with streamer credit, and mix voiceovers or copyright-safe music.
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-3 text-xs text-slate-400 tabular-nums">
          <span>{clipCount} clips saved</span>
          <span aria-hidden="true">·</span>
          <span>{gameCount} games tracked</span>
          <span aria-hidden="true">·</span>
          <span className={copyrightSafeMode ? 'text-emerald-400 font-medium' : 'text-amber-400 font-medium'}>
            Copyright-Safe Mode {copyrightSafeMode ? 'ON' : 'OFF'}
          </span>
          <span aria-hidden="true">·</span>
          <button
            type="button"
            onClick={() => setExportModalOpen(true)}
            className="inline-flex items-center gap-1.5 rounded-lg border border-rose-500/40 bg-rose-500/10 px-2.5 py-1 font-semibold text-rose-300 transition-colors hover:bg-rose-500/20 hover:text-white whitespace-nowrap"
          >
            <Download className="h-3.5 w-3.5" aria-hidden="true" />
            <span>Download React + Android Code</span>
          </button>
        </div>
      </section>

      {/* Today's Best Clip Card */}
      {bestClipEntry && (
        <section
          aria-labelledby="todays-best-clip-heading"
          className="rounded-xl border border-amber-500/40 bg-gradient-to-br from-[#161C2A] to-[#121722] p-4 sm:p-5 space-y-3"
        >
          <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
            <div className="flex items-center gap-3.5 min-w-0">
              <button
                type="button"
                onClick={() => onPlayBestClip?.(bestClipEntry.clip)}
                className="group relative h-20 w-32 shrink-0 overflow-hidden rounded-lg border border-amber-500/40 bg-[#07090D]"
                aria-label={\`Play \${bestClipEntry.clip.title}\`}
              >
                {bestClipEntry.clip.thumbnailDataUrl ? (
                  <img
                    src={bestClipEntry.clip.thumbnailDataUrl}
                    alt={bestClipEntry.clip.title}
                    className="h-full w-full object-cover"
                    referrerPolicy="no-referrer"
                  />
                ) : (
                  <div className="flex h-full w-full items-center justify-center bg-slate-900">
                    <Film className="h-6 w-6 text-slate-600" aria-hidden="true" />
                  </div>
                )}
                <div className="absolute inset-0 flex items-center justify-center bg-black/35 group-hover:bg-black/50 transition-colors">
                  <span className="flex h-8 w-8 items-center justify-center rounded-full bg-rose-600 text-white shadow-lg">
                    <Play className="h-4 w-4 fill-current ml-0.5" aria-hidden="true" />
                  </span>
                </div>
                <span className="absolute bottom-1 right-1.5 font-mono text-[10px] font-bold text-white bg-black/75 px-1 rounded tabular-nums">
                  {formatSeconds(bestClipEntry.clip.durationSec)}
                </span>
              </button>

              <div className="min-w-0 space-y-1">
                <div className="flex flex-wrap items-center gap-2 text-xs font-bold text-amber-300">
                  <Trophy className="h-3.5 w-3.5 shrink-0" aria-hidden="true" />
                  <h2 id="todays-best-clip-heading" className="uppercase tracking-wider">
                    {bestClipEntry.isFromToday ? "Today's Best Clip" : 'Top Best Clip'}
                  </h2>
                  <span className="text-slate-400 font-semibold">· {bestClipEntry.reason}</span>
                </div>
                <div className="font-display text-base font-bold text-white truncate">
                  {bestClipEntry.clip.title}
                </div>
                <div className="flex flex-wrap items-center gap-2 text-xs text-slate-400 tabular-nums">
                  <span>{bestClipEntry.clip.gameTag}</span>
                  <span aria-hidden="true">·</span>
                  <span>{bestClipEntry.clip.durationSec} sec</span>
                  {bestClipEntry.clip.isFavourite && (
                    <>
                      <span aria-hidden="true">·</span>
                      <span className="inline-flex items-center gap-1 text-amber-300 font-semibold">
                        <Star className="h-3 w-3 fill-current" aria-hidden="true" />
                        <span>Favourite</span>
                      </span>
                    </>
                  )}
                </div>
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-1.5 shrink-0">
              <button
                type="button"
                onClick={() => onPlayBestClip?.(bestClipEntry.clip)}
                className="inline-flex items-center gap-1.5 rounded-lg bg-rose-600 px-3.5 py-2 text-xs font-bold text-white hover:bg-rose-500"
              >
                <Play className="h-3.5 w-3.5 fill-current" aria-hidden="true" />
                <span>Play</span>
              </button>
              <button
                type="button"
                onClick={() => setPendingSharePlatform('youtube')}
                className="rounded-lg bg-red-600/90 px-2.5 py-2 text-[11px] font-bold text-white hover:bg-red-500"
              >
                YT Shorts
              </button>
              <button
                type="button"
                onClick={() => setPendingSharePlatform('instagram')}
                className="rounded-lg bg-fuchsia-600/90 px-2.5 py-2 text-[11px] font-bold text-white hover:bg-fuchsia-500"
              >
                Reels
              </button>
              <button
                type="button"
                onClick={() => setPendingSharePlatform('whatsapp')}
                className="rounded-lg bg-emerald-600/90 px-2.5 py-2 text-[11px] font-bold text-white hover:bg-emerald-500"
              >
                WhatsApp
              </button>
            </div>
          </div>
          {bestClipShareNotice && (
            <div className="text-xs font-semibold text-emerald-300">{bestClipShareNotice}</div>
          )}
        </section>
      )}

      {/* Quick Actions Grid */}
      <section aria-labelledby="quick-actions-heading" className="space-y-3">
        <div className="flex items-center justify-between">
          <h2 id="quick-actions-heading" className="font-display text-base font-semibold text-slate-200">
            Quick Actions
          </h2>
        </div>

        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-6">
          <button
            type="button"
            onClick={() => onNavigate('cut')}
            className="group flex flex-col items-start justify-between gap-3 rounded-xl border border-slate-800 bg-[#121722] p-4 text-left transition-colors hover:border-rose-500/60 hover:bg-[#171E2C] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-rose-500"
          >
            <span className="flex h-10 w-10 items-center justify-center rounded-lg bg-rose-500/15 text-rose-400">
              <Scissors className="h-5 w-5" aria-hidden="true" />
            </span>
            <div>
              <div className="font-display text-sm font-semibold text-white whitespace-nowrap">
                Cut Video
              </div>
              <div className="mt-0.5 text-xs text-slate-400">10–60s permission trim</div>
            </div>
          </button>

          <button
            type="button"
            onClick={() => onNavigate('voice')}
            className="group flex flex-col items-start justify-between gap-3 rounded-xl border border-slate-800 bg-[#121722] p-4 text-left transition-colors hover:border-slate-600 hover:bg-[#171E2C] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-rose-500"
          >
            <span className="flex h-10 w-10 items-center justify-center rounded-lg bg-sky-500/15 text-sky-400">
              <Mic className="h-5 w-5" aria-hidden="true" />
            </span>
            <div>
              <div className="font-display text-sm font-semibold text-white whitespace-nowrap">
                Add Voice
              </div>
              <div className="mt-0.5 text-xs text-slate-400">Mic or audio upload</div>
            </div>
          </button>

          <button
            type="button"
            onClick={() => onNavigate('music')}
            className="group flex flex-col items-start justify-between gap-3 rounded-xl border border-slate-800 bg-[#121722] p-4 text-left transition-colors hover:border-slate-600 hover:bg-[#171E2C] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-rose-500"
          >
            <span className="flex h-10 w-10 items-center justify-center rounded-lg bg-amber-500/15 text-amber-400">
              <Music className="h-5 w-5" aria-hidden="true" />
            </span>
            <div>
              <div className="font-display text-sm font-semibold text-white whitespace-nowrap">
                Add Music
              </div>
              <div className="mt-0.5 text-xs text-slate-400">Royalty-free backing</div>
            </div>
          </button>

          <button
            type="button"
            onClick={() => onNavigate('clips')}
            className="group flex flex-col items-start justify-between gap-3 rounded-xl border border-slate-800 bg-[#121722] p-4 text-left transition-colors hover:border-slate-600 hover:bg-[#171E2C] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-rose-500"
          >
            <span className="flex h-10 w-10 items-center justify-center rounded-lg bg-indigo-500/15 text-indigo-400">
              <Film className="h-5 w-5" aria-hidden="true" />
            </span>
            <div>
              <div className="font-display text-sm font-semibold text-white whitespace-nowrap">
                My Clips
              </div>
              <div className="mt-0.5 text-xs text-slate-400 tabular-nums">
                {clipCount} {clipCount === 1 ? 'clip' : 'clips'} saved
              </div>
            </div>
          </button>

          <button
            type="button"
            onClick={() => onNavigate('games')}
            className="group flex flex-col items-start justify-between gap-3 rounded-xl border border-slate-800 bg-[#121722] p-4 text-left transition-colors hover:border-slate-600 hover:bg-[#171E2C] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-rose-500"
          >
            <span className="flex h-10 w-10 items-center justify-center rounded-lg bg-violet-500/15 text-violet-400">
              <Gamepad2 className="h-5 w-5" aria-hidden="true" />
            </span>
            <div>
              <div className="font-display text-sm font-semibold text-white whitespace-nowrap">
                My Games
              </div>
              <div className="mt-0.5 text-xs text-slate-400 tabular-nums">
                {gameCount} titles & mini-game
              </div>
            </div>
          </button>

          <button
            type="button"
            onClick={() => onNavigate('apps')}
            className="group flex flex-col items-start justify-between gap-3 rounded-xl border border-rose-500/40 bg-[#121722] p-4 text-left transition-colors hover:border-rose-500 hover:bg-[#171E2C] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-rose-500"
          >
            <span className="flex h-10 w-10 items-center justify-center rounded-lg bg-rose-500/15 text-rose-400">
              <Smartphone className="h-5 w-5" aria-hidden="true" />
            </span>
            <div>
              <div className="font-display text-sm font-semibold text-white whitespace-nowrap">
                My Apps
              </div>
              <div className="mt-0.5 text-xs text-slate-400">YT, IG, FB, WA + BGMI</div>
            </div>
          </button>

          <button
            type="button"
            role="switch"
            aria-checked={copyrightSafeMode}
            onClick={onToggleCopyrightSafeMode}
            className={\`flex flex-col items-start justify-between gap-3 rounded-xl border p-4 text-left transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-rose-500 sm:col-span-3 lg:col-span-3 \${
              copyrightSafeMode
                ? 'border-emerald-500/40 bg-emerald-950/25 hover:bg-emerald-950/35'
                : 'border-amber-500/40 bg-amber-950/20 hover:bg-amber-950/30'
            }\`}
          >
            <div className="flex w-full items-center justify-between gap-3">
              <div className="flex items-center gap-3">
                <span
                  className={\`flex h-9 w-9 items-center justify-center rounded-lg \${
                    copyrightSafeMode
                      ? 'bg-emerald-500/20 text-emerald-400'
                      : 'bg-amber-500/20 text-amber-400'
                  }\`}
                >
                  {copyrightSafeMode ? (
                    <ShieldCheck className="h-5 w-5" aria-hidden="true" />
                  ) : (
                    <ShieldAlert className="h-5 w-5" aria-hidden="true" />
                  )}
                </span>
                <div>
                  <div className="font-display text-sm font-semibold text-white">
                    Copyright-Safe Mode {copyrightSafeMode ? 'ON' : 'OFF'}
                  </div>
                  <div className="text-xs text-slate-300">
                    {copyrightSafeMode ? 'Attribution & safe audio active' : 'Tap to re-enable safety'}
                  </div>
                </div>
              </div>
              <span className="text-xs font-bold uppercase tracking-wider text-slate-300">
                {copyrightSafeMode ? 'Enabled' : 'Disabled'}
              </span>
            </div>
          </button>

          {onToggleShowViralScoreInApp && (
            <button
              type="button"
              role="switch"
              aria-checked={showViralScoreInApp}
              onClick={onToggleShowViralScoreInApp}
              className={\`flex flex-col items-start justify-between gap-3 rounded-xl border p-4 text-left transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-amber-500 sm:col-span-3 lg:col-span-3 \${
                showViralScoreInApp
                  ? 'border-amber-500/40 bg-amber-950/20 hover:bg-amber-950/30'
                  : 'border-slate-700 bg-[#121722] hover:border-slate-500'
              }\`}
            >
              <div className="flex w-full items-center justify-between gap-3">
                <div className="flex items-center gap-3">
                  <span
                    className={\`flex h-9 w-9 items-center justify-center rounded-lg \${
                      showViralScoreInApp
                        ? 'bg-amber-500/20 text-amber-400'
                        : 'bg-slate-800 text-slate-400'
                    }\`}
                  >
                    <Flame className="h-5 w-5" aria-hidden="true" />
                  </span>
                  <div>
                    <div className="font-display text-sm font-semibold text-white">
                      Show Viral Score in App · {showViralScoreInApp ? 'ON' : 'OFF'}
                    </div>
                    <div className="text-xs text-slate-300">
                      {showViralScoreInApp
                        ? 'Visible in My Clips only (clean exports by default)'
                        : 'Hidden in My Clips & export stays clean'}
                    </div>
                  </div>
                </div>
                <span className="text-xs font-bold uppercase tracking-wider text-slate-300">
                  {showViralScoreInApp ? 'ON' : 'OFF'}
                </span>
              </div>
            </button>
          )}
        </div>
      </section>

      {/* Open Inside Viewer */}
      <section
        aria-labelledby="open-inside-heading"
        className="rounded-xl border border-slate-800 bg-[#121722] p-5 sm:p-6 space-y-5"
      >
        <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
          <div>
            <h2 id="open-inside-heading" className="font-display text-lg font-bold text-white">
              Open Inside Viewer
            </h2>
            <p className="mt-0.5 text-sm text-slate-400">
              Preview YouTube, Instagram, or Facebook links directly inside ClipKaro before cutting.
            </p>
          </div>

          {/* Platform Switcher */}
          <div
            role="tablist"
            aria-label="Social Platform"
            className="inline-flex items-center gap-1 rounded-lg border border-slate-800 bg-[#0B0E14] p-1 self-start"
          >
            {PLATFORMS.map((plat) => {
              const selected = activePlatform === plat.id;
              return (
                <button
                  key={plat.id}
                  type="button"
                  role="tab"
                  aria-selected={selected}
                  onClick={() => handlePlatformSwitch(plat.id)}
                  className={\`rounded-md px-4 py-1.5 text-xs font-semibold transition-colors whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-rose-500 \${
                    selected
                      ? 'bg-rose-600 text-white'
                      : 'text-slate-400 hover:text-slate-100'
                  }\`}
                >
                  {plat.label}
                </button>
              );
            })}
          </div>
        </div>

        {/* URL Input + Action Controls */}
        <form onSubmit={handleOpenInside} className="flex flex-col gap-3 sm:flex-row">
          <div className="relative flex-1">
            <Globe
              className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-500"
              aria-hidden="true"
            />
            <input
              type="url"
              value={urlInput}
              onChange={(e) => setUrlInput(e.target.value)}
              placeholder={\`Paste \${
                activePlatform === 'youtube'
                  ? 'YouTube watch, Shorts, or live'
                  : activePlatform === 'instagram'
                    ? 'Instagram Reel or Post'
                    : 'Facebook Video'
              } URL...\`}
              aria-label="Video URL to open inside viewer"
              className="w-full rounded-lg border border-slate-700/80 bg-[#0B0E14] py-2.5 pl-10 pr-4 text-sm text-white placeholder:text-slate-500 focus:border-rose-500 focus:outline-none"
            />
          </div>
          <div className="flex items-center gap-2.5 shrink-0">
            <button
              type="submit"
              className="inline-flex items-center gap-2 rounded-lg border border-slate-700 bg-slate-800 px-4 py-2.5 text-sm font-semibold text-white transition-colors hover:bg-slate-700 whitespace-nowrap shrink-0"
            >
              <PlayCircle className="h-4 w-4" aria-hidden="true" />
              <span>Open Inside</span>
            </button>
            <button
              type="button"
              onClick={() =>
                onSendLinkToCut(
                  parsedEmbed.originalUrl || urlInput,
                  parsedEmbed.platform,
                  suggestedStreamer
                )
              }
              className="inline-flex items-center gap-2 rounded-lg bg-rose-600 px-4 py-2.5 text-sm font-semibold text-white transition-colors hover:bg-rose-500 whitespace-nowrap shrink-0"
            >
              <span>Cut This Link</span>
              <ArrowRight className="h-4 w-4" aria-hidden="true" />
            </button>
          </div>
        </form>

        {/* Quick Presets for Active Platform */}
        <div className="flex flex-wrap items-center gap-2 text-xs">
          <span className="text-slate-400">Quick examples:</span>
          {platformPresets.map((preset) => (
            <button
              key={preset.id}
              type="button"
              onClick={() => handleSelectPreset(preset.url, preset.platform, preset.creator)}
              className={\`rounded-md border px-2.5 py-1 transition-colors whitespace-nowrap shrink-0 \${
                loadedUrl === preset.url
                  ? 'border-rose-500/60 bg-rose-500/10 text-rose-300'
                  : 'border-slate-800 bg-[#0B0E14] text-slate-300 hover:border-slate-700 hover:text-white'
              }\`}
            >
              {preset.label}
            </button>
          ))}
        </div>

        {/* Viewer Frame */}
        <div className="overflow-hidden rounded-xl border border-slate-800 bg-[#07090D]">
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-800/80 px-4 py-2.5 text-xs text-slate-400">
            <div className="flex items-center gap-2 truncate">
              <span className="font-semibold text-slate-200 capitalize">{parsedEmbed.platform}</span>
              <span aria-hidden="true">·</span>
              <span className="truncate">{parsedEmbed.displayLabel}</span>
            </div>
            {parsedEmbed.originalUrl && (
              <a
                href={parsedEmbed.originalUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1.5 text-slate-300 hover:text-white whitespace-nowrap shrink-0"
              >
                <span>Open source link</span>
                <ExternalLink className="h-3.5 w-3.5" aria-hidden="true" />
              </a>
            )}
          </div>

          {parsedEmbed.embedUrl ? (
            <div className="relative aspect-video w-full bg-black">
              <iframe
                key={parsedEmbed.embedUrl}
                src={parsedEmbed.embedUrl}
                title={parsedEmbed.displayLabel}
                className="h-full w-full border-0"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                allowFullScreen
                referrerPolicy="strict-origin-when-cross-origin"
              />
            </div>
          ) : (
            <div className="flex aspect-video w-full flex-col items-center justify-center gap-3 p-6 text-center">
              <Globe className="h-9 w-9 text-slate-400" aria-hidden="true" />
              <div className="max-w-md space-y-1">
                <p className="text-sm font-medium text-slate-200">{parsedEmbed.displayLabel}</p>
                <p className="text-xs text-slate-400">
                  {parsedEmbed.hint ||
                    'Open directly inside ClipKaro WebView, native app, or browser — never a blank screen.'}
                </p>
              </div>
              <div className="flex flex-wrap items-center justify-center gap-2.5 pt-1">
                {parsedEmbed.originalUrl && (
                  <>
                    <button
                      type="button"
                      onClick={() => {
                        const platformLabel =
                          parsedEmbed.platform === 'youtube'
                            ? 'YouTube'
                            : parsedEmbed.platform === 'instagram'
                              ? 'Instagram'
                              : 'Facebook';
                        const handled = openUrlInsideNativeWebView(
                          parsedEmbed.originalUrl,
                          platformLabel,
                          getNativePackageForPlatform(parsedEmbed.platform)
                        );
                        if (!handled) {
                          window.location.href = parsedEmbed.originalUrl;
                        }
                      }}
                      className="inline-flex items-center gap-1.5 rounded-lg bg-rose-600 px-4 py-2 text-xs font-bold text-white hover:bg-rose-500"
                    >
                      <PlayCircle className="h-3.5 w-3.5" aria-hidden="true" />
                      <span>Open in App / WebView</span>
                    </button>
                    <a
                      href={parsedEmbed.originalUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1.5 rounded-lg border border-slate-700 bg-slate-800 px-4 py-2 text-xs font-semibold text-white hover:bg-slate-700"
                    >
                      <ExternalLink className="h-3.5 w-3.5" aria-hidden="true" />
                      <span>Open in Browser</span>
                    </a>
                  </>
                )}
                <button
                  type="button"
                  onClick={() => onNavigate('cut')}
                  className="rounded-lg border border-slate-700 bg-[#0B0E14] px-4 py-2 text-xs font-semibold text-slate-200 hover:text-white"
                >
                  Upload or Cut Video
                </button>
              </div>
            </div>
          )}

          <div className="flex flex-wrap items-center justify-between gap-2 border-t border-slate-800/80 bg-[#0B0E14] px-4 py-2.5 text-xs text-slate-400">
            <span className="truncate">
              {parsedEmbed.hint ||
                'If embed is blocked by X-Frame-Options, tap Open in App / Browser to view immediately.'}
            </span>
            {parsedEmbed.originalUrl && (
              <div className="flex items-center gap-2 shrink-0">
                <button
                  type="button"
                  onClick={() => {
                    const platformLabel =
                      parsedEmbed.platform === 'youtube'
                        ? 'YouTube'
                        : parsedEmbed.platform === 'instagram'
                          ? 'Instagram'
                          : 'Facebook';
                    const handled = openUrlInsideNativeWebView(
                      parsedEmbed.originalUrl,
                      platformLabel,
                      getNativePackageForPlatform(parsedEmbed.platform)
                    );
                    if (!handled) {
                      const a = document.createElement('a');
                      a.href = parsedEmbed.originalUrl;
                      a.target = '_blank';
                      a.rel = 'noopener noreferrer';
                      a.click();
                    }
                  }}
                  className="rounded bg-slate-800 px-2.5 py-1 font-semibold text-slate-200 hover:bg-slate-700 hover:text-white"
                >
                  Open in WebView / App
                </button>
              </div>
            )}
          </div>
        </div>
      </section>

      <ExportCodeModal isOpen={exportModalOpen} onClose={() => setExportModalOpen(false)} />

      {bestClipEntry && (
        <ViralScoreExportDialog
          isOpen={Boolean(pendingSharePlatform)}
          actionLabel={\`sharing to \${
            pendingSharePlatform === 'youtube'
              ? 'YouTube Shorts'
              : pendingSharePlatform === 'instagram'
                ? 'Instagram Reels'
                : 'WhatsApp'
          }\`}
          viralScore={calculateViralScore(bestClipEntry.clip).score}
          isProcessing={isExportingBestClip}
          onChoose={(includeScore) => void handleConfirmBestClipShare(includeScore)}
          onCancel={() => setPendingSharePlatform(null)}
        />
      )}
    </div>
  );
}
`,"/src/components/InGameFloatingButton.tsx":`import { PointerEvent as ReactPointerEvent, useEffect, useRef, useState } from 'react';
import {
  Bell,
  Camera,
  CheckCircle2,
  Mic,
  Move,
  Pause,
  Play,
  Repeat,
  Scissors,
  Square,
  Video,
  X,
  Zap,
} from 'lucide-react';
import { AudioSourceMode, ClipItem, VoiceChangerPreset } from '../types/clipkaro';
import { saveVideoToNativeClipKaroFolder } from '../utils/androidPermissions';
import { formatSeconds } from '../utils/mediaGenerators';

interface InGameFloatingButtonProps {
  visible: boolean;
  activeGameName: string;
  isWebPreviewDemo: boolean;
  facecamEnabled?: boolean;
  voiceChanger?: VoiceChangerPreset;
  reactionMode?: boolean;
  onUpdateReactionOptions?: (partial: {
    reactionMode?: boolean;
    facecamEnabled?: boolean;
    voiceChanger?: VoiceChangerPreset;
  }) => void;
  onSaveClip: (clip: ClipItem) => Promise<void>;
  onNavigateToClips: () => void;
  onClose?: () => void;
}

const CLIP_DURATIONS = [10, 20, 30, 40, 50, 60] as const;

const AUDIO_LABELS: Record<AudioSourceMode, string> = {
  game: 'Game/Video Only',
  mic: 'Mic Only',
  both: 'Game+Mic Both',
};

const VOICE_ORDER: VoiceChangerPreset[] = ['normal', 'funny', 'robot', 'deep'];

export function InGameFloatingButton({
  visible,
  activeGameName,
  isWebPreviewDemo,
  facecamEnabled = false,
  voiceChanger = 'normal',
  reactionMode = false,
  onUpdateReactionOptions,
  onSaveClip,
  onNavigateToClips,
  onClose,
}: InGameFloatingButtonProps) {
  const [position, setPosition] = useState<{ x: number; y: number }>(() => {
    if (typeof window === 'undefined') return { x: 24, y: 120 };
    return {
      x: Math.max(16, window.innerWidth - 76),
      y: Math.max(88, window.innerHeight - 132),
    };
  });

  const [menuOpen, setMenuOpen] = useState<boolean>(false);
  const [longPressMenuOpen, setLongPressMenuOpen] = useState<boolean>(false);
  const [isRecording, setIsRecording] = useState<boolean>(false);
  const [recordingModeLabel, setRecordingModeLabel] = useState<string>('');
  const [targetSeconds, setTargetSeconds] = useState<number | null>(null);
  const [elapsedSeconds, setElapsedSeconds] = useState<number>(0);
  const [audioMode, setAudioMode] = useState<AudioSourceMode>('both');
  const [autoContinuous, setAutoContinuous] = useState<boolean>(true);
  const [clipSequence, setClipSequence] = useState<number>(1);
  const [notifBarEnabled, setNotifBarEnabled] = useState<boolean>(false);
  const [autoHighlight, setAutoHighlight] = useState<boolean>(() => {
    try {
      const saved = localStorage.getItem('clipkaro_auto_highlight_enabled');
      return saved === null ? true : saved === 'true';
    } catch {
      return true;
    }
  });
  const [savedToast, setSavedToast] = useState<string | null>(null);
  const [isPaused, setIsPaused] = useState<boolean>(false);
  const [topBanner, setTopBanner] = useState<{
    title: string;
    subtitle: string;
    isRedDot: boolean;
  } | null>(null);

  // Draggable & resizable 120dp circular Facecam window state
  const [facecamSizePx, setFacecamSizePx] = useState<number>(120);
  const [facecamPos, setFacecamPos] = useState<{ x: number; y: number }>(() => {
    if (typeof window === 'undefined') return { x: 20, y: 84 };
    return { x: Math.max(16, window.innerWidth - 144), y: 84 };
  });
  const [facecamLive, setFacecamLive] = useState<boolean>(false);
  const facecamVideoRef = useRef<HTMLVideoElement | null>(null);
  const facecamDragRef = useRef<{
    pointerId: number;
    startX: number;
    startY: number;
    originX: number;
    originY: number;
  } | null>(null);

  const buttonRef = useRef<HTMLButtonElement | null>(null);
  const rootRef = useRef<HTMLDivElement | null>(null);
  const longPressTimerRef = useRef<number | null>(null);
  const dragStateRef = useRef<{
    dragging: boolean;
    pointerId: number;
    startX: number;
    startY: number;
    originX: number;
    originY: number;
    moved: boolean;
    longPressed: boolean;
  } | null>(null);

  // Recording Refs
  const recorderRef = useRef<MediaRecorder | null>(null);
  const chunksRef = useRef<BlobPart[]>([]);
  const activeStreamsRef = useRef<MediaStream[]>([]);
  const audioCtxRef = useRef<AudioContext | null>(null);
  const timerRef = useRef<number | null>(null);
  const topBannerTimerRef = useRef<number | null>(null);
  const canvasRafRef = useRef<number>(0);
  const startedAtRef = useRef<number>(0);
  const pauseStartedAtRef = useRef<number>(0);
  const pausedTotalMsRef = useRef<number>(0);
  const isPausedRef = useRef<boolean>(false);
  const activeTargetSecRef = useRef<number | null>(null);
  const activeLabelRef = useRef<string>('');
  const activeGameRef = useRef<string>(activeGameName);
  const audioModeRef = useRef<AudioSourceMode>('both');
  const autoContinuousRef = useRef<boolean>(true);
  const manualStopRequestedRef = useRef<boolean>(false);
  const clipSeqRef = useRef<number>(1);
  const thumbnailRef = useRef<string | undefined>(undefined);
  const autoHighlightRef = useRef<boolean>(autoHighlight);
  const autoHighlightSavedForSessionRef = useRef<boolean>(false);
  const [facecamManualOff, setFacecamManualOff] = useState<boolean>(() => {
    try {
      return localStorage.getItem('clipkaro_facecam_manual_off') === 'true';
    } catch {
      return false;
    }
  });
  const isFacecamToggleOn = !facecamManualOff && (facecamEnabled || reactionMode);
  const isRecordingRef = useRef<boolean>(false);
  const facecamActiveRef = useRef<boolean>(isFacecamToggleOn);
  const voiceChangerRef = useRef<VoiceChangerPreset>(voiceChanger);
  const reactionModeRef = useRef<boolean>(reactionMode);
  const facecamSizeRef = useRef<number>(facecamSizePx);

  useEffect(() => {
    activeGameRef.current = activeGameName;
  }, [activeGameName]);

  useEffect(() => {
    audioModeRef.current = audioMode;
  }, [audioMode]);

  useEffect(() => {
    autoContinuousRef.current = autoContinuous;
  }, [autoContinuous]);

  useEffect(() => {
    isRecordingRef.current = isRecording;
  }, [isRecording]);

  useEffect(() => {
    if (facecamEnabled) {
      setFacecamManualOff(false);
      try {
        localStorage.setItem('clipkaro_facecam_manual_off', 'false');
      } catch {
        // ignore
      }
    }
  }, [facecamEnabled]);

  useEffect(() => {
    facecamActiveRef.current = isRecording && isFacecamToggleOn;
  }, [isRecording, isFacecamToggleOn]);

  useEffect(() => {
    voiceChangerRef.current = voiceChanger;
  }, [voiceChanger]);

  useEffect(() => {
    reactionModeRef.current = reactionMode;
  }, [reactionMode]);

  useEffect(() => {
    facecamSizeRef.current = facecamSizePx;
  }, [facecamSizePx]);

  // Open Facecam ONLY when Recording is active AND (Facecam toggle is ON OR Reaction Mode is ON)
  useEffect(() => {
    const showCam = visible && isRecording && isFacecamToggleOn;
    if (!showCam) {
      setFacecamLive(false);
      if (facecamVideoRef.current) {
        facecamVideoRef.current.srcObject = null;
      }
      return;
    }
    let camStream: MediaStream | null = null;
    let cancelled = false;
    if (navigator.mediaDevices?.getUserMedia) {
      navigator.mediaDevices
        .getUserMedia({ video: { facingMode: 'user', width: 320, height: 320 }, audio: false })
        .then((stream) => {
          if (cancelled) {
            stream.getTracks().forEach((t) => t.stop());
            return;
          }
          camStream = stream;
          if (facecamVideoRef.current) {
            facecamVideoRef.current.srcObject = stream;
            facecamVideoRef.current.play().catch(() => undefined);
            setFacecamLive(true);
          }
        })
        .catch(() => setFacecamLive(false));
    }
    return () => {
      cancelled = true;
      camStream?.getTracks().forEach((t) => t.stop());
    };
  }, [visible, isRecording, isFacecamToggleOn]);

  useEffect(() => {
    autoHighlightRef.current = autoHighlight;
    try {
      localStorage.setItem('clipkaro_auto_highlight_enabled', String(autoHighlight));
    } catch {
      // ignore storage errors
    }
  }, [autoHighlight]);

  // Keep 32dp button inside viewport on resize
  useEffect(() => {
    const handleResize = () => {
      setPosition((prev) => ({
        x: Math.min(Math.max(12, prev.x), Math.max(12, window.innerWidth - 48)),
        y: Math.min(Math.max(12, prev.y), Math.max(12, window.innerHeight - 48)),
      }));
    };
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  // Auto-collapse when tapping outside the expanded menu or long-press popup
  useEffect(() => {
    if (!menuOpen && !longPressMenuOpen) return;
    const handleOutsideTap = (e: PointerEvent) => {
      if (rootRef.current && !rootRef.current.contains(e.target as Node)) {
        setMenuOpen(false);
        setLongPressMenuOpen(false);
      }
    };
    document.addEventListener('pointerdown', handleOutsideTap);
    return () => document.removeEventListener('pointerdown', handleOutsideTap);
  }, [menuOpen, longPressMenuOpen]);

  // Cleanup active recording resources on unmount
  useEffect(() => {
    return () => {
      manualStopRequestedRef.current = true;
      if (longPressTimerRef.current) window.clearTimeout(longPressTimerRef.current);
      if (timerRef.current) window.clearInterval(timerRef.current);
      if (topBannerTimerRef.current) window.clearTimeout(topBannerTimerRef.current);
      cancelAnimationFrame(canvasRafRef.current);
      activeStreamsRef.current.forEach((s) => s.getTracks().forEach((t) => t.stop()));
      audioCtxRef.current?.close().catch(() => undefined);
    };
  }, []);

  const showTopPopupNotification = (title: string, subtitle: string, isRedDot = true) => {
    if (topBannerTimerRef.current) {
      window.clearTimeout(topBannerTimerRef.current);
      topBannerTimerRef.current = null;
    }
    setTopBanner({ title, subtitle, isRedDot });
    topBannerTimerRef.current = window.setTimeout(() => {
      setTopBanner(null);
      topBannerTimerRef.current = null;
    }, 2000);
  };

  const clearLongPressTimer = () => {
    if (longPressTimerRef.current) {
      window.clearTimeout(longPressTimerRef.current);
      longPressTimerRef.current = null;
    }
  };

  const handlePointerDown = (e: ReactPointerEvent<HTMLButtonElement>) => {
    e.currentTarget.setPointerCapture(e.pointerId);
    clearLongPressTimer();
    const state = {
      dragging: true,
      pointerId: e.pointerId,
      startX: e.clientX,
      startY: e.clientY,
      originX: position.x,
      originY: position.y,
      moved: false,
      longPressed: false,
    };
    dragStateRef.current = state;
    longPressTimerRef.current = window.setTimeout(() => {
      if (dragStateRef.current && !dragStateRef.current.moved) {
        dragStateRef.current.longPressed = true;
        setMenuOpen(false);
        setLongPressMenuOpen(true);
      }
    }, 500);
  };

  const handlePointerMove = (e: ReactPointerEvent<HTMLButtonElement>) => {
    const state = dragStateRef.current;
    if (!state || !state.dragging || state.pointerId !== e.pointerId) return;
    const dx = e.clientX - state.startX;
    const dy = e.clientY - state.startY;
    if (Math.hypot(dx, dy) > 5) {
      state.moved = true;
      clearLongPressTimer();
    }
    const maxX = Math.max(12, window.innerWidth - 64);
    const maxY = Math.max(12, window.innerHeight - 64);
    setPosition({
      x: Math.min(Math.max(12, state.originX + dx), maxX),
      y: Math.min(Math.max(12, state.originY + dy), maxY),
    });
  };

  const handlePointerUp = (e: ReactPointerEvent<HTMLButtonElement>) => {
    clearLongPressTimer();
    const state = dragStateRef.current;
    if (!state || state.pointerId !== e.pointerId) return;
    dragStateRef.current = null;
    if (!state.moved && !state.longPressed) {
      setLongPressMenuOpen(false);
      setMenuOpen((prev) => !prev);
      setSavedToast(null);
    }
  };

  const cleanupRecordingStreams = () => {
    if (timerRef.current) {
      window.clearInterval(timerRef.current);
      timerRef.current = null;
    }
    cancelAnimationFrame(canvasRafRef.current);
    activeStreamsRef.current.forEach((s) => s.getTracks().forEach((t) => t.stop()));
    activeStreamsRef.current = [];
    audioCtxRef.current?.close().catch(() => undefined);
    audioCtxRef.current = null;
  };

  const finalizeAndSaveRecording = async (
    blob: Blob,
    durationSec: number,
    sequenceNum: number,
    highlightEvent?: string,
    reactionPart = false
  ) => {
    const gameName = activeGameRef.current || 'BGMI';
    const cleanDuration = Math.max(1, Math.round(durationSec));
    const safeGameSlug = gameName.replace(/[^A-Za-z0-9_]+/g, '_');
    const fileName = highlightEvent
      ? \`ClipKaro_AutoHighlight_\${safeGameSlug}_\${highlightEvent}_15s_Clip\${sequenceNum}.webm\`
      : reactionPart
        ? \`ClipKaro_Reaction_\${safeGameSlug}_Part_\${cleanDuration}s_Clip\${sequenceNum}.webm\`
        : \`ClipKaro_\${safeGameSlug}_\${cleanDuration}s_Clip\${sequenceNum}.webm\`;

    const newClip: ClipItem = {
      id: \`clip-\${Date.now()}-\${Math.random().toString(36).slice(2, 7)}\`,
      title: highlightEvent
        ? \`\${gameName} Auto Highlight (\${highlightEvent} · 15s)\`
        : reactionPart
          ? \`\${gameName} Reaction Clip (\${cleanDuration}s)\`
          : \`\${gameName} Clip #\${sequenceNum} (\${cleanDuration}s)\`,
      platform: 'studio',
      gameTag: gameName,
      durationSec: highlightEvent ? 15 : cleanDuration,
      trimStart: 0,
      trimEnd: highlightEvent ? 15 : cleanDuration,
      createdAt: Date.now(),
      copyrightSafe: true,
      isReaction: reactionPart || reactionModeRef.current,
      hasFacecam: facecamActiveRef.current,
      voiceChanger: voiceChangerRef.current,
      autoCaption: highlightEvent ? 'What a Headshot!' : undefined,
      permission: {
        hasPermission: true,
        streamerName: 'MyGameplay',
        originalVideoLink: '',
        creditText: 'Credit: @MyGameplay',
      },
      videoBlob: blob,
      videoMimeType: blob.type || 'video/webm',
      nativeFileName: fileName,
      audioSourceMode: audioModeRef.current,
      thumbnailDataUrl: thumbnailRef.current,
      voiceVolume: 1,
      musicVolume: 0.45,
      originalVolume: 1,
    };

    await onSaveClip(newClip);
    await saveVideoToNativeClipKaroFolder(fileName, blob);
    setSavedToast(
      highlightEvent
        ? \`Auto Highlight (\${highlightEvent} · 15s) saved to ClipKaro & My Clips\`
        : reactionPart
          ? \`Saved Reaction Clip (\${cleanDuration}s) with Facecam\`
          : \`Saved Clip #\${sequenceNum} (\${cleanDuration}s) to ClipKaro & My Clips\`
    );
  };

  const handleSaveReactionPartNow = async () => {
    if (!isRecording || chunksRef.current.length === 0) {
      showTopPopupNotification(
        'Start recording first',
        'Tap 10s–60s or Full Video, then tap Save Clip',
        false
      );
      return;
    }
    const snapshot = new Blob([...chunksRef.current], {
      type: recorderRef.current?.mimeType || 'video/webm',
    });
    const partSec = Math.max(5, Math.min(20, elapsedSeconds || 10));
    await finalizeAndSaveRecording(snapshot, partSec, clipSeqRef.current, undefined, true);
    showTopPopupNotification(
      'Reaction Clip Saved!',
      \`Saved \${partSec}s selected part with Facecam → My Clips\`,
      false
    );
  };

  const stopRecording = (manualStop = true) => {
    if (manualStop) {
      manualStopRequestedRef.current = true;
      isPausedRef.current = false;
      setIsPaused(false);
      // Auto collapse menu back to 32dp small button when STOP is tapped
      setMenuOpen(false);
    }
    const recorder = recorderRef.current;
    if (recorder && recorder.state !== 'inactive') {
      recorder.stop();
    } else {
      cleanupRecordingStreams();
      setIsRecording(false);
      if (manualStop) {
        showTopPopupNotification(
          'Clipping Saved - My Clips me save ho gayi',
          'Saved to My Clips & ClipKaro',
          false
        );
      }
    }
  };

  // On game / app close (visible -> false), auto-save clip & close Facecam immediately
  useEffect(() => {
    if (!visible && isRecordingRef.current) {
      stopRecording(true);
    }
  }, [visible]);

  const handleToggleFacecamChoice = () => {
    const next = !isFacecamToggleOn;
    setFacecamManualOff(!next);
    try {
      localStorage.setItem('clipkaro_facecam_manual_off', String(!next));
    } catch {
      // ignore
    }
    onUpdateReactionOptions?.({ facecamEnabled: next });
    showTopPopupNotification(
      next ? 'Facecam ON' : 'Facecam OFF',
      next
        ? isRecording
          ? 'Facecam opened with RED dot'
          : 'Facecam will open when Recording starts'
        : 'Facecam closed & preference saved',
      next && isRecording
    );
  };

  const pauseRecording = () => {
    if (!isRecording || isPausedRef.current) return;
    isPausedRef.current = true;
    setIsPaused(true);
    pauseStartedAtRef.current = Date.now();
    facecamVideoRef.current?.pause();
    if (recorderRef.current?.state === 'recording' && typeof recorderRef.current.pause === 'function') {
      try {
        recorderRef.current.pause();
      } catch {
        // ignore if unsupported
      }
    }
    showTopPopupNotification(
      'Recording Paused',
      \`Paused at \${formatSeconds(elapsedSeconds)} · Tap Resume to continue\`,
      false
    );
  };

  const resumeRecording = () => {
    if (!isRecording || !isPausedRef.current) return;
    if (pauseStartedAtRef.current > 0) {
      pausedTotalMsRef.current += Math.max(0, Date.now() - pauseStartedAtRef.current);
      pauseStartedAtRef.current = 0;
    }
    isPausedRef.current = false;
    setIsPaused(false);
    facecamVideoRef.current?.play().catch(() => undefined);
    if (recorderRef.current?.state === 'paused' && typeof recorderRef.current.resume === 'function') {
      try {
        recorderRef.current.resume();
      } catch {
        // ignore if unsupported
      }
    }
    showTopPopupNotification(
      'Recording Resumed',
      \`Continuing from \${formatSeconds(elapsedSeconds)} · Tap CLIP to Stop\`,
      true
    );
  };

  const startHdDemoStream = (): MediaStream => {
    const canvas = document.createElement('canvas');
    canvas.width = 1280;
    canvas.height = 720;
    const ctx = canvas.getContext('2d')!;

    const startMs = performance.now();
    let capturedThumb = false;

    const renderFrame = () => {
      const elapsed = performance.now() - startMs;
      const t = elapsed / 1000;

      const grad = ctx.createLinearGradient(0, 0, canvas.width, canvas.height);
      grad.addColorStop(0, '#090d16');
      grad.addColorStop(0.6, '#131b2e');
      grad.addColorStop(1, '#0b1120');
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      ctx.strokeStyle = 'rgba(56, 189, 248, 0.14)';
      ctx.lineWidth = 1.5;
      const scroll = (elapsed * 0.06) % 64;
      for (let x = -64 + scroll; x < canvas.width; x += 64) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, canvas.height);
        ctx.stroke();
      }
      for (let y = 0; y < canvas.height; y += 64) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(canvas.width, y);
        ctx.stroke();
      }

      const cx = canvas.width / 2 + Math.cos(t * 1.4) * 220;
      const cy = canvas.height / 2 + Math.sin(t * 2.1) * 110;
      ctx.strokeStyle = '#f43f5e';
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.arc(cx, cy, 34, 0, Math.PI * 2);
      ctx.stroke();
      ctx.beginPath();
      ctx.moveTo(cx - 48, cy);
      ctx.lineTo(cx + 48, cy);
      ctx.moveTo(cx, cy - 48);
      ctx.lineTo(cx, cy + 48);
      ctx.stroke();

      ctx.fillStyle = 'rgba(11, 14, 20, 0.85)';
      ctx.fillRect(36, 32, 520, 74);
      ctx.fillStyle = '#ffffff';
      ctx.font = '700 26px system-ui, sans-serif';
      ctx.fillText(\`\${activeGameRef.current || 'Game'} · Clip #\${clipSeqRef.current}\`, 56, 68);
      ctx.fillStyle = '#34d399';
      ctx.font = '500 16px system-ui, sans-serif';
      ctx.fillText(\`1280×720 HD · \${AUDIO_LABELS[audioModeRef.current]}\`, 56, 94);

      for (let i = 0; i < 20; i += 1) {
        const h = 14 + Math.abs(Math.sin(t * 6 + i * 0.6)) * 44;
        ctx.fillStyle = i % 2 === 0 ? '#f43f5e' : '#38bdf8';
        ctx.fillRect(36 + i * 18, canvas.height - 56 - h, 10, h);
      }

      ctx.fillStyle = '#f8fafc';
      ctx.font = '600 22px monospace';
      ctx.fillText(\`REC \${t.toFixed(1)}s\`, canvas.width - 190, canvas.height - 46);

      // Composite circular Facecam into recorded frame when Facecam / Reaction Mode is ON
      if (facecamActiveRef.current) {
        const radius = Math.round(facecamSizeRef.current * 0.58);
        const fcx = canvas.width - radius - 34;
        const fcy = radius + 34;
        ctx.save();
        ctx.beginPath();
        ctx.arc(fcx, fcy, radius, 0, Math.PI * 2);
        ctx.closePath();
        ctx.clip();
        if (facecamVideoRef.current && facecamVideoRef.current.readyState >= 2) {
          ctx.drawImage(
            facecamVideoRef.current,
            fcx - radius,
            fcy - radius,
            radius * 2,
            radius * 2
          );
        } else {
          ctx.fillStyle = '#0f766e';
          ctx.fillRect(fcx - radius, fcy - radius, radius * 2, radius * 2);
          ctx.fillStyle = '#ffffff';
          ctx.font = '700 16px system-ui, sans-serif';
          ctx.textAlign = 'center';
          ctx.fillText('FACECAM', fcx, fcy + 5);
          ctx.textAlign = 'left';
        }
        ctx.restore();
        ctx.strokeStyle = reactionModeRef.current ? '#f43f5e' : '#34d399';
        ctx.lineWidth = 4;
        ctx.beginPath();
        ctx.arc(fcx, fcy, radius, 0, Math.PI * 2);
        ctx.stroke();
      }

      if (!capturedThumb && elapsed > 250) {
        capturedThumb = true;
        try {
          thumbnailRef.current = canvas.toDataURL('image/jpeg', 0.8);
        } catch {
          // ignore
        }
      }

      canvasRafRef.current = requestAnimationFrame(renderFrame);
    };

    canvasRafRef.current = requestAnimationFrame(renderFrame);
    const canvasStream = canvas.captureStream(30);
    activeStreamsRef.current.push(canvasStream);
    return canvasStream;
  };

  const startRecording = async (
    durationSec: number | null,
    label: string,
    sequenceNum = 1
  ) => {
    // Close menu automatically right on tap
    setMenuOpen(false);
    manualStopRequestedRef.current = false;
    isPausedRef.current = false;
    setIsPaused(false);
    pausedTotalMsRef.current = 0;
    pauseStartedAtRef.current = 0;
    setSavedToast(null);
    thumbnailRef.current = undefined;
    chunksRef.current = [];
    clipSeqRef.current = sequenceNum;
    setClipSequence(sequenceNum);
    activeTargetSecRef.current = durationSec;
    activeLabelRef.current = label;
    setTargetSeconds(durationSec);
    setElapsedSeconds(0);
    setRecordingModeLabel(label);

    const startBadgeLabel = durationSec ? \`\${durationSec} sec Clip\` : 'Full Video';
    if (sequenceNum === 1) {
      showTopPopupNotification(
        \`Clipping Started - \${startBadgeLabel}\`,
        \`\${startBadgeLabel} · Tap CLIP button to Stop\`,
        true
      );
    }

    const mode = audioModeRef.current;
    const wantGameAudio = mode === 'game' || mode === 'both';
    const wantMicAudio = mode === 'mic' || mode === 'both';

    let videoStream: MediaStream | null = null;
    let gameAudioStream: MediaStream | null = null;
    let chatAudioStream: MediaStream | null = null;

    if (navigator.mediaDevices?.getDisplayMedia) {
      try {
        const displayStream = await navigator.mediaDevices.getDisplayMedia({
          video: {
            width: { ideal: 1920 },
            height: { ideal: 1080 },
            frameRate: { ideal: 30 },
          },
          audio: wantGameAudio,
        });
        videoStream = displayStream;
        if (wantGameAudio) gameAudioStream = displayStream;
        activeStreamsRef.current.push(displayStream);

        try {
          const track = displayStream.getVideoTracks()[0];
          const tempVideo = document.createElement('video');
          tempVideo.srcObject = new MediaStream([track]);
          tempVideo.muted = true;
          await tempVideo.play();
          const c = document.createElement('canvas');
          c.width = 480;
          c.height = 270;
          const cx = c.getContext('2d');
          cx?.drawImage(tempVideo, 0, 0, c.width, c.height);
          thumbnailRef.current = c.toDataURL('image/jpeg', 0.8);
          tempVideo.pause();
          tempVideo.srcObject = null;
        } catch {
          // ignore
        }
      } catch {
        videoStream = null;
      }
    }

    if (wantMicAudio && navigator.mediaDevices?.getUserMedia) {
      try {
        const micStream = await navigator.mediaDevices.getUserMedia({
          audio: { echoCancellation: true, noiseSuppression: true },
        });
        chatAudioStream = micStream;
        activeStreamsRef.current.push(micStream);
      } catch {
        chatAudioStream = null;
      }
    }

    if (!videoStream) {
      videoStream = startHdDemoStream();
    }

    const audioCtx = new AudioContext();
    audioCtxRef.current = audioCtx;
    const mixedDest = audioCtx.createMediaStreamDestination();
    let hasAudioTrack = false;

    if (wantGameAudio) {
      if (gameAudioStream && gameAudioStream.getAudioTracks().length > 0) {
        const gameSrc = audioCtx.createMediaStreamSource(
          new MediaStream(gameAudioStream.getAudioTracks())
        );
        gameSrc.connect(mixedDest);
        hasAudioTrack = true;
      } else {
        const osc = audioCtx.createOscillator();
        const gain = audioCtx.createGain();
        osc.type = 'triangle';
        osc.frequency.value = 180;
        gain.gain.value = 0.035;
        osc.connect(gain);
        gain.connect(mixedDest);
        osc.start();
        hasAudioTrack = true;
      }
    }

    if (wantMicAudio && chatAudioStream && chatAudioStream.getAudioTracks().length > 0) {
      const chatSrc = audioCtx.createMediaStreamSource(chatAudioStream);
      const activePreset = voiceChangerRef.current;
      if (activePreset === 'funny') {
        const biquad = audioCtx.createBiquadFilter();
        biquad.type = 'highshelf';
        biquad.frequency.value = 1800;
        biquad.gain.value = 10;
        chatSrc.connect(biquad);
        biquad.connect(mixedDest);
      } else if (activePreset === 'deep') {
        const biquad = audioCtx.createBiquadFilter();
        biquad.type = 'lowpass';
        biquad.frequency.value = 580;
        chatSrc.connect(biquad);
        biquad.connect(mixedDest);
      } else if (activePreset === 'robot') {
        const bp = audioCtx.createBiquadFilter();
        bp.type = 'bandpass';
        bp.frequency.value = 1100;
        bp.Q.value = 3.5;
        const ringGain = audioCtx.createGain();
        ringGain.gain.value = 0.6;
        const lfo = audioCtx.createOscillator();
        const lfoDepth = audioCtx.createGain();
        lfo.frequency.value = 58;
        lfoDepth.gain.value = 0.4;
        lfo.connect(lfoDepth);
        lfoDepth.connect(ringGain.gain);
        lfo.start();
        chatSrc.connect(bp);
        bp.connect(ringGain);
        ringGain.connect(mixedDest);
      } else {
        chatSrc.connect(mixedDest);
      }
      hasAudioTrack = true;
    }

    const combinedStream = new MediaStream([
      ...videoStream.getVideoTracks(),
      ...(hasAudioTrack ? mixedDest.stream.getAudioTracks() : []),
    ]);

    videoStream.getVideoTracks().forEach((track) => {
      track.onended = () => stopRecording(true);
    });

    const mimeType = MediaRecorder.isTypeSupported('video/webm;codecs=vp9,opus')
      ? 'video/webm;codecs=vp9,opus'
      : MediaRecorder.isTypeSupported('video/webm')
        ? 'video/webm'
        : '';

    const recorder = new MediaRecorder(combinedStream, {
      ...(mimeType ? { mimeType } : {}),
      videoBitsPerSecond: 4_000_000,
    });

    recorderRef.current = recorder;
    startedAtRef.current = Date.now();

    recorder.ondataavailable = (ev) => {
      if (ev.data && ev.data.size > 0) chunksRef.current.push(ev.data);
    };

    recorder.onstop = async () => {
      const activeMs = Math.max(
        1000,
        (isPausedRef.current ? pauseStartedAtRef.current : Date.now()) -
          startedAtRef.current -
          pausedTotalMsRef.current
      );
      const actualSec = Math.max(1, activeMs / 1000);
      const finalBlob = new Blob(chunksRef.current, { type: mimeType || 'video/webm' });
      const finishedTarget = activeTargetSecRef.current;
      const finishedSeq = clipSeqRef.current;
      // Recording NEVER stops automatically on timed clip end — only manual STOP ends recording
      const shouldContinue =
        finishedTarget !== null && !manualStopRequestedRef.current;

      cleanupRecordingStreams();
      setIsRecording(false);
      isPausedRef.current = false;
      setIsPaused(false);

      await finalizeAndSaveRecording(
        finalBlob,
        finishedTarget ?? actualSec,
        finishedSeq
      );

      if (shouldContinue && finishedTarget !== null) {
        // Start next clip immediately with exact same duration until STOP
        await startRecording(finishedTarget, activeLabelRef.current, finishedSeq + 1);
      } else {
        setTargetSeconds(null);
        setRecordingModeLabel('');
        showTopPopupNotification(
          'Clipping Saved - My Clips me save ho gayi',
          'Saved to My Clips & ClipKaro',
          false
        );
      }
    };

    // Start recording immediately with RED dot + timer
    recorder.start(250);
    setIsRecording(true);
    autoHighlightSavedForSessionRef.current = false;

    timerRef.current = window.setInterval(() => {
      if (isPausedRef.current) {
        return;
      }
      const secs = Math.max(
        0,
        Math.floor((Date.now() - startedAtRef.current - pausedTotalMsRef.current) / 1000)
      );
      setElapsedSeconds(secs);

      // In web preview mode with Auto Highlight ON during Full Video, save a 15s Kill/Headshot highlight automatically without pressing any button
      if (
        autoHighlightRef.current &&
        activeTargetSecRef.current === null &&
        !autoHighlightSavedForSessionRef.current &&
        secs >= 15 &&
        chunksRef.current.length > 0
      ) {
        autoHighlightSavedForSessionRef.current = true;
        const snapshotBlob = new Blob([...chunksRef.current], {
          type: mimeType || 'video/webm',
        });
        void finalizeAndSaveRecording(snapshotBlob, 15, clipSeqRef.current, 'Headshot');
      }

      if (activeTargetSecRef.current !== null && secs >= activeTargetSecRef.current) {
        // Auto-finish current segment & immediately continue next clip until user taps STOP
        stopRecording(false);
      }
    }, 250);
  };

  const cycleAudioMode = () => {
    setAudioMode((prev) => (prev === 'both' ? 'game' : prev === 'game' ? 'mic' : 'both'));
  };

  const cycleVoicePreset = () => {
    const idx = VOICE_ORDER.indexOf(voiceChanger);
    const next = VOICE_ORDER[(idx + 1) % VOICE_ORDER.length];
    onUpdateReactionOptions?.({ voiceChanger: next });
    setSavedToast(\`Voice Changer: \${next.toUpperCase()}\`);
  };

  if (!visible) return null;

  const winW = typeof window !== 'undefined' ? window.innerWidth : 390;
  const winH = typeof window !== 'undefined' ? window.innerHeight : 844;
  const menuSize = isRecording ? 246 : 254;
  const expandedLeft = Math.min(Math.max(10, position.x - menuSize / 2 + 16), Math.max(10, winW - menuSize - 10));
  const expandedTop = Math.min(Math.max(16, position.y - menuSize / 2 + 16), Math.max(16, winH - menuSize - 16));
  const openLeftward = position.x > winW * 0.55;
  const showFacecamWindow = isRecording && isFacecamToggleOn;

  return (
    <>
      {/* Draggable & Resizable 120dp Circular Facecam Overlay Window (Opens ONLY during active recording) */}
      {showFacecamWindow && (
        <div
          style={{ left: \`\${facecamPos.x}px\`, top: \`\${facecamPos.y}px\` }}
          className="fixed z-40 flex flex-col items-center select-none"
        >
          <div
            onPointerDown={(e) => {
              e.currentTarget.setPointerCapture(e.pointerId);
              facecamDragRef.current = {
                pointerId: e.pointerId,
                startX: e.clientX,
                startY: e.clientY,
                originX: facecamPos.x,
                originY: facecamPos.y,
              };
            }}
            onPointerMove={(e) => {
              const st = facecamDragRef.current;
              if (!st || st.pointerId !== e.pointerId) return;
              const maxX = Math.max(8, winW - facecamSizePx - 8);
              const maxY = Math.max(12, winH - facecamSizePx - 12);
              setFacecamPos({
                x: Math.min(Math.max(8, st.originX + (e.clientX - st.startX)), maxX),
                y: Math.min(Math.max(12, st.originY + (e.clientY - st.startY)), maxY),
              });
            }}
            onPointerUp={() => {
              facecamDragRef.current = null;
            }}
            style={{ width: \`\${facecamSizePx}px\`, height: \`\${facecamSizePx}px\` }}
            className={\`touch-none relative overflow-hidden rounded-full border-2 shadow-2xl flex items-center justify-center cursor-move \${
              reactionMode ? 'border-rose-500 bg-slate-900' : 'border-emerald-400 bg-slate-900'
            }\`}
          >
            <video
              ref={facecamVideoRef}
              muted
              playsInline
              className={\`h-full w-full object-cover \${facecamLive ? 'block' : 'hidden'}\`}
            />
            {!facecamLive && (
              <div className="flex flex-col items-center text-white pointer-events-none">
                <Camera className="h-5 w-5 text-emerald-300" aria-hidden="true" />
                <span className="mt-0.5 text-[9px] font-bold">Facecam {facecamSizePx}dp</span>
              </div>
            )}
            {/* Recording RED dot (or Yellow PAUSED indicator) on Facecam */}
            <div className="pointer-events-none absolute top-1.5 left-1/2 -translate-x-1/2 flex items-center gap-1 rounded-full bg-black/80 px-1.5 py-0.5">
              <span
                className={\`h-2 w-2 rounded-full \${
                  isPaused ? 'bg-yellow-400' : 'bg-red-500 animate-pulse'
                }\`}
                aria-hidden="true"
              />
              <span className="text-[8px] font-extrabold tracking-wide text-white">
                {isPaused ? 'PAUSED' : 'REC'}
              </span>
            </div>
            <button
              type="button"
              onPointerDown={(e) => e.stopPropagation()}
              onClick={() =>
                setFacecamSizePx((s) => (s === 120 ? 156 : s === 156 ? 96 : 120))
              }
              title="Resize Facecam circle"
              aria-label="Resize Facecam circle"
              className="absolute bottom-1.5 right-1.5 flex h-5 w-5 items-center justify-center rounded-full border border-slate-500 bg-slate-900/90 text-[10px] font-bold text-white"
            >
              ⤢
            </button>
          </div>
          {reactionMode && isRecording && (
            <button
              type="button"
              onClick={() => void handleSaveReactionPartNow()}
              className="mt-1 rounded-full bg-rose-600 px-2.5 py-0.5 text-[10px] font-bold text-white shadow-lg hover:bg-rose-500"
            >
              Save Clip
            </button>
          )}
        </div>
      )}

      {/* 2-Second Top-of-Screen Notification Popup */}
      {topBanner && (
        <div
          role="status"
          aria-live="polite"
          className="fixed top-4 left-1/2 z-[70] -translate-x-1/2 flex items-center gap-2.5 rounded-full border border-slate-600/80 bg-[#0B0E14]/95 px-4 py-2 shadow-2xl backdrop-blur-md max-w-[92vw]"
        >
          <span
            className={\`h-2.5 w-2.5 rounded-full shrink-0 \${
              topBanner.isRedDot ? 'bg-red-500 animate-pulse' : 'bg-emerald-400'
            }\`}
            aria-hidden="true"
          />
          <div className="min-w-0">
            <div className="text-xs font-extrabold text-white truncate">{topBanner.title}</div>
            <div className="text-[10px] text-slate-300 truncate">{topBanner.subtitle}</div>
          </div>
        </div>
      )}
      {/* Optional Top Notification Recording Bar (for Preview / Notification Quick Controls) */}
      {notifBarEnabled && (
        <div className="fixed bottom-4 left-4 z-40 flex flex-wrap items-center gap-2 rounded-xl border border-slate-700 bg-[#0F172A]/95 px-3 py-2 text-xs text-slate-200 shadow-2xl backdrop-blur-md">
          <Bell className="h-3.5 w-3.5 text-rose-400 shrink-0" aria-hidden="true" />
          <span className="font-semibold">
            {isRecording
              ? \`REC \${formatSeconds(elapsedSeconds)}\${targetSeconds ? \` / \${formatSeconds(targetSeconds)}\` : ''} · #\${clipSequence}\`
              : 'Notification Record:'}
          </span>
          {isRecording ? (
            <>
              <button
                type="button"
                onClick={isPaused ? resumeRecording : pauseRecording}
                className={\`rounded-md px-2 py-1 font-bold \${
                  isPaused
                    ? 'bg-green-600 text-white hover:bg-green-500'
                    : 'bg-yellow-400 text-slate-950 hover:bg-yellow-300'
                }\`}
              >
                {isPaused ? 'Resume' : 'Pause'}
              </button>
              <button
                type="button"
                onClick={() => stopRecording(true)}
                className="rounded-md bg-rose-600 px-2.5 py-1 font-bold text-white hover:bg-rose-500"
              >
                Stop
              </button>
            </>
          ) : (
            <>
              <button
                type="button"
                onClick={() => startRecording(10, 'Clip 10 sec')}
                className="rounded-md border border-slate-700 bg-[#0B0E14] px-2 py-1 font-semibold hover:border-rose-500"
              >
                10s Clip
              </button>
              <button
                type="button"
                onClick={() => startRecording(30, 'Clip 30 sec')}
                className="rounded-md border border-slate-700 bg-[#0B0E14] px-2 py-1 font-semibold hover:border-rose-500"
              >
                30s Clip
              </button>
              <button
                type="button"
                onClick={() => startRecording(null, 'Full Video')}
                className="rounded-md bg-rose-600 px-2 py-1 font-semibold text-white hover:bg-rose-500"
              >
                Full
              </button>
            </>
          )}
          <button
            type="button"
            onClick={() => setNotifBarEnabled(false)}
            aria-label="Hide notification bar"
            className="rounded p-0.5 text-slate-400 hover:text-white"
          >
            <X className="h-3.5 w-3.5" aria-hidden="true" />
          </button>
        </div>
      )}

      {/* Draggable Expand / Collapse 32dp (60% Transparent) Floating Bubble & 180dp+ Circular Menu */}
      <div
        ref={rootRef}
        style={
          menuOpen
            ? { left: \`\${expandedLeft}px\`, top: \`\${expandedTop}px\` }
            : { left: \`\${position.x}px\`, top: \`\${position.y}px\` }
        }
        className="fixed z-50 select-none"
      >
        {/* SMALL MODE: 32dp circle, 60% transparent (opacity-40), draggable anywhere */}
        {!menuOpen && (
          <button
            ref={buttonRef}
            type="button"
            onPointerDown={handlePointerDown}
            onPointerMove={handlePointerMove}
            onPointerUp={handlePointerUp}
            onPointerCancel={clearLongPressTimer}
            onContextMenu={(e) => {
              e.preventDefault();
              setMenuOpen(false);
              setLongPressMenuOpen(true);
            }}
            aria-label="ClipKaro 32dp Floating CLIP Button"
            title={
              isWebPreviewDemo
                ? 'ClipKaro 32dp Floating CLIP Button (Tap: Menu · Hold 500ms: Options)'
                : \`ClipKaro Floating CLIP (\${activeGameName})\`
            }
            aria-expanded={menuOpen}
            className={\`touch-none flex h-8 w-8 flex-col items-center justify-center rounded-full border shadow-xl opacity-40 hover:opacity-80 transition-opacity focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-rose-400 \${
              isRecording
                ? isPaused
                  ? 'border-yellow-400 bg-[#0F172A] text-white'
                  : 'border-red-500 bg-[#0F172A] text-white'
                : 'border-white/85 bg-rose-600 text-white'
            }\`}
          >
            {isRecording ? (
              <>
                <span
                  className={\`h-1.5 w-1.5 rounded-full \${
                    isPaused ? 'bg-yellow-400' : 'bg-red-500 animate-pulse'
                  }\`}
                  aria-hidden="true"
                />
                <span className="mt-0.5 font-mono text-[8px] font-bold tabular-nums leading-none">
                  {formatSeconds(elapsedSeconds)}
                </span>
              </>
            ) : (
              <div className="flex flex-col items-center justify-center leading-none">
                <Scissors className="h-3 w-3 text-white" aria-hidden="true" />
                <span className="mt-0.5 text-[6px] font-extrabold tracking-tight text-white">
                  CLIP
                </span>
              </div>
            )}
          </button>
        )}

        {/* 500ms Long-Press Popup Menu */}
        {longPressMenuOpen && !menuOpen && (
          <div
            role="menu"
            aria-label="Floating Button Quick Options"
            className={\`absolute \${
              openLeftward ? 'right-10' : 'left-10'
            } -top-2 z-[60] w-44 rounded-xl border border-slate-600 bg-[#0B0E14]/95 p-2 shadow-2xl backdrop-blur-md space-y-1.5\`}
          >
            <div className="px-1 text-[10px] font-bold uppercase tracking-wider text-slate-400">
              CLIP Options
            </div>
            <button
              type="button"
              onClick={() => {
                setLongPressMenuOpen(false);
                onClose?.();
              }}
              className="w-full rounded-lg bg-slate-800 px-3 py-1.5 text-left text-xs font-semibold text-white hover:bg-slate-700"
            >
              Hide Button
            </button>
            <button
              type="button"
              onClick={() => {
                setLongPressMenuOpen(false);
                if (isRecording) stopRecording(true);
                onClose?.();
              }}
              className="w-full rounded-lg bg-amber-700 px-3 py-1.5 text-left text-xs font-semibold text-white hover:bg-amber-600"
            >
              Stop Recording + Hide
            </button>
            <button
              type="button"
              onClick={() => {
                setLongPressMenuOpen(false);
                if (isRecording) stopRecording(true);
                onClose?.();
              }}
              className="w-full rounded-lg bg-red-600 px-3 py-1.5 text-left text-xs font-bold text-white hover:bg-red-500"
            >
              Stop
            </button>
          </div>
        )}

        {/* Saved Toast next to Small Button */}
        {savedToast && !menuOpen && (
          <div
            className={\`absolute \${
              openLeftward ? 'right-10' : 'left-10'
            } top-0 flex items-center gap-2 rounded-lg border border-emerald-500/40 bg-[#121722] px-3 py-1.5 text-xs text-emerald-200 shadow-xl whitespace-nowrap\`}
          >
            <CheckCircle2 className="h-3.5 w-3.5 text-emerald-400 shrink-0" aria-hidden="true" />
            <span>{savedToast}</span>
            <button
              type="button"
              onClick={() => {
                setSavedToast(null);
                onNavigateToClips();
              }}
              className="rounded bg-emerald-600 px-2 py-0.5 font-semibold text-white hover:bg-emerald-500"
            >
              Open
            </button>
          </div>
        )}

        {/* BIG MODE: Expanded 246dp Semi-Transparent Dark Circle Menu */}
        {menuOpen && isRecording && (
          <div
            role="dialog"
            aria-label="Recording Controls"
            className="flex h-[246px] w-[246px] flex-col items-center justify-center rounded-full border-2 border-red-500/80 bg-[#0B0E14]/90 p-3 text-center shadow-2xl backdrop-blur-md"
          >
            <div className="flex items-center gap-2">
              <span
                className={\`h-2.5 w-2.5 rounded-full \${
                  isPaused ? 'bg-yellow-400' : 'bg-red-500 animate-pulse'
                }\`}
                aria-hidden="true"
              />
              <span className="font-mono text-base font-bold text-white tabular-nums">
                {formatSeconds(elapsedSeconds)}
              </span>
              <button
                type="button"
                onClick={() => setMenuOpen(false)}
                aria-label="Collapse floating menu"
                className="flex h-6 w-6 items-center justify-center rounded-full border border-slate-500 bg-slate-800/90 text-white hover:bg-slate-700"
              >
                <X className="h-3.5 w-3.5" aria-hidden="true" />
              </button>
            </div>

            <div
              className={\`mt-1 text-[10px] font-semibold truncate max-w-[165px] \${
                isPaused ? 'text-yellow-300' : 'text-slate-300'
              }\`}
            >
              {isPaused ? \`PAUSED · \${recordingModeLabel}\` : \`\${recordingModeLabel} #\${clipSequence}\`}
            </div>

            {/* PAUSE (YELLOW) + RESUME (GREEN) */}
            <div className="mt-2 flex items-center justify-center gap-2">
              <button
                type="button"
                disabled={isPaused}
                onClick={pauseRecording}
                className="inline-flex items-center justify-center gap-1 rounded-full bg-yellow-400 px-3 py-1.5 text-[11px] font-extrabold text-slate-950 shadow hover:bg-yellow-300 disabled:opacity-45"
              >
                <Pause className="h-3 w-3 fill-current" aria-hidden="true" />
                <span>PAUSE</span>
              </button>
              <button
                type="button"
                disabled={!isPaused}
                onClick={resumeRecording}
                className="inline-flex items-center justify-center gap-1 rounded-full bg-green-600 px-3 py-1.5 text-[11px] font-extrabold text-white shadow hover:bg-green-500 disabled:opacity-45"
              >
                <Play className="h-3 w-3 fill-current" aria-hidden="true" />
                <span>RESUME</span>
              </button>
            </div>

            {/* Facecam ON / OFF toggle inside Recording menu (saves last choice) */}
            <button
              type="button"
              onClick={handleToggleFacecamChoice}
              className={\`mt-1.5 inline-flex items-center justify-center gap-1.5 rounded-full px-3.5 py-1 text-[10px] font-bold transition-colors \${
                isFacecamToggleOn
                  ? 'bg-teal-600 text-white hover:bg-teal-500'
                  : 'border border-slate-600 bg-slate-800 text-slate-300 hover:text-white'
              }\`}
            >
              <Camera className="h-3 w-3" aria-hidden="true" />
              <span>{isFacecamToggleOn ? 'Facecam ON' : 'Facecam OFF'}</span>
            </button>

            {reactionMode && (
              <button
                type="button"
                onClick={() => {
                  setMenuOpen(false);
                  void handleSaveReactionPartNow();
                }}
                className="mt-1.5 inline-flex items-center justify-center gap-1 rounded-full bg-rose-700 px-4 py-1 text-[10px] font-bold text-white hover:bg-rose-600"
              >
                <Scissors className="h-3 w-3" aria-hidden="true" />
                <span>Save Clip (Part)</span>
              </button>
            )}

            {/* BIG RED STOP */}
            <button
              type="button"
              onClick={() => stopRecording(true)}
              className="mt-1.5 inline-flex items-center justify-center gap-1.5 rounded-full border-2 border-red-300 bg-red-600 px-6 py-1.5 text-xs font-extrabold text-white shadow-lg transition-transform hover:scale-105 hover:bg-red-500"
            >
              <Square className="h-3.5 w-3.5 fill-current" aria-hidden="true" />
              <span>STOP</span>
            </button>
          </div>
        )}

        {menuOpen && !isRecording && (
          <div
            role="dialog"
            aria-label="In-Game Clip Menu"
            className="flex h-[254px] w-[254px] flex-col items-center justify-between rounded-full border border-slate-500/70 bg-[#0B0E14]/88 px-4 py-3 shadow-2xl backdrop-blur-md"
          >
            {/* Top: CLIP + CLOSE (X) */}
            <div className="flex w-full items-center justify-between px-4">
              <div className="flex items-center gap-1 text-xs font-extrabold text-white">
                <Move className="h-3 w-3 text-rose-400 shrink-0" aria-hidden="true" />
                <span>CLIP</span>
              </div>
              <div className="flex items-center gap-1">
                {onClose && (
                  <button
                    type="button"
                    onClick={() => {
                      setMenuOpen(false);
                      onClose();
                    }}
                    title="Turn off floating bubble"
                    className="rounded-full border border-slate-600 bg-slate-800 px-1.5 py-0.5 text-[9px] font-semibold text-slate-300 hover:text-white"
                  >
                    Off
                  </button>
                )}
                <button
                  type="button"
                  onClick={() => setMenuOpen(false)}
                  aria-label="Close floating menu"
                  className="flex h-6 w-6 items-center justify-center rounded-full border border-slate-500 bg-slate-800 text-white hover:bg-slate-700"
                >
                  <X className="h-3.5 w-3.5" aria-hidden="true" />
                </button>
              </div>
            </div>

            {/* Compact Feature Toggles Row 1: Audio / Auto Loop / Auto Highlight */}
            <div className="grid w-full grid-cols-3 gap-1 px-2">
              <button
                type="button"
                onClick={cycleAudioMode}
                title={\`Audio: \${AUDIO_LABELS[audioMode]}\`}
                className="inline-flex items-center justify-center gap-0.5 rounded-full bg-rose-600/90 px-1.5 py-1 text-[9px] font-bold text-white hover:bg-rose-500 truncate"
              >
                <Mic className="h-2.5 w-2.5 shrink-0" aria-hidden="true" />
                <span className="truncate">
                  {audioMode === 'game' ? 'Game' : audioMode === 'mic' ? 'Mic' : 'Both'}
                </span>
              </button>
              <button
                type="button"
                onClick={() => {
                  setAutoContinuous(true);
                  setSavedToast('Continuous Clips stays ON until you tap STOP');
                }}
                className="inline-flex items-center justify-center gap-0.5 rounded-full bg-emerald-700/90 px-1.5 py-1 text-[9px] font-bold text-white"
              >
                <Repeat className="h-2.5 w-2.5 shrink-0" aria-hidden="true" />
                <span>Loop:ON</span>
              </button>
              <button
                type="button"
                onClick={() => setAutoHighlight((prev) => !prev)}
                className={\`inline-flex items-center justify-center gap-0.5 rounded-full px-1.5 py-1 text-[9px] font-bold \${
                  autoHighlight
                    ? 'bg-amber-600/90 text-white'
                    : 'border border-slate-600 bg-slate-800 text-slate-300'
                }\`}
              >
                <Zap className="h-2.5 w-2.5 shrink-0" aria-hidden="true" />
                <span>15sHL</span>
              </button>
            </div>

            {/* Compact Feature Toggles Row 2: Facecam / Voice Changer / Reaction Mode */}
            <div className="grid w-full grid-cols-3 gap-1 px-2">
              <button
                type="button"
                onClick={handleToggleFacecamChoice}
                className={\`inline-flex items-center justify-center gap-0.5 rounded-full px-1.5 py-1 text-[9px] font-bold \${
                  isFacecamToggleOn
                    ? 'bg-teal-600 text-white'
                    : 'border border-slate-600 bg-slate-800 text-slate-300'
                }\`}
              >
                <Camera className="h-2.5 w-2.5 shrink-0" aria-hidden="true" />
                <span>{isFacecamToggleOn ? 'Facecam ON' : 'Facecam OFF'}</span>
              </button>
              <button
                type="button"
                onClick={cycleVoicePreset}
                className={\`inline-flex items-center justify-center gap-0.5 rounded-full px-1.5 py-1 text-[9px] font-bold capitalize \${
                  voiceChanger !== 'normal'
                    ? 'bg-violet-600 text-white'
                    : 'border border-slate-600 bg-slate-800 text-slate-300'
                }\`}
              >
                <span>V:{voiceChanger}</span>
              </button>
              <button
                type="button"
                onClick={() => {
                  const nextReact = !reactionMode;
                  if (nextReact) {
                    setFacecamManualOff(false);
                    try {
                      localStorage.setItem('clipkaro_facecam_manual_off', 'false');
                    } catch {
                      // ignore
                    }
                  }
                  onUpdateReactionOptions?.({
                    reactionMode: nextReact,
                    facecamEnabled: nextReact ? true : facecamEnabled,
                  });
                }}
                className={\`inline-flex items-center justify-center gap-0.5 rounded-full px-1.5 py-1 text-[9px] font-bold \${
                  reactionMode
                    ? 'bg-rose-600 text-white'
                    : 'border border-slate-600 bg-slate-800 text-slate-300'
                }\`}
              >
                <span>{reactionMode ? 'React:ON' : 'React:OFF'}</span>
              </button>
            </div>

            {/* 10 sec - 60 sec Clip Buttons */}
            <div className="grid w-full grid-cols-3 gap-1 px-0.5">
              {CLIP_DURATIONS.map((sec) => (
                <button
                  key={sec}
                  type="button"
                  onClick={() => startRecording(sec, \`\${sec}s Clip\`)}
                  className="rounded-full border border-slate-600 bg-slate-800/95 py-1 text-[10px] font-bold text-white transition-colors hover:border-rose-400 hover:bg-rose-600 tabular-nums"
                >
                  {sec} sec
                </button>
              ))}
            </div>

            {/* Full Video + RED STOP */}
            <div className="flex w-full items-center justify-center gap-1.5 px-3">
              <button
                type="button"
                onClick={() => startRecording(null, 'Full Video')}
                className="inline-flex flex-1 items-center justify-center gap-1 rounded-full bg-teal-700 px-2.5 py-1.5 text-[10px] font-bold text-white hover:bg-teal-600 whitespace-nowrap"
              >
                <Video className="h-3 w-3" aria-hidden="true" />
                <span>Full Video</span>
              </button>
              <button
                type="button"
                onClick={() => stopRecording(true)}
                className="inline-flex items-center justify-center gap-1 rounded-full bg-red-600 px-3 py-1.5 text-[10px] font-extrabold text-white hover:bg-red-500 whitespace-nowrap"
              >
                <Square className="h-2.5 w-2.5 fill-current" aria-hidden="true" />
                <span>STOP</span>
              </button>
            </div>
          </div>
        )}
      </div>
    </>
  );
}
`,"/src/components/MyAppsView.tsx":`import { FormEvent, useEffect, useRef, useState } from 'react';
import {
  Camera,
  CheckCircle2,
  Crosshair,
  Film,
  Globe,
  MessageCircle,
  Mic,
  Play,
  Plus,
  Rocket,
  Scissors,
  Share2,
  Smartphone,
  Sparkles,
  Square,
  Trash2,
  Video,
} from 'lucide-react';
import { ClipItem, UniversalAppItem, VoiceChangerPreset } from '../types/clipkaro';
import {
  requestCameraPermission,
  saveVideoToNativeClipKaroFolder,
} from '../utils/androidPermissions';
import { formatSeconds } from '../utils/mediaGenerators';

interface MyAppsViewProps {
  clips: ClipItem[];
  floatingVisible: boolean;
  activeFloatingTarget: string;
  reactionMode: boolean;
  facecamEnabled: boolean;
  voiceChanger: VoiceChangerPreset;
  onUpdateReactionOptions: (partial: {
    reactionMode?: boolean;
    facecamEnabled?: boolean;
    voiceChanger?: VoiceChangerPreset;
  }) => void;
  onSaveClip?: (clip: ClipItem) => Promise<void>;
  onActivateFloatingForApp: (appName: string) => void;
  onStopFloatingButton: () => void;
  onViewAppClips: (appName: string) => void;
}

const VOICE_PRESETS: { id: VoiceChangerPreset; label: string; hint: string }[] = [
  { id: 'normal', label: 'Normal', hint: 'Natural mic' },
  { id: 'funny', label: 'Funny', hint: 'High pitch' },
  { id: 'robot', label: 'Robot', hint: 'Synth mod' },
  { id: 'deep', label: 'Deep', hint: 'Heavy bass' },
];

const DEFAULT_UNIVERSAL_APPS: UniversalAppItem[] = [
  {
    id: 'app-youtube',
    name: 'YouTube',
    category: 'Videos & Shorts',
    androidPackage: 'com.google.android.youtube',
    webFallbackUrl: 'https://play.google.com/store/apps/details?id=com.google.android.youtube',
    accentColor: 'red',
    iconKey: 'youtube',
  },
  {
    id: 'app-instagram',
    name: 'Instagram',
    category: 'Reels & Stories',
    androidPackage: 'com.instagram.android',
    webFallbackUrl: 'https://play.google.com/store/apps/details?id=com.instagram.android',
    accentColor: 'fuchsia',
    iconKey: 'instagram',
  },
  {
    id: 'app-facebook',
    name: 'Facebook',
    category: 'Watch & Reels',
    androidPackage: 'com.facebook.katana',
    webFallbackUrl: 'https://play.google.com/store/apps/details?id=com.facebook.katana',
    accentColor: 'sky',
    iconKey: 'facebook',
  },
  {
    id: 'app-whatsapp',
    name: 'WhatsApp',
    category: 'Status & Video Calls',
    androidPackage: 'com.whatsapp',
    webFallbackUrl: 'https://play.google.com/store/apps/details?id=com.whatsapp',
    accentColor: 'emerald',
    iconKey: 'whatsapp',
  },
  {
    id: 'app-bgmi',
    name: 'BGMI',
    category: 'Battle Royale',
    androidPackage: 'com.pubg.imobile',
    webFallbackUrl: 'https://play.google.com/store/apps/details?id=com.pubg.imobile',
    accentColor: 'amber',
    iconKey: 'bgmi',
  },
];

const CUSTOM_APPS_STORAGE_KEY = 'clipkaro_custom_universal_apps';

function loadCustomApps(): UniversalAppItem[] {
  try {
    const raw = localStorage.getItem(CUSTOM_APPS_STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? (parsed as UniversalAppItem[]) : [];
  } catch {
    return [];
  }
}

function saveCustomApps(items: UniversalAppItem[]): void {
  try {
    localStorage.setItem(CUSTOM_APPS_STORAGE_KEY, JSON.stringify(items));
  } catch {
    // ignore storage errors
  }
}

function renderAppIcon(iconKey: UniversalAppItem['iconKey']) {
  switch (iconKey) {
    case 'youtube':
      return <Play className="h-5 w-5 text-red-400 fill-current" aria-hidden="true" />;
    case 'instagram':
      return <Camera className="h-5 w-5 text-fuchsia-400" aria-hidden="true" />;
    case 'facebook':
      return <Share2 className="h-5 w-5 text-sky-400" aria-hidden="true" />;
    case 'whatsapp':
      return <MessageCircle className="h-5 w-5 text-emerald-400" aria-hidden="true" />;
    case 'bgmi':
      return <Crosshair className="h-5 w-5 text-amber-400" aria-hidden="true" />;
    default:
      return <Globe className="h-5 w-5 text-violet-400" aria-hidden="true" />;
  }
}

export function MyAppsView({
  clips,
  floatingVisible,
  activeFloatingTarget,
  reactionMode,
  facecamEnabled,
  voiceChanger,
  onUpdateReactionOptions,
  onSaveClip,
  onActivateFloatingForApp,
  onStopFloatingButton,
  onViewAppClips,
}: MyAppsViewProps) {
  const [customApps, setCustomApps] = useState<UniversalAppItem[]>(() => loadCustomApps());
  const [newAppName, setNewAppName] = useState<string>('');
  const [newAppPackage, setNewAppPackage] = useState<string>('');
  const [statusMessage, setStatusMessage] = useState<string | null>(null);

  // In-App Reaction Studio Player + "Save Clip" (Selected Part) state
  const [reactionPlatformLabel, setReactionPlatformLabel] = useState<string>('YouTube');
  const [reactionPartStart, setReactionPartStart] = useState<number>(0);
  const [reactionPartEnd, setReactionPartEnd] = useState<number>(15);
  const [reactionVideoUrl, setReactionVideoUrl] = useState<string | null>(null);
  const [isSavingReactionPart, setIsSavingReactionPart] = useState<boolean>(false);
  const [reactionFacecamSizePx, setReactionFacecamSizePx] = useState<number>(120);
  const [reactionCamActive, setReactionCamActive] = useState<boolean>(false);
  const [reactionPreviewRequested, setReactionPreviewRequested] = useState<boolean>(false);
  const reactionCamVideoRef = useRef<HTMLVideoElement | null>(null);
  const reactionSourceVideoRef = useRef<HTMLVideoElement | null>(null);

  useEffect(() => {
    if (!reactionMode || !reactionPreviewRequested) {
      setReactionCamActive(false);
      return;
    }
    let activeStream: MediaStream | null = null;
    let cancelled = false;
    if (navigator.mediaDevices?.getUserMedia) {
      navigator.mediaDevices
        .getUserMedia({ video: { facingMode: 'user', width: 320, height: 320 }, audio: false })
        .then((stream) => {
          if (cancelled) {
            stream.getTracks().forEach((t) => t.stop());
            return;
          }
          activeStream = stream;
          if (reactionCamVideoRef.current) {
            reactionCamVideoRef.current.srcObject = stream;
            reactionCamVideoRef.current.play().catch(() => undefined);
            setReactionCamActive(true);
          }
        })
        .catch(() => {
          setReactionCamActive(false);
        });
    }
    return () => {
      cancelled = true;
      activeStream?.getTracks().forEach((t) => t.stop());
    };
  }, [reactionMode, reactionPreviewRequested]);

  useEffect(() => {
    return () => {
      if (reactionVideoUrl) URL.revokeObjectURL(reactionVideoUrl);
    };
  }, [reactionVideoUrl]);

  const allApps = [...DEFAULT_UNIVERSAL_APPS, ...customApps];

  const handleToggleFacecam = () => {
    const next = !facecamEnabled;
    if (next) {
      requestCameraPermission();
    }
    onUpdateReactionOptions({ facecamEnabled: next });
  };

  const handleToggleReactionMode = () => {
    const next = !reactionMode;
    if (next) {
      requestCameraPermission();
      onUpdateReactionOptions({ reactionMode: true, facecamEnabled: true });
    } else {
      onUpdateReactionOptions({ reactionMode: false });
    }
  };

  const handleAddCustomApp = (e: FormEvent) => {
    e.preventDefault();
    if (!newAppName.trim()) return;
    const pkg = newAppPackage.trim() || 'com.android.chrome';
    const item: UniversalAppItem = {
      id: \`app-custom-\${Date.now()}\`,
      name: newAppName.trim(),
      category: 'Custom App',
      androidPackage: pkg,
      webFallbackUrl: \`https://play.google.com/store/apps/details?id=\${encodeURIComponent(pkg)}\`,
      accentColor: 'violet',
      iconKey: 'custom',
      isCustom: true,
    };
    const next = [...customApps, item];
    setCustomApps(next);
    saveCustomApps(next);
    setNewAppName('');
    setNewAppPackage('');
  };

  const handleRemoveCustomApp = (id: string) => {
    const next = customApps.filter((a) => a.id !== id);
    setCustomApps(next);
    saveCustomApps(next);
  };

  const handleOpenAppWithFloatingButton = (app: UniversalAppItem) => {
    if (facecamEnabled || reactionMode) {
      requestCameraPermission();
    }
    onActivateFloatingForApp(app.name);

    const win = window as unknown as {
      Android?: {
        startFloatingWithOptions?: (
          pkg: string,
          fallbackUrl: string,
          appName: string,
          reactionMode: boolean,
          facecamEnabled: boolean,
          voiceEffect: string
        ) => string;
        startFloatingAndLaunchGame?: (pkg: string, fallbackUrl: string, appName: string) => string;
        stopFloatingService?: () => void;
        canDrawOverlays?: () => boolean;
        requestOverlayPermission?: () => void;
      };
    };

    const launchFn = win.Android?.startFloatingWithOptions
      ? () =>
          win.Android!.startFloatingWithOptions!(
            app.androidPackage,
            app.webFallbackUrl,
            app.name,
            reactionMode,
            facecamEnabled,
            voiceChanger
          )
      : win.Android?.startFloatingAndLaunchGame
        ? () =>
            win.Android!.startFloatingAndLaunchGame!(
              app.androidPackage,
              app.webFallbackUrl,
              app.name
            )
        : null;

    if (launchFn) {
      const outcome = launchFn();
      if (outcome === 'overlay_required') {
        setStatusMessage(
          \`Overlay Permission needed to show the 32dp Floating CLIP button over \${app.name}.\`
        );
      } else {
        setStatusMessage(
          \`Floating CLIP started for \${app.name}\${
            reactionMode ? ' · Reaction Mode (120dp Facecam + Mic)' : facecamEnabled ? ' · Facecam ON' : ''
          }\${voiceChanger !== 'normal' ? \` · \${voiceChanger.toUpperCase()} Voice\` : ''}.\`
        );
      }
      return;
    }

    setStatusMessage(
      \`Universal Floating CLIP active for \${app.name}\${
        reactionMode ? ' · Reaction Mode + 120dp Facecam ON' : facecamEnabled ? ' · 120dp Facecam ON' : ''
      } — tap the 32dp circle to record.\`
    );
  };

  const handleStopFloating = () => {
    onStopFloatingButton();
    const win = window as unknown as {
      Android?: { stopFloatingService?: () => void };
    };
    win.Android?.stopFloatingService?.();
    setStatusMessage('Floating CLIP button stopped.');
  };

  const handleSaveSelectedReactionPart = async () => {
    if (!onSaveClip || isSavingReactionPart) return;
    const partDur = Math.max(5, Math.min(60, reactionPartEnd - reactionPartStart));
    setIsSavingReactionPart(true);
    try {
      const canvas = document.createElement('canvas');
      canvas.width = 960;
      canvas.height = 540;
      const ctx = canvas.getContext('2d')!;
      const stream = canvas.captureStream(24);
      const mime = MediaRecorder.isTypeSupported('video/webm;codecs=vp9')
        ? 'video/webm;codecs=vp9'
        : 'video/webm';
      const recorder = new MediaRecorder(stream, { mimeType: mime, videoBitsPerSecond: 2_500_000 });
      const chunks: BlobPart[] = [];
      recorder.ondataavailable = (ev) => {
        if (ev.data && ev.data.size > 0) chunks.push(ev.data);
      };

      const renderMs = Math.min(2400, partDur * 180);
      const started = performance.now();
      let thumbDataUrl: string | undefined;

      await new Promise<void>((resolve) => {
        recorder.onstop = () => resolve();
        recorder.start(150);

        const draw = () => {
          const now = performance.now();
          const elapsed = now - started;
          const t = elapsed / 1000;

          if (reactionSourceVideoRef.current && reactionSourceVideoRef.current.readyState >= 2) {
            ctx.drawImage(reactionSourceVideoRef.current, 0, 0, canvas.width, canvas.height);
          } else {
            const g = ctx.createLinearGradient(0, 0, canvas.width, canvas.height);
            g.addColorStop(0, '#0f172a');
            g.addColorStop(1, '#1e1b4b');
            ctx.fillStyle = g;
            ctx.fillRect(0, 0, canvas.width, canvas.height);
            ctx.fillStyle = 'rgba(255,255,255,0.92)';
            ctx.font = '700 28px system-ui, sans-serif';
            ctx.fillText(\`\${reactionPlatformLabel} Reaction Clip\`, 42, 74);
            ctx.fillStyle = '#38bdf8';
            ctx.font = '600 18px system-ui, sans-serif';
            ctx.fillText(
              \`Selected Part: \${formatSeconds(reactionPartStart)} → \${formatSeconds(reactionPartEnd)} (\${partDur}s) · Voice: \${voiceChanger}\`,
              42,
              112
            );
          }

          // Corner Circular Facecam (matching 120dp circle!)
          const camRadius = Math.round(reactionFacecamSizePx * 0.55);
          const camCx = canvas.width - camRadius - 32;
          const camCy = camRadius + 32;
          ctx.save();
          ctx.beginPath();
          ctx.arc(camCx, camCy, camRadius, 0, Math.PI * 2);
          ctx.closePath();
          ctx.clip();
          if (reactionCamVideoRef.current && reactionCamVideoRef.current.readyState >= 2) {
            ctx.drawImage(
              reactionCamVideoRef.current,
              camCx - camRadius,
              camCy - camRadius,
              camRadius * 2,
              camRadius * 2
            );
          } else {
            ctx.fillStyle = '#0f766e';
            ctx.fillRect(camCx - camRadius, camCy - camRadius, camRadius * 2, camRadius * 2);
            ctx.fillStyle = '#ffffff';
            ctx.font = '700 18px system-ui, sans-serif';
            ctx.textAlign = 'center';
            ctx.fillText('FACECAM', camCx, camCy + 6);
            ctx.textAlign = 'left';
          }
          ctx.restore();

          ctx.strokeStyle = '#f43f5e';
          ctx.lineWidth = 4;
          ctx.beginPath();
          ctx.arc(camCx, camCy, camRadius, 0, Math.PI * 2);
          ctx.stroke();

          ctx.fillStyle = 'rgba(0,0,0,0.65)';
          ctx.fillRect(34, canvas.height - 54, 340, 32);
          ctx.fillStyle = '#e2e8f0';
          ctx.font = '600 14px monospace';
          ctx.fillText(\`Reaction Part \${(t * 3).toFixed(1)}s · #ClipKaro\`, 44, canvas.height - 33);

          if (!thumbDataUrl && elapsed > 200) {
            try {
              thumbDataUrl = canvas.toDataURL('image/jpeg', 0.8);
            } catch {
              // ignore
            }
          }

          if (elapsed < renderMs) {
            requestAnimationFrame(draw);
          } else {
            recorder.stop();
          }
        };
        requestAnimationFrame(draw);
      });

      stream.getTracks().forEach((t) => t.stop());
      const blob = new Blob(chunks, { type: mime });
      const fileName = \`ClipKaro_Reaction_\${reactionPlatformLabel}_\${partDur}s_\${Date.now()}.webm\`;

      await onSaveClip({
        id: \`reaction-\${Date.now()}\`,
        title: \`\${reactionPlatformLabel} Reaction (\${formatSeconds(reactionPartStart)}–\${formatSeconds(reactionPartEnd)})\`,
        platform: 'studio',
        gameTag: reactionPlatformLabel,
        durationSec: partDur,
        trimStart: 0,
        trimEnd: partDur,
        createdAt: Date.now(),
        copyrightSafe: true,
        isReaction: true,
        hasFacecam: true,
        voiceChanger,
        autoCaption: 'Live Reaction!',
        thumbnailDataUrl: thumbDataUrl,
        permission: {
          hasPermission: true,
          streamerName: 'MyReaction',
          originalVideoLink: '',
          creditText: 'Reaction · #ClipKaro',
        },
        videoBlob: blob,
        videoMimeType: blob.type || 'video/webm',
        nativeFileName: fileName,
        voiceVolume: 1,
        musicVolume: 0.3,
        originalVolume: 1,
      });
      await saveVideoToNativeClipKaroFolder(fileName, blob);
      setStatusMessage(
        \`Saved \${partDur}s Reaction Clip with Facecam in corner to My Clips & ClipKaro folder!\`
      );
    } finally {
      setIsSavingReactionPart(false);
    }
  };

  return (
    <div className="space-y-7">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <div className="inline-flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-rose-400">
            <Smartphone className="h-3.5 w-3.5" aria-hidden="true" />
            <span>Universal Floating Button</span>
          </div>
          <h1 className="mt-1 font-display text-2xl font-bold tracking-tight text-white">
            My Apps
          </h1>
          <p className="mt-1 text-sm text-slate-400">
            Tap any app to open it with the 32dp 60% transparent Expand / Collapse CLIP button for 10s–60s, Full Video, Game/Video Sound + Mic, and Auto Continuous Clips.
          </p>
        </div>

        {floatingVisible && (
          <button
            type="button"
            onClick={handleStopFloating}
            className="inline-flex items-center gap-2 rounded-lg border border-rose-500/40 bg-rose-950/30 px-3.5 py-2 text-xs font-bold text-rose-200 hover:bg-rose-900/40 whitespace-nowrap shrink-0"
          >
            <Square className="h-3.5 w-3.5 fill-current" aria-hidden="true" />
            <span>Stop Floating Bubble ({activeFloatingTarget})</span>
          </button>
        )}
      </div>

      {statusMessage && (
        <div className="flex items-center gap-2 rounded-xl border border-emerald-500/40 bg-emerald-950/30 px-4 py-3 text-xs font-semibold text-emerald-200">
          <CheckCircle2 className="h-4 w-4 text-emerald-400 shrink-0" aria-hidden="true" />
          <span>{statusMessage}</span>
        </div>
      )}

      {/* Pre-Recording Facecam, Voice Changer & Reaction Mode Studio */}
      <section
        aria-label="Facecam, Voice Changer & Reaction Mode"
        className="rounded-xl border border-slate-800 bg-[#121722] p-4 sm:p-5 space-y-4"
      >
        <div className="flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between">
          <div>
            <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-teal-400">
              <Video className="h-3.5 w-3.5" aria-hidden="true" />
              <span>Facecam + Voice Changer + Reaction Mode</span>
            </div>
            <p className="mt-0.5 text-xs text-slate-400">
              Turn ON before opening YouTube, Instagram, Facebook, or BGMI. Front camera + screen record together with live Mic Voice Changer.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              role="switch"
              aria-checked={facecamEnabled}
              onClick={handleToggleFacecam}
              className={\`inline-flex items-center gap-1.5 rounded-lg border px-3 py-2 text-xs font-bold transition-colors \${
                facecamEnabled
                  ? 'border-emerald-500/60 bg-emerald-500/20 text-emerald-200'
                  : 'border-slate-700 bg-[#0B0E14] text-slate-300 hover:border-slate-500'
              }\`}
            >
              <Camera className="h-3.5 w-3.5" aria-hidden="true" />
              <span>Facecam (120dp Circle): {facecamEnabled ? 'ON' : 'OFF'}</span>
            </button>

            <button
              type="button"
              role="switch"
              aria-checked={reactionMode}
              onClick={handleToggleReactionMode}
              className={\`inline-flex items-center gap-1.5 rounded-lg border px-3 py-2 text-xs font-bold transition-colors \${
                reactionMode
                  ? 'border-rose-500/70 bg-rose-600/25 text-rose-200'
                  : 'border-slate-700 bg-[#0B0E14] text-slate-300 hover:border-slate-500'
              }\`}
            >
              <Sparkles className="h-3.5 w-3.5" aria-hidden="true" />
              <span>Reaction Mode: {reactionMode ? 'ON' : 'OFF'}</span>
            </button>
          </div>
        </div>

        {/* Voice Changer Selector (Normal / Funny / Robot / Deep) */}
        <div className="flex flex-col gap-2 border-t border-slate-800/80 pt-3 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex items-center gap-2 text-xs font-semibold text-slate-300">
            <Mic className="h-4 w-4 text-violet-400 shrink-0" aria-hidden="true" />
            <span>Voice Changer (Applied to Mic in Recording):</span>
          </div>
          <div className="grid grid-cols-4 gap-1.5 sm:w-auto">
            {VOICE_PRESETS.map((preset) => {
              const selected = voiceChanger === preset.id;
              return (
                <button
                  key={preset.id}
                  type="button"
                  onClick={() => onUpdateReactionOptions({ voiceChanger: preset.id })}
                  className={\`rounded-lg border px-3 py-1.5 text-center transition-colors \${
                    selected
                      ? 'border-violet-400 bg-violet-600 text-white'
                      : 'border-slate-700 bg-[#0B0E14] text-slate-300 hover:border-slate-500'
                  }\`}
                >
                  <div className="text-xs font-bold">{preset.label}</div>
                  <div className="text-[10px] opacity-80 hidden sm:block">{preset.hint}</div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Reaction Mode Preview + Selected Part "Save Clip" Panel */}
        {reactionMode && (
          <div className="rounded-xl border border-rose-500/40 bg-[#0B0E14] p-4 space-y-3">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div>
                <div className="text-sm font-bold text-white">
                  Reaction Studio · Video + Facecam + Mic ({voiceChanger.toUpperCase()})
                </div>
                <p className="text-xs text-slate-400">
                  Watch YouTube / Instagram / Facebook normally or load a video here, then tap Save Clip for only your selected part with corner Facecam.
                </p>
              </div>
              <label className="cursor-pointer rounded-lg border border-slate-700 bg-slate-800 px-3 py-1.5 text-xs font-semibold text-slate-200 hover:bg-slate-700">
                <span>Load Local Video</span>
                <input
                  type="file"
                  accept="video/*"
                  className="hidden"
                  onChange={(e) => {
                    const file = e.target.files?.[0];
                    if (!file) return;
                    if (reactionVideoUrl) URL.revokeObjectURL(reactionVideoUrl);
                    setReactionVideoUrl(URL.createObjectURL(file));
                  }}
                />
              </label>
            </div>

            <div className="relative aspect-video w-full overflow-hidden rounded-lg border border-slate-800 bg-black">
              {reactionVideoUrl ? (
                <video
                  ref={reactionSourceVideoRef}
                  src={reactionVideoUrl}
                  controls
                  playsInline
                  className="h-full w-full object-contain"
                />
              ) : (
                <div className="flex h-full w-full flex-col items-center justify-center gap-2 bg-gradient-to-br from-slate-900 to-indigo-950 p-4 text-center">
                  <Play className="h-8 w-8 text-rose-400" aria-hidden="true" />
                  <div className="text-sm font-semibold text-white">
                    {reactionPlatformLabel} Reaction Feed Ready
                  </div>
                  <div className="text-xs text-slate-400 max-w-md">
                    Launch {reactionPlatformLabel} below with the Floating CLIP button + 120dp corner Facecam, or pick Start/End seconds right here to test Save Clip!
                  </div>
                </div>
              )}

              {/* Live 120dp Circular Corner Facecam Preview (Tap to test/resize; auto-opens on Record Start) */}
              <button
                type="button"
                onClick={() => {
                  if (!reactionPreviewRequested) {
                    setReactionPreviewRequested(true);
                  } else {
                    setReactionFacecamSizePx((s) => (s === 120 ? 148 : s === 148 ? 96 : 120));
                  }
                }}
                title="Tap to preview/resize Facecam circle (opens automatically on Record Start)"
                style={{ width: \`\${reactionFacecamSizePx}px\`, height: \`\${reactionFacecamSizePx}px\` }}
                className="absolute top-3 right-3 overflow-hidden rounded-full border-2 border-rose-500 bg-emerald-900 shadow-2xl flex items-center justify-center"
              >
                <video
                  ref={reactionCamVideoRef}
                  muted
                  playsInline
                  className={\`h-full w-full object-cover \${reactionCamActive ? 'block' : 'hidden'}\`}
                />
                {!reactionCamActive && (
                  <div className="flex flex-col items-center text-white px-2 text-center">
                    <Camera className="h-5 w-5 text-emerald-300" aria-hidden="true" />
                    <span className="mt-0.5 text-[9px] font-bold">
                      {facecamEnabled ? \`Opens on Record (\${reactionFacecamSizePx}dp)\` : 'Facecam OFF'}
                    </span>
                  </div>
                )}
              </button>
            </div>

            <div className="flex flex-col gap-2.5 sm:flex-row sm:items-center sm:justify-between">
              <div className="flex flex-wrap items-center gap-2 text-xs">
                <select
                  value={reactionPlatformLabel}
                  onChange={(e) => setReactionPlatformLabel(e.target.value)}
                  aria-label="Reaction app label"
                  className="rounded-lg border border-slate-700 bg-[#121722] px-2.5 py-1.5 text-white"
                >
                  <option value="YouTube">YouTube</option>
                  <option value="Instagram">Instagram</option>
                  <option value="Facebook">Facebook</option>
                </select>
                <label className="flex items-center gap-1 text-slate-300">
                  <span>Start (s):</span>
                  <input
                    type="number"
                    min={0}
                    max={600}
                    value={reactionPartStart}
                    onChange={(e) => setReactionPartStart(Math.max(0, Number(e.target.value)))}
                    className="w-16 rounded border border-slate-700 bg-[#121722] px-2 py-1 text-white tabular-nums"
                  />
                </label>
                <label className="flex items-center gap-1 text-slate-300">
                  <span>End (s):</span>
                  <input
                    type="number"
                    min={5}
                    max={660}
                    value={reactionPartEnd}
                    onChange={(e) =>
                      setReactionPartEnd(Math.max(reactionPartStart + 5, Number(e.target.value)))
                    }
                    className="w-16 rounded border border-slate-700 bg-[#121722] px-2 py-1 text-white tabular-nums"
                  />
                </label>
              </div>

              <button
                type="button"
                disabled={isSavingReactionPart}
                onClick={() => void handleSaveSelectedReactionPart()}
                className="inline-flex items-center justify-center gap-1.5 rounded-lg bg-rose-600 px-4 py-2 text-xs font-bold text-white hover:bg-rose-500 disabled:opacity-60"
              >
                <Scissors className="h-3.5 w-3.5" aria-hidden="true" />
                <span>
                  {isSavingReactionPart
                    ? 'Saving Reaction Clip…'
                    : \`Save Clip (\${Math.max(5, reactionPartEnd - reactionPartStart)}s)\`}
                </span>
              </button>
            </div>
          </div>
        )}
      </section>

      {/* Apps Grid */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {allApps.map((app) => {
          const clipCount = clips.filter(
            (c) => c.gameTag.toLowerCase() === app.name.toLowerCase()
          ).length;
          const isCurrentTarget =
            floatingVisible && activeFloatingTarget.toLowerCase() === app.name.toLowerCase();

          return (
            <article
              key={app.id}
              className={\`flex flex-col justify-between gap-4 rounded-xl border p-4 transition-colors \${
                isCurrentTarget
                  ? 'border-rose-500/70 bg-[#171E2C]'
                  : 'border-slate-800 bg-[#121722]'
              }\`}
            >
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-center gap-3 min-w-0">
                  <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl border border-slate-700/80 bg-[#0B0E14]">
                    {renderAppIcon(app.iconKey)}
                  </span>
                  <div className="min-w-0">
                    <div className="flex items-center gap-2">
                      <h2 className="font-display text-base font-bold text-white truncate">
                        {app.name}
                      </h2>
                      {isCurrentTarget && (
                        <span className="inline-flex items-center gap-1 text-[10px] font-bold text-emerald-400">
                          <span className="h-1.5 w-1.5 rounded-full bg-emerald-400 animate-pulse" />
                          Active
                        </span>
                      )}
                    </div>
                    <div className="mt-0.5 flex items-center gap-1.5 text-xs text-slate-400 tabular-nums">
                      <span className="truncate">{app.category}</span>
                      <span aria-hidden="true">·</span>
                      <span className="shrink-0">
                        {clipCount} {clipCount === 1 ? 'clip' : 'clips'}
                      </span>
                    </div>
                  </div>
                </div>

                {app.isCustom && (
                  <button
                    type="button"
                    onClick={() => handleRemoveCustomApp(app.id)}
                    aria-label={\`Remove \${app.name}\`}
                    className="rounded p-1 text-slate-500 hover:bg-slate-800 hover:text-rose-300 shrink-0"
                  >
                    <Trash2 className="h-3.5 w-3.5" aria-hidden="true" />
                  </button>
                )}
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => handleOpenAppWithFloatingButton(app)}
                  className="inline-flex flex-1 items-center justify-center gap-2 rounded-lg bg-rose-600 px-3.5 py-2.5 text-xs font-bold text-white transition-colors hover:bg-rose-500 whitespace-nowrap"
                >
                  <Rocket className="h-3.5 w-3.5" aria-hidden="true" />
                  <span>Open with Floating CLIP</span>
                </button>
                <button
                  type="button"
                  onClick={() => onViewAppClips(app.name)}
                  title={\`View \${app.name} clips\`}
                  className="inline-flex items-center justify-center gap-1 rounded-lg border border-slate-700 bg-[#0B0E14] px-3 py-2.5 text-xs font-semibold text-slate-200 hover:border-slate-500 hover:text-white shrink-0"
                >
                  <Film className="h-3.5 w-3.5" aria-hidden="true" />
                  <span>Clips</span>
                </button>
              </div>
            </article>
          );
        })}
      </div>

      {/* Add Custom App */}
      <form
        onSubmit={handleAddCustomApp}
        className="flex flex-col gap-3 rounded-xl border border-slate-800 bg-[#121722] p-4 sm:flex-row sm:items-end"
      >
        <div className="flex-1 space-y-1.5">
          <label htmlFor="custom-app-name" className="block text-xs font-semibold text-slate-300">
            Add Another App
          </label>
          <input
            id="custom-app-name"
            type="text"
            value={newAppName}
            onChange={(e) => setNewAppName(e.target.value)}
            placeholder="e.g. Chrome, Twitch, Hotstar"
            className="w-full rounded-lg border border-slate-700/80 bg-[#0B0E14] px-3.5 py-2 text-sm text-white placeholder:text-slate-500 focus:border-rose-500 focus:outline-none"
          />
        </div>
        <div className="sm:w-64 space-y-1.5">
          <label htmlFor="custom-app-pkg" className="block text-xs font-semibold text-slate-300">
            Android Package (optional)
          </label>
          <input
            id="custom-app-pkg"
            type="text"
            value={newAppPackage}
            onChange={(e) => setNewAppPackage(e.target.value)}
            placeholder="e.g. tv.twitch.android.app"
            className="w-full rounded-lg border border-slate-700/80 bg-[#0B0E14] px-3.5 py-2 text-sm text-white placeholder:text-slate-500 focus:border-rose-500 focus:outline-none"
          />
        </div>
        <button
          type="submit"
          disabled={!newAppName.trim()}
          className="inline-flex items-center justify-center gap-2 rounded-lg bg-rose-600 px-4 py-2 text-sm font-semibold text-white hover:bg-rose-500 disabled:opacity-50 whitespace-nowrap shrink-0"
        >
          <Plus className="h-4 w-4" aria-hidden="true" />
          <span>Add App</span>
        </button>
      </form>

      {/* Universal Floating Capabilities Summary */}
      <div className="grid grid-cols-1 gap-3 sm:grid-cols-3 rounded-xl border border-slate-800 bg-[#121722] p-4 text-xs text-slate-300">
        <div className="flex items-start gap-2.5">
          <Scissors className="h-4 w-4 text-rose-400 shrink-0 mt-0.5" aria-hidden="true" />
          <div>
            <div className="font-bold text-white">32dp 60% Transparent Expand / Collapse</div>
            <div className="text-slate-400 mt-0.5">
              Tap the tiny 32dp circle to expand 180dp+ controls; auto-collapses to RED dot + timer on record.
            </div>
          </div>
        </div>
        <div className="flex items-start gap-2.5">
          <MessageCircle className="h-4 w-4 text-sky-400 shrink-0 mt-0.5" aria-hidden="true" />
          <div>
            <div className="font-bold text-white">Game/Video Sound + Mic</div>
            <div className="text-slate-400 mt-0.5">
              Switch between Game/Video Only, Mic Only, or Game+Mic Both on any app.
            </div>
          </div>
        </div>
        <div className="flex items-start gap-2.5">
          <Film className="h-4 w-4 text-emerald-400 shrink-0 mt-0.5" aria-hidden="true" />
          <div>
            <div className="font-bold text-white">Auto Continuous Clips</div>
            <div className="text-slate-400 mt-0.5">
              Works for normal YouTube, Instagram, Facebook &amp; WhatsApp videos too until STOP.
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
`,"/src/components/MyClipsView.tsx":`import { useEffect, useMemo, useRef, useState } from 'react';
import {
  CheckCircle2,
  Download,
  ExternalLink,
  Eye,
  EyeOff,
  Film,
  Flame,
  FolderSync,
  HardDrive,
  Image as ImageIcon,
  Mic,
  Music,
  Play,
  Scissors,
  Search,
  Share2,
  ShieldCheck,
  SlidersHorizontal,
  Sparkles,
  Star,
  Trash2,
  Wand2,
  X,
} from 'lucide-react';
import { ClipItem, GameItem, WorkspaceTab } from '../types/clipkaro';
import {
  formatSeconds,
  generateRoyaltyFreeWavBlob,
  generateSampleStreamVideoBlob,
  ROYALTY_FREE_TRACKS,
} from '../utils/mediaGenerators';
import { shareClipToPlatform, ShareTargetPlatform } from '../utils/androidPermissions';
import {
  calculateClipsStorageBytes,
  findExpiredClips,
  formatStorageBytes,
} from '../utils/mediaStorage';
import {
  combineCssFilters,
  EFFECT_MODES,
  FILTER_PRESETS,
  getAspectContainerClass,
  getSpeedAtTime,
} from '../utils/videoEditorPresets';
import { AiAutoEditAnalysis, runAiAutoEdit } from '../utils/aiAutoEditor';
import {
  calculateViralScore,
  prepareExportVideoBlobWithViralScore,
} from '../utils/viralScore';
import { AiAutoEditModal } from './AiAutoEditModal';
import { ClipEditorModal, EditorTab } from './ClipEditorModal';
import { ViralScoreExportDialog } from './ViralScoreExportDialog';

interface MyClipsViewProps {
  clips: ClipItem[];
  games: GameItem[];
  initialGameFilter?: string;
  initialPlayClipId?: string | null;
  onClearInitialPlayClip?: () => void;
  isNativeAndroid?: boolean;
  autoDelete7Days?: boolean;
  keepBestClips?: boolean;
  showViralScoreInApp?: boolean;
  onToggleShowViralScoreInApp?: () => void;
  onToggleClipHideScore?: (clip: ClipItem) => Promise<void>;
  onToggleAutoDelete7Days?: () => void | Promise<void>;
  onToggleKeepBestClips?: () => void;
  onRunSmartCleanupNow?: () => Promise<number>;
  onToggleFavouriteClip?: (clip: ClipItem) => Promise<void>;
  onSyncClipKaroFolder?: () => Promise<number>;
  onDeleteClip: (id: string) => Promise<void>;
  onSaveClip: (clip: ClipItem) => Promise<void>;
  onNavigate: (tab: WorkspaceTab) => void;
}

type ClipFilterMode = 'all' | 'favourites' | 'permission' | 'voice' | 'music';
type ClipSortMode = 'newest' | 'viral';

export function MyClipsView({
  clips,
  games,
  initialGameFilter = 'all',
  initialPlayClipId,
  onClearInitialPlayClip,
  isNativeAndroid = false,
  autoDelete7Days = false,
  keepBestClips = true,
  showViralScoreInApp = true,
  onToggleShowViralScoreInApp,
  onToggleClipHideScore,
  onToggleAutoDelete7Days,
  onToggleKeepBestClips,
  onRunSmartCleanupNow,
  onToggleFavouriteClip,
  onSyncClipKaroFolder,
  onDeleteClip,
  onSaveClip,
  onNavigate,
}: MyClipsViewProps) {
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [gameFilter, setGameFilter] = useState<string>(initialGameFilter);
  const [filterMode, setFilterMode] = useState<ClipFilterMode>('all');
  const [sortMode, setSortMode] = useState<ClipSortMode>('newest');

  // Active Player Modal State
  const [playingClip, setPlayingClip] = useState<ClipItem | null>(null);
  const [editingClip, setEditingClip] = useState<ClipItem | null>(null);
  const [editorInitialTab, setEditorInitialTab] = useState<EditorTab>('trim');
  const [shareNotice, setShareNotice] = useState<string | null>(null);
  const [activeVideoUrl, setActiveVideoUrl] = useState<string | null>(null);
  const [activeVoiceUrl, setActiveVoiceUrl] = useState<string | null>(null);
  const [activeMusicUrl, setActiveMusicUrl] = useState<string | null>(null);
  const [activeProofUrl, setActiveProofUrl] = useState<string | null>(null);

  // Viral Score Share/Export Prompt & Per-Clip Long-Press State
  const [pendingExportAction, setPendingExportAction] = useState<{
    clip: ClipItem;
    kind: 'share' | 'download';
    platform?: ShareTargetPlatform;
  } | null>(null);
  const [isExportingViralChoice, setIsExportingViralChoice] = useState<boolean>(false);
  const [longPressClip, setLongPressClip] = useState<ClipItem | null>(null);
  const longPressTimerRef = useRef<number | null>(null);
  const longPressStartPosRef = useRef<{ x: number; y: number } | null>(null);

  // AI Auto Edit State
  const [aiEditingClipId, setAiEditingClipId] = useState<string | null>(null);
  const [aiStatusText, setAiStatusText] = useState<string>('');
  const [aiComparisonState, setAiComparisonState] = useState<{
    originalClip: ClipItem;
    analysis: AiAutoEditAnalysis;
  } | null>(null);

  // Delete & Folder Sync State
  const [clipPendingDelete, setClipPendingDelete] = useState<ClipItem | null>(null);
  const [isDeleting, setIsDeleting] = useState<boolean>(false);
  const [isSyncingFolder, setIsSyncingFolder] = useState<boolean>(false);

  // Quick sample creation in My Clips
  const [isCreatingSample, setIsCreatingSample] = useState<boolean>(false);
  const [samplePct, setSamplePct] = useState<number>(0);

  const playerVideoRef = useRef<HTMLVideoElement | null>(null);
  const playerVoiceRef = useRef<HTMLAudioElement | null>(null);
  const playerMusicRef = useRef<HTMLAudioElement | null>(null);

  useEffect(() => {
    setGameFilter(initialGameFilter || 'all');
  }, [initialGameFilter]);

  useEffect(() => {
    if (!initialPlayClipId) return;
    const match = clips.find((c) => c.id === initialPlayClipId);
    if (match) {
      setPlayingClip(match);
      onClearInitialPlayClip?.();
    }
  }, [clips, initialPlayClipId, onClearInitialPlayClip]);

  const totalStorageLabel = useMemo(
    () => formatStorageBytes(calculateClipsStorageBytes(clips)),
    [clips]
  );

  const expiredClipsCount = useMemo(
    () => findExpiredClips(clips, keepBestClips).length,
    [clips, keepBestClips]
  );

  const favouriteClipsCount = useMemo(
    () => clips.filter((c) => c.isFavourite).length,
    [clips]
  );

  // Create and revoke object URLs whenever playingClip changes
  useEffect(() => {
    if (!playingClip) {
      setActiveVideoUrl(null);
      setActiveVoiceUrl(null);
      setActiveMusicUrl(null);
      setActiveProofUrl(null);
      return;
    }

    const vUrl = URL.createObjectURL(playingClip.videoBlob);
    const voUrl = playingClip.voiceBlob ? URL.createObjectURL(playingClip.voiceBlob) : null;
    const muUrl = playingClip.musicBlob ? URL.createObjectURL(playingClip.musicBlob) : null;
    const prUrl =
      playingClip.permission.proofBlob &&
      playingClip.permission.proofMimeType?.startsWith('image/')
        ? URL.createObjectURL(playingClip.permission.proofBlob)
        : null;

    setActiveVideoUrl(vUrl);
    setActiveVoiceUrl(voUrl);
    setActiveMusicUrl(muUrl);
    setActiveProofUrl(prUrl);

    return () => {
      URL.revokeObjectURL(vUrl);
      if (voUrl) URL.revokeObjectURL(voUrl);
      if (muUrl) URL.revokeObjectURL(muUrl);
      if (prUrl) URL.revokeObjectURL(prUrl);
    };
  }, [playingClip]);

  // Sync audio track volumes when player mounts
  useEffect(() => {
    if (!playingClip) return;
    if (playerVideoRef.current) {
      playerVideoRef.current.volume = playingClip.originalVolume ?? 1;
    }
    if (playerVoiceRef.current) {
      playerVoiceRef.current.volume = playingClip.voiceVolume ?? 1;
    }
    if (playerMusicRef.current) {
      playerMusicRef.current.volume = playingClip.musicVolume ?? 0.45;
    }
  }, [playingClip, activeVideoUrl, activeVoiceUrl, activeMusicUrl]);

  const filteredClips = useMemo(() => {
    const matched = clips.filter((clip) => {
      const q = searchQuery.trim().toLowerCase();
      if (q) {
        const matchesTitle = clip.title.toLowerCase().includes(q);
        const matchesCredit = clip.permission.creditText.toLowerCase().includes(q);
        const matchesGame = clip.gameTag.toLowerCase().includes(q);
        if (!matchesTitle && !matchesCredit && !matchesGame) return false;
      }
      if (gameFilter !== 'all' && clip.gameTag !== gameFilter) return false;
      if (filterMode === 'favourites' && !clip.isFavourite) return false;
      if (filterMode === 'permission' && !clip.permission.hasPermission) return false;
      if (filterMode === 'voice' && !clip.voiceBlob) return false;
      if (filterMode === 'music' && !clip.musicBlob) return false;
      return true;
    });

    if (sortMode === 'viral') {
      return [...matched].sort((a, b) => {
        const diff = calculateViralScore(b).score - calculateViralScore(a).score;
        return diff !== 0 ? diff : b.createdAt - a.createdAt;
      });
    }
    return matched;
  }, [clips, searchQuery, gameFilter, filterMode, sortMode]);

  const handlePlayerLoadedMetadata = () => {
    const vEl = playerVideoRef.current;
    if (!vEl || !playingClip) return;
    if (playingClip.trimStart > 0 && playingClip.trimStart < vEl.duration) {
      vEl.currentTime = playingClip.trimStart;
    }
    vEl.play().catch(() => undefined);
  };

  const handlePlayerPlay = () => {
    const vEl = playerVideoRef.current;
    if (!vEl || !playingClip) return;
    const offset = Math.max(0, vEl.currentTime - playingClip.trimStart);
    vEl.playbackRate = getSpeedAtTime(playingClip.speedSegments, offset);
    if (playerVoiceRef.current) {
      playerVoiceRef.current.currentTime = Math.min(
        offset,
        playerVoiceRef.current.duration || offset
      );
      playerVoiceRef.current.play().catch(() => undefined);
    }
    if (playerMusicRef.current) {
      playerMusicRef.current.currentTime =
        playerMusicRef.current.duration > 0 ? offset % playerMusicRef.current.duration : 0;
      playerMusicRef.current.play().catch(() => undefined);
    }
  };

  const handlePlayerPause = () => {
    playerVoiceRef.current?.pause();
    playerMusicRef.current?.pause();
  };

  const handlePlayerTimeUpdate = () => {
    const vEl = playerVideoRef.current;
    if (!vEl || !playingClip) return;
    const offset = Math.max(0, vEl.currentTime - playingClip.trimStart);
    const segSpeed = getSpeedAtTime(playingClip.speedSegments, offset);
    if (Math.abs(vEl.playbackRate - segSpeed) > 0.01) {
      vEl.playbackRate = segSpeed;
    }
    if (playingClip.trimEnd > playingClip.trimStart && vEl.currentTime >= playingClip.trimEnd) {
      vEl.pause();
      vEl.currentTime = playingClip.trimStart;
      playerVoiceRef.current?.pause();
      playerMusicRef.current?.pause();
    }
  };

  const handleConfirmDelete = async () => {
    if (!clipPendingDelete) return;
    setIsDeleting(true);
    try {
      await onDeleteClip(clipPendingDelete.id);
      if (playingClip?.id === clipPendingDelete.id) {
        setPlayingClip(null);
      }
      setClipPendingDelete(null);
    } finally {
      setIsDeleting(false);
    }
  };

  const handleCreateDemoClip = async () => {
    setIsCreatingSample(true);
    setSamplePct(0);
    try {
      const blob = await generateSampleStreamVideoBlob({
        durationSec: 10,
        title: 'Clutch Arena Highlight',
        creditLine: 'Credit: @AlexPlays',
        onProgress: setSamplePct,
      });
      const sampleClip: ClipItem = {
        id: \`clip-\${Date.now()}-\${Math.random().toString(36).slice(2, 6)}\`,
        title: 'Clutch Arena Highlight',
        platform: 'youtube',
        gameTag: games[0]?.name || 'Valorant & Tactical FPS',
        durationSec: 10,
        trimStart: 0,
        trimEnd: 10,
        createdAt: Date.now(),
        copyrightSafe: true,
        permission: {
          hasPermission: true,
          streamerName: 'AlexPlays',
          originalVideoLink: 'https://www.youtube.com/watch?v=aqz-KE-bpKQ',
          creditText: 'Credit: @AlexPlays',
        },
        videoBlob: blob,
        videoMimeType: blob.type || 'video/webm',
        voiceVolume: 1,
        musicVolume: 0.45,
        originalVolume: 1,
      };
      await onSaveClip(sampleClip);
    } finally {
      setIsCreatingSample(false);
    }
  };

  const handleRequestShareClip = (clip: ClipItem, platform: ShareTargetPlatform) => {
    setPendingExportAction({ clip, kind: 'share', platform });
  };

  const handleRequestDownloadClip = (clip: ClipItem) => {
    setPendingExportAction({ clip, kind: 'download' });
  };

  const handleConfirmExportViralChoice = async (includeScoreOnVideo: boolean) => {
    if (!pendingExportAction) return;
    setIsExportingViralChoice(true);
    try {
      const { clip, kind, platform } = pendingExportAction;
      const prepared = await prepareExportVideoBlobWithViralScore(clip, includeScoreOnVideo);

      if (kind === 'share' && platform) {
        const captionBase = clip.autoCaption || 'What a Headshot!';
        const msg = await shareClipToPlatform({
          platform,
          title: clip.title,
          gameTag: clip.gameTag,
          autoCaption:
            includeScoreOnVideo && prepared.scoreBadgeText
              ? \`\${captionBase} (\${prepared.scoreBadgeText})\`
              : captionBase,
          videoBlob: prepared.blob,
          videoMimeType: prepared.mimeType,
          nativeUri: prepared.nativeUri,
        });
        setShareNotice(includeScoreOnVideo ? \`\${msg} (With Viral Score)\` : \`\${msg} (Clean Video)\`);
      } else {
        const ext = prepared.mimeType.includes('mp4') ? 'mp4' : 'webm';
        const url = URL.createObjectURL(prepared.blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = \`\${clip.title.replace(/[^a-z0-9_-]/gi, '_')}\${
          includeScoreOnVideo ? '_Scored' : ''
        }.\${ext}\`;
        document.body.appendChild(a);
        a.click();
        a.remove();
        setTimeout(() => URL.revokeObjectURL(url), 2500);
        setShareNotice(
          includeScoreOnVideo
            ? 'Exported video with Viral Score badge!'
            : 'Saved clean video without Viral Score!'
        );
      }
      setPendingExportAction(null);
    } finally {
      setIsExportingViralChoice(false);
    }
  };

  const clearCardLongPress = () => {
    if (longPressTimerRef.current !== null) {
      window.clearTimeout(longPressTimerRef.current);
      longPressTimerRef.current = null;
    }
    longPressStartPosRef.current = null;
  };

  const handleOneTapTrendingMusicAndCaption = async (clip: ClipItem) => {
    const trendingTrack = ROYALTY_FREE_TRACKS[0];
    const musicBlob = generateRoyaltyFreeWavBlob(trendingTrack.id);
    const updated: ClipItem = {
      ...clip,
      musicBlob,
      musicName: trendingTrack.title,
      musicVolume: 0.45,
      originalVolume: 0.85,
      autoCaption: clip.autoCaption?.trim() || 'What a Headshot!',
    };
    await onSaveClip(updated);
    if (playingClip?.id === clip.id) {
      setPlayingClip(updated);
    }
    setShareNotice('Applied Trending Music + "What a Headshot!" caption in 1 tap!');
  };

  const handleRunAiAutoEdit = async (clip: ClipItem) => {
    if (aiEditingClipId) return;
    setAiEditingClipId(clip.id);
    setAiStatusText('AI analyzing clip…');
    try {
      const analysis = await runAiAutoEdit(clip, (stage) => {
        setAiStatusText(stage);
      });
      setAiComparisonState({ originalClip: clip, analysis });
    } catch {
      setShareNotice('AI Auto Edit could not process this clip. Try Edit Clip manually.');
    } finally {
      setAiEditingClipId(null);
      setAiStatusText('');
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <h1 className="font-display text-2xl font-bold tracking-tight text-white">My Clips</h1>
          <p className="mt-1 text-sm text-slate-400">
            Play saved video files with synced voiceovers, background music, and streamer attribution, or remove unwanted clips.
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2.5">
          {isNativeAndroid && onSyncClipKaroFolder && (
            <button
              type="button"
              disabled={isSyncingFolder}
              onClick={async () => {
                setIsSyncingFolder(true);
                try {
                  await onSyncClipKaroFolder();
                } finally {
                  setIsSyncingFolder(false);
                }
              }}
              className="inline-flex items-center gap-2 rounded-lg border border-slate-700 bg-[#121722] px-3.5 py-2 text-xs font-semibold text-slate-200 hover:border-slate-500 hover:text-white disabled:opacity-60 whitespace-nowrap shrink-0"
            >
              <FolderSync className="h-3.5 w-3.5 text-emerald-400" aria-hidden="true" />
              <span>{isSyncingFolder ? 'Syncing…' : 'Sync ClipKaro Folder'}</span>
            </button>
          )}
          <button
            type="button"
            disabled={isCreatingSample}
            onClick={handleCreateDemoClip}
            className="inline-flex items-center gap-2 rounded-lg border border-slate-700 bg-[#121722] px-3.5 py-2 text-xs font-semibold text-slate-200 hover:border-slate-500 hover:text-white disabled:opacity-60 whitespace-nowrap shrink-0"
          >
            <Sparkles className="h-3.5 w-3.5 text-rose-400" aria-hidden="true" />
            <span>
              {isCreatingSample ? \`Creating Demo (\${samplePct}%)\` : 'Create 10s Sample Clip'}
            </span>
          </button>
          <button
            type="button"
            onClick={() => onNavigate('cut')}
            className="inline-flex items-center gap-2 rounded-lg bg-rose-600 px-4 py-2 text-xs font-semibold text-white hover:bg-rose-500 whitespace-nowrap shrink-0"
          >
            <Scissors className="h-3.5 w-3.5" aria-hidden="true" />
            <span>Cut New Clip</span>
          </button>
        </div>
      </div>

      {/* Smart Storage Card */}
      <section
        aria-label="Smart Storage"
        className="flex flex-col gap-3 rounded-xl border border-slate-800 bg-[#121722] p-4 sm:flex-row sm:items-center sm:justify-between"
      >
        <div className="flex items-center gap-3">
          <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-amber-500/15 text-amber-400">
            <HardDrive className="h-5 w-5" aria-hidden="true" />
          </span>
          <div>
            <div className="flex flex-wrap items-center gap-2">
              <span className="font-display text-sm font-bold text-white">Smart Storage:</span>
              <span className="font-mono text-sm font-bold text-amber-300 tabular-nums">
                {totalStorageLabel}
              </span>
              <span className="text-xs text-slate-400 tabular-nums">
                ({clips.length} clips · {favouriteClipsCount} Best kept)
              </span>
            </div>
            <p className="text-xs text-slate-400">
              Auto-clean clips older than 7 days while protecting clips marked Favourite / Best.
            </p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            role="switch"
            aria-checked={autoDelete7Days}
            onClick={() => void onToggleAutoDelete7Days?.()}
            className={\`rounded-lg border px-3 py-1.5 text-xs font-bold transition-colors \${
              autoDelete7Days
                ? 'border-rose-500/60 bg-rose-600/20 text-rose-200'
                : 'border-slate-700 bg-[#0B0E14] text-slate-300 hover:border-slate-500'
            }\`}
          >
            Auto delete &gt; 7 days: {autoDelete7Days ? 'ON' : 'OFF'}
          </button>

          <button
            type="button"
            role="switch"
            aria-checked={keepBestClips}
            onClick={() => onToggleKeepBestClips?.()}
            className={\`rounded-lg border px-3 py-1.5 text-xs font-bold transition-colors \${
              keepBestClips
                ? 'border-amber-500/60 bg-amber-500/20 text-amber-200'
                : 'border-slate-700 bg-[#0B0E14] text-slate-300 hover:border-slate-500'
            }\`}
          >
            Keep Best Clips: {keepBestClips ? 'ON' : 'OFF'}
          </button>

          {onToggleShowViralScoreInApp && (
            <button
              type="button"
              role="switch"
              aria-checked={showViralScoreInApp}
              onClick={onToggleShowViralScoreInApp}
              className={\`rounded-lg border px-3 py-1.5 text-xs font-bold transition-colors \${
                showViralScoreInApp
                  ? 'border-emerald-500/60 bg-emerald-500/20 text-emerald-200'
                  : 'border-slate-700 bg-[#0B0E14] text-slate-300 hover:border-slate-500'
              }\`}
            >
              Show Viral Score in App: {showViralScoreInApp ? 'ON' : 'OFF'}
            </button>
          )}

          {expiredClipsCount > 0 && onRunSmartCleanupNow && (
            <button
              type="button"
              onClick={async () => {
                const removed = await onRunSmartCleanupNow();
                if (removed > 0) {
                  setShareNotice(\`Smart Storage cleaned \${removed} clip(s) older than 7 days.\`);
                }
              }}
              className="rounded-lg bg-rose-600 px-3 py-1.5 text-xs font-bold text-white hover:bg-rose-500"
            >
              Clean {expiredClipsCount} Old
            </button>
          )}
        </div>
      </section>

      {/* Filters */}
      <div className="flex flex-col gap-3 rounded-xl border border-slate-800 bg-[#121722] p-4 lg:flex-row lg:items-center lg:justify-between">
        <div className="flex flex-1 flex-col gap-3 sm:flex-row">
          <div className="relative flex-1">
            <Search
              className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-500"
              aria-hidden="true"
            />
            <input
              type="search"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search by title, @streamer, or game..."
              aria-label="Search clips"
              className="w-full rounded-lg border border-slate-700/80 bg-[#0B0E14] py-2 pl-9 pr-3 text-sm text-white placeholder:text-slate-500 focus:border-rose-500 focus:outline-none"
            />
          </div>

          <select
            value={gameFilter}
            onChange={(e) => setGameFilter(e.target.value)}
            aria-label="Filter by game"
            className="rounded-lg border border-slate-700/80 bg-[#0B0E14] px-3 py-2 text-sm text-white focus:border-rose-500 focus:outline-none"
          >
            <option value="all">All Games &amp; Apps</option>
            {games.map((g) => (
              <option key={g.id} value={g.name}>
                {g.name}
              </option>
            ))}
            <option value="YouTube">YouTube</option>
            <option value="Instagram">Instagram</option>
            <option value="Facebook">Facebook</option>
            <option value="WhatsApp">WhatsApp</option>
            <option value="Just Chatting & IRL">Just Chatting & IRL</option>
          </select>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <div className="flex items-center gap-1 overflow-x-auto rounded-lg border border-slate-800 bg-[#0B0E14] p-1">
            {(
              [
                { id: 'all', label: 'All' },
                { id: 'favourites', label: 'Best / Fav' },
                { id: 'permission', label: 'Permission Verified' },
                { id: 'voice', label: 'With Voice' },
                { id: 'music', label: 'With Music' },
              ] as { id: ClipFilterMode; label: string }[]
            ).map((tab) => (
              <button
                key={tab.id}
                type="button"
                onClick={() => setFilterMode(tab.id)}
                className={\`rounded-md px-3 py-1.5 text-xs font-medium whitespace-nowrap shrink-0 transition-colors \${
                  filterMode === tab.id
                    ? 'bg-slate-800 text-white'
                    : 'text-slate-400 hover:text-slate-200'
                }\`}
              >
                {tab.label}
              </button>
            ))}
          </div>

          <button
            type="button"
            onClick={() => setSortMode((prev) => (prev === 'viral' ? 'newest' : 'viral'))}
            className={\`inline-flex items-center gap-1.5 rounded-lg border px-3 py-2 text-xs font-bold whitespace-nowrap shrink-0 transition-colors \${
              sortMode === 'viral'
                ? 'border-amber-400/70 bg-amber-500/20 text-amber-200'
                : 'border-slate-700 bg-[#0B0E14] text-slate-300 hover:border-slate-500'
            }\`}
          >
            <Flame className="h-3.5 w-3.5 text-amber-400" aria-hidden="true" />
            <span>
              {sortMode === 'viral' ? 'Sorted: Viral Score (Highest First)' : 'Sort: Viral Score'}
            </span>
          </button>
        </div>
      </div>

      {shareNotice && (
        <div className="flex items-center justify-between gap-3 rounded-xl border border-emerald-500/40 bg-emerald-950/30 px-4 py-2.5 text-xs font-semibold text-emerald-200">
          <div className="flex items-center gap-2 min-w-0">
            <CheckCircle2 className="h-4 w-4 text-emerald-400 shrink-0" aria-hidden="true" />
            <span className="truncate">{shareNotice}</span>
          </div>
          <button
            type="button"
            onClick={() => setShareNotice(null)}
            aria-label="Dismiss notice"
            className="rounded p-1 text-emerald-300 hover:text-white shrink-0"
          >
            <X className="h-3.5 w-3.5" aria-hidden="true" />
          </button>
        </div>
      )}

      {/* Clips Grid or Empty State */}
      {filteredClips.length === 0 ? (
        <div className="flex flex-col items-center justify-center gap-4 rounded-xl border border-slate-800 bg-[#121722] px-6 py-16 text-center">
          <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-slate-800/80 text-slate-400">
            <Film className="h-6 w-6" aria-hidden="true" />
          </div>
          <div className="max-w-md space-y-1">
            <h2 className="font-display text-base font-semibold text-white">
              {clips.length === 0 ? 'No saved clips yet' : 'No clips match your filters'}
            </h2>
            <p className="text-sm text-slate-400">
              {clips.length === 0
                ? 'Cut a video file in Cut Video or generate a 10-second sample clip to test real playback and deletion.'
                : 'Try clearing your search query or switching back to All Games.'}
            </p>
          </div>
          <div className="flex flex-wrap items-center justify-center gap-3 pt-1">
            <button
              type="button"
              onClick={() => onNavigate('cut')}
              className="inline-flex items-center gap-2 rounded-lg bg-rose-600 px-4 py-2.5 text-sm font-semibold text-white hover:bg-rose-500"
            >
              <Scissors className="h-4 w-4" aria-hidden="true" />
              <span>Go to Cut Video</span>
            </button>
            {clips.length === 0 && (
              <button
                type="button"
                disabled={isCreatingSample}
                onClick={handleCreateDemoClip}
                className="inline-flex items-center gap-2 rounded-lg border border-slate-700 bg-slate-800 px-4 py-2.5 text-sm font-semibold text-white hover:bg-slate-700 disabled:opacity-60"
              >
                <Sparkles className="h-4 w-4 text-rose-400" aria-hidden="true" />
                <span>
                  {isCreatingSample ? \`Creating (\${samplePct}%)\` : 'Create 10s Sample Clip'}
                </span>
              </button>
            )}
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {filteredClips.map((clip) => {
            const viral = calculateViralScore(clip);
            const isAiBusy = aiEditingClipId === clip.id;
            const shouldShowViralOnCard = showViralScoreInApp && !clip.hideViralScore;

            return (
              <article
                key={clip.id}
                onPointerDown={(e) => {
                  clearCardLongPress();
                  longPressStartPosRef.current = { x: e.clientX, y: e.clientY };
                  longPressTimerRef.current = window.setTimeout(() => {
                    longPressTimerRef.current = null;
                    setLongPressClip(clip);
                  }, 500);
                }}
                onPointerMove={(e) => {
                  const start = longPressStartPosRef.current;
                  if (!start) return;
                  if (Math.hypot(e.clientX - start.x, e.clientY - start.y) > 10) {
                    clearCardLongPress();
                  }
                }}
                onPointerUp={clearCardLongPress}
                onPointerCancel={clearCardLongPress}
                onContextMenu={(e) => {
                  e.preventDefault();
                  clearCardLongPress();
                  setLongPressClip(clip);
                }}
                className="flex flex-col justify-between overflow-hidden rounded-xl border border-slate-800 bg-[#121722]"
              >
                <div>
                  {/* Thumbnail with duration scrim */}
                  <div className="relative aspect-video w-full bg-[#07090D] overflow-hidden">
                    {clip.thumbnailDataUrl ? (
                      <img
                        src={clip.thumbnailDataUrl}
                        alt={clip.title}
                        style={{ filter: combineCssFilters(clip.filterPreset, clip.effectMode) }}
                        className={\`h-full w-full \${
                          clip.fitMode === 'fit' ? 'object-contain' : 'object-cover'
                        }\`}
                        referrerPolicy="no-referrer"
                      />
                    ) : (
                      <div className="flex h-full w-full items-center justify-center bg-gradient-to-br from-slate-900 to-slate-800">
                        <Film className="h-9 w-9 text-slate-600" aria-hidden="true" />
                      </div>
                    )}
                    {clip.effectMode === 'cinematic' && (
                      <>
                        <div className="pointer-events-none absolute inset-x-0 top-0 h-[10%] bg-black" />
                        <div className="pointer-events-none absolute inset-x-0 bottom-0 h-[10%] bg-black" />
                      </>
                    )}
                    <div className="pointer-events-none absolute inset-x-0 bottom-0 h-14 bg-gradient-to-t from-black/85 via-black/40 to-transparent" />
                    <button
                      type="button"
                      onClick={() => void onToggleFavouriteClip?.(clip)}
                      title={clip.isFavourite ? 'Marked Best / Keep Forever' : 'Mark as Best / Favourite'}
                      aria-label={clip.isFavourite ? 'Unmark Best clip' : 'Mark as Best clip'}
                      className={\`absolute top-2.5 right-2.5 flex h-8 w-8 items-center justify-center rounded-full border backdrop-blur-sm transition-colors \${
                        clip.isFavourite
                          ? 'border-amber-400 bg-amber-500/90 text-slate-950'
                          : 'border-slate-600/80 bg-black/60 text-slate-200 hover:border-amber-400 hover:text-amber-300'
                      }\`}
                    >
                      <Star
                        className={\`h-4 w-4 \${clip.isFavourite ? 'fill-current' : ''}\`}
                        aria-hidden="true"
                      />
                    </button>
                    <span className="absolute bottom-2.5 right-3 font-mono text-xs font-semibold text-white tabular-nums">
                      {formatSeconds(clip.durationSec)}
                    </span>
                  </div>

                  {/* Metadata (Zero-pill discipline: unboxed text with separators) */}
                  <div className="space-y-2 p-4">
                    <div className="flex items-center justify-between gap-2">
                      <h3 className="font-display text-base font-semibold text-white truncate">
                        {clip.title}
                      </h3>
                      {clip.isFavourite && (
                        <span className="text-[11px] font-bold text-amber-300 shrink-0">
                          ★ Best
                        </span>
                      )}
                    </div>

                    {/* Viral Score + Tip (App-only; hidden if Settings OFF or long-pressed Hide Score) */}
                    {shouldShowViralOnCard ? (
                      <div
                        className={\`rounded-lg border px-2.5 py-2 \${
                          viral.tier === 'high'
                            ? 'border-emerald-500/40 bg-emerald-950/25'
                            : viral.tier === 'medium'
                              ? 'border-amber-500/40 bg-amber-950/20'
                              : 'border-slate-700/80 bg-[#0B0E14]'
                        }\`}
                      >
                        <div className="flex items-center gap-1.5 text-xs font-bold">
                          <Flame
                            className={\`h-3.5 w-3.5 shrink-0 \${
                              viral.tier === 'high'
                                ? 'text-emerald-400'
                                : viral.tier === 'medium'
                                  ? 'text-amber-400'
                                  : 'text-slate-400'
                            }\`}
                            aria-hidden="true"
                          />
                          <span
                            className={
                              viral.tier === 'high'
                                ? 'text-emerald-200'
                                : viral.tier === 'medium'
                                  ? 'text-amber-200'
                                  : 'text-slate-200'
                            }
                          >
                            {viral.label}
                          </span>
                        </div>
                        <div className="mt-0.5 text-[11px] text-slate-400">
                          Tip: {viral.tip}
                        </div>
                      </div>
                    ) : showViralScoreInApp && clip.hideViralScore ? (
                      <div className="text-[11px] text-slate-500 italic">
                        Score hidden · Long-press clip to Show Score
                      </div>
                    ) : null}

                    <div className="flex flex-wrap items-center gap-x-2 gap-y-1 text-xs text-slate-400 tabular-nums">
                      <span>{clip.durationSec} sec</span>
                      <span aria-hidden="true">·</span>
                      <span className="capitalize">{clip.platform}</span>
                      <span aria-hidden="true">·</span>
                      <span className="truncate max-w-[160px]">{clip.gameTag}</span>
                      {clip.isReaction && (
                        <>
                          <span aria-hidden="true">·</span>
                          <span className="font-semibold text-teal-300">Reaction</span>
                        </>
                      )}
                      {clip.voiceChanger && clip.voiceChanger !== 'normal' && (
                        <>
                          <span aria-hidden="true">·</span>
                          <span className="capitalize text-violet-300">{clip.voiceChanger} Voice</span>
                        </>
                      )}
                      {clip.aspectRatio && clip.aspectRatio !== '16:9' && (
                        <>
                          <span aria-hidden="true">·</span>
                          <span className="font-semibold text-rose-300">{clip.aspectRatio}</span>
                        </>
                      )}
                      {clip.effectMode && clip.effectMode !== 'none' && (
                        <>
                          <span aria-hidden="true">·</span>
                          <span className="text-amber-300">
                            {EFFECT_MODES.find((m) => m.id === clip.effectMode)?.label}
                          </span>
                        </>
                      )}
                      {clip.speedSegments &&
                        clip.speedSegments.some((s) => s.speed !== 1) && (
                          <>
                            <span aria-hidden="true">·</span>
                            <span className="text-sky-300">
                              {clip.speedSegments.length > 1
                                ? 'Split Speed'
                                : \`\${clip.speedSegments[0].speed}x\`}
                            </span>
                          </>
                        )}
                    </div>

                    <div className="text-xs text-slate-300 font-mono truncate">
                      {clip.permission.creditText}
                    </div>

                    <div className="flex flex-wrap items-center gap-x-3 gap-y-1 pt-0.5 text-xs text-slate-400">
                      {clip.permission.hasPermission && (
                        <span className="inline-flex items-center gap-1 text-emerald-400">
                          <ShieldCheck className="h-3.5 w-3.5" aria-hidden="true" />
                          <span>Permission verified</span>
                        </span>
                      )}
                      {clip.voiceBlob && (
                        <span className="inline-flex items-center gap-1 text-sky-400">
                          <Mic className="h-3.5 w-3.5" aria-hidden="true" />
                          <span>Voice</span>
                        </span>
                      )}
                      {clip.musicBlob && (
                        <span className="inline-flex items-center gap-1 text-amber-400">
                          <Music className="h-3.5 w-3.5" aria-hidden="true" />
                          <span>Music</span>
                        </span>
                      )}
                    </div>
                  </div>
                </div>

                {/* AI Auto Edit 1-Tap Action Strip */}
                <div className="border-t border-slate-800/80 bg-[#0F1520] px-4 py-2">
                  <button
                    type="button"
                    disabled={Boolean(aiEditingClipId)}
                    onClick={() => void handleRunAiAutoEdit(clip)}
                    className="inline-flex w-full items-center justify-center gap-2 rounded-lg border border-amber-500/50 bg-gradient-to-r from-amber-500/20 via-rose-500/20 to-violet-500/20 px-3 py-2 text-xs font-bold text-amber-200 transition-colors hover:border-amber-400 hover:text-white disabled:opacity-60"
                  >
                    <Wand2 className="h-3.5 w-3.5 text-amber-400" aria-hidden="true" />
                    <span>
                      {isAiBusy
                        ? aiStatusText || 'AI Auto Editing…'
                        : 'AI Auto Edit (Best 15s + Music + Cinematic)'}
                    </span>
                  </button>
                </div>

                {/* 1-Tap Share Bar (#BGMI #ClipKaro) */}
                <div className="flex items-center justify-between gap-1.5 border-t border-slate-800/80 bg-[#0B0E14]/60 px-4 py-2">
                  <span className="inline-flex items-center gap-1 text-[10px] font-semibold text-slate-400 shrink-0">
                    <Share2 className="h-3 w-3 text-rose-400" aria-hidden="true" />
                    <span>Share:</span>
                  </span>
                  <div className="flex items-center gap-1">
                    <button
                      type="button"
                      onClick={() => handleRequestShareClip(clip, 'youtube')}
                      className="rounded bg-red-600/90 px-2 py-1 text-[10px] font-bold text-white hover:bg-red-500"
                    >
                      YT Shorts
                    </button>
                    <button
                      type="button"
                      onClick={() => handleRequestShareClip(clip, 'instagram')}
                      className="rounded bg-fuchsia-600/90 px-2 py-1 text-[10px] font-bold text-white hover:bg-fuchsia-500"
                    >
                      Reels
                    </button>
                    <button
                      type="button"
                      onClick={() => handleRequestShareClip(clip, 'whatsapp')}
                      className="rounded bg-emerald-600/90 px-2 py-1 text-[10px] font-bold text-white hover:bg-emerald-500"
                    >
                      WhatsApp
                    </button>
                  </div>
                </div>

                {/* Card Actions: Play, Thumbnail, Edit & Delete */}
                <div className="flex items-center gap-1.5 border-t border-slate-800/80 px-4 py-3">
                  <button
                    type="button"
                    onClick={() => setPlayingClip(clip)}
                    className="inline-flex flex-1 items-center justify-center gap-1.5 rounded-lg bg-rose-600 px-3 py-2 text-xs font-semibold text-white transition-colors hover:bg-rose-500 whitespace-nowrap"
                  >
                    <Play className="h-3.5 w-3.5 fill-current" aria-hidden="true" />
                    <span>Play</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setEditorInitialTab('thumbnail');
                      setEditingClip(clip);
                    }}
                    title="Thumbnail Maker (1 VS 4 CLUTCH)"
                    className="inline-flex items-center justify-center gap-1 rounded-lg border border-slate-700 bg-[#0B0E14] px-2.5 py-2 text-xs font-semibold text-amber-300 transition-colors hover:border-amber-400 hover:text-amber-200 whitespace-nowrap shrink-0"
                  >
                    <ImageIcon className="h-3.5 w-3.5" aria-hidden="true" />
                    <span>Thumb</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setEditorInitialTab('trim');
                      setEditingClip(clip);
                    }}
                    className="inline-flex items-center justify-center gap-1 rounded-lg border border-slate-700 bg-[#0B0E14] px-2.5 py-2 text-xs font-semibold text-slate-200 transition-colors hover:border-rose-500 hover:text-white whitespace-nowrap shrink-0"
                  >
                    <SlidersHorizontal className="h-3.5 w-3.5" aria-hidden="true" />
                    <span>Edit</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setClipPendingDelete(clip)}
                    aria-label="Delete clip"
                    className="inline-flex items-center justify-center rounded-lg border border-slate-700 bg-[#0B0E14] p-2 text-slate-300 transition-colors hover:border-rose-500/60 hover:bg-rose-950/30 hover:text-rose-200 shrink-0"
                  >
                    <Trash2 className="h-3.5 w-3.5" aria-hidden="true" />
                  </button>
                </div>
              </article>
            );
          })}
        </div>
      )}

      {/* Actual File Clip Player Modal */}
      {playingClip && activeVideoUrl && (
        <div
          role="dialog"
          aria-modal="true"
          aria-labelledby="clip-player-title"
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4 backdrop-blur-sm"
        >
          <div className="w-full max-w-4xl overflow-hidden rounded-xl border border-slate-800 bg-[#121722] shadow-2xl max-h-[92vh] overflow-y-auto">
            <div className="flex items-center justify-between gap-4 border-b border-slate-800 px-5 py-4">
              <div className="min-w-0">
                <h2 id="clip-player-title" className="font-display text-lg font-bold text-white truncate">
                  {playingClip.title}
                </h2>
                <div className="mt-0.5 flex flex-wrap items-center gap-2 text-xs text-slate-400 tabular-nums">
                  <span>{playingClip.durationSec} sec</span>
                  <span aria-hidden="true">·</span>
                  <span className="font-mono text-slate-200">{playingClip.permission.creditText}</span>
                  <span aria-hidden="true">·</span>
                  <span>{playingClip.gameTag}</span>
                  {playingClip.aspectRatio && (
                    <>
                      <span aria-hidden="true">·</span>
                      <span className="text-rose-300 font-semibold">
                        {playingClip.aspectRatio} ({playingClip.fitMode === 'fit' ? 'Fit' : 'Fill'})
                      </span>
                    </>
                  )}
                  {playingClip.filterPreset && playingClip.filterPreset !== 'none' && (
                    <>
                      <span aria-hidden="true">·</span>
                      <span className="text-amber-300">
                        {FILTER_PRESETS.find((f) => f.id === playingClip.filterPreset)?.label}
                      </span>
                    </>
                  )}
                  {playingClip.effectMode && playingClip.effectMode !== 'none' && (
                    <>
                      <span aria-hidden="true">·</span>
                      <span className="text-amber-200">
                        {EFFECT_MODES.find((m) => m.id === playingClip.effectMode)?.label} Mode
                      </span>
                    </>
                  )}
                </div>
              </div>
              <button
                type="button"
                onClick={() => setPlayingClip(null)}
                aria-label="Close player"
                className="rounded-lg p-2 text-slate-400 hover:bg-slate-800 hover:text-white shrink-0"
              >
                <X className="h-5 w-5" aria-hidden="true" />
              </button>
            </div>

            <div className="relative flex items-center justify-center bg-[#06080D] p-2">
              <div
                className={\`relative overflow-hidden bg-black \${getAspectContainerClass(
                  playingClip.aspectRatio ?? '16:9'
                )}\`}
              >
                <video
                  ref={playerVideoRef}
                  src={activeVideoUrl}
                  controls
                  playsInline
                  onLoadedMetadata={handlePlayerLoadedMetadata}
                  onPlay={handlePlayerPlay}
                  onPause={handlePlayerPause}
                  onTimeUpdate={handlePlayerTimeUpdate}
                  style={{
                    filter: combineCssFilters(playingClip.filterPreset, playingClip.effectMode),
                  }}
                  className={\`h-full w-full \${
                    playingClip.fitMode === 'fit' ? 'object-contain' : 'object-cover'
                  }\`}
                />
                {playingClip.effectMode === 'cinematic' && (
                  <>
                    <div className="pointer-events-none absolute inset-x-0 top-0 h-[11%] bg-black" />
                    <div className="pointer-events-none absolute inset-x-0 bottom-0 h-[11%] bg-black" />
                  </>
                )}
                {playingClip.autoCaption && (
                  <div className="pointer-events-none absolute inset-x-0 bottom-12 flex justify-center px-4">
                    <span className="rounded bg-black px-3 py-1 text-xs font-bold text-white shadow">
                      {playingClip.autoCaption}
                    </span>
                  </div>
                )}
              </div>
              {activeVoiceUrl && (
                <audio ref={playerVoiceRef} src={activeVoiceUrl} className="hidden" />
              )}
              {activeMusicUrl && (
                <audio ref={playerMusicRef} src={activeMusicUrl} loop className="hidden" />
              )}
            </div>

            <div className="grid grid-cols-1 gap-4 p-5 sm:grid-cols-2">
              <div className="space-y-2 text-xs text-slate-300">
                <div className="font-semibold text-white">Attribution & Audio Mix</div>
                <p className="font-mono text-slate-200">{playingClip.permission.creditText}</p>
                {playingClip.permission.originalVideoLink && (
                  <a
                    href={playingClip.permission.originalVideoLink}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1.5 text-rose-400 hover:text-rose-300"
                  >
                    <span>Original Video Link</span>
                    <ExternalLink className="h-3.5 w-3.5" aria-hidden="true" />
                  </a>
                )}
                <div className="flex flex-wrap items-center gap-3 pt-1 text-slate-400 tabular-nums">
                  <span>Original Audio: {Math.round((playingClip.originalVolume ?? 1) * 100)}%</span>
                  {playingClip.voiceName && (
                    <span>
                      Voice ({playingClip.voiceName}): {Math.round(playingClip.voiceVolume * 100)}%
                    </span>
                  )}
                  {playingClip.musicName && (
                    <span>
                      Music ({playingClip.musicName}): {Math.round(playingClip.musicVolume * 100)}%
                    </span>
                  )}
                </div>
              </div>

              <div className="flex flex-col items-start justify-between gap-3 sm:items-end">
                {activeProofUrl ? (
                  <div className="flex items-center gap-2.5 rounded-lg border border-slate-800 bg-[#0B0E14] p-2">
                    <img
                      src={activeProofUrl}
                      alt="Streamer permission proof"
                      className="h-10 w-10 rounded object-cover"
                      referrerPolicy="no-referrer"
                    />
                    <div className="text-xs">
                      <div className="font-medium text-emerald-300">Permission Proof</div>
                      <div className="text-slate-400 truncate max-w-[160px]">
                        {playingClip.permission.proofFileName}
                      </div>
                    </div>
                  </div>
                ) : playingClip.permission.proofFileName ? (
                  <div className="text-xs text-emerald-300">
                    Proof attached: {playingClip.permission.proofFileName}
                  </div>
                ) : null}

                <div className="flex flex-wrap items-center gap-2">
                  <button
                    type="button"
                    disabled={Boolean(aiEditingClipId)}
                    onClick={() => {
                      const target = playingClip;
                      setPlayingClip(null);
                      void handleRunAiAutoEdit(target);
                    }}
                    className="inline-flex items-center gap-1.5 rounded-lg border border-amber-400/60 bg-amber-500/20 px-3 py-2 text-xs font-bold text-amber-200 hover:bg-amber-500/30 disabled:opacity-60"
                  >
                    <Wand2 className="h-3.5 w-3.5" aria-hidden="true" />
                    <span>AI Auto Edit</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => void handleOneTapTrendingMusicAndCaption(playingClip)}
                    className="inline-flex items-center gap-1.5 rounded-lg bg-amber-500 px-3 py-2 text-xs font-bold text-slate-950 hover:bg-amber-400"
                  >
                    <Sparkles className="h-3.5 w-3.5" aria-hidden="true" />
                    <span>1-Tap Trending + Caption</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      const target = playingClip;
                      setPlayingClip(null);
                      setEditorInitialTab('thumbnail');
                      setEditingClip(target);
                    }}
                    className="inline-flex items-center gap-1.5 rounded-lg border border-amber-500/40 bg-[#0B0E14] px-3 py-2 text-xs font-semibold text-amber-300 hover:border-amber-400"
                  >
                    <ImageIcon className="h-3.5 w-3.5" aria-hidden="true" />
                    <span>Thumbnail</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      const target = playingClip;
                      setPlayingClip(null);
                      setEditorInitialTab('trim');
                      setEditingClip(target);
                    }}
                    className="inline-flex items-center gap-1.5 rounded-lg bg-rose-600 px-3.5 py-2 text-xs font-semibold text-white hover:bg-rose-500"
                  >
                    <SlidersHorizontal className="h-3.5 w-3.5" aria-hidden="true" />
                    <span>Edit Clip</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => handleRequestDownloadClip(playingClip)}
                    className="inline-flex items-center gap-2 rounded-lg border border-slate-700 bg-[#0B0E14] px-3.5 py-2 text-xs font-semibold text-white hover:bg-slate-800"
                  >
                    <Download className="h-3.5 w-3.5" aria-hidden="true" />
                    <span>Download File</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setClipPendingDelete(playingClip)}
                    className="inline-flex items-center gap-1.5 rounded-lg border border-rose-500/40 bg-rose-950/30 px-3.5 py-2 text-xs font-semibold text-rose-200 hover:bg-rose-900/40"
                  >
                    <Trash2 className="h-3.5 w-3.5" aria-hidden="true" />
                    <span>Delete Clip</span>
                  </button>
                </div>

                {/* 1-Tap Share inside Player Modal */}
                <div className="flex flex-wrap items-center gap-1.5 pt-1">
                  <span className="text-[11px] font-semibold text-slate-400 mr-1">
                    Share (#BGMI #ClipKaro):
                  </span>
                  <button
                    type="button"
                    onClick={() => handleRequestShareClip(playingClip, 'youtube')}
                    className="rounded-md bg-red-600 px-2.5 py-1 text-[11px] font-bold text-white hover:bg-red-500"
                  >
                    YouTube Shorts
                  </button>
                  <button
                    type="button"
                    onClick={() => handleRequestShareClip(playingClip, 'instagram')}
                    className="rounded-md bg-fuchsia-600 px-2.5 py-1 text-[11px] font-bold text-white hover:bg-fuchsia-500"
                  >
                    Instagram Reels
                  </button>
                  <button
                    type="button"
                    onClick={() => handleRequestShareClip(playingClip, 'whatsapp')}
                    className="rounded-md bg-emerald-600 px-2.5 py-1 text-[11px] font-bold text-white hover:bg-emerald-500"
                  >
                    WhatsApp
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Long-Press Per-Clip Options Menu (Hide Score / Show Score) */}
      {longPressClip && (
        <div
          role="dialog"
          aria-modal="true"
          aria-label="Clip Options"
          className="fixed inset-0 z-[75] flex items-center justify-center bg-black/75 p-4 backdrop-blur-sm"
          onClick={() => setLongPressClip(null)}
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="w-full max-w-xs rounded-2xl border border-slate-700 bg-[#121722] p-4 shadow-2xl space-y-2.5"
          >
            <div className="flex items-center justify-between gap-2 border-b border-slate-800 pb-2.5">
              <div className="min-w-0">
                <div className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
                  Clip Options
                </div>
                <div className="text-sm font-bold text-white truncate">{longPressClip.title}</div>
              </div>
              <button
                type="button"
                onClick={() => setLongPressClip(null)}
                aria-label="Close options"
                className="rounded p-1 text-slate-400 hover:text-white"
              >
                <X className="h-4 w-4" aria-hidden="true" />
              </button>
            </div>

            {onToggleClipHideScore && (
              <button
                type="button"
                onClick={async () => {
                  const target = longPressClip;
                  setLongPressClip(null);
                  await onToggleClipHideScore(target);
                  setShareNotice(
                    target.hideViralScore
                      ? \`Viral Score shown for "\${target.title}"\`
                      : \`Viral Score hidden for "\${target.title}"\`
                  );
                }}
                className="flex w-full items-center gap-2.5 rounded-xl border border-amber-500/40 bg-amber-500/15 px-3.5 py-2.5 text-xs font-bold text-amber-200 hover:bg-amber-500/25"
              >
                {longPressClip.hideViralScore ? (
                  <Eye className="h-4 w-4 text-amber-400" aria-hidden="true" />
                ) : (
                  <EyeOff className="h-4 w-4 text-amber-400" aria-hidden="true" />
                )}
                <span>{longPressClip.hideViralScore ? 'Show Score' : 'Hide Score'}</span>
              </button>
            )}

            {onToggleFavouriteClip && (
              <button
                type="button"
                onClick={async () => {
                  const target = longPressClip;
                  setLongPressClip(null);
                  await onToggleFavouriteClip(target);
                }}
                className="flex w-full items-center gap-2.5 rounded-xl border border-slate-700 bg-[#0B0E14] px-3.5 py-2.5 text-xs font-semibold text-slate-200 hover:border-slate-500"
              >
                <Star className="h-4 w-4 text-amber-400" aria-hidden="true" />
                <span>{longPressClip.isFavourite ? 'Remove Best / Fav' : 'Mark as Best / Fav'}</span>
              </button>
            )}

            <button
              type="button"
              onClick={() => setLongPressClip(null)}
              className="w-full rounded-xl border border-slate-800 bg-slate-900 px-3.5 py-2 text-xs font-semibold text-slate-400 hover:text-white"
            >
              Cancel
            </button>
          </div>
        </div>
      )}

      {/* Share / Save Prompt: Show Viral Score on video? YES / NO */}
      {pendingExportAction && (
        <ViralScoreExportDialog
          isOpen={Boolean(pendingExportAction)}
          actionLabel={
            pendingExportAction.kind === 'share'
              ? \`sharing to \${
                  pendingExportAction.platform === 'youtube'
                    ? 'YouTube Shorts'
                    : pendingExportAction.platform === 'instagram'
                      ? 'Instagram Reels'
                      : 'WhatsApp'
                }\`
              : 'saving/downloading video'
          }
          viralScore={calculateViralScore(pendingExportAction.clip).score}
          isProcessing={isExportingViralChoice}
          onChoose={(includeScore) => void handleConfirmExportViralChoice(includeScore)}
          onCancel={() => setPendingExportAction(null)}
        />
      )}

      {/* AI Auto Edit Compare Modal (Original vs AI Edited) */}
      {aiComparisonState && (
        <AiAutoEditModal
          originalClip={aiComparisonState.originalClip}
          analysis={aiComparisonState.analysis}
          onSaveClip={onSaveClip}
          onClose={() => setAiComparisonState(null)}
          onCompleteNotice={(msg) => setShareNotice(msg)}
        />
      )}

      {/* In-App Clip Editor Modal (Trim/Cut + Add Music + Add Voiceover + Thumbnail Maker + Save) */}
      {editingClip && (
        <ClipEditorModal
          clip={editingClip}
          initialTab={editorInitialTab}
          onSaveClip={async (savedClip) => {
            await onSaveClip(savedClip);
            setEditingClip(savedClip);
          }}
          onClose={() => setEditingClip(null)}
        />
      )}

      {/* Delete Confirmation Modal */}
      {clipPendingDelete && (
        <div
          role="alertdialog"
          aria-modal="true"
          aria-labelledby="delete-confirm-title"
          aria-describedby="delete-confirm-desc"
          className="fixed inset-0 z-[60] flex items-center justify-center bg-black/80 p-4 backdrop-blur-sm"
        >
          <div className="w-full max-w-md rounded-xl border border-slate-800 bg-[#121722] p-6 shadow-2xl space-y-4">
            <div className="space-y-1.5">
              <h2 id="delete-confirm-title" className="font-display text-lg font-bold text-white">
                Delete this clip?
              </h2>
              <p id="delete-confirm-desc" className="text-sm text-slate-400">
                Are you sure you want to permanently delete{' '}
                <span className="font-semibold text-slate-200">{clipPendingDelete.title}</span>? This
                removes the video file and any attached voice or music tracks from My Clips.
              </p>
            </div>
            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                type="button"
                disabled={isDeleting}
                onClick={() => setClipPendingDelete(null)}
                className="rounded-lg border border-slate-700 bg-[#0B0E14] px-4 py-2 text-sm font-semibold text-slate-200 hover:bg-slate-800"
              >
                Cancel
              </button>
              <button
                type="button"
                disabled={isDeleting}
                onClick={handleConfirmDelete}
                className="rounded-lg bg-rose-600 px-4 py-2 text-sm font-semibold text-white hover:bg-rose-500 disabled:opacity-60"
              >
                {isDeleting ? 'Deleting…' : 'Confirm Delete'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
`,"/src/components/MyGamesView.tsx":`import { FormEvent, useEffect, useRef, useState } from 'react';
import {
  Box,
  Car,
  Crosshair,
  Film,
  Flame,
  Gamepad2,
  Plus,
  Rocket,
  Scissors,
  Shield,
  Sparkles,
  Swords,
  Target,
  Trash2,
  X,
} from 'lucide-react';
import { ClipItem, GameItem } from '../types/clipkaro';
import { generateSampleStreamVideoBlob } from '../utils/mediaGenerators';

interface MyGamesViewProps {
  games: GameItem[];
  clips: ClipItem[];
  onAddGame: (name: string, genre: string) => Promise<void>;
  onDeleteCustomGame: (id: string) => Promise<void>;
  onViewGameClips: (gameName: string) => void;
  onCutClipForGame: (gameName: string) => void;
  onSaveClip: (clip: ClipItem) => Promise<void>;
  onActivateFloatingButton?: (gameName: string) => void;
}

const CUSTOM_GAME_CARD: GameItem = {
  id: 'game-custom-launcher',
  name: 'Custom Game',
  genre: 'Custom Title',
  coverUrl: '/src/assets/images/game_tactical_arena_1795269900712.jpg',
  iconKey: 'custom',
};

function renderGameIcon(iconKey?: GameItem['iconKey']) {
  switch (iconKey) {
    case 'bgmi':
      return <Crosshair className="h-5 w-5 text-amber-400" aria-hidden="true" />;
    case 'freefire':
      return <Flame className="h-5 w-5 text-orange-400" aria-hidden="true" />;
    case 'gtav':
      return <Car className="h-5 w-5 text-emerald-400" aria-hidden="true" />;
    case 'minecraft':
      return <Box className="h-5 w-5 text-lime-400" aria-hidden="true" />;
    case 'valorant':
      return <Swords className="h-5 w-5 text-rose-400" aria-hidden="true" />;
    case 'codm':
      return <Shield className="h-5 w-5 text-sky-400" aria-hidden="true" />;
    default:
      return <Gamepad2 className="h-5 w-5 text-violet-400" aria-hidden="true" />;
  }
}

export function MyGamesView({
  games,
  clips,
  onAddGame,
  onDeleteCustomGame,
  onViewGameClips,
  onCutClipForGame,
  onSaveClip,
  onActivateFloatingButton,
}: MyGamesViewProps) {
  const [newName, setNewName] = useState<string>('');
  const [newGenre, setNewGenre] = useState<string>('Action / Stream');
  const [isAdding, setIsAdding] = useState<boolean>(false);

  // Open Game / Launch Game Modal State
  const [openedGame, setOpenedGame] = useState<GameItem | null>(null);
  const [customLaunchName, setCustomLaunchName] = useState<string>('');
  const [customLaunchUrl, setCustomLaunchUrl] = useState<string>('');
  const [launchStatus, setLaunchStatus] = useState<string | null>(null);

  // Interactive Mini-Game: Highlight Timing Challenge
  const [isPlayingMini, setIsPlayingMini] = useState<boolean>(false);
  const [cursorPos, setCursorPos] = useState<number>(0.15);
  const [targetStart, setTargetStart] = useState<number>(0.42);
  const [streak, setStreak] = useState<number>(0);
  const [bestStreak, setBestStreak] = useState<number>(0);
  const [lastResult, setLastResult] = useState<string>(
    'Press Hit Target when the marker enters the highlighted zone.'
  );
  const [isSavingReplay, setIsSavingReplay] = useState<boolean>(false);
  const [replayPct, setReplayPct] = useState<number>(0);

  const dirRef = useRef<number>(1);
  const posRef = useRef<number>(0.15);
  const rafRef = useRef<number>(0);

  useEffect(() => {
    if (!isPlayingMini) {
      cancelAnimationFrame(rafRef.current);
      return;
    }

    let lastTime = performance.now();
    const tick = (now: number) => {
      const dt = (now - lastTime) / 1000;
      lastTime = now;
      const speed = 0.85 + Math.min(streak * 0.08, 0.9);
      let next = posRef.current + dirRef.current * speed * dt;
      if (next >= 0.96) {
        next = 0.96;
        dirRef.current = -1;
      } else if (next <= 0.04) {
        next = 0.04;
        dirRef.current = 1;
      }
      posRef.current = next;
      setCursorPos(next);
      rafRef.current = requestAnimationFrame(tick);
    };
    rafRef.current = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(rafRef.current);
  }, [isPlayingMini, streak]);

  const handleHitTarget = () => {
    if (!isPlayingMini) {
      setIsPlayingMini(true);
      setLastResult('Timing active — click Hit Target inside the rose zone!');
      return;
    }
    const targetEnd = targetStart + 0.16;
    if (posRef.current >= targetStart && posRef.current <= targetEnd) {
      const nextStreak = streak + 1;
      setStreak(nextStreak);
      setBestStreak((prev) => Math.max(prev, nextStreak));
      setLastResult(\`Clean clip hit! Streak \${nextStreak}.\`);
      setTargetStart(0.15 + Math.random() * 0.62);
    } else {
      setStreak(0);
      setLastResult('Missed timing window — streak reset to 0.');
    }
  };

  const handleSaveMiniGameReplay = async () => {
    setIsSavingReplay(true);
    setReplayPct(0);
    try {
      const blob = await generateSampleStreamVideoBlob({
        durationSec: 10,
        title: \`Highlight Challenge (Best Streak \${bestStreak})\`,
        creditLine: 'Credit: @ClipKaroPlayer',
        onProgress: setReplayPct,
      });
      await onSaveClip({
        id: \`clip-\${Date.now()}-\${Math.random().toString(36).slice(2, 6)}\`,
        title: \`Reaction Streak \${bestStreak} Highlight\`,
        platform: 'studio',
        gameTag: games[0]?.name || 'BGMI',
        durationSec: 10,
        trimStart: 0,
        trimEnd: 10,
        createdAt: Date.now(),
        copyrightSafe: true,
        permission: {
          hasPermission: true,
          streamerName: 'ClipKaroPlayer',
          originalVideoLink: '',
          creditText: 'Credit: @ClipKaroPlayer',
        },
        videoBlob: blob,
        videoMimeType: blob.type || 'video/webm',
        voiceVolume: 1,
        musicVolume: 0.45,
        originalVolume: 1,
      });
      setLastResult('10s highlight clip saved to My Clips.');
    } finally {
      setIsSavingReplay(false);
    }
  };

  const handleAddSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (!newName.trim()) return;
    setIsAdding(true);
    try {
      await onAddGame(newName.trim(), newGenre.trim() || 'Stream Category');
      setNewName('');
    } finally {
      setIsAdding(false);
    }
  };

  useEffect(() => {
    const closeOnBackgroundOrSave = () => {
      if (document.visibilityState === 'hidden') {
        setOpenedGame(null);
        setLaunchStatus(null);
      }
    };
    const closeOnNativeSave = () => {
      setOpenedGame(null);
      setLaunchStatus(null);
    };
    document.addEventListener('visibilitychange', closeOnBackgroundOrSave);
    window.addEventListener('clipkaro-native-clips-updated', closeOnNativeSave);
    return () => {
      document.removeEventListener('visibilitychange', closeOnBackgroundOrSave);
      window.removeEventListener('clipkaro-native-clips-updated', closeOnNativeSave);
    };
  }, []);

  const handleOpenGame = (game: GameItem) => {
    setOpenedGame(game);
    setLaunchStatus(null);
    setCustomLaunchName(game.id === CUSTOM_GAME_CARD.id ? '' : game.name);
    setCustomLaunchUrl(game.androidPackage ?? '');
  };

  const allDisplayedGames: GameItem[] = [...games, CUSTOM_GAME_CARD];

  const effectiveLaunchTitle =
    openedGame?.id === CUSTOM_GAME_CARD.id
      ? customLaunchName.trim() || 'Custom Game'
      : openedGame?.name || 'Game';

  const effectivePackageName = (
    openedGame?.id === CUSTOM_GAME_CARD.id
      ? customLaunchUrl.trim()
      : openedGame?.androidPackage || ''
  ).trim();

  const handleLaunchGame = () => {
    const targetTitle = effectiveLaunchTitle;

    const win = window as unknown as {
      Android?: {
        launchApp?: (pkg: string, fallbackUrl?: string) => boolean;
        startFloatingAndLaunchGame?: (pkg: string, fallbackUrl: string, gameName: string) => string;
        canDrawOverlays?: () => boolean;
        requestOverlayPermission?: () => void;
      };
      Capacitor?: { isNativePlatform?: () => boolean };
    };

    const isAndroidUa = typeof navigator !== 'undefined' && /Android/i.test(navigator.userAgent);
    const hasNativeBridge = Boolean(
      win.Android?.startFloatingAndLaunchGame ||
        win.Android?.launchApp ||
        win.Capacitor?.isNativePlatform?.()
    );
    const isInIframe = typeof window !== 'undefined' && window.self !== window.top;

    // Web preview (non-Android or embedded preview iframe without native APK bridge)
    if (!hasNativeBridge && (!isAndroidUa || isInIframe)) {
      onActivateFloatingButton?.(targetTitle);
      setOpenedGame(null);
      setLaunchStatus(null);
      return;
    }

    if (!effectivePackageName) {
      setLaunchStatus('Enter an Android package name (e.g. com.pubg.imobile) to launch.');
      return;
    }

    const playStoreUrl = \`https://play.google.com/store/apps/details?id=\${encodeURIComponent(
      effectivePackageName
    )}\`;

    if (win.Android?.startFloatingAndLaunchGame) {
      const outcome = win.Android.startFloatingAndLaunchGame(
        effectivePackageName,
        playStoreUrl,
        targetTitle
      );
      if (outcome === 'overlay_required') {
        setLaunchStatus(
          \`Permission Required: Enable Display over other apps to show the Floating CLIP bubble over \${targetTitle}.\`
        );
      } else {
        // Immediately close Launch Game modal so it never reappears on recording start or return
        setOpenedGame(null);
        setLaunchStatus(null);
      }
      return;
    }

    if (win.Android?.launchApp) {
      if (win.Android.canDrawOverlays && !win.Android.canDrawOverlays()) {
        win.Android.requestOverlayPermission?.();
        setLaunchStatus(
          \`Permission Required: Enable Display over other apps to show the Floating CLIP bubble over \${targetTitle}.\`
        );
        return;
      }
      setOpenedGame(null);
      setLaunchStatus(null);
      win.Android.launchApp(effectivePackageName, playStoreUrl);
      return;
    }

    // Android Intent URI: opens installed app directly or falls back to Google Play Store page
    const intentUri = \`intent:#Intent;action=android.intent.action.MAIN;category=android.intent.category.LAUNCHER;package=\${encodeURIComponent(
      effectivePackageName
    )};S.browser_fallback_url=\${encodeURIComponent(playStoreUrl)};end\`;

    setOpenedGame(null);
    setLaunchStatus(null);
    window.location.href = intentUri;
  };

  return (
    <div className="space-y-8">
      <div className="flex flex-col gap-2 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <h1 className="font-display text-2xl font-bold tracking-tight text-white">My Games</h1>
          <p className="mt-1 text-sm text-slate-400">
            Select a game to launch, manage custom titles, or jump straight into cutting highlights.
          </p>
        </div>
      </div>

      {/* Add Custom Game Bar */}
      <form
        onSubmit={handleAddSubmit}
        className="flex flex-col gap-3 rounded-xl border border-slate-800 bg-[#121722] p-4 sm:flex-row sm:items-end"
      >
        <div className="flex-1 space-y-1.5">
          <label htmlFor="custom-game-name" className="block text-xs font-semibold text-slate-300">
            Add Game Title
          </label>
          <input
            id="custom-game-name"
            type="text"
            value={newName}
            onChange={(e) => setNewName(e.target.value)}
            placeholder="e.g. Apex Legends, Counter-Strike 2"
            className="w-full rounded-lg border border-slate-700/80 bg-[#0B0E14] px-3.5 py-2 text-sm text-white placeholder:text-slate-500 focus:border-rose-500 focus:outline-none"
          />
        </div>
        <div className="sm:w-56 space-y-1.5">
          <label htmlFor="custom-game-genre" className="block text-xs font-semibold text-slate-300">
            Genre
          </label>
          <input
            id="custom-game-genre"
            type="text"
            value={newGenre}
            onChange={(e) => setNewGenre(e.target.value)}
            className="w-full rounded-lg border border-slate-700/80 bg-[#0B0E14] px-3.5 py-2 text-sm text-white focus:border-rose-500 focus:outline-none"
          />
        </div>
        <button
          type="submit"
          disabled={!newName.trim() || isAdding}
          className="inline-flex items-center justify-center gap-2 rounded-lg bg-rose-600 px-4 py-2 text-sm font-semibold text-white hover:bg-rose-500 disabled:opacity-50 whitespace-nowrap shrink-0"
        >
          <Plus className="h-4 w-4" aria-hidden="true" />
          <span>Add Game</span>
        </button>
      </form>

      {/* Games Grid */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {allDisplayedGames.map((game) => {
          const isCustomLauncher = game.id === CUSTOM_GAME_CARD.id;
          const count = isCustomLauncher
            ? clips.filter((c) => !games.some((g) => g.name === c.gameTag)).length
            : clips.filter((c) => c.gameTag === game.name).length;

          return (
            <article
              key={game.id}
              className="flex flex-col justify-between gap-4 rounded-xl border border-slate-800 bg-[#121722] p-4"
            >
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-center gap-3 min-w-0">
                  <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-lg border border-slate-700/80 bg-[#0B0E14]">
                    {renderGameIcon(game.iconKey)}
                  </span>
                  <div className="min-w-0">
                    <h2 className="font-display text-base font-semibold text-white truncate">
                      {game.name}
                    </h2>
                    <div className="mt-0.5 flex items-center gap-1.5 text-xs text-slate-400 tabular-nums">
                      <span className="truncate">{game.genre}</span>
                      {!isCustomLauncher && (
                        <>
                          <span aria-hidden="true">·</span>
                          <span className="shrink-0">
                            {count} {count === 1 ? 'clip' : 'clips'}
                          </span>
                        </>
                      )}
                    </div>
                  </div>
                </div>

                {game.isCustom && (
                  <button
                    type="button"
                    onClick={() => onDeleteCustomGame(game.id)}
                    aria-label={\`Remove \${game.name}\`}
                    className="rounded p-1 text-slate-500 hover:bg-slate-800 hover:text-rose-300 shrink-0"
                  >
                    <Trash2 className="h-3.5 w-3.5" aria-hidden="true" />
                  </button>
                )}
              </div>

              <button
                type="button"
                onClick={() => handleOpenGame(game)}
                className="inline-flex w-full items-center justify-center gap-2 rounded-lg bg-rose-600 px-4 py-2.5 text-sm font-semibold text-white transition-colors hover:bg-rose-500 whitespace-nowrap"
              >
                <Gamepad2 className="h-4 w-4" aria-hidden="true" />
                <span>Open Game</span>
              </button>
            </article>
          );
        })}
      </div>

      {/* Playable Creator Mini-Game */}
      <section className="rounded-xl border border-slate-800 bg-[#121722] p-5 sm:p-6 space-y-4">
        <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex items-center gap-3">
            <span className="flex h-10 w-10 items-center justify-center rounded-lg bg-rose-500/15 text-rose-400">
              <Gamepad2 className="h-5 w-5" aria-hidden="true" />
            </span>
            <div>
              <h2 className="font-display text-base font-bold text-white">
                Clip Timing Mini-Game
              </h2>
              <p className="text-xs text-slate-400">{lastResult}</p>
            </div>
          </div>
          <div className="flex items-center gap-4 text-xs text-slate-300 tabular-nums">
            <span>Streak: {streak}</span>
            <span aria-hidden="true">·</span>
            <span>Best: {bestStreak}</span>
          </div>
        </div>

        <div className="relative h-10 w-full overflow-hidden rounded-lg border border-slate-800 bg-[#0B0E14]">
          <div
            className="absolute inset-y-0 bg-rose-500/25 border-x border-rose-500/60"
            style={{
              left: \`\${targetStart * 100}%\`,
              width: '16%',
            }}
          />
          <div
            className="absolute inset-y-1 w-1.5 rounded-full bg-white shadow"
            style={{ left: \`calc(\${cursorPos * 100}% - 3px)\` }}
          />
        </div>

        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2.5">
            <button
              type="button"
              onClick={handleHitTarget}
              className="inline-flex items-center gap-2 rounded-lg bg-rose-600 px-4 py-2 text-sm font-semibold text-white hover:bg-rose-500"
            >
              <Target className="h-4 w-4" aria-hidden="true" />
              <span>{isPlayingMini ? 'Hit Target' : 'Start Challenge'}</span>
            </button>
            {isPlayingMini && (
              <button
                type="button"
                onClick={() => setIsPlayingMini(false)}
                className="rounded-lg border border-slate-700 bg-[#0B0E14] px-3.5 py-2 text-sm font-medium text-slate-300 hover:text-white"
              >
                Pause
              </button>
            )}
          </div>

          <button
            type="button"
            disabled={isSavingReplay}
            onClick={handleSaveMiniGameReplay}
            className="inline-flex items-center gap-2 rounded-lg border border-slate-700 bg-[#0B0E14] px-3.5 py-2 text-xs font-semibold text-slate-200 hover:border-slate-500 hover:text-white disabled:opacity-60"
          >
            <Sparkles className="h-3.5 w-3.5 text-rose-400" aria-hidden="true" />
            <span>
              {isSavingReplay ? \`Saving Replay (\${replayPct}%)\` : 'Save 10s Highlight to My Clips'}
            </span>
          </button>
        </div>
      </section>

      {/* Open Game / Launch Game Modal */}
      {openedGame && (
        <div
          role="dialog"
          aria-modal="true"
          aria-labelledby="open-game-modal-title"
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4 backdrop-blur-sm"
        >
          <div className="w-full max-w-md rounded-xl border border-slate-800 bg-[#121722] p-6 shadow-2xl space-y-5">
            <div className="flex items-start justify-between gap-4">
              <div className="flex items-center gap-3">
                <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl border border-slate-700 bg-[#0B0E14]">
                  {renderGameIcon(openedGame.iconKey)}
                </span>
                <div>
                  <h2 id="open-game-modal-title" className="font-display text-lg font-bold text-white">
                    {openedGame.name}
                  </h2>
                  <p className="text-xs text-slate-400">{openedGame.genre}</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setOpenedGame(null)}
                aria-label="Close game dialog"
                className="rounded-lg p-1.5 text-slate-400 hover:bg-slate-800 hover:text-white"
              >
                <X className="h-5 w-5" aria-hidden="true" />
              </button>
            </div>

            {openedGame.id === CUSTOM_GAME_CARD.id && (
              <div className="space-y-3 rounded-lg border border-slate-800 bg-[#0B0E14] p-4">
                <div className="space-y-1.5">
                  <label htmlFor="launch-custom-name" className="block text-xs font-semibold text-slate-300">
                    Custom Game Name
                  </label>
                  <input
                    id="launch-custom-name"
                    type="text"
                    value={customLaunchName}
                    onChange={(e) => setCustomLaunchName(e.target.value)}
                    placeholder="e.g. Apex Legends"
                    className="w-full rounded-lg border border-slate-700 bg-[#121722] px-3 py-2 text-sm text-white placeholder:text-slate-500 focus:border-rose-500 focus:outline-none"
                  />
                </div>
                <div className="space-y-1.5">
                  <label htmlFor="launch-custom-package" className="block text-xs font-semibold text-slate-300">
                    Android Package Name
                  </label>
                  <input
                    id="launch-custom-package"
                    type="text"
                    value={customLaunchUrl}
                    onChange={(e) => setCustomLaunchUrl(e.target.value)}
                    placeholder="e.g. com.ea.gp.apexlegendsmobilefps"
                    className="w-full rounded-lg border border-slate-700 bg-[#121722] px-3 py-2 text-sm text-white placeholder:text-slate-500 focus:border-rose-500 focus:outline-none"
                  />
                </div>
              </div>
            )}

            <div className="space-y-2.5">
              <button
                type="button"
                onClick={handleLaunchGame}
                className="inline-flex w-full items-center justify-center gap-2 rounded-lg bg-rose-600 px-4 py-3 text-sm font-bold text-white transition-colors hover:bg-rose-500"
              >
                <Rocket className="h-4 w-4" aria-hidden="true" />
                <span>Launch Game</span>
              </button>

              <div className="grid grid-cols-2 gap-2.5">
                <button
                  type="button"
                  onClick={() => {
                    const targetName = effectiveLaunchTitle;
                    setOpenedGame(null);
                    onViewGameClips(targetName);
                  }}
                  className="inline-flex items-center justify-center gap-1.5 rounded-lg border border-slate-700 bg-[#0B0E14] px-3 py-2 text-xs font-semibold text-slate-200 hover:border-slate-500 hover:text-white"
                >
                  <Film className="h-3.5 w-3.5" aria-hidden="true" />
                  <span>View Clips</span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    const targetName = effectiveLaunchTitle;
                    setOpenedGame(null);
                    onCutClipForGame(targetName);
                  }}
                  className="inline-flex items-center justify-center gap-1.5 rounded-lg border border-slate-700 bg-[#0B0E14] px-3 py-2 text-xs font-semibold text-slate-200 hover:border-slate-500 hover:text-white"
                >
                  <Scissors className="h-3.5 w-3.5" aria-hidden="true" />
                  <span>Cut Clip</span>
                </button>
              </div>
            </div>

            {launchStatus && (
              <div className="rounded-lg border border-emerald-500/40 bg-emerald-950/25 px-3.5 py-2.5 text-xs text-emerald-200">
                {launchStatus}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
`,"/src/components/TopNav.tsx":`import { Scissors } from 'lucide-react';
import { WorkspaceTab } from '../types/clipkaro';

interface TopNavProps {
  activeTab: WorkspaceTab;
  onNavigate: (tab: WorkspaceTab) => void;
}

const NAV_ITEMS: { id: WorkspaceTab; label: string }[] = [
  { id: 'home', label: 'Home' },
  { id: 'apps', label: 'My Apps' },
  { id: 'cut', label: 'Cut Video' },
  { id: 'voice', label: 'Add Voice' },
  { id: 'music', label: 'Add Music' },
  { id: 'clips', label: 'My Clips' },
];

export function TopNav({ activeTab, onNavigate }: TopNavProps) {
  return (
    <header className="sticky top-0 z-40 border-b border-slate-800/80 bg-[#0B0E14]/95 backdrop-blur-md">
      <div className="mx-auto flex max-w-7xl items-center justify-between gap-8 px-4 py-3.5 sm:px-6">
        {/* Zone 1: Single text element wordmark */}
        <button
          type="button"
          onClick={() => onNavigate('home')}
          className="font-display text-xl font-extrabold tracking-tight text-white whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-rose-500 rounded-md"
        >
          ClipKaro
        </button>

        {/* Zone 2: 5 single-line navigation links */}
        <nav aria-label="Primary" className="hidden md:flex items-center gap-7">
          {NAV_ITEMS.map((item) => {
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => onNavigate(item.id)}
                className={\`relative py-1.5 text-sm font-medium transition-colors whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-rose-500 rounded \${
                  isActive ? 'text-white' : 'text-slate-400 hover:text-slate-100'
                }\`}
              >
                {item.label}
                {isActive && (
                  <span
                    aria-hidden="true"
                    className="absolute inset-x-0 -bottom-[15px] h-0.5 bg-rose-500"
                  />
                )}
              </button>
            );
          })}
        </nav>

        {/* Zone 3: Single primary action */}
        <div className="shrink-0">
          <button
            type="button"
            onClick={() => onNavigate('cut')}
            className="inline-flex items-center gap-2 rounded-lg bg-rose-600 px-4 py-2 text-sm font-semibold text-white transition-colors hover:bg-rose-500 whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-rose-400"
          >
            <Scissors className="h-4 w-4" aria-hidden="true" />
            <span>New Clip</span>
          </button>
        </div>
      </div>

      {/* Compact mobile navigation row */}
      <nav
        aria-label="Mobile navigation"
        className="flex md:hidden items-center gap-1 overflow-x-auto border-t border-slate-800/70 px-3 py-1.5"
      >
        {[...NAV_ITEMS, { id: 'games' as WorkspaceTab, label: 'My Games' }].map((item) => {
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              type="button"
              onClick={() => onNavigate(item.id)}
              className={\`rounded-md px-3 py-1.5 text-xs font-medium whitespace-nowrap shrink-0 transition-colors \${
                isActive
                  ? 'bg-slate-800 text-white'
                  : 'text-slate-400 hover:text-slate-200'
              }\`}
            >
              {item.label}
            </button>
          );
        })}
      </nav>
    </header>
  );
}
`,"/src/components/ViralScoreExportDialog.tsx":`import { Flame, ShieldCheck, X } from 'lucide-react';

interface ViralScoreExportDialogProps {
  isOpen: boolean;
  actionLabel: string;
  viralScore: number;
  isProcessing?: boolean;
  onChoose: (showScoreOnVideo: boolean) => void | Promise<void>;
  onCancel: () => void;
}

export function ViralScoreExportDialog({
  isOpen,
  actionLabel,
  viralScore,
  isProcessing = false,
  onChoose,
  onCancel,
}: ViralScoreExportDialogProps) {
  if (!isOpen) return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="viral-export-prompt-title"
      className="fixed inset-0 z-[80] flex items-center justify-center bg-black/80 p-4 backdrop-blur-sm"
    >
      <div className="w-full max-w-md rounded-2xl border border-slate-700 bg-[#121722] p-5 shadow-2xl space-y-4">
        <div className="flex items-start justify-between gap-3">
          <div className="flex items-center gap-2.5">
            <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-amber-500/15 text-amber-400">
              <Flame className="h-5 w-5" aria-hidden="true" />
            </span>
            <div>
              <h2 id="viral-export-prompt-title" className="font-display text-base font-bold text-white">
                Show Viral Score on video?
              </h2>
              <p className="text-xs text-slate-400">
                Before {actionLabel} · Score: <span className="font-bold text-amber-300">{viralScore}/100</span>
              </p>
            </div>
          </div>
          <button
            type="button"
            disabled={isProcessing}
            onClick={onCancel}
            aria-label="Cancel"
            className="rounded-lg p-1.5 text-slate-400 hover:bg-slate-800 hover:text-white"
          >
            <X className="h-4 w-4" aria-hidden="true" />
          </button>
        </div>

        <p className="rounded-xl border border-slate-800 bg-[#0B0E14] p-3 text-xs text-slate-300">
          By default, exported videos stay clean without any Viral Score overlay. Choose <strong>NO</strong> for a clean video, or <strong>YES</strong> to include the score badge on the video.
        </p>

        <div className="flex flex-col gap-2 sm:flex-row sm:justify-end">
          <button
            type="button"
            disabled={isProcessing}
            onClick={() => void onChoose(false)}
            className="inline-flex items-center justify-center gap-1.5 rounded-lg bg-emerald-600 px-4 py-2.5 text-xs font-bold text-white hover:bg-emerald-500 disabled:opacity-60"
          >
            <ShieldCheck className="h-4 w-4" aria-hidden="true" />
            <span>{isProcessing ? 'Preparing…' : 'NO (Clean Video)'}</span>
          </button>
          <button
            type="button"
            disabled={isProcessing}
            onClick={() => void onChoose(true)}
            className="inline-flex items-center justify-center gap-1.5 rounded-lg border border-amber-500/60 bg-amber-500/20 px-4 py-2.5 text-xs font-bold text-amber-200 hover:bg-amber-500/30 disabled:opacity-60"
          >
            <Flame className="h-4 w-4" aria-hidden="true" />
            <span>{isProcessing ? 'Rendering…' : 'YES (Show Score)'}</span>
          </button>
        </div>
      </div>
    </div>
  );
}
`,"/src/components/WelcomePermissionScreen.tsx":`import { useEffect, useState } from 'react';
import {
  AlertTriangle,
  BatteryCharging,
  CheckCircle2,
  Eye,
  FolderOpen,
  Layers,
  Mic,
  RefreshCw,
  ShieldAlert,
} from 'lucide-react';
import {
  ClipKaroPermissionState,
  PermissionKind,
  markPermissionSetupDone,
  requestBatteryPermission,
  requestMicrophonePermission,
  requestOverlayPermission,
  requestStoragePermission,
  requestUsageAccessPermission,
  setPreviewPermissionDenied,
} from '../utils/androidPermissions';

interface WelcomePermissionScreenProps {
  permissionState: ClipKaroPermissionState;
  onRefreshPermissions: () => ClipKaroPermissionState;
  onComplete: () => void;
}

type PermissionFlags = Record<PermissionKind, boolean>;

const INITIAL_FLAGS: PermissionFlags = {
  overlay: false,
  storage: false,
  microphone: false,
  battery: false,
  usageAccess: false,
};

export function WelcomePermissionScreen({
  permissionState,
  onRefreshPermissions,
  onComplete,
}: WelcomePermissionScreenProps) {
  const [awaitingReturn, setAwaitingReturn] = useState<PermissionFlags>(INITIAL_FLAGS);
  const [stillDenied, setStillDenied] = useState<PermissionFlags>(INITIAL_FLAGS);
  const [micNote, setMicNote] = useState<string | null>(null);

  const allGranted =
    permissionState.overlay &&
    permissionState.storage &&
    permissionState.microphone &&
    permissionState.battery &&
    permissionState.usageAccess;

  // Automatically save SharedPreferences & enter Home Screen once permissions are granted
  useEffect(() => {
    if (allGranted) {
      markPermissionSetupDone(true);
      onComplete();
    }
  }, [allGranted, onComplete]);

  // Auto re-check all permissions whenever user returns from Android Settings
  useEffect(() => {
    const checkReturnFromSettings = () => {
      const latest = onRefreshPermissions();

      setAwaitingReturn((prevAwaiting) => {
        const nextAwaiting: PermissionFlags = { ...prevAwaiting };
        const deniedUpdates: Partial<PermissionFlags> = {};

        (
          [
            'overlay',
            'storage',
            'microphone',
            'battery',
            'usageAccess',
          ] as PermissionKind[]
        ).forEach((key) => {
          if (latest[key]) {
            nextAwaiting[key] = false;
            deniedUpdates[key] = false;
          } else if (prevAwaiting[key]) {
            nextAwaiting[key] = false;
            deniedUpdates[key] = true;
          }
        });

        if (Object.keys(deniedUpdates).length > 0) {
          setStillDenied((prevDenied) => ({ ...prevDenied, ...deniedUpdates }));
        }

        return nextAwaiting;
      });
    };

    const handleVisibility = () => {
      if (document.visibilityState === 'visible') {
        checkReturnFromSettings();
      }
    };

    window.addEventListener('focus', checkReturnFromSettings);
    window.addEventListener('clipkaro-permissions-updated', checkReturnFromSettings);
    document.addEventListener('visibilitychange', handleVisibility);

    return () => {
      window.removeEventListener('focus', checkReturnFromSettings);
      window.removeEventListener('clipkaro-permissions-updated', checkReturnFromSettings);
      document.removeEventListener('visibilitychange', handleVisibility);
    };
  }, [onRefreshPermissions]);

  const handleAllowFloatingButton = () => {
    setStillDenied((prev) => ({ ...prev, overlay: false }));
    const { awaitingNativeSettings } = requestOverlayPermission();
    if (awaitingNativeSettings) {
      setAwaitingReturn((prev) => ({ ...prev, overlay: true }));
    } else {
      onRefreshPermissions();
    }
  };

  const handleAllowStorage = () => {
    setStillDenied((prev) => ({ ...prev, storage: false }));
    const { awaitingNativeSettings } = requestStoragePermission();
    if (awaitingNativeSettings) {
      setAwaitingReturn((prev) => ({ ...prev, storage: true }));
    } else {
      onRefreshPermissions();
    }
  };

  const handleAllowMicrophone = async () => {
    const openSettingsAgain = stillDenied.microphone;
    setStillDenied((prev) => ({ ...prev, microphone: false }));
    const { awaitingNativeSettings } = await requestMicrophonePermission(openSettingsAgain);
    if (awaitingNativeSettings) {
      setAwaitingReturn((prev) => ({ ...prev, microphone: true }));
    } else {
      const latest = onRefreshPermissions();
      if (!latest.isNativeAndroid && latest.microphone) {
        setMicNote('Microphone access ready for voiceover and in-game chat.');
      }
    }
  };

  const handleAllowBattery = () => {
    setStillDenied((prev) => ({ ...prev, battery: false }));
    const { awaitingNativeSettings } = requestBatteryPermission();
    if (awaitingNativeSettings) {
      setAwaitingReturn((prev) => ({ ...prev, battery: true }));
    } else {
      onRefreshPermissions();
    }
  };

  const handleAllowUsageAccess = () => {
    setStillDenied((prev) => ({ ...prev, usageAccess: false }));
    const { awaitingNativeSettings } = requestUsageAccessPermission();
    if (awaitingNativeSettings) {
      setAwaitingReturn((prev) => ({ ...prev, usageAccess: true }));
    } else {
      onRefreshPermissions();
    }
  };

  const handlePreviewDeny = (kind: PermissionKind) => {
    setPreviewPermissionDenied(kind);
    setStillDenied((prev) => ({ ...prev, [kind]: true }));
    onRefreshPermissions();
  };

  const handleContinueClick = () => {
    if (!permissionState.overlay) {
      setStillDenied((prev) => ({ ...prev, overlay: true }));
      return;
    }
    markPermissionSetupDone(true);
    onComplete();
  };

  const handleContinueLimited = () => {
    markPermissionSetupDone(true);
    onComplete();
  };

  return (
    <div className="min-h-screen bg-[#0B0E14] text-slate-100 flex items-center justify-center px-4 py-8">
      <div className="w-full max-w-2xl rounded-2xl border border-slate-800 bg-[#121722] p-6 sm:p-8 shadow-2xl space-y-6">
        {/* Header */}
        <div className="space-y-2">
          <div className="inline-flex items-center gap-2 rounded-lg border border-rose-500/30 bg-rose-500/10 px-3 py-1 text-xs font-semibold text-rose-300">
            <span>ClipKaro First-Launch Setup</span>
          </div>
          <h1 className="font-display text-2xl sm:text-3xl font-bold tracking-tight text-white">
            Welcome to ClipKaro
          </h1>
          <p className="text-sm text-slate-400">
            Grant permissions directly via Android deep links so you never have to search Settings manually. Screen Capture is NOT asked here — it is requested per-app only when you tap Record.
          </p>
        </div>

        {/* Red Warning Banner if Overlay Permission Denied */}
        {stillDenied.overlay && !permissionState.overlay && (
          <div
            role="alert"
            className="flex flex-col gap-3 rounded-xl border border-rose-500/70 bg-rose-950/50 p-4 sm:flex-row sm:items-center sm:justify-between"
          >
            <div className="flex items-start gap-3">
              <ShieldAlert className="h-5 w-5 text-rose-400 shrink-0 mt-0.5" aria-hidden="true" />
              <div>
                <p className="text-sm font-bold text-rose-200">
                  Floating button will not appear in BGMI without this permission
                </p>
                <p className="mt-0.5 text-xs text-rose-300/90">
                  Tap Open Settings Again to jump directly to ClipKaro&rsquo;s Display over other apps toggle.
                </p>
              </div>
            </div>
            <button
              type="button"
              onClick={handleAllowFloatingButton}
              className="inline-flex items-center justify-center gap-1.5 rounded-lg bg-rose-600 px-3.5 py-2 text-xs font-bold text-white hover:bg-rose-500 shrink-0 whitespace-nowrap"
            >
              <RefreshCw className="h-3.5 w-3.5" aria-hidden="true" />
              <span>Open Settings Again</span>
            </button>
          </div>
        )}

        {/* 4 Permission Cards */}
        <div className="space-y-3.5">
          {/* 1. Display Over Other Apps — Most Important */}
          <section
            className={\`rounded-xl border p-4 sm:p-5 transition-colors \${
              permissionState.overlay
                ? 'border-emerald-500/40 bg-emerald-950/20'
                : 'border-rose-500/50 bg-[#0B0E14]'
            }\`}
          >
            <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
              <div className="flex items-start gap-3.5">
                <span
                  className={\`flex h-11 w-11 shrink-0 items-center justify-center rounded-xl \${
                    permissionState.overlay
                      ? 'bg-emerald-500/15 text-emerald-400'
                      : 'bg-rose-500/15 text-rose-400'
                  }\`}
                >
                  <Layers className="h-5 w-5" aria-hidden="true" />
                </span>
                <div className="space-y-1">
                  <div className="flex flex-wrap items-center gap-2">
                    <h2 className="font-display text-sm sm:text-base font-bold text-white">
                      1. Display over other apps (Floating CLIP button)
                    </h2>
                    <span className="rounded bg-rose-600/20 px-2 py-0.5 text-[11px] font-bold text-rose-300">
                      Most important
                    </span>
                  </div>
                  <p className="text-xs text-slate-400">
                    Directly opens ClipKaro&rsquo;s Overlay Permission Settings page so the draggable CLIP bubble stays on top of BGMI.
                  </p>
                  {!permissionState.overlay && (
                    <p className="flex items-center gap-1.5 pt-0.5 text-xs font-semibold text-amber-300">
                      <AlertTriangle className="h-3.5 w-3.5 shrink-0" aria-hidden="true" />
                      <span>Permission Required to show CLIP button in BGMI</span>
                    </p>
                  )}
                </div>
              </div>

              <div className="flex flex-wrap items-center gap-2 shrink-0">
                {permissionState.overlay ? (
                  <span className="inline-flex items-center gap-1.5 rounded-lg border border-emerald-500/40 bg-emerald-500/15 px-3.5 py-2 text-xs font-bold text-emerald-300">
                    <CheckCircle2 className="h-4 w-4" aria-hidden="true" />
                    <span>Granted</span>
                  </span>
                ) : (
                  <>
                    <button
                      type="button"
                      onClick={handleAllowFloatingButton}
                      className="inline-flex items-center justify-center gap-2 rounded-lg bg-rose-600 px-4 py-2.5 text-xs font-bold text-white transition-colors hover:bg-rose-500 whitespace-nowrap"
                    >
                      <span>{stillDenied.overlay ? 'Open Settings Again' : 'Allow Floating Button'}</span>
                    </button>
                    {!permissionState.isNativeAndroid && (
                      <button
                        type="button"
                        onClick={() => handlePreviewDeny('overlay')}
                        className="rounded-lg border border-slate-700 bg-[#121722] px-3 py-2 text-xs font-medium text-slate-300 hover:border-rose-500/50 hover:text-rose-300"
                      >
                        Deny
                      </button>
                    )}
                  </>
                )}
              </div>
            </div>
          </section>

          {/* 2. Storage / Photos & Videos */}
          <section
            className={\`rounded-xl border p-4 sm:p-5 transition-colors \${
              permissionState.storage
                ? 'border-emerald-500/40 bg-emerald-950/20'
                : 'border-slate-800 bg-[#0B0E14]'
            }\`}
          >
            <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
              <div className="flex items-start gap-3.5">
                <span
                  className={\`flex h-11 w-11 shrink-0 items-center justify-center rounded-xl \${
                    permissionState.storage
                      ? 'bg-emerald-500/15 text-emerald-400'
                      : 'bg-sky-500/15 text-sky-400'
                  }\`}
                >
                  <FolderOpen className="h-5 w-5" aria-hidden="true" />
                </span>
                <div className="space-y-1">
                  <h2 className="font-display text-sm sm:text-base font-bold text-white">
                    2. Storage / Photos &amp; Videos
                  </h2>
                  <p className="text-xs text-slate-400">
                    Directly opens ClipKaro App Details Settings to grant Photos &amp; Videos access (<span className="font-mono text-slate-300">READ_MEDIA_VIDEO</span> &amp; <span className="font-mono text-slate-300">READ_MEDIA_IMAGES</span>).
                  </p>
                  {stillDenied.storage && !permissionState.storage && (
                    <p className="text-xs font-semibold text-rose-300">
                      Storage permission is still off in App Settings.
                    </p>
                  )}
                </div>
              </div>

              <div className="flex flex-wrap items-center gap-2 shrink-0">
                {permissionState.storage ? (
                  <span className="inline-flex items-center gap-1.5 rounded-lg border border-emerald-500/40 bg-emerald-500/15 px-3.5 py-2 text-xs font-bold text-emerald-300">
                    <CheckCircle2 className="h-4 w-4" aria-hidden="true" />
                    <span>Granted</span>
                  </span>
                ) : (
                  <>
                    <button
                      type="button"
                      onClick={handleAllowStorage}
                      className={\`inline-flex items-center justify-center rounded-lg px-4 py-2.5 text-xs font-bold text-white transition-colors whitespace-nowrap \${
                        stillDenied.storage
                          ? 'bg-rose-600 hover:bg-rose-500'
                          : 'border border-slate-700 bg-slate-800 hover:bg-slate-700'
                      }\`}
                    >
                      {stillDenied.storage ? 'Open Settings Again' : 'Allow Storage'}
                    </button>
                    {!permissionState.isNativeAndroid && (
                      <button
                        type="button"
                        onClick={() => handlePreviewDeny('storage')}
                        className="rounded-lg border border-slate-700 bg-[#121722] px-3 py-2 text-xs font-medium text-slate-300 hover:border-rose-500/50 hover:text-rose-300"
                      >
                        Deny
                      </button>
                    )}
                  </>
                )}
              </div>
            </div>
          </section>

          {/* 3. Microphone */}
          <section
            className={\`rounded-xl border p-4 sm:p-5 transition-colors \${
              permissionState.microphone
                ? 'border-emerald-500/40 bg-emerald-950/20'
                : 'border-slate-800 bg-[#0B0E14]'
            }\`}
          >
            <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
              <div className="flex items-start gap-3.5">
                <span
                  className={\`flex h-11 w-11 shrink-0 items-center justify-center rounded-xl \${
                    permissionState.microphone
                      ? 'bg-emerald-500/15 text-emerald-400'
                      : 'bg-amber-500/15 text-amber-400'
                  }\`}
                >
                  <Mic className="h-5 w-5" aria-hidden="true" />
                </span>
                <div className="space-y-1">
                  <h2 className="font-display text-sm sm:text-base font-bold text-white">
                    3. Microphone
                  </h2>
                  <p className="text-xs text-slate-400">
                    Requests <span className="font-mono text-slate-300">RECORD_AUDIO</span> for game sound + voiceover, and opens App Details Settings if denied.
                  </p>
                  {stillDenied.microphone && !permissionState.microphone && (
                    <p className="text-xs font-semibold text-rose-300">
                      Microphone permission is still denied in App Settings.
                    </p>
                  )}
                  {micNote && <p className="text-[11px] text-emerald-300">{micNote}</p>}
                </div>
              </div>

              <div className="flex flex-wrap items-center gap-2 shrink-0">
                {permissionState.microphone ? (
                  <span className="inline-flex items-center gap-1.5 rounded-lg border border-emerald-500/40 bg-emerald-500/15 px-3.5 py-2 text-xs font-bold text-emerald-300">
                    <CheckCircle2 className="h-4 w-4" aria-hidden="true" />
                    <span>Granted</span>
                  </span>
                ) : (
                  <>
                    <button
                      type="button"
                      onClick={handleAllowMicrophone}
                      className={\`inline-flex items-center justify-center rounded-lg px-4 py-2.5 text-xs font-bold text-white transition-colors whitespace-nowrap \${
                        stillDenied.microphone
                          ? 'bg-rose-600 hover:bg-rose-500'
                          : 'border border-slate-700 bg-slate-800 hover:bg-slate-700'
                      }\`}
                    >
                      {stillDenied.microphone ? 'Open Settings Again' : 'Allow Microphone'}
                    </button>
                    {!permissionState.isNativeAndroid && (
                      <button
                        type="button"
                        onClick={() => handlePreviewDeny('microphone')}
                        className="rounded-lg border border-slate-700 bg-[#121722] px-3 py-2 text-xs font-medium text-slate-300 hover:border-rose-500/50 hover:text-rose-300"
                      >
                        Deny
                      </button>
                    )}
                  </>
                )}
              </div>
            </div>
          </section>

          {/* 4. Battery / Background */}
          <section
            className={\`rounded-xl border p-4 sm:p-5 transition-colors \${
              permissionState.battery
                ? 'border-emerald-500/40 bg-emerald-950/20'
                : 'border-slate-800 bg-[#0B0E14]'
            }\`}
          >
            <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
              <div className="flex items-start gap-3.5">
                <span
                  className={\`flex h-11 w-11 shrink-0 items-center justify-center rounded-xl \${
                    permissionState.battery
                      ? 'bg-emerald-500/15 text-emerald-400'
                      : 'bg-purple-500/15 text-purple-400'
                  }\`}
                >
                  <BatteryCharging className="h-5 w-5" aria-hidden="true" />
                </span>
                <div className="space-y-1">
                  <h2 className="font-display text-sm sm:text-base font-bold text-white">
                    4. Battery / Background
                  </h2>
                  <p className="text-xs text-slate-400">
                    Directly opens ClipKaro Battery Optimization Settings so the floating CLIP service is never killed while playing BGMI.
                  </p>
                  {stillDenied.battery && !permissionState.battery && (
                    <p className="text-xs font-semibold text-rose-300">
                      Background battery exemption is still not enabled.
                    </p>
                  )}
                </div>
              </div>

              <div className="flex flex-wrap items-center gap-2 shrink-0">
                {permissionState.battery ? (
                  <span className="inline-flex items-center gap-1.5 rounded-lg border border-emerald-500/40 bg-emerald-500/15 px-3.5 py-2 text-xs font-bold text-emerald-300">
                    <CheckCircle2 className="h-4 w-4" aria-hidden="true" />
                    <span>Granted</span>
                  </span>
                ) : (
                  <>
                    <button
                      type="button"
                      onClick={handleAllowBattery}
                      className={\`inline-flex items-center justify-center rounded-lg px-4 py-2.5 text-xs font-bold text-white transition-colors whitespace-nowrap \${
                        stillDenied.battery
                          ? 'bg-rose-600 hover:bg-rose-500'
                          : 'border border-slate-700 bg-slate-800 hover:bg-slate-700'
                      }\`}
                    >
                      {stillDenied.battery ? 'Open Settings Again' : 'Allow Battery / Background'}
                    </button>
                    {!permissionState.isNativeAndroid && (
                      <button
                        type="button"
                        onClick={() => handlePreviewDeny('battery')}
                        className="rounded-lg border border-slate-700 bg-[#121722] px-3 py-2 text-xs font-medium text-slate-300 hover:border-rose-500/50 hover:text-rose-300"
                      >
                        Deny
                      </button>
                    )}
                  </>
                )}
              </div>
            </div>
          </section>
          {/* 5. Auto-Hide App Detection (Usage Access) */}
          <section
            className={\`rounded-xl border p-4 sm:p-5 transition-colors \${
              permissionState.usageAccess
                ? 'border-emerald-500/40 bg-emerald-950/20'
                : 'border-slate-800 bg-[#0B0E14]'
            }\`}
          >
            <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
              <div className="flex items-start gap-3.5">
                <span
                  className={\`flex h-11 w-11 shrink-0 items-center justify-center rounded-xl \${
                    permissionState.usageAccess
                      ? 'bg-emerald-500/15 text-emerald-400'
                      : 'bg-cyan-500/15 text-cyan-400'
                  }\`}
                >
                  <Eye className="h-5 w-5" aria-hidden="true" />
                </span>
                <div className="space-y-1">
                  <h2 className="font-display text-sm sm:text-base font-bold text-white">
                    5. App Detection (Auto-Hide Floating Button)
                  </h2>
                  <p className="text-xs text-slate-400">
                    Detects when you close BGMI or YouTube so the floating CLIP button automatically saves &amp; hides itself after 3 seconds.
                  </p>
                  {stillDenied.usageAccess && !permissionState.usageAccess && (
                    <p className="text-xs font-semibold text-rose-300">
                      Usage Access is still off in Settings.
                    </p>
                  )}
                </div>
              </div>

              <div className="flex flex-wrap items-center gap-2 shrink-0">
                {permissionState.usageAccess ? (
                  <span className="inline-flex items-center gap-1.5 rounded-lg border border-emerald-500/40 bg-emerald-500/15 px-3.5 py-2 text-xs font-bold text-emerald-300">
                    <CheckCircle2 className="h-4 w-4" aria-hidden="true" />
                    <span>Granted</span>
                  </span>
                ) : (
                  <>
                    <button
                      type="button"
                      onClick={handleAllowUsageAccess}
                      className={\`inline-flex items-center justify-center rounded-lg px-4 py-2.5 text-xs font-bold text-white transition-colors whitespace-nowrap \${
                        stillDenied.usageAccess
                          ? 'bg-rose-600 hover:bg-rose-500'
                          : 'border border-slate-700 bg-slate-800 hover:bg-slate-700'
                      }\`}
                    >
                      {stillDenied.usageAccess ? 'Open Settings Again' : 'Allow Auto-Hide'}
                    </button>
                    {!permissionState.isNativeAndroid && (
                      <button
                        type="button"
                        onClick={() => handlePreviewDeny('usageAccess')}
                        className="rounded-lg border border-slate-700 bg-[#121722] px-3 py-2 text-xs font-medium text-slate-300 hover:border-rose-500/50 hover:text-rose-300"
                      >
                        Deny
                      </button>
                    )}
                  </>
                )}
              </div>
            </div>
          </section>
        </div>

        {/* Footer Actions */}
        <div className="flex flex-col gap-3 border-t border-slate-800 pt-5 sm:flex-row sm:items-center sm:justify-between">
          <p className="text-xs text-slate-400">
            {allGranted
              ? 'All permissions granted — opening Home Screen…'
              : 'Grant Floating Button and permissions above to enter ClipKaro.'}
          </p>

          <div className="flex flex-wrap items-center gap-2.5">
            {stillDenied.overlay && !permissionState.overlay && (
              <button
                type="button"
                onClick={handleContinueLimited}
                className="rounded-lg border border-slate-700 bg-[#0B0E14] px-3.5 py-2 text-xs font-semibold text-slate-300 hover:border-slate-500 hover:text-white"
              >
                Continue Without My Games
              </button>
            )}
            <button
              type="button"
              onClick={handleContinueClick}
              className="rounded-lg bg-rose-600 px-4 py-2 text-xs font-bold text-white transition-colors hover:bg-rose-500"
            >
              Continue to Home
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
`,"/src/index.css":`@import "tailwindcss";

@layer base {
  :root {
    --font-display: "Plus Jakarta Sans", system-ui, -apple-system, sans-serif;
    --font-sans: "DM Sans", system-ui, -apple-system, sans-serif;
    --font-mono: "JetBrains Mono", ui-monospace, SFMono-Regular, monospace;
  }

  body {
    font-family: var(--font-sans);
    background-color: #0b0e14;
    color: #f1f5f9;
    letter-spacing: 0.005em;
  }

  h1,
  h2,
  h3,
  h4,
  .font-display {
    font-family: var(--font-display);
  }

  .font-mono {
    font-family: var(--font-mono);
  }
}

.tabular-nums {
  font-variant-numeric: tabular-nums;
}

/* Subtle custom scrollbars for dark studio workspace */
::-webkit-scrollbar {
  width: 8px;
  height: 8px;
}

::-webkit-scrollbar-track {
  background: #0b0e14;
}

::-webkit-scrollbar-thumb {
  background: #232a3b;
  border-radius: 4px;
}

::-webkit-scrollbar-thumb:hover {
  background: #334155;
}

@media (prefers-reduced-motion: reduce) {
  *,
  *::before,
  *::after {
    animation-duration: 0.01ms !important;
    animation-iteration-count: 1 !important;
    transition-duration: 0.01ms !important;
  }
}
`,"/src/main.tsx":`import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import './index.css';

createRoot(document.getElementById('root')!).render(<App />);
`,"/src/types/clipkaro.ts":`export type SocialPlatform = 'youtube' | 'instagram' | 'facebook';

export type WorkspaceTab = 'home' | 'cut' | 'voice' | 'music' | 'clips' | 'games' | 'apps';

export type ClipLengthOption = 10 | 20 | 30 | 40 | 50 | 60;

export type AudioSourceMode = 'game' | 'mic' | 'both';

export type VoiceChangerPreset = 'normal' | 'funny' | 'robot' | 'deep';

export interface UniversalAppItem {
  id: string;
  name: string;
  category: string;
  androidPackage: string;
  webFallbackUrl: string;
  accentColor: 'red' | 'fuchsia' | 'sky' | 'emerald' | 'amber' | 'violet';
  iconKey: 'youtube' | 'instagram' | 'facebook' | 'whatsapp' | 'bgmi' | 'custom';
  isCustom?: boolean;
}

export const CLIP_LENGTH_OPTIONS: ClipLengthOption[] = [10, 20, 30, 40, 50, 60];

export interface PermissionInfo {
  hasPermission: boolean;
  streamerName: string;
  proofFileName?: string;
  proofMimeType?: string;
  proofBlob?: Blob;
  originalVideoLink: string;
  creditText: string;
}

export type AspectRatioOption = '16:9' | '9:16' | '1:1' | '4:5';
export type VideoFitMode = 'fill' | 'fit';
export type VideoFilterPreset =
  | 'none'
  | 'cinematic'
  | 'vivid'
  | 'warm'
  | 'cool'
  | 'bw'
  | 'vintage'
  | 'hdr';
export type VideoEffectMode = 'none' | 'cinematic' | 'gaming' | 'vlog' | 'night';
export type SpeedPreset = 0.25 | 0.5 | 1 | 1.5 | 2;

export interface SpeedSegment {
  id: string;
  startSec: number;
  endSec: number;
  speed: SpeedPreset;
}

export interface ClipItem {
  id: string;
  title: string;
  platform: SocialPlatform | 'upload' | 'studio';
  gameTag: string;
  durationSec: number;
  trimStart: number;
  trimEnd: number;
  createdAt: number;
  copyrightSafe: boolean;
  permission: PermissionInfo;
  videoBlob: Blob;
  videoMimeType: string;
  thumbnailDataUrl?: string;
  autoCaption?: string;
  voiceBlob?: Blob;
  voiceName?: string;
  voiceVolume: number;
  musicBlob?: Blob;
  musicName?: string;
  musicVolume: number;
  originalVolume: number;
  nativeUri?: string;
  nativeFileName?: string;
  audioSourceMode?: AudioSourceMode;
  voiceChanger?: VoiceChangerPreset;
  isFavourite?: boolean;
  isReaction?: boolean;
  hasFacecam?: boolean;
  killCount?: number;
  hideViralScore?: boolean;
  aspectRatio?: AspectRatioOption;
  fitMode?: VideoFitMode;
  filterPreset?: VideoFilterPreset;
  effectMode?: VideoEffectMode;
  speedSegments?: SpeedSegment[];
}

export interface GameItem {
  id: string;
  name: string;
  genre: string;
  coverUrl: string;
  androidPackage?: string;
  launchUrl?: string;
  iconKey?: 'bgmi' | 'freefire' | 'gtav' | 'minecraft' | 'valorant' | 'codm' | 'custom';
  isCustom?: boolean;
}

export interface RoyaltyFreeTrack {
  id: string;
  title: string;
  mood: string;
  bpm: number;
  durationSec: number;
  license: string;
}
`,"/src/utils/aiAutoEditor.ts":`import { ClipItem } from '../types/clipkaro';
import {
  formatSeconds,
  generateRoyaltyFreeWavBlob,
  generateStyledThumbnailDataUrl,
  ROYALTY_FREE_TRACKS,
} from './mediaGenerators';
import { trimVideoWithFFmpeg } from './ffmpegCutter';

export type AiDetectedMomentType = 'Headshot' | 'Kill Clutch' | 'Funny Moment';

export interface AiAutoEditAnalysis {
  detectedMoment: AiDetectedMomentType;
  peakTimestampSec: number;
  cutStartSec: number;
  cutEndSec: number;
  cutDurationSec: number;
  autoCaption: string;
  musicName: string;
  editedClip: ClipItem;
  hardCutApplied: boolean;
}

async function detectAudioPeakTimeSec(blob: Blob, totalDurationSec: number): Promise<number | null> {
  if (typeof AudioContext === 'undefined' || blob.size > 45 * 1024 * 1024) {
    return null;
  }
  let ctx: AudioContext | null = null;
  try {
    const buf = await blob.arrayBuffer();
    ctx = new AudioContext();
    const audioBuf = await ctx.decodeAudioData(buf.slice(0));
    const channel = audioBuf.getChannelData(0);
    const dur = audioBuf.duration || totalDurationSec;
    if (!channel.length || dur <= 1) return null;

    const bucketSec = 1;
    const sampleStep = Math.max(1, Math.floor(audioBuf.sampleRate / 25));
    const bucketCount = Math.max(1, Math.floor(dur / bucketSec));
    let bestBucket = 0;
    let bestRms = -1;

    for (let b = 0; b < bucketCount; b += 1) {
      const startSample = Math.floor(b * bucketSec * audioBuf.sampleRate);
      const endSample = Math.min(channel.length, Math.floor((b + 1) * bucketSec * audioBuf.sampleRate));
      let sumSq = 0;
      let count = 0;
      for (let i = startSample; i < endSample; i += sampleStep) {
        const s = channel[i];
        sumSq += s * s;
        count += 1;
      }
      const rms = count > 0 ? Math.sqrt(sumSq / count) : 0;
      if (rms > bestRms) {
        bestRms = rms;
        bestBucket = b;
      }
    }

    return Math.min(dur, bestBucket + 0.5);
  } catch {
    return null;
  } finally {
    ctx?.close().catch(() => undefined);
  }
}

function inferMomentAndCaption(clip: ClipItem): {
  moment: AiDetectedMomentType;
  caption: string;
  trackIndex: number;
} {
  const hay = \`\${clip.title} \${clip.gameTag} \${clip.autoCaption || ''}\`.toLowerCase();
  const isNormalSocial =
    hay.includes('youtube') ||
    hay.includes('instagram') ||
    hay.includes('facebook') ||
    hay.includes('whatsapp') ||
    hay.includes('vlog') ||
    hay.includes('reaction') ||
    Boolean(clip.isReaction);

  if (hay.includes('headshot') || hay.includes('awm') || hay.includes('sniper')) {
    return {
      moment: 'Headshot',
      caption: 'What a Headshot!',
      trackIndex: 0,
    };
  }

  if (
    hay.includes('funny') ||
    hay.includes('comedy') ||
    hay.includes('meme') ||
    hay.includes('fail') ||
    isNormalSocial
  ) {
    return {
      moment: 'Funny Moment',
      caption: isNormalSocial ? 'Wait For This Moment!' : 'What a Funny Clutch!',
      trackIndex: 1,
    };
  }

  if (
    hay.includes('bgmi') ||
    hay.includes('kill') ||
    hay.includes('clutch') ||
    hay.includes('free fire') ||
    hay.includes('valorant') ||
    hay.includes('cod')
  ) {
    return {
      moment: 'Headshot',
      caption: 'What a Headshot!',
      trackIndex: 0,
    };
  }

  return {
    moment: 'Kill Clutch',
    caption: 'What a Headshot!',
    trackIndex: 0,
  };
}

export async function runAiAutoEdit(
  clip: ClipItem,
  onProgress?: (stage: string, pct: number) => void
): Promise<AiAutoEditAnalysis> {
  onProgress?.('AI scanning clip for Kill / Headshot / Funny peak…', 18);

  const totalDur = Math.max(1, clip.durationSec || clip.trimEnd || 15);
  const targetLen = Math.min(15, totalDur);

  const audioPeak = await detectAudioPeakTimeSec(clip.videoBlob, totalDur);
  const fallbackPeak = totalDur > 16 ? Math.round(totalDur * 0.58 * 10) / 10 : Math.round((totalDur / 2) * 10) / 10;
  const peakSec = audioPeak !== null ? Math.round(audioPeak * 10) / 10 : fallbackPeak;

  let cutStart = 0;
  let cutEnd = totalDur;
  if (totalDur > 15.2) {
    cutStart = Math.max(0, Math.round((peakSec - targetLen / 2) * 10) / 10);
    if (cutStart + targetLen > totalDur) {
      cutStart = Math.max(0, Math.round((totalDur - targetLen) * 10) / 10);
    }
    cutEnd = Math.min(totalDur, Math.round((cutStart + targetLen) * 10) / 10);
  }
  const cutDur = Math.max(1, Math.round(cutEnd - cutStart));

  onProgress?.('Selecting best 15s highlight & Trending Music…', 48);

  const { moment, caption, trackIndex } = inferMomentAndCaption(clip);
  const trendingTrack = ROYALTY_FREE_TRACKS[trackIndex] ?? ROYALTY_FREE_TRACKS[0];
  const musicBlob = generateRoyaltyFreeWavBlob(trendingTrack.id);

  let finalBlob = clip.videoBlob;
  let finalMime = clip.videoMimeType;
  let finalTrimStart = cutStart;
  let finalTrimEnd = cutEnd;
  let hardCutApplied = false;

  // Attempt hard 15s MP4 cut with Cinematic filter + Auto Caption if clip is long and FFmpeg is available online/cached
  if (totalDur > 16) {
    try {
      onProgress?.('Auto-cutting best 15s clip & applying Cinematic look…', 68);
      const trimmed = await trimVideoWithFFmpeg({
        sourceBlob: clip.videoBlob,
        sourceFileName: clip.nativeFileName || \`\${clip.title}.mp4\`,
        startSec: cutStart,
        durationSec: cutDur,
        burnCredit: false,
        creditText: clip.permission.creditText,
        burnAutoCaption: false,
      });
      finalBlob = trimmed.mp4Blob;
      finalMime = 'video/mp4';
      finalTrimStart = 0;
      finalTrimEnd = cutDur;
      hardCutApplied = true;
    } catch {
      // Offline / fast fallback: non-destructive exact 15s peak window + live Cinematic filter & caption
      hardCutApplied = false;
    }
  }

  onProgress?.('Polishing AI Auto Caption & Cinematic Thumbnail…', 88);

  let aiThumb = clip.thumbnailDataUrl;
  try {
    aiThumb = await generateStyledThumbnailDataUrl({
      fallbackImageUrl: clip.thumbnailDataUrl,
      headline: moment === 'Funny Moment' ? 'BEST MOMENT!' : '1 VS 4 CLUTCH',
      badgeText: clip.gameTag ? \`#\${clip.gameTag.replace(/\\s+/g, '')}\` : '#BGMI',
      stylePreset: 'clutch-red-gold',
    });
  } catch {
    // keep existing thumbnail
  }

  const baseTitle = clip.title.replace(/\\s*\\(AI Edited\\)$/i, '').trim() || 'Highlight Clip';
  const editedClip: ClipItem = {
    ...clip,
    id: \`clip-ai-\${Date.now()}-\${Math.random().toString(36).slice(2, 6)}\`,
    title: \`\${baseTitle} (AI Edited)\`,
    createdAt: Date.now(),
    durationSec: cutDur,
    trimStart: finalTrimStart,
    trimEnd: finalTrimEnd,
    videoBlob: finalBlob,
    videoMimeType: finalMime,
    autoCaption: caption,
    musicBlob,
    musicName: trendingTrack.title,
    musicVolume: 0.45,
    originalVolume: 0.85,
    filterPreset: 'cinematic',
    effectMode: 'cinematic',
    thumbnailDataUrl: aiThumb,
    killCount: Math.max(clip.killCount ?? 0, moment === 'Headshot' || moment === 'Kill Clutch' ? 2 : 0),
    nativeUri: undefined,
    nativeFileName: \`ClipKaro_AI_\${clip.gameTag.replace(/[^a-z0-9]/gi, '')}_\${cutDur}s_\${Date.now()}.\${
      finalMime.includes('mp4') ? 'mp4' : 'webm'
    }\`,
  };

  onProgress?.(
    \`Ready! Best \${cutDur}s \${moment} detected at \${formatSeconds(peakSec)}\`,
    100
  );

  return {
    detectedMoment: moment,
    peakTimestampSec: peakSec,
    cutStartSec: cutStart,
    cutEndSec: cutEnd,
    cutDurationSec: cutDur,
    autoCaption: caption,
    musicName: trendingTrack.title,
    editedClip,
    hardCutApplied,
  };
}
`,"/src/utils/androidPermissions.ts":`export type PermissionKind =
  | 'overlay'
  | 'storage'
  | 'microphone'
  | 'battery'
  | 'usageAccess';

export interface NativeClipEntry {
  uri: string;
  fileName: string;
  durationSec: number;
  createdAtMs: number;
}

export interface AndroidBridge {
  launchApp?: (packageName: string, playStoreUrl?: string) => boolean;
  openUrlInsideWebView?: (url: string, platformLabel: string, fallbackPackage: string) => void;
  startFloatingAndLaunchGame?: (packageName: string, playStoreUrl: string, gameName: string) => string;
  startFloatingWithOptions?: (
    packageName: string,
    playStoreUrl: string,
    gameName: string,
    reactionMode: boolean,
    facecamEnabled: boolean,
    voiceEffect: string
  ) => string;
  setFloatingRecordingOptions?: (
    facecamEnabled: boolean,
    voiceEffect: string,
    reactionMode: boolean
  ) => void;
  hasCameraPermission?: () => boolean;
  requestCameraPermission?: () => void;
  deleteNativeClipFile?: (uriStr: string) => boolean;
  stopFloatingService?: () => void;
  hasUsageAccessPermission?: () => boolean;
  requestUsageAccessPermission?: () => void;
  canDrawOverlays?: () => boolean;
  requestOverlayPermission?: () => void;
  hasStoragePermission?: () => boolean;
  requestStoragePermission?: () => void;
  hasMicrophonePermission?: () => boolean;
  requestMicrophonePermission?: () => void;
  openMicrophoneSettings?: () => void;
  hasBatteryPermission?: () => boolean;
  requestBatteryPermission?: () => void;
  isPermissionSetupDone?: () => boolean;
  setPermissionSetupDone?: (done: boolean) => void;
  getPermissionStatusJson?: () => string;
  listNativeClipKaroVideosJson?: () => string;
  saveVideoFileToClipKaroFolder?: (fileName: string, base64Video: string) => boolean;
  shareVideoToPlatform?: (
    targetPlatform: string,
    fileName: string,
    base64Video: string,
    nativeUriStr: string,
    captionText: string
  ) => boolean;
}

export interface ClipKaroPermissionState {
  overlay: boolean;
  storage: boolean;
  microphone: boolean;
  battery: boolean;
  usageAccess: boolean;
  setupDone: boolean;
  isNativeAndroid: boolean;
}

const KEY_SETUP_DONE = 'clipkaro_permission_screen_done';
const KEY_OVERLAY = 'clipkaro_perm_overlay_granted';
const KEY_STORAGE = 'clipkaro_perm_storage_granted';
const KEY_MIC = 'clipkaro_perm_mic_granted';
const KEY_BATTERY = 'clipkaro_perm_battery_granted';
const KEY_USAGE_ACCESS = 'clipkaro_perm_usage_granted';

function getAndroidBridge(): AndroidBridge | undefined {
  if (typeof window === 'undefined') return undefined;
  return (window as unknown as { Android?: AndroidBridge }).Android;
}

function readLocalBool(key: string): boolean {
  try {
    return localStorage.getItem(key) === 'true';
  } catch {
    return false;
  }
}

function writeLocalBool(key: string, value: boolean): void {
  try {
    localStorage.setItem(key, value ? 'true' : 'false');
  } catch {
    // ignore storage quota/privacy mode errors
  }
}

export function dispatchPermissionsUpdated(): void {
  if (typeof window !== 'undefined') {
    window.dispatchEvent(new CustomEvent('clipkaro-permissions-updated'));
  }
}

export function getPermissionState(): ClipKaroPermissionState {
  const android = getAndroidBridge();
  if (android && typeof android.getPermissionStatusJson === 'function') {
    try {
      const parsed = JSON.parse(android.getPermissionStatusJson()) as {
        overlay?: boolean;
        storage?: boolean;
        microphone?: boolean;
        battery?: boolean;
        usageAccess?: boolean;
        setupDone?: boolean;
      };
      return {
        overlay: Boolean(parsed.overlay),
        storage: Boolean(parsed.storage),
        microphone: Boolean(parsed.microphone),
        battery: parsed.battery !== undefined ? Boolean(parsed.battery) : true,
        usageAccess: Boolean(parsed.usageAccess),
        setupDone: Boolean(parsed.setupDone),
        isNativeAndroid: true,
      };
    } catch {
      // fall through to individual bridge checks
    }
  }

  if (android) {
    return {
      overlay: android.canDrawOverlays ? android.canDrawOverlays() : false,
      storage: android.hasStoragePermission ? android.hasStoragePermission() : false,
      microphone: android.hasMicrophonePermission ? android.hasMicrophonePermission() : false,
      battery: android.hasBatteryPermission ? android.hasBatteryPermission() : true,
      usageAccess: android.hasUsageAccessPermission ? android.hasUsageAccessPermission() : false,
      setupDone: android.isPermissionSetupDone ? android.isPermissionSetupDone() : false,
      isNativeAndroid: true,
    };
  }

  return {
    overlay: readLocalBool(KEY_OVERLAY),
    storage: readLocalBool(KEY_STORAGE),
    microphone: readLocalBool(KEY_MIC),
    battery: readLocalBool(KEY_BATTERY),
    usageAccess: readLocalBool(KEY_USAGE_ACCESS),
    setupDone: readLocalBool(KEY_SETUP_DONE),
    isNativeAndroid: false,
  };
}

export function markPermissionSetupDone(done = true): void {
  const android = getAndroidBridge();
  if (android?.setPermissionSetupDone) {
    android.setPermissionSetupDone(done);
  }
  writeLocalBool(KEY_SETUP_DONE, done);
  dispatchPermissionsUpdated();
}

export function requestOverlayPermission(): { awaitingNativeSettings: boolean } {
  const android = getAndroidBridge();
  if (android?.requestOverlayPermission) {
    android.requestOverlayPermission();
    return { awaitingNativeSettings: true };
  }

  writeLocalBool(KEY_OVERLAY, true);
  dispatchPermissionsUpdated();
  return { awaitingNativeSettings: false };
}

export function requestStoragePermission(): { awaitingNativeSettings: boolean } {
  const android = getAndroidBridge();
  if (android?.requestStoragePermission) {
    android.requestStoragePermission();
    return { awaitingNativeSettings: true };
  }

  writeLocalBool(KEY_STORAGE, true);
  dispatchPermissionsUpdated();
  return { awaitingNativeSettings: false };
}

export async function requestMicrophonePermission(
  openAppSettingsDirectly = false
): Promise<{ awaitingNativeSettings: boolean }> {
  const android = getAndroidBridge();
  if (android) {
    if (openAppSettingsDirectly && android.openMicrophoneSettings) {
      android.openMicrophoneSettings();
      return { awaitingNativeSettings: true };
    }
    if (android.requestMicrophonePermission) {
      android.requestMicrophonePermission();
      return { awaitingNativeSettings: true };
    }
  }

  try {
    if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      stream.getTracks().forEach((t) => t.stop());
    }
    writeLocalBool(KEY_MIC, true);
  } catch {
    // In web preview iframes, browser microphone policy may block prompt; allow preview testing
    writeLocalBool(KEY_MIC, true);
  }
  dispatchPermissionsUpdated();
  return { awaitingNativeSettings: false };
}

export function requestBatteryPermission(): { awaitingNativeSettings: boolean } {
  const android = getAndroidBridge();
  if (android?.requestBatteryPermission) {
    android.requestBatteryPermission();
    return { awaitingNativeSettings: true };
  }

  writeLocalBool(KEY_BATTERY, true);
  dispatchPermissionsUpdated();
  return { awaitingNativeSettings: false };
}

export function requestUsageAccessPermission(): { awaitingNativeSettings: boolean } {
  const android = getAndroidBridge();
  if (android?.requestUsageAccessPermission) {
    android.requestUsageAccessPermission();
    return { awaitingNativeSettings: true };
  }

  writeLocalBool(KEY_USAGE_ACCESS, true);
  dispatchPermissionsUpdated();
  return { awaitingNativeSettings: false };
}

export function openUrlInsideNativeWebView(
  url: string,
  platformLabel: string,
  fallbackPackage: string
): boolean {
  const android = getAndroidBridge();
  if (android?.openUrlInsideWebView) {
    android.openUrlInsideWebView(url, platformLabel, fallbackPackage);
    return true;
  }
  return false;
}

export function setPreviewPermissionDenied(kind: PermissionKind): void {
  const android = getAndroidBridge();
  if (android) return;
  const keyMap: Record<PermissionKind, string> = {
    overlay: KEY_OVERLAY,
    storage: KEY_STORAGE,
    microphone: KEY_MIC,
    battery: KEY_BATTERY,
    usageAccess: KEY_USAGE_ACCESS,
  };
  writeLocalBool(keyMap[kind], false);
  dispatchPermissionsUpdated();
}

export function setPreviewOverlayDenied(): void {
  setPreviewPermissionDenied('overlay');
}

export function requestCameraPermission(): boolean {
  const android = getAndroidBridge();
  if (android?.hasCameraPermission && android.hasCameraPermission()) {
    return true;
  }
  if (android?.requestCameraPermission) {
    android.requestCameraPermission();
    return false;
  }
  return true;
}

export function syncNativeFloatingOptions(
  facecamEnabled: boolean,
  voiceEffect: string,
  reactionMode: boolean
): void {
  const android = getAndroidBridge();
  android?.setFloatingRecordingOptions?.(facecamEnabled, voiceEffect, reactionMode);
}

export function deleteNativeClipKaroVideo(nativeUri?: string): boolean {
  if (!nativeUri) return false;
  const android = getAndroidBridge();
  if (android?.deleteNativeClipFile) {
    return Boolean(android.deleteNativeClipFile(nativeUri));
  }
  return false;
}

export function listNativeClipKaroVideos(): NativeClipEntry[] {
  const android = getAndroidBridge();
  if (!android?.listNativeClipKaroVideosJson) return [];
  try {
    const raw = android.listNativeClipKaroVideosJson();
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? (parsed as NativeClipEntry[]) : [];
  } catch {
    return [];
  }
}

export async function fetchNativeClipBlob(uri: string): Promise<Blob | null> {
  if (!uri) return null;
  try {
    const res = await fetch(\`https://appassets.androidplatform.net/native-clip?uri=\${encodeURIComponent(uri)}\`);
    if (!res.ok) return null;
    return await res.blob();
  } catch {
    return null;
  }
}

export async function saveVideoToNativeClipKaroFolder(fileName: string, blob: Blob): Promise<boolean> {
  const android = getAndroidBridge();
  if (!android?.saveVideoFileToClipKaroFolder) return false;
  try {
    const bytes = new Uint8Array(await blob.arrayBuffer());
    let binary = '';
    const chunkSize = 0x8000;
    for (let i = 0; i < bytes.length; i += chunkSize) {
      binary += String.fromCharCode(...bytes.subarray(i, i + chunkSize));
    }
    const base64 = btoa(binary);
    return Boolean(android.saveVideoFileToClipKaroFolder(fileName, base64));
  } catch {
    return false;
  }
}

export type ShareTargetPlatform = 'youtube' | 'instagram' | 'whatsapp';

export async function shareClipToPlatform(params: {
  platform: ShareTargetPlatform;
  title: string;
  gameTag: string;
  autoCaption?: string;
  videoBlob: Blob;
  videoMimeType: string;
  nativeUri?: string;
}): Promise<string> {
  const { platform, title, gameTag, autoCaption, videoBlob, videoMimeType, nativeUri } = params;
  const gameHashtag = gameTag.toLowerCase().includes('bgmi') ? '#BGMI' : \`#\${gameTag.replace(/[^A-Za-z0-9]/g, '')}\`;
  const shareText = [
    autoCaption?.trim() || title.trim(),
    \`\${gameHashtag === '#BGMI' ? '' : \`\${gameHashtag} \`}#BGMI #ClipKaro #Gaming\`,
  ]
    .filter(Boolean)
    .join(' ');

  const ext = videoMimeType.includes('mp4') ? 'mp4' : 'webm';
  const fileName = \`\${title.replace(/[^A-Za-z0-9_-]+/g, '_') || 'ClipKaro_Clip'}.\${ext}\`;

  const android = getAndroidBridge();
  if (android?.shareVideoToPlatform) {
    let base64 = '';
    if (!nativeUri) {
      const bytes = new Uint8Array(await videoBlob.arrayBuffer());
      let binary = '';
      const chunkSize = 0x8000;
      for (let i = 0; i < bytes.length; i += chunkSize) {
        binary += String.fromCharCode(...bytes.subarray(i, i + chunkSize));
      }
      base64 = btoa(binary);
    }
    const ok = android.shareVideoToPlatform(
      platform,
      fileName,
      base64,
      nativeUri || '',
      shareText
    );
    if (ok) {
      const appNames: Record<ShareTargetPlatform, string> = {
        youtube: 'YouTube Shorts',
        instagram: 'Instagram Reels',
        whatsapp: 'WhatsApp',
      };
      return \`Opened \${appNames[platform]} share with hashtags #BGMI #ClipKaro\`;
    }
  }

  // Web Browser / Preview fallback: copy hashtags and invoke Web Share API or trigger download
  try {
    await navigator.clipboard?.writeText(shareText);
  } catch {
    // ignore clipboard permission errors
  }

  try {
    const file = new File([videoBlob], fileName, { type: videoMimeType || 'video/mp4' });
    if (navigator.share && navigator.canShare?.({ files: [file] })) {
      await navigator.share({
        title,
        text: shareText,
        files: [file],
      });
      return \`Shared clip with #BGMI #ClipKaro\`;
    }
  } catch {
    // fall through to clean download + copied hashtag toast
  }

  const blobUrl = URL.createObjectURL(videoBlob);
  const a = document.createElement('a');
  a.href = blobUrl;
  a.download = fileName;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(blobUrl), 2500);

  const label =
    platform === 'youtube'
      ? 'YouTube Shorts'
      : platform === 'instagram'
        ? 'Instagram Reels'
        : 'WhatsApp';
  return \`Downloaded clip for \${label} & copied hashtags: #BGMI #ClipKaro\`;
}


`,"/src/utils/embedUrl.ts":`import { SocialPlatform } from '../types/clipkaro';

export interface ParsedEmbedResult {
  platform: SocialPlatform;
  originalUrl: string;
  embedUrl: string | null;
  displayLabel: string;
  isValidUrl: boolean;
  hint?: string;
}

export interface PlatformPreset {
  id: string;
  platform: SocialPlatform;
  label: string;
  creator: string;
  url: string;
}

export const PLATFORM_PRESETS: PlatformPreset[] = [
  {
    id: 'yt-1',
    platform: 'youtube',
    label: 'Blender Studio Open Reel',
    creator: 'BlenderFoundation',
    url: 'https://www.youtube.com/watch?v=aqz-KE-bpKQ',
  },
  {
    id: 'yt-2',
    platform: 'youtube',
    label: 'Lofi Coding & Stream Session',
    creator: 'LofiStudio',
    url: 'https://www.youtube.com/watch?v=jfKfPfyJRdk',
  },
  {
    id: 'ig-1',
    platform: 'instagram',
    label: 'Instagram Creator Reel',
    creator: 'creators',
    url: 'https://www.instagram.com/reel/C8xYz91vK2P/',
  },
  {
    id: 'fb-1',
    platform: 'facebook',
    label: 'Facebook Gaming Highlight',
    creator: 'FacebookGaming',
    url: 'https://www.facebook.com/facebook/videos/10153231379946729/',
  },
];

export function formatCreditHandle(rawName: string): string {
  const cleaned = rawName.trim().replace(/^@+/, '').replace(/\\s+/g, '');
  if (!cleaned) {
    return 'Credit: @StreamerName';
  }
  return \`Credit: @\${cleaned}\`;
}

export function extractYouTubeId(url: string): string | null {
  try {
    const parsed = new URL(url);
    const host = parsed.hostname.replace(/^www\\./, '');
    if (host === 'youtu.be') {
      const id = parsed.pathname.split('/').filter(Boolean)[0];
      return id || null;
    }
    if (host === 'youtube.com' || host === 'm.youtube.com' || host === 'youtube-nocookie.com') {
      if (parsed.pathname === '/watch') {
        return parsed.searchParams.get('v');
      }
      const parts = parsed.pathname.split('/').filter(Boolean);
      if (parts[0] === 'embed' || parts[0] === 'shorts' || parts[0] === 'live') {
        return parts[1] || null;
      }
    }
    return null;
  } catch {
    return null;
  }
}

export function parseSocialEmbedUrl(inputUrl: string, activePlatform: SocialPlatform): ParsedEmbedResult {
  const trimmed = inputUrl.trim();
  if (!trimmed) {
    return {
      platform: activePlatform,
      originalUrl: '',
      embedUrl: null,
      displayLabel: 'Enter a link to open inside ClipKaro',
      isValidUrl: false,
    };
  }

  let normalized = trimmed;
  if (!/^https?:\\/\\//i.test(normalized)) {
    normalized = \`https://\${normalized}\`;
  }

  let parsed: URL;
  try {
    parsed = new URL(normalized);
  } catch {
    return {
      platform: activePlatform,
      originalUrl: trimmed,
      embedUrl: null,
      displayLabel: 'Invalid URL format',
      isValidUrl: false,
      hint: 'Please enter a complete YouTube, Instagram, or Facebook link.',
    };
  }

  const host = parsed.hostname.toLowerCase();

  if (host.includes('youtube.com') || host.includes('youtu.be')) {
    const videoId = extractYouTubeId(normalized);
    if (videoId) {
      return {
        platform: 'youtube',
        originalUrl: normalized,
        embedUrl: \`https://www.youtube.com/embed/\${encodeURIComponent(videoId)}?rel=0&modestbranding=1\`,
        displayLabel: \`YouTube Video (\${videoId})\`,
        isValidUrl: true,
      };
    }
    return {
      platform: 'youtube',
      originalUrl: normalized,
      embedUrl: null,
      displayLabel: 'YouTube link detected',
      isValidUrl: true,
      hint: 'Paste a specific YouTube watch, Shorts, or live video URL to embed the player.',
    };
  }

  if (host.includes('instagram.com')) {
    const parts = parsed.pathname.split('/').filter(Boolean);
    const kind = parts[0];
    const code = parts[1];
    if ((kind === 'p' || kind === 'reel' || kind === 'reels' || kind === 'tv') && code) {
      const embedKind = kind === 'reels' ? 'reel' : kind;
      return {
        platform: 'instagram',
        originalUrl: normalized,
        embedUrl: \`https://www.instagram.com/\${embedKind}/\${encodeURIComponent(code)}/embed/\`,
        displayLabel: \`Instagram \${embedKind === 'reel' ? 'Reel' : 'Post'} (\${code})\`,
        isValidUrl: true,
        hint: 'If Instagram restricts embedding for private or age-gated posts, open the link externally or upload your authorized clip in Cut Video.',
      };
    }
    return {
      platform: 'instagram',
      originalUrl: normalized,
      embedUrl: null,
      displayLabel: 'Instagram profile or page',
      isValidUrl: true,
      hint: 'Paste a direct Instagram Reel or Post URL (/reel/... or /p/...) to open it inside the viewer.',
    };
  }

  if (host.includes('facebook.com') || host.includes('fb.watch')) {
    return {
      platform: 'facebook',
      originalUrl: normalized,
      embedUrl: \`https://www.facebook.com/plugins/video.php?href=\${encodeURIComponent(normalized)}&show_text=false&width=720\`,
      displayLabel: 'Facebook Video Viewer',
      isValidUrl: true,
      hint: 'Public Facebook videos load directly in the embed frame. Private group or restricted videos may require uploading an authorized file.',
    };
  }

  return {
    platform: activePlatform,
    originalUrl: normalized,
    embedUrl: null,
    displayLabel: parsed.hostname,
    isValidUrl: true,
    hint: 'Only YouTube, Instagram, and Facebook URLs support direct social embedding here.',
  };
}
`,"/src/utils/ffmpegCutter.ts":`import { FFmpeg } from '@ffmpeg/ffmpeg';
import { fetchFile, toBlobURL } from '@ffmpeg/util';
import {
  AspectRatioOption,
  SpeedPreset,
  VideoEffectMode,
  VideoFilterPreset,
  VideoFitMode,
} from '../types/clipkaro';

let ffmpegInstance: FFmpeg | null = null;
let loadPromise: Promise<FFmpeg> | null = null;

async function getLoadedFFmpeg(onStatus?: (msg: string) => void): Promise<FFmpeg> {
  if (ffmpegInstance && ffmpegInstance.loaded) {
    return ffmpegInstance;
  }
  if (loadPromise) {
    return loadPromise;
  }

  loadPromise = (async () => {
    onStatus?.('Loading FFmpeg video engine…');
    const ffmpeg = new FFmpeg();
    let basePath = '/ffmpeg';
    try {
      const probe = await fetch('/ffmpeg/ffmpeg-core.js', { method: 'HEAD' });
      const ctype = probe.headers.get('content-type') || '';
      if (!probe.ok || ctype.includes('text/html')) {
        basePath = 'https://unpkg.com/@ffmpeg/core@0.12.10/dist/esm';
      }
    } catch {
      basePath = 'https://unpkg.com/@ffmpeg/core@0.12.10/dist/esm';
    }
    const coreURL = await toBlobURL(\`\${basePath}/ffmpeg-core.js\`, 'text/javascript');
    const wasmURL = await toBlobURL(\`\${basePath}/ffmpeg-core.wasm\`, 'application/wasm');
    await ffmpeg.load({ coreURL, wasmURL });
    ffmpegInstance = ffmpeg;
    return ffmpeg;
  })();

  try {
    return await loadPromise;
  } catch (err) {
    loadPromise = null;
    throw err;
  }
}

async function createTextBarPng(
  text: string,
  targetWidth: number,
  variant: 'credit' | 'caption' | 'viral'
): Promise<Uint8Array> {
  if (variant === 'viral') {
    const badgeW = Math.max(220, Math.round((targetWidth * 360) / 1280));
    const badgeH = Math.max(40, Math.round((badgeW * 52) / 360));
    const canvas = document.createElement('canvas');
    canvas.width = badgeW;
    canvas.height = badgeH;
    const ctx = canvas.getContext('2d');
    if (!ctx) {
      throw new Error('Canvas 2D context unavailable for viral overlay');
    }
    ctx.fillStyle = 'rgba(15, 23, 42, 0.9)';
    ctx.fillRect(0, 0, badgeW, badgeH);
    ctx.fillStyle = '#F59E0B';
    ctx.fillRect(0, badgeH - 3, badgeW, 3);
    const fontSize = Math.max(14, Math.round((badgeW * 20) / 360));
    ctx.font = \`800 \${fontSize}px system-ui, -apple-system, sans-serif\`;
    ctx.fillStyle = '#FDE68A';
    ctx.textBaseline = 'middle';
    ctx.textAlign = 'center';
    ctx.fillText(text, badgeW / 2, badgeH / 2, badgeW - 16);

    const blob = await new Promise<Blob>((resolve, reject) => {
      canvas.toBlob((b) => {
        if (b) resolve(b);
        else reject(new Error('Failed to render viral badge PNG'));
      }, 'image/png');
    });
    const buf = await blob.arrayBuffer();
    return new Uint8Array(buf);
  }

  const width = Math.max(320, Math.round(targetWidth / 2) * 2);
  const height = Math.max(48, Math.round((width * (variant === 'caption' ? 72 : 58)) / 1280));
  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext('2d');
  if (!ctx) {
    throw new Error('Canvas 2D context unavailable for overlay');
  }

  if (variant === 'caption') {
    // Auto-Caption with solid black background pill/bar for clear legibility
    ctx.clearRect(0, 0, width, height);
    const fontSize = Math.max(18, Math.round((width * 26) / 1280));
    ctx.font = \`700 \${fontSize}px system-ui, -apple-system, sans-serif\`;
    const metrics = ctx.measureText(text);
    const padX = Math.round((width * 28) / 1280);
    const boxW = Math.min(width - 24, Math.round(metrics.width + padX * 2));
    const boxH = Math.round(height * 0.78);
    const boxX = Math.round((width - boxW) / 2);
    const boxY = Math.round((height - boxH) / 2);

    ctx.fillStyle = '#000000';
    ctx.fillRect(boxX, boxY, boxW, boxH);

    ctx.fillStyle = '#ffffff';
    ctx.textBaseline = 'middle';
    ctx.textAlign = 'center';
    ctx.fillText(text, width / 2, height / 2, boxW - 16);
  } else {
    // Top credit bar with black background
    ctx.fillStyle = 'rgba(0, 0, 0, 0.88)';
    ctx.fillRect(0, 0, width, height);

    ctx.fillStyle = 'rgba(244, 63, 94, 0.9)';
    ctx.fillRect(0, height - 2, width, 2);

    const fontSize = Math.max(16, Math.round((width * 24) / 1280));
    ctx.font = \`700 \${fontSize}px system-ui, -apple-system, sans-serif\`;
    ctx.fillStyle = '#ffffff';
    ctx.textBaseline = 'middle';
    ctx.textAlign = 'center';
    ctx.fillText(text, width / 2, height / 2, width - 32);
  }

  const blob = await new Promise<Blob>((resolve, reject) => {
    canvas.toBlob((b) => {
      if (b) resolve(b);
      else reject(new Error('Failed to render overlay PNG'));
    }, 'image/png');
  });

  const buf = await blob.arrayBuffer();
  return new Uint8Array(buf);
}

export interface TrimVideoParams {
  sourceBlob: Blob;
  sourceFileName: string;
  startSec: number;
  durationSec: number;
  videoWidth?: number;
  burnCredit: boolean;
  creditText: string;
  burnAutoCaption?: boolean;
  autoCaptionText?: string;
  burnViralScore?: boolean;
  viralScoreText?: string;
  aspectRatio?: AspectRatioOption;
  fitMode?: VideoFitMode;
  filterPreset?: VideoFilterPreset;
  effectMode?: VideoEffectMode;
  uniformSpeed?: SpeedPreset;
  onProgress?: (percent: number, stage: string) => void;
}

export interface TrimVideoResult {
  mp4Blob: Blob;
  thumbnailDataUrl?: string;
}

function buildFfmpegVisualFilters(params: {
  aspectRatio?: AspectRatioOption;
  fitMode?: VideoFitMode;
  filterPreset?: VideoFilterPreset;
  effectMode?: VideoEffectMode;
  uniformSpeed?: SpeedPreset;
  fallbackW: number;
}): { vfChain: string; targetW: number; atempoChain: string | null } {
  const { aspectRatio, fitMode = 'fill', filterPreset = 'none', effectMode = 'none', uniformSpeed = 1, fallbackW } = params;
  const parts: string[] = [];

  let targetW = fallbackW;
  let targetH = -2;
  if (aspectRatio === '9:16') {
    targetW = 720;
    targetH = 1280;
  } else if (aspectRatio === '1:1') {
    targetW = 720;
    targetH = 720;
  } else if (aspectRatio === '4:5') {
    targetW = 720;
    targetH = 900;
  } else if (aspectRatio === '16:9') {
    targetW = 1280;
    targetH = 720;
  }

  if (aspectRatio) {
    if (fitMode === 'fit') {
      parts.push(
        \`scale=\${targetW}:\${targetH}:force_original_aspect_ratio=decrease,pad=\${targetW}:\${targetH}:(ow-iw)/2:(oh-ih)/2:black\`
      );
    } else {
      parts.push(
        \`scale=\${targetW}:\${targetH}:force_original_aspect_ratio=increase,crop=\${targetW}:\${targetH}\`
      );
    }
  } else {
    parts.push(\`scale=\${targetW}:-2\`);
  }

  if (filterPreset === 'cinematic') parts.push('eq=contrast=1.14:saturation=0.88:brightness=-0.03');
  else if (filterPreset === 'vivid') parts.push('eq=contrast=1.12:saturation=1.42:brightness=0.02');
  else if (filterPreset === 'warm') parts.push('colorbalance=rs=0.08:gs=0.02:bs=-0.08,eq=saturation=1.18');
  else if (filterPreset === 'cool') parts.push('colorbalance=rs=-0.07:gs=0.01:bs=0.1,eq=contrast=1.06');
  else if (filterPreset === 'bw') parts.push('hue=s=0,eq=contrast=1.18');
  else if (filterPreset === 'vintage') parts.push('colorbalance=rs=0.1:gs=0.04:bs=-0.1,eq=contrast=0.94:saturation=0.82');
  else if (filterPreset === 'hdr') parts.push('eq=contrast=1.25:saturation=1.24:brightness=0.03');

  if (effectMode === 'cinematic') {
    parts.push('eq=contrast=1.1:saturation=0.92');
    parts.push('drawbox=x=0:y=0:w=iw:h=ih*0.12:color=black:t=fill');
    parts.push('drawbox=x=0:y=ih*0.88:w=iw:h=ih*0.12:color=black:t=fill');
  } else if (effectMode === 'gaming') {
    parts.push('eq=contrast=1.22:saturation=1.25:brightness=0.03');
  } else if (effectMode === 'vlog') {
    parts.push('eq=brightness=0.08:contrast=0.96:saturation=1.1');
  } else if (effectMode === 'night') {
    parts.push('eq=brightness=0.18:contrast=1.08:saturation=1.06');
  }

  let atempoChain: string | null = null;
  if (uniformSpeed && uniformSpeed !== 1) {
    parts.push(\`setpts=\${(1 / uniformSpeed).toFixed(4)}*PTS\`);
    if (uniformSpeed === 0.25) atempoChain = 'atempo=0.5,atempo=0.5';
    else if (uniformSpeed === 0.5) atempoChain = 'atempo=0.5';
    else if (uniformSpeed === 1.5) atempoChain = 'atempo=1.5';
    else if (uniformSpeed === 2) atempoChain = 'atempo=2.0';
  }

  return { vfChain: parts.join(','), targetW, atempoChain };
}

export async function trimVideoWithFFmpeg(params: TrimVideoParams): Promise<TrimVideoResult> {
  const {
    sourceBlob,
    sourceFileName,
    startSec,
    durationSec,
    videoWidth,
    burnCredit,
    creditText,
    burnAutoCaption = false,
    autoCaptionText = '',
    burnViralScore = false,
    viralScoreText = '',
    aspectRatio,
    fitMode,
    filterPreset,
    effectMode,
    uniformSpeed,
    onProgress,
  } = params;

  onProgress?.(5, 'Loading FFmpeg engine…');
  const ffmpeg = await getLoadedFFmpeg((msg) => onProgress?.(10, msg));

  const extMatch = sourceFileName.match(/\\.([a-z0-9]+)$/i);
  const inputExt = extMatch
    ? extMatch[1].toLowerCase()
    : sourceBlob.type.includes('mp4')
      ? 'mp4'
      : 'webm';
  const ts = Date.now();
  const inputFile = \`input_\${ts}.\${inputExt}\`;
  const creditOverlayFile = \`credit_\${ts}.png\`;
  const captionOverlayFile = \`caption_\${ts}.png\`;
  const viralOverlayFile = \`viral_\${ts}.png\`;
  const outputFile = \`output_\${ts}.mp4\`;

  const hasCreditOverlay = burnCredit && creditText.trim().length > 0;
  const hasCaptionOverlay = burnAutoCaption && autoCaptionText.trim().length > 0;
  const hasViralOverlay = burnViralScore && viralScoreText.trim().length > 0;

  const progressHandler = ({ progress }: { progress: number }) => {
    const safePct = Math.max(15, Math.min(96, 15 + Math.round((progress || 0) * 80)));
    onProgress?.(
      safePct,
      hasCreditOverlay || hasCaptionOverlay || hasViralOverlay
        ? 'Trimming & burning overlays onto MP4…'
        : 'Cutting MP4 video…'
    );
  };

  ffmpeg.on('progress', progressHandler);

  try {
    onProgress?.(12, 'Preparing video file…');
    await ffmpeg.writeFile(inputFile, await fetchFile(sourceBlob));

    const safeStart = Math.max(0, startSec).toFixed(2);
    const safeDur = Math.max(1, durationSec).toFixed(2);
    const fallbackW = Math.max(320, Math.round((videoWidth || 1280) / 2) * 2);
    const { vfChain, targetW, atempoChain } = buildFfmpegVisualFilters({
      aspectRatio,
      fitMode,
      filterPreset,
      effectMode,
      uniformSpeed,
      fallbackW,
    });

    const args: string[] = ['-ss', safeStart, '-t', safeDur, '-i', inputFile];

    let nextInputIdx = 1;
    let creditIdx = -1;
    let captionIdx = -1;
    let viralIdx = -1;

    if (hasCreditOverlay) {
      const creditPng = await createTextBarPng(creditText.trim(), targetW, 'credit');
      await ffmpeg.writeFile(creditOverlayFile, creditPng);
      args.push('-i', creditOverlayFile);
      creditIdx = nextInputIdx++;
    }

    if (hasCaptionOverlay) {
      const captionPng = await createTextBarPng(autoCaptionText.trim(), targetW, 'caption');
      await ffmpeg.writeFile(captionOverlayFile, captionPng);
      args.push('-i', captionOverlayFile);
      captionIdx = nextInputIdx++;
    }

    if (hasViralOverlay) {
      const viralPng = await createTextBarPng(viralScoreText.trim(), targetW, 'viral');
      await ffmpeg.writeFile(viralOverlayFile, viralPng);
      args.push('-i', viralOverlayFile);
      viralIdx = nextInputIdx++;
    }

    if (creditIdx !== -1 || captionIdx !== -1 || viralIdx !== -1) {
      const chains: string[] = [\`[0:v]\${vfChain}[v0]\`];
      let prev = 'v0';
      let step = 1;
      if (creditIdx !== -1) {
        const out = \`v\${step++}\`;
        chains.push(\`[\${prev}][\${creditIdx}:v]overlay=0:0[\${out}]\`);
        prev = out;
      }
      if (captionIdx !== -1) {
        const out = \`v\${step++}\`;
        chains.push(\`[\${prev}][\${captionIdx}:v]overlay=0:H-h-16[\${out}]\`);
        prev = out;
      }
      if (viralIdx !== -1) {
        const out = \`v\${step++}\`;
        chains.push(\`[\${prev}][\${viralIdx}:v]overlay=W-w-16:16[\${out}]\`);
        prev = out;
      }
      args.push('-filter_complex', chains.join(';'), '-map', \`[\${prev}]\`, '-map', '0:a?');
    } else {
      args.push('-vf', vfChain, '-map', '0:v:0', '-map', '0:a?');
    }

    if (atempoChain) {
      args.push('-af', atempoChain);
    }

    const outDur =
      uniformSpeed && uniformSpeed !== 1
        ? Math.max(0.5, Number(safeDur) / uniformSpeed).toFixed(2)
        : safeDur;

    args.push(
      '-c:v',
      'libx264',
      '-preset',
      'ultrafast',
      '-crf',
      '23',
      '-pix_fmt',
      'yuv420p',
      '-c:a',
      'aac',
      '-b:a',
      '128k',
      '-movflags',
      '+faststart',
      '-t',
      outDur,
      outputFile
    );

    const exitCode = await ffmpeg.exec(args);

    if (exitCode !== 0) {
      throw new Error(\`FFmpeg exited with code \${exitCode}\`);
    }

    onProgress?.(98, 'Finalizing MP4 clip…');
    const outputData = await ffmpeg.readFile(outputFile);
    if (typeof outputData === 'string') {
      throw new Error('Unexpected string output from FFmpeg');
    }

    const copiedBytes = new Uint8Array(outputData.byteLength);
    copiedBytes.set(outputData);
    const mp4Blob = new Blob([copiedBytes.buffer], { type: 'video/mp4' });
    onProgress?.(100, 'Complete');

    return { mp4Blob };
  } finally {
    ffmpeg.off('progress', progressHandler);
    await ffmpeg.deleteFile(inputFile).catch(() => undefined);
    await ffmpeg.deleteFile(creditOverlayFile).catch(() => undefined);
    await ffmpeg.deleteFile(captionOverlayFile).catch(() => undefined);
    await ffmpeg.deleteFile(viralOverlayFile).catch(() => undefined);
    await ffmpeg.deleteFile(outputFile).catch(() => undefined);
  }
}
`,"/src/utils/mediaGenerators.ts":`import { RoyaltyFreeTrack } from '../types/clipkaro';

export const ROYALTY_FREE_TRACKS: RoyaltyFreeTrack[] = [
  {
    id: 'trending-phonk-clutch',
    title: 'Trending: Phonk Clutch Drop',
    mood: 'Trending / BGMI Montage',
    bpm: 136,
    durationSec: 12,
    license: 'ClipKaro Safe License (CC0)',
  },
  {
    id: 'trending-bgmi-victory',
    title: 'Trending: Victory Zone Bass',
    mood: 'Trending / Headshot Shorts',
    bpm: 124,
    durationSec: 12,
    license: 'ClipKaro Safe License (CC0)',
  },
  {
    id: 'lofi-studio',
    title: 'Lo-Fi Studio Beat',
    mood: 'Chill / Stream Commentary',
    bpm: 84,
    durationSec: 12,
    license: 'ClipKaro Safe License (CC0)',
  },
  {
    id: 'night-drive',
    title: 'Night Drive Synth',
    mood: 'Electronic / Highlight Reel',
    bpm: 112,
    durationSec: 12,
    license: 'ClipKaro Safe License (CC0)',
  },
  {
    id: 'acoustic-chill',
    title: 'Acoustic Stream Warmth',
    mood: 'Warm / Podcast & IRL',
    bpm: 92,
    durationSec: 12,
    license: 'ClipKaro Safe License (CC0)',
  },
  {
    id: 'tournament-hype',
    title: 'Tournament Hype Loop',
    mood: 'Energetic / Clutch Moments',
    bpm: 128,
    durationSec: 12,
    license: 'ClipKaro Safe License (CC0)',
  },
];

function encodeWavFromFloat32(samples: Float32Array, sampleRate: number): Blob {
  const buffer = new ArrayBuffer(44 + samples.length * 2);
  const view = new DataView(buffer);

  const writeString = (offset: number, str: string) => {
    for (let i = 0; i < str.length; i += 1) {
      view.setUint8(offset + i, str.charCodeAt(i));
    }
  };

  writeString(0, 'RIFF');
  view.setUint32(4, 36 + samples.length * 2, true);
  writeString(8, 'WAVE');
  writeString(12, 'fmt ');
  view.setUint32(16, 16, true);
  view.setUint16(20, 1, true);
  view.setUint16(22, 1, true);
  view.setUint32(24, sampleRate, true);
  view.setUint32(28, sampleRate * 2, true);
  view.setUint16(32, 2, true);
  view.setUint16(34, 16, true);
  writeString(36, 'data');
  view.setUint32(40, samples.length * 2, true);

  let offset = 44;
  for (let i = 0; i < samples.length; i += 1) {
    const clamped = Math.max(-1, Math.min(1, samples[i]));
    view.setInt16(offset, clamped < 0 ? clamped * 0x8000 : clamped * 0x7fff, true);
    offset += 2;
  }

  return new Blob([buffer], { type: 'audio/wav' });
}

export function generateRoyaltyFreeWavBlob(trackId: string): Blob {
  const sampleRate = 22050;
  const track = ROYALTY_FREE_TRACKS.find((t) => t.id === trackId) ?? ROYALTY_FREE_TRACKS[0];
  const length = sampleRate * track.durationSec;
  const samples = new Float32Array(length);

  const chordsByTrack: Record<string, number[][]> = {
    'lofi-studio': [
      [220, 261.63, 329.63],
      [174.61, 220, 261.63],
      [196, 246.94, 293.66],
      [164.81, 196, 246.94],
    ],
    'night-drive': [
      [146.83, 220, 293.66],
      [130.81, 196, 261.63],
      [116.54, 174.61, 233.08],
      [130.81, 196, 261.63],
    ],
    'acoustic-chill': [
      [196, 246.94, 293.66],
      [164.81, 207.65, 246.94],
      [146.83, 220, 293.66],
      [130.81, 196, 261.63],
    ],
    'trending-phonk-clutch': [
      [98, 146.83, 196],
      [116.54, 174.61, 233.08],
      [130.81, 196, 261.63],
      [92.5, 138.59, 185],
    ],
    'trending-bgmi-victory': [
      [123.47, 185, 246.94],
      [146.83, 220, 293.66],
      [164.81, 246.94, 329.63],
      [130.81, 196, 261.63],
    ],
    'tournament-hype': [
      [110, 164.81, 220],
      [130.81, 196, 261.63],
      [146.83, 220, 293.66],
      [164.81, 246.94, 329.63],
    ],
  };

  const chords = chordsByTrack[track.id] ?? chordsByTrack['lofi-studio'];
  const beatDur = 60 / track.bpm;

  for (let i = 0; i < length; i += 1) {
    const t = i / sampleRate;
    const barIndex = Math.floor(t / (beatDur * 2)) % chords.length;
    const chord = chords[barIndex];
    const beatPos = (t % beatDur) / beatDur;

    // Warm harmonic pad
    let pad = 0;
    for (const freq of chord) {
      pad += Math.sin(2 * Math.PI * freq * t) * 0.11;
    }

    // Gentle rhythmic pulse / kick envelope
    const kickEnv = Math.exp(-beatPos * 12);
    const kickFreq = 55 + 90 * Math.exp(-beatPos * 24);
    const kick = Math.sin(2 * Math.PI * kickFreq * t) * kickEnv * (track.id === 'tournament-hype' ? 0.35 : 0.22);

    // Subtle arpeggio pluck on half-beats
    const eighthPos = ((t * 2) % beatDur) / beatDur;
    const arpFreq = chord[Math.floor((t * 2) / beatDur) % chord.length] * 2;
    const arp = Math.sin(2 * Math.PI * arpFreq * t) * Math.exp(-eighthPos * 8) * 0.1;

    // Smooth fade in/out at loop boundary
    const fadeIn = Math.min(1, t / 0.15);
    const fadeOut = Math.min(1, (track.durationSec - t) / 0.25);
    samples[i] = (pad + kick + arp) * fadeIn * fadeOut;
  }

  return encodeWavFromFloat32(samples, sampleRate);
}

export function formatSeconds(totalSeconds: number): string {
  const safe = Math.max(0, Math.floor(totalSeconds));
  const mins = Math.floor(safe / 60);
  const secs = safe % 60;
  return \`\${String(mins).padStart(2, '0')}:\${String(secs).padStart(2, '0')}\`;
}

export async function captureVideoThumbnail(videoEl: HTMLVideoElement): Promise<string | undefined> {
  try {
    const width = videoEl.videoWidth || 640;
    const height = videoEl.videoHeight || 360;
    const canvas = document.createElement('canvas');
    canvas.width = 480;
    canvas.height = Math.max(270, Math.round((480 * height) / width));
    const ctx = canvas.getContext('2d');
    if (!ctx) return undefined;
    ctx.drawImage(videoEl, 0, 0, canvas.width, canvas.height);
    return canvas.toDataURL('image/jpeg', 0.8);
  } catch {
    return undefined;
  }
}

export type ThumbnailStylePreset = 'clutch-red-gold' | 'cyber-cyan' | 'dark-impact';

export function generateStyledThumbnailDataUrl(options: {
  videoEl?: HTMLVideoElement | null;
  fallbackImageUrl?: string;
  headline: string;
  badgeText?: string;
  stylePreset: ThumbnailStylePreset;
}): Promise<string> {
  const { videoEl, fallbackImageUrl, headline, badgeText = '#BGMI', stylePreset } = options;

  return new Promise((resolve) => {
    const canvas = document.createElement('canvas');
    canvas.width = 1280;
    canvas.height = 720;
    const ctx = canvas.getContext('2d')!;

    const drawOverlay = () => {
      const vignette = ctx.createLinearGradient(0, 0, 0, canvas.height);
      vignette.addColorStop(0, 'rgba(5, 7, 11, 0.25)');
      vignette.addColorStop(0.55, 'rgba(5, 7, 11, 0.38)');
      vignette.addColorStop(1, 'rgba(5, 7, 11, 0.92)');
      ctx.fillStyle = vignette;
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      const glowColor =
        stylePreset === 'cyber-cyan'
          ? 'rgba(56, 189, 248, 0.34)'
          : stylePreset === 'dark-impact'
            ? 'rgba(244, 63, 94, 0.28)'
            : 'rgba(225, 29, 72, 0.42)';
      const radial = ctx.createRadialGradient(
        canvas.width * 0.5,
        canvas.height * 0.52,
        40,
        canvas.width * 0.5,
        canvas.height * 0.52,
        600
      );
      radial.addColorStop(0, glowColor);
      radial.addColorStop(1, 'rgba(0,0,0,0)');
      ctx.fillStyle = radial;
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      const badgeLabel = badgeText.trim() || '#BGMI';
      ctx.font = '800 28px system-ui, -apple-system, sans-serif';
      const badgeW = Math.min(340, Math.max(150, ctx.measureText(badgeLabel).width + 44));
      ctx.fillStyle = stylePreset === 'cyber-cyan' ? '#0284C7' : '#E11D48';
      ctx.fillRect(48, 42, badgeW, 54);
      ctx.fillStyle = '#FFFFFF';
      ctx.textBaseline = 'middle';
      ctx.textAlign = 'center';
      ctx.fillText(badgeLabel, 48 + badgeW / 2, 69, badgeW - 20);

      const mainText = (headline.trim() || '1 VS 4 CLUTCH').toUpperCase();
      ctx.save();
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';

      let fontSize = 112;
      if (mainText.length > 16) fontSize = 86;
      if (mainText.length > 24) fontSize = 68;
      ctx.font = \`900 \${fontSize}px system-ui, -apple-system, Impact, sans-serif\`;

      const textX = canvas.width / 2;
      const textY = canvas.height - 138;

      if (stylePreset === 'dark-impact') {
        const textMetrics = ctx.measureText(mainText);
        const boxW = Math.min(canvas.width - 80, textMetrics.width + 88);
        ctx.fillStyle = 'rgba(0, 0, 0, 0.88)';
        ctx.fillRect(textX - boxW / 2, textY - 70, boxW, 136);
        ctx.fillStyle = '#E11D48';
        ctx.fillRect(textX - boxW / 2, textY + 62, boxW, 6);
      }

      ctx.lineWidth = 16;
      ctx.strokeStyle = '#05070B';
      ctx.lineJoin = 'round';
      ctx.strokeText(mainText, textX, textY, canvas.width - 96);

      const textGrad = ctx.createLinearGradient(0, textY - 56, 0, textY + 56);
      if (stylePreset === 'cyber-cyan') {
        textGrad.addColorStop(0, '#FFFFFF');
        textGrad.addColorStop(1, '#38BDF8');
      } else if (stylePreset === 'dark-impact') {
        textGrad.addColorStop(0, '#FFFFFF');
        textGrad.addColorStop(1, '#F43F5E');
      } else {
        textGrad.addColorStop(0, '#FFFBEB');
        textGrad.addColorStop(0.55, '#FACC15');
        textGrad.addColorStop(1, '#F97316');
      }
      ctx.fillStyle = textGrad;
      ctx.fillText(mainText, textX, textY, canvas.width - 96);
      ctx.restore();

      ctx.font = '700 22px system-ui, sans-serif';
      ctx.fillStyle = 'rgba(255,255,255,0.85)';
      ctx.textAlign = 'right';
      ctx.fillText('ClipKaro', canvas.width - 48, 66);

      resolve(canvas.toDataURL('image/jpeg', 0.9));
    };

    const drawBackdrop = () => {
      const bg = ctx.createLinearGradient(0, 0, canvas.width, canvas.height);
      bg.addColorStop(0, '#090D16');
      bg.addColorStop(0.55, '#172033');
      bg.addColorStop(1, '#1E0B14');
      ctx.fillStyle = bg;
      ctx.fillRect(0, 0, canvas.width, canvas.height);
    };

    if (videoEl && videoEl.readyState >= 2 && videoEl.videoWidth > 0) {
      try {
        ctx.drawImage(videoEl, 0, 0, canvas.width, canvas.height);
        drawOverlay();
        return;
      } catch {
        // fallback below
      }
    }

    if (fallbackImageUrl) {
      const img = new Image();
      img.crossOrigin = 'anonymous';
      img.onload = () => {
        ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
        drawOverlay();
      };
      img.onerror = () => {
        drawBackdrop();
        drawOverlay();
      };
      img.src = fallbackImageUrl;
      return;
    }

    drawBackdrop();
    drawOverlay();
  });
}

export interface SampleVideoOptions {
  durationSec: number;
  title: string;
  creditLine: string;
  onProgress?: (pct: number) => void;
}

export function generateSampleStreamVideoBlob(options: SampleVideoOptions): Promise<Blob> {
  const { durationSec, title, creditLine, onProgress } = options;
  return new Promise((resolve, reject) => {
    const canvas = document.createElement('canvas');
    canvas.width = 854;
    canvas.height = 480;
    const ctx = canvas.getContext('2d');
    if (!ctx) {
      reject(new Error('Canvas context unavailable'));
      return;
    }

    const canvasStream = canvas.captureStream(30);
    let audioCtx: AudioContext | null = null;
    let combinedStream = canvasStream;
    let soundTimer: number | null = null;

    try {
      audioCtx = new AudioContext();
      if (audioCtx.state === 'suspended') {
        audioCtx.resume().catch(() => undefined);
      }
      const dest = audioCtx.createMediaStreamDestination();
      const masterGain = audioCtx.createGain();
      masterGain.gain.value = 0.28;
      masterGain.connect(dest);

      // Warm ambient chord bed + rhythmic game synth pulses so sample video has clear audible sound
      const notes = [261.63, 329.63, 392.0, 523.25];
      let step = 0;

      const triggerNote = () => {
        if (!audioCtx || audioCtx.state === 'closed') return;
        const now = audioCtx.currentTime;
        const osc = audioCtx.createOscillator();
        const env = audioCtx.createGain();
        osc.type = step % 2 === 0 ? 'triangle' : 'sine';
        osc.frequency.setValueAtTime(notes[step % notes.length], now);
        env.gain.setValueAtTime(0.001, now);
        env.gain.exponentialRampToValueAtTime(0.35, now + 0.04);
        env.gain.exponentialRampToValueAtTime(0.001, now + 0.42);
        osc.connect(env);
        env.connect(masterGain);
        osc.start(now);
        osc.stop(now + 0.45);

        // Subtle bass pulse every 2 steps
        if (step % 2 === 0) {
          const bass = audioCtx.createOscillator();
          const bassEnv = audioCtx.createGain();
          bass.type = 'sine';
          bass.frequency.setValueAtTime(130.81, now);
          bass.frequency.exponentialRampToValueAtTime(65.41, now + 0.18);
          bassEnv.gain.setValueAtTime(0.45, now);
          bassEnv.gain.exponentialRampToValueAtTime(0.001, now + 0.22);
          bass.connect(bassEnv);
          bassEnv.connect(masterGain);
          bass.start(now);
          bass.stop(now + 0.24);
        }
        step += 1;
      };

      triggerNote();
      soundTimer = window.setInterval(triggerNote, 450);

      combinedStream = new MediaStream([
        ...canvasStream.getVideoTracks(),
        ...dest.stream.getAudioTracks(),
      ]);
    } catch {
      // Fallback to video-only stream if AudioContext is blocked
    }

    const mimeType = MediaRecorder.isTypeSupported('video/webm;codecs=vp8,opus')
      ? 'video/webm;codecs=vp8,opus'
      : MediaRecorder.isTypeSupported('video/webm;codecs=vp9,opus')
        ? 'video/webm;codecs=vp9,opus'
        : MediaRecorder.isTypeSupported('video/webm')
          ? 'video/webm'
          : '';

    const recorder = mimeType
      ? new MediaRecorder(combinedStream, { mimeType, videoBitsPerSecond: 2_500_000 })
      : new MediaRecorder(combinedStream);

    const chunks: BlobPart[] = [];
    recorder.ondataavailable = (ev) => {
      if (ev.data && ev.data.size > 0) chunks.push(ev.data);
    };

    const startTime = performance.now();
    const totalMs = Math.max(3000, durationSec * 1000);
    let rafId = 0;

    const drawFrame = () => {
      const elapsedMs = performance.now() - startTime;
      const t = elapsedMs / 1000;
      const progress = Math.min(1, elapsedMs / totalMs);
      onProgress?.(Math.round(progress * 100));

      // 1. Sunset / Twilight Arena Sky Backdrop
      const skyGrad = ctx.createLinearGradient(0, 0, 0, canvas.height * 0.62);
      skyGrad.addColorStop(0, '#0b1120');
      skyGrad.addColorStop(0.55, '#1e293b');
      skyGrad.addColorStop(1, '#3b1d3a');
      ctx.fillStyle = skyGrad;
      ctx.fillRect(0, 0, canvas.width, canvas.height * 0.62);

      // Sun / horizon glow
      const sunX = canvas.width * 0.5 + Math.sin(t * 0.35) * 40;
      const sunY = canvas.height * 0.44;
      const sunGrad = ctx.createRadialGradient(sunX, sunY, 12, sunX, sunY, 140);
      sunGrad.addColorStop(0, 'rgba(251, 146, 60, 0.9)');
      sunGrad.addColorStop(0.4, 'rgba(244, 63, 94, 0.35)');
      sunGrad.addColorStop(1, 'rgba(244, 63, 94, 0)');
      ctx.fillStyle = sunGrad;
      ctx.beginPath();
      ctx.arc(sunX, sunY, 140, 0, Math.PI * 2);
      ctx.fill();

      // Distant mountain silhouettes
      ctx.fillStyle = '#0f172a';
      ctx.beginPath();
      ctx.moveTo(0, canvas.height * 0.62);
      for (let x = 0; x <= canvas.width; x += 60) {
        const ridge = Math.sin(x * 0.012 + 1.2) * 34 + Math.cos(x * 0.025) * 18;
        ctx.lineTo(x, canvas.height * 0.55 - ridge);
      }
      ctx.lineTo(canvas.width, canvas.height * 0.62);
      ctx.closePath();
      ctx.fill();

      // 2. Ground / 3D Perspective Arena Floor
      const floorTop = canvas.height * 0.62;
      const floorGrad = ctx.createLinearGradient(0, floorTop, 0, canvas.height);
      floorGrad.addColorStop(0, '#111827');
      floorGrad.addColorStop(1, '#05080f');
      ctx.fillStyle = floorGrad;
      ctx.fillRect(0, floorTop, canvas.width, canvas.height - floorTop);

      // Perspective lanes moving toward camera
      ctx.strokeStyle = 'rgba(56, 189, 248, 0.28)';
      ctx.lineWidth = 1.5;
      const vanishX = canvas.width / 2;
      for (let lane = -8; lane <= 8; lane += 1) {
        ctx.beginPath();
        ctx.moveTo(vanishX + lane * 24, floorTop);
        ctx.lineTo(vanishX + lane * 135, canvas.height);
        ctx.stroke();
      }
      for (let row = 0; row < 7; row += 1) {
        const z = ((row / 7 + t * 0.55) % 1);
        const y = floorTop + Math.pow(z, 1.8) * (canvas.height - floorTop);
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(canvas.width, y);
        ctx.stroke();
      }

      // 3. Moving Player Target / Action Drone in Arena
      const targetX = canvas.width * 0.5 + Math.sin(t * 1.6) * 190;
      const targetY = canvas.height * 0.52 + Math.cos(t * 2.2) * 42;
      ctx.fillStyle = '#38bdf8';
      ctx.beginPath();
      ctx.arc(targetX, targetY, 16, 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = '#ffffff';
      ctx.lineWidth = 2.5;
      ctx.beginPath();
      ctx.arc(targetX, targetY, 26 + Math.sin(t * 6) * 4, 0, Math.PI * 2);
      ctx.stroke();

      // Smooth tracking crosshair reticle
      const aimX = canvas.width * 0.5 + Math.sin(t * 1.6 - 0.18) * 180;
      const aimY = canvas.height * 0.52 + Math.cos(t * 2.2 - 0.18) * 38;
      ctx.strokeStyle = '#f43f5e';
      ctx.lineWidth = 2.5;
      ctx.beginPath();
      ctx.arc(aimX, aimY, 22, 0, Math.PI * 2);
      ctx.stroke();
      ctx.beginPath();
      ctx.moveTo(aimX - 32, aimY);
      ctx.lineTo(aimX - 12, aimY);
      ctx.moveTo(aimX + 12, aimY);
      ctx.lineTo(aimX + 32, aimY);
      ctx.moveTo(aimX, aimY - 32);
      ctx.lineTo(aimX, aimY - 12);
      ctx.moveTo(aimX, aimY + 12);
      ctx.lineTo(aimX, aimY + 32);
      ctx.stroke();

      // 4. Streamer Facecam Picture-in-Picture Frame (Bottom-Right)
      const camW = 152;
      const camH = 104;
      const camX = canvas.width - camW - 24;
      const camY = canvas.height - camH - 24;
      ctx.fillStyle = '#1e293b';
      ctx.fillRect(camX, camY, camW, camH);
      ctx.strokeStyle = '#f43f5e';
      ctx.lineWidth = 2.5;
      ctx.strokeRect(camX, camY, camW, camH);
      // Stylized streamer silhouette in facecam
      ctx.fillStyle = '#94a3b8';
      ctx.beginPath();
      ctx.arc(camX + camW / 2, camY + 38, 18, 0, Math.PI * 2);
      ctx.fill();
      ctx.beginPath();
      ctx.arc(camX + camW / 2, camY + 92, 34, Math.PI, 0);
      ctx.fill();
      ctx.fillStyle = '#f8fafc';
      ctx.font = '600 11px system-ui, sans-serif';
      ctx.fillText('STREAM CAM', camX + 10, camY + 18);

      // 5. Stream Title & Match HUD Overlay (Top-Left)
      ctx.fillStyle = 'rgba(11, 14, 20, 0.78)';
      ctx.fillRect(24, 22, 390, 68);
      ctx.fillStyle = '#f8fafc';
      ctx.font = '700 22px system-ui, sans-serif';
      ctx.fillText(title || 'Sample Gameplay Stream', 40, 52);
      ctx.fillStyle = '#cbd5e1';
      ctx.font = '500 14px system-ui, sans-serif';
      ctx.fillText(creditLine || 'Credit: @StreamerName', 40, 76);

      // Live Clock HUD (Bottom-Left)
      ctx.fillStyle = 'rgba(11, 14, 20, 0.82)';
      ctx.fillRect(24, canvas.height - 62, 150, 38);
      ctx.fillStyle = '#f43f5e';
      ctx.font = '700 16px monospace';
      ctx.fillText(\`LIVE \${t.toFixed(1)}s\`, 38, canvas.height - 37);

      if (elapsedMs < totalMs) {
        rafId = requestAnimationFrame(drawFrame);
      } else if (recorder.state === 'recording') {
        recorder.stop();
      }
    };

    recorder.onstop = () => {
      cancelAnimationFrame(rafId);
      if (soundTimer !== null) window.clearInterval(soundTimer);
      audioCtx?.close().catch(() => undefined);
      const blob = new Blob(chunks, { type: mimeType || 'video/webm' });
      resolve(blob);
    };

    recorder.onerror = (err) => {
      cancelAnimationFrame(rafId);
      if (soundTimer !== null) window.clearInterval(soundTimer);
      audioCtx?.close().catch(() => undefined);
      reject(err);
    };

    recorder.start(250);
    rafId = requestAnimationFrame(drawFrame);
  });
}
`,"/src/utils/mediaStorage.ts":`import { ClipItem, GameItem } from '../types/clipkaro';

const DB_NAME = 'clipkaro_studio_db';
const DB_VERSION = 1;
const CLIPS_STORE = 'clips';
const GAMES_STORE = 'games';
const COPYRIGHT_MODE_KEY = 'clipkaro_copyright_safe_mode';

export const DEFAULT_GAMES: GameItem[] = [
  {
    id: 'game-bgmi',
    name: 'BGMI',
    genre: 'Battle Royale',
    coverUrl: '/src/assets/images/game_tactical_arena_1795269900712.jpg',
    androidPackage: 'com.pubg.imobile',
    iconKey: 'bgmi',
  },
  {
    id: 'game-free-fire-max',
    name: 'Free Fire MAX',
    genre: 'Battle Royale',
    coverUrl: '/src/assets/images/game_tactical_arena_1795269900712.jpg',
    androidPackage: 'com.dts.freefiremax',
    iconKey: 'freefire',
  },
  {
    id: 'game-gta-v',
    name: 'GTA V',
    genre: 'Open World Action',
    coverUrl: '/src/assets/images/game_coastal_highway_1795269900686.jpg',
    androidPackage: 'com.rockstargames.gtav',
    iconKey: 'gtav',
  },
  {
    id: 'game-minecraft',
    name: 'Minecraft',
    genre: 'Sandbox Survival',
    coverUrl: '/src/assets/images/game_voxel_valley_1795269899720.jpg',
    androidPackage: 'com.mojang.minecraftpe',
    iconKey: 'minecraft',
  },
  {
    id: 'game-valorant',
    name: 'Valorant',
    genre: 'Tactical Shooter',
    coverUrl: '/src/assets/images/game_tactical_arena_1795269900712.jpg',
    androidPackage: 'com.riotgames.valorant',
    iconKey: 'valorant',
  },
  {
    id: 'game-cod-mobile',
    name: 'Call of Duty Mobile',
    genre: 'Multiplayer FPS',
    coverUrl: '/src/assets/images/game_stadium_floodlights_1795269900819.jpg',
    androidPackage: 'com.activision.callofduty.shooter',
    iconKey: 'codm',
  },
];

function openDatabase(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);
    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains(CLIPS_STORE)) {
        const clipStore = db.createObjectStore(CLIPS_STORE, { keyPath: 'id' });
        clipStore.createIndex('createdAt', 'createdAt', { unique: false });
      }
      if (!db.objectStoreNames.contains(GAMES_STORE)) {
        db.createObjectStore(GAMES_STORE, { keyPath: 'id' });
      }
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

export async function getAllClips(): Promise<ClipItem[]> {
  const db = await openDatabase();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(CLIPS_STORE, 'readonly');
    const store = tx.objectStore(CLIPS_STORE);
    const req = store.getAll();
    req.onsuccess = () => {
      const items = (req.result as ClipItem[]).sort((a, b) => b.createdAt - a.createdAt);
      resolve(items);
    };
    req.onerror = () => reject(req.error);
  });
}

export async function saveClipToDb(clip: ClipItem): Promise<void> {
  const db = await openDatabase();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(CLIPS_STORE, 'readwrite');
    const store = tx.objectStore(CLIPS_STORE);
    const req = store.put(clip);
    req.onsuccess = () => resolve();
    req.onerror = () => reject(req.error);
  });
}

export async function deleteClipFromDb(id: string): Promise<void> {
  const db = await openDatabase();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(CLIPS_STORE, 'readwrite');
    const store = tx.objectStore(CLIPS_STORE);
    const req = store.delete(id);
    req.onsuccess = () => resolve();
    req.onerror = () => reject(req.error);
  });
}

export async function getAllGames(): Promise<GameItem[]> {
  const db = await openDatabase();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(GAMES_STORE, 'readonly');
    const store = tx.objectStore(GAMES_STORE);
    const req = store.getAll();
    req.onsuccess = () => {
      const customGames = req.result as GameItem[];
      resolve([...DEFAULT_GAMES, ...customGames]);
    };
    req.onerror = () => reject(req.error);
  });
}

export async function addCustomGameToDb(game: GameItem): Promise<void> {
  const db = await openDatabase();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(GAMES_STORE, 'readwrite');
    const store = tx.objectStore(GAMES_STORE);
    const req = store.put({ ...game, isCustom: true });
    req.onsuccess = () => resolve();
    req.onerror = () => reject(req.error);
  });
}

export async function deleteCustomGameFromDb(id: string): Promise<void> {
  const db = await openDatabase();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(GAMES_STORE, 'readwrite');
    const store = tx.objectStore(GAMES_STORE);
    const req = store.delete(id);
    req.onsuccess = () => resolve();
    req.onerror = () => reject(req.error);
  });
}

export function getStoredCopyrightSafeMode(): boolean {
  try {
    const stored = localStorage.getItem(COPYRIGHT_MODE_KEY);
    if (stored === null) return true; // Default ON as required
    return stored === 'true';
  } catch {
    return true;
  }
}

export function setStoredCopyrightSafeMode(enabled: boolean): void {
  try {
    localStorage.setItem(COPYRIGHT_MODE_KEY, String(enabled));
  } catch {
    // ignore storage errors
  }
}

const AUTO_DELETE_7D_KEY = 'clipkaro_auto_delete_7days';
const KEEP_BEST_CLIPS_KEY = 'clipkaro_keep_best_clips';
const REACTION_MODE_KEY = 'clipkaro_reaction_mode_enabled';
const FACECAM_ENABLED_KEY = 'clipkaro_facecam_enabled';
const VOICE_CHANGER_KEY = 'clipkaro_voice_changer_preset';
const SHOW_VIRAL_SCORE_KEY = 'clipkaro_show_viral_score_in_app';

export function getStoredShowViralScoreInApp(): boolean {
  try {
    const val = localStorage.getItem(SHOW_VIRAL_SCORE_KEY);
    return val === null ? true : val === 'true';
  } catch {
    return true;
  }
}

export function setStoredShowViralScoreInApp(enabled: boolean): void {
  try {
    localStorage.setItem(SHOW_VIRAL_SCORE_KEY, String(enabled));
  } catch {
    // ignore
  }
}

export function getStoredAutoDelete7Days(): boolean {
  try {
    return localStorage.getItem(AUTO_DELETE_7D_KEY) === 'true';
  } catch {
    return false;
  }
}

export function setStoredAutoDelete7Days(enabled: boolean): void {
  try {
    localStorage.setItem(AUTO_DELETE_7D_KEY, String(enabled));
  } catch {
    // ignore
  }
}

export function getStoredKeepBestClips(): boolean {
  try {
    const val = localStorage.getItem(KEEP_BEST_CLIPS_KEY);
    return val === null ? true : val === 'true';
  } catch {
    return true;
  }
}

export function setStoredKeepBestClips(enabled: boolean): void {
  try {
    localStorage.setItem(KEEP_BEST_CLIPS_KEY, String(enabled));
  } catch {
    // ignore
  }
}

export function getStoredReactionOptions(): {
  reactionMode: boolean;
  facecamEnabled: boolean;
  voiceChanger: 'normal' | 'funny' | 'robot' | 'deep';
} {
  try {
    const reactionMode = localStorage.getItem(REACTION_MODE_KEY) === 'true';
    const facecamEnabled = localStorage.getItem(FACECAM_ENABLED_KEY) === 'true';
    const vc = localStorage.getItem(VOICE_CHANGER_KEY);
    const voiceChanger =
      vc === 'funny' || vc === 'robot' || vc === 'deep' ? vc : 'normal';
    return { reactionMode, facecamEnabled, voiceChanger };
  } catch {
    return { reactionMode: false, facecamEnabled: false, voiceChanger: 'normal' };
  }
}

export function setStoredReactionOptions(opts: {
  reactionMode?: boolean;
  facecamEnabled?: boolean;
  voiceChanger?: 'normal' | 'funny' | 'robot' | 'deep';
}): void {
  try {
    if (opts.reactionMode !== undefined) {
      localStorage.setItem(REACTION_MODE_KEY, String(opts.reactionMode));
    }
    if (opts.facecamEnabled !== undefined) {
      localStorage.setItem(FACECAM_ENABLED_KEY, String(opts.facecamEnabled));
    }
    if (opts.voiceChanger !== undefined) {
      localStorage.setItem(VOICE_CHANGER_KEY, opts.voiceChanger);
    }
  } catch {
    // ignore
  }
}

export function calculateClipsStorageBytes(clips: ClipItem[]): number {
  return clips.reduce((acc, clip) => {
    const vSize = clip.videoBlob?.size || 0;
    const voSize = clip.voiceBlob?.size || 0;
    const muSize = clip.musicBlob?.size || 0;
    const prSize = clip.permission?.proofBlob?.size || 0;
    return acc + vSize + voSize + muSize + prSize;
  }, 0);
}

export function formatStorageBytes(bytes: number): string {
  if (bytes <= 0) return '0 MB used';
  const kb = bytes / 1024;
  if (kb < 1024) return \`\${Math.max(1, Math.round(kb))} KB used\`;
  const mb = kb / 1024;
  if (mb < 1024) return \`\${mb.toFixed(1)} MB used\`;
  const gb = mb / 1024;
  return \`\${gb.toFixed(2)} GB used\`;
}

export function findExpiredClips(
  clips: ClipItem[],
  keepBestClips: boolean,
  nowMs = Date.now()
): ClipItem[] {
  const sevenDaysMs = 7 * 24 * 60 * 60 * 1000;
  return clips.filter((clip) => {
    if (keepBestClips && clip.isFavourite) return false;
    return nowMs - (clip.createdAt || nowMs) > sevenDaysMs;
  });
}

export function selectTodaysBestClip(clips: ClipItem[]): {
  clip: ClipItem;
  reason: string;
  isFromToday: boolean;
} | null {
  if (!clips.length) return null;

  const startOfToday = new Date();
  startOfToday.setHours(0, 0, 0, 0);
  const todayCutoff = startOfToday.getTime();
  const todaysClips = clips.filter((c) => c.createdAt >= todayCutoff);
  const pool = todaysClips.length > 0 ? todaysClips : clips;
  const isFromToday = todaysClips.length > 0;

  let best = pool[0];
  let bestScore = -1;
  let bestReason = 'Longest recording';

  for (const clip of pool) {
    const titleLower = clip.title.toLowerCase();
    const isHighlight =
      titleLower.includes('headshot') ||
      titleLower.includes('kill') ||
      titleLower.includes('clutch') ||
      titleLower.includes('highlight') ||
      Boolean(clip.autoCaption?.toLowerCase().includes('headshot'));
    const kills = clip.killCount ?? (isHighlight ? 2 : 0);

    let score = Math.min(clip.durationSec || 0, 600);
    if (clip.isFavourite) score += 2000;
    if (kills > 0) score += kills * 300;
    if (isHighlight) score += 250;

    if (score > bestScore) {
      bestScore = score;
      best = clip;
      if (clip.isFavourite) {
        bestReason = 'Marked Favourite / Best';
      } else if (kills > 0 || isHighlight) {
        bestReason = kills > 1 ? \`\${kills} Kills / Highlight\` : 'Auto Highlight Moment';
      } else {
        bestReason = \`Longest (\${clip.durationSec}s)\`;
      }
    }
  }

  return { clip: best, reason: bestReason, isFromToday };
}

`,"/src/utils/videoEditorPresets.ts":`import {
  AspectRatioOption,
  SpeedPreset,
  SpeedSegment,
  VideoEffectMode,
  VideoFilterPreset,
} from '../types/clipkaro';

export const ASPECT_RATIO_OPTIONS: {
  id: AspectRatioOption;
  label: string;
  platformHint: string;
}[] = [
  { id: '16:9', label: '16:9', platformHint: 'YouTube Horizontal' },
  { id: '9:16', label: '9:16', platformHint: 'Shorts / Reels Vertical' },
  { id: '1:1', label: '1:1', platformHint: 'IG / FB Square' },
  { id: '4:5', label: '4:5', platformHint: 'Instagram Portrait' },
];

export const FILTER_PRESETS: {
  id: VideoFilterPreset;
  label: string;
  cssFilter: string;
}[] = [
  { id: 'none', label: 'Original', cssFilter: '' },
  {
    id: 'cinematic',
    label: 'Cinematic',
    cssFilter: 'contrast(1.14) saturate(0.88) brightness(0.95) sepia(0.08)',
  },
  {
    id: 'vivid',
    label: 'Vivid',
    cssFilter: 'saturate(1.42) contrast(1.12) brightness(1.03)',
  },
  {
    id: 'warm',
    label: 'Warm',
    cssFilter: 'sepia(0.24) saturate(1.22) brightness(1.03)',
  },
  {
    id: 'cool',
    label: 'Cool',
    cssFilter: 'saturate(0.95) contrast(1.06) brightness(1.02) hue-rotate(-14deg)',
  },
  {
    id: 'bw',
    label: 'Black & White',
    cssFilter: 'grayscale(1) contrast(1.18)',
  },
  {
    id: 'vintage',
    label: 'Vintage',
    cssFilter: 'sepia(0.42) contrast(0.94) brightness(0.96) saturate(0.85)',
  },
  {
    id: 'hdr',
    label: 'HDR Look',
    cssFilter: 'contrast(1.28) saturate(1.26) brightness(1.04)',
  },
];

export const EFFECT_MODES: {
  id: VideoEffectMode;
  label: string;
  description: string;
  cssFilter: string;
}[] = [
  { id: 'none', label: 'Standard', description: 'Original look', cssFilter: '' },
  {
    id: 'cinematic',
    label: 'Cinematic',
    description: '2.35:1 black bars + film look',
    cssFilter: 'contrast(1.12) saturate(0.9) brightness(0.96)',
  },
  {
    id: 'gaming',
    label: 'Gaming',
    description: 'Sharp + High Contrast',
    cssFilter: 'contrast(1.25) saturate(1.28) brightness(1.04)',
  },
  {
    id: 'vlog',
    label: 'Vlog',
    description: 'Bright + Soft',
    cssFilter: 'brightness(1.1) contrast(0.95) saturate(1.12)',
  },
  {
    id: 'night',
    label: 'Night',
    description: 'Low light boost',
    cssFilter: 'brightness(1.28) contrast(1.1) saturate(1.08)',
  },
];

export const SPEED_OPTIONS: SpeedPreset[] = [0.25, 0.5, 1, 1.5, 2];

export function combineCssFilters(
  filterPreset: VideoFilterPreset = 'none',
  effectMode: VideoEffectMode = 'none'
): string {
  const f = FILTER_PRESETS.find((x) => x.id === filterPreset)?.cssFilter ?? '';
  const m = EFFECT_MODES.find((x) => x.id === effectMode)?.cssFilter ?? '';
  return [f, m].filter(Boolean).join(' ') || 'none';
}

export function getAspectContainerClass(ratio: AspectRatioOption = '16:9'): string {
  switch (ratio) {
    case '9:16':
      return 'aspect-[9/16] max-h-[360px] mx-auto';
    case '1:1':
      return 'aspect-square max-h-[340px] mx-auto';
    case '4:5':
      return 'aspect-[4/5] max-h-[360px] mx-auto';
    case '16:9':
    default:
      return 'aspect-video w-full';
  }
}

export function getSpeedAtTime(segments: SpeedSegment[] | undefined, timeSec: number): SpeedPreset {
  if (!segments || segments.length === 0) return 1;
  const match = segments.find((seg) => timeSec >= seg.startSec && timeSec <= seg.endSec);
  if (match) return match.speed;
  if (timeSec < segments[0].startSec) return segments[0].speed;
  return segments[segments.length - 1].speed;
}

export function getSpeedSegmentClasses(speed: SpeedPreset): {
  barClass: string;
  badgeClass: string;
  tag: string;
} {
  if (speed < 1) {
    return {
      barClass: 'bg-sky-500/80 hover:bg-sky-400',
      badgeClass: 'border-sky-500/50 bg-sky-950/50 text-sky-200',
      tag: 'Slow-Mo',
    };
  }
  if (speed > 1) {
    return {
      barClass: 'bg-rose-500/85 hover:bg-rose-400',
      badgeClass: 'border-rose-500/50 bg-rose-950/50 text-rose-200',
      tag: 'Fast',
    };
  }
  return {
    barClass: 'bg-emerald-500/75 hover:bg-emerald-400',
    badgeClass: 'border-emerald-500/50 bg-emerald-950/40 text-emerald-200',
    tag: 'Normal',
  };
}
`,"/src/utils/viralScore.ts":`import { ClipItem } from '../types/clipkaro';
import { trimVideoWithFFmpeg } from './ffmpegCutter';

export interface ViralScoreResult {
  score: number;
  verdict: string;
  label: string;
  tip: string;
  tier: 'high' | 'medium' | 'low';
}

export function calculateViralScore(clip: ClipItem): ViralScoreResult {
  const dur = Math.max(0, clip.trimEnd > clip.trimStart ? clip.trimEnd - clip.trimStart : clip.durationSec);

  // 1. Length score (15-30 sec = highest)
  let lengthPts = 10;
  if (dur >= 15 && dur <= 30) {
    lengthPts = 35;
  } else if ((dur >= 10 && dur < 15) || (dur > 30 && dur <= 45)) {
    lengthPts = 22;
  } else if (dur > 45 && dur <= 60) {
    lengthPts = 15;
  }

  // 2. Music used
  const hasMusic = Boolean(clip.musicBlob || clip.musicName);
  const musicPts = hasMusic ? 22 : 0;

  // 3. Caption used
  const hasCaption = Boolean(clip.autoCaption && clip.autoCaption.trim().length > 0);
  const captionPts = hasCaption ? 20 : 0;

  // 4. Filter / Mode used
  const hasFilter = Boolean(
    (clip.filterPreset && clip.filterPreset !== 'none') ||
      (clip.effectMode && clip.effectMode !== 'none')
  );
  const filterPts = hasFilter ? 15 : 0;

  // 5. Bonus: Thumbnail + Vertical Ratio
  const hasThumb = Boolean(clip.thumbnailDataUrl);
  const isVertical = clip.aspectRatio === '9:16' || clip.aspectRatio === '4:5';
  const bonusPts = (hasThumb ? 4 : 0) + (isVertical ? 4 : 0);

  const score = Math.min(100, Math.max(15, lengthPts + musicPts + captionPts + filterPts + bonusPts));

  let verdict = 'Thoda aur edit karo';
  let tier: ViralScoreResult['tier'] = 'low';
  if (score >= 80) {
    verdict = 'Ye Reels par chalegi!';
    tier = 'high';
  } else if (score >= 55) {
    verdict = 'Achhi reach aa sakti hai!';
    tier = 'medium';
  }

  let tip = 'Score top par hai — Shorts & Reels par post karo!';
  if (!hasMusic) {
    tip = 'Score badhane ke liye Music lagao';
  } else if (!hasCaption) {
    tip = 'Score badhane ke liye Auto Caption lagao';
  } else if (!hasFilter) {
    tip = 'Score badhane ke liye Cinematic Filter lagao';
  } else if (!hasThumb) {
    tip = 'Score badhane ke liye Thumbnail lagao';
  } else if (dur < 15 || dur > 30) {
    tip = '15-30 sec cut karne par aur zyada Viral Score milega';
  }

  return {
    score,
    verdict,
    label: \`Viral Score: \${score}/100 - \${verdict}\`,
    tip,
    tier,
  };
}

export async function prepareExportVideoBlobWithViralScore(
  clip: ClipItem,
  includeViralScore: boolean
): Promise<{ blob: Blob; mimeType: string; nativeUri?: string; scoreBadgeText?: string }> {
  if (!includeViralScore) {
    return {
      blob: clip.videoBlob,
      mimeType: clip.videoMimeType,
      nativeUri: clip.nativeUri,
    };
  }

  const viral = calculateViralScore(clip);
  const badgeText = \`Viral Score: \${viral.score}/100\`;
  const dur = Math.max(1, clip.trimEnd > clip.trimStart ? clip.trimEnd - clip.trimStart : clip.durationSec);

  try {
    const rendered = await trimVideoWithFFmpeg({
      sourceBlob: clip.videoBlob,
      sourceFileName: clip.nativeFileName || \`\${clip.title}.mp4\`,
      startSec: Math.max(0, clip.trimStart || 0),
      durationSec: dur,
      burnCredit: false,
      creditText: clip.permission.creditText,
      burnViralScore: true,
      viralScoreText: badgeText,
      aspectRatio: clip.aspectRatio,
      fitMode: clip.fitMode,
      filterPreset: clip.filterPreset,
      effectMode: clip.effectMode,
    });
    return {
      blob: rendered.mp4Blob,
      mimeType: 'video/mp4',
      nativeUri: undefined,
      scoreBadgeText: badgeText,
    };
  } catch {
    // Offline fallback if FFmpeg WASM is not cached
    return {
      blob: clip.videoBlob,
      mimeType: clip.videoMimeType,
      nativeUri: clip.nativeUri,
      scoreBadgeText: badgeText,
    };
  }
}
`,"/src/utils/zipBuilder.ts":`export interface ZipInputFile {
  path: string;
  content: string | Uint8Array;
}

const CRC_TABLE = (() => {
  const table = new Uint32Array(256);
  for (let i = 0; i < 256; i++) {
    let c = i;
    for (let k = 0; k < 8; k++) {
      c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    }
    table[i] = c >>> 0;
  }
  return table;
})();

function crc32(bytes: Uint8Array): number {
  let crc = 0xffffffff;
  for (let i = 0; i < bytes.length; i++) {
    crc = CRC_TABLE[(crc ^ bytes[i]) & 0xff] ^ (crc >>> 8);
  }
  return (crc ^ 0xffffffff) >>> 0;
}

export function createZipBlob(files: ZipInputFile[]): Blob {
  const encoder = new TextEncoder();
  const localParts: Uint8Array[] = [];
  const centralParts: Uint8Array[] = [];
  let offset = 0;

  const now = new Date();
  const dosTime =
    ((now.getHours() & 0x1f) << 11) |
    ((now.getMinutes() & 0x3f) << 5) |
    ((now.getSeconds() >> 1) & 0x1f);
  const dosDate =
    (((Math.max(1980, now.getFullYear()) - 1980) & 0x7f) << 9) |
    (((now.getMonth() + 1) & 0x0f) << 5) |
    (now.getDate() & 0x1f);

  for (const file of files) {
    const cleanName = file.path.replace(/^\\/+/, '');
    const nameBytes = encoder.encode(cleanName);
    const dataBytes =
      typeof file.content === 'string' ? encoder.encode(file.content) : file.content;
    const crc = crc32(dataBytes);

    // Local file header (30 bytes + filename)
    const localHeader = new Uint8Array(30 + nameBytes.length);
    const lv = new DataView(localHeader.buffer);
    lv.setUint32(0, 0x04034b50, true);
    lv.setUint16(4, 20, true); // version needed
    lv.setUint16(6, 0x0800, true); // UTF-8 filename flag
    lv.setUint16(8, 0, true); // store (no compression)
    lv.setUint16(10, dosTime, true);
    lv.setUint16(12, dosDate, true);
    lv.setUint32(14, crc, true);
    lv.setUint32(18, dataBytes.length, true);
    lv.setUint32(22, dataBytes.length, true);
    lv.setUint16(26, nameBytes.length, true);
    lv.setUint16(28, 0, true);
    localHeader.set(nameBytes, 30);

    localParts.push(localHeader, dataBytes);

    // Central directory header (46 bytes + filename)
    const centralHeader = new Uint8Array(46 + nameBytes.length);
    const cv = new DataView(centralHeader.buffer);
    cv.setUint32(0, 0x02014b50, true);
    cv.setUint16(4, 20, true);
    cv.setUint16(6, 20, true);
    cv.setUint16(8, 0x0800, true);
    cv.setUint16(10, 0, true);
    cv.setUint16(12, dosTime, true);
    cv.setUint16(14, dosDate, true);
    cv.setUint32(16, crc, true);
    cv.setUint32(20, dataBytes.length, true);
    cv.setUint32(24, dataBytes.length, true);
    cv.setUint16(28, nameBytes.length, true);
    cv.setUint16(30, 0, true);
    cv.setUint16(32, 0, true);
    cv.setUint16(34, 0, true);
    cv.setUint16(36, 0, true);
    cv.setUint32(38, 0, true);
    cv.setUint32(42, offset, true);
    centralHeader.set(nameBytes, 46);

    centralParts.push(centralHeader);
    offset += localHeader.length + dataBytes.length;
  }

  let centralSize = 0;
  for (const part of centralParts) {
    centralSize += part.length;
  }

  const endRecord = new Uint8Array(22);
  const ev = new DataView(endRecord.buffer);
  ev.setUint32(0, 0x06054b50, true);
  ev.setUint16(4, 0, true);
  ev.setUint16(6, 0, true);
  ev.setUint16(8, files.length, true);
  ev.setUint16(10, files.length, true);
  ev.setUint32(12, centralSize, true);
  ev.setUint32(16, offset, true);
  ev.setUint16(20, 0, true);

  const totalSize = offset + centralSize + endRecord.length;
  const outputBuffer = new ArrayBuffer(totalSize);
  const outputBytes = new Uint8Array(outputBuffer);
  let cursor = 0;

  for (const part of localParts) {
    outputBytes.set(part, cursor);
    cursor += part.length;
  }
  for (const part of centralParts) {
    outputBytes.set(part, cursor);
    cursor += part.length;
  }
  outputBytes.set(endRecord, cursor);

  return new Blob([outputBuffer], {
    type: 'application/zip',
  });
}

export function triggerBlobDownload(blob: Blob, filename: string): void {
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement('a');
  anchor.href = url;
  anchor.download = filename;
  anchor.rel = 'noopener';
  anchor.style.display = 'none';
  document.body.appendChild(anchor);
  anchor.click();
  setTimeout(() => {
    document.body.removeChild(anchor);
    URL.revokeObjectURL(url);
  }, 4000);
}
`,"/tsconfig.json":`{
  "compilerOptions": {
    "target": "ES2022",
    "experimentalDecorators": true,
    "useDefineForClassFields": false,
    "module": "ESNext",
    "types": ["vite/client"],
    "lib": [
      "ES2022",
      "DOM",
      "DOM.Iterable"
    ],
    "skipLibCheck": true,
    "moduleResolution": "bundler",
    "isolatedModules": true,
    "moduleDetection": "force",
    "allowJs": true,
    "jsx": "react-jsx",
    "paths": {
      "@/*": [
        "./*"
      ]
    },
    "allowImportingTsExtensions": true,
    "noEmit": true
  },
  "exclude": ["dist"]
}
`,"/vite.config.ts":`import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import fs from 'fs';
import path from 'path';
import {defineConfig} from 'vite';

export default defineConfig(() => {
  return {
    plugins: [
      react(),
      tailwindcss(),
      // Copies src/assets into dist/ so root-relative URLs like
      // "/src/assets/images/..." (e.g. generate_image output) still resolve
      // in production builds. Do not remove.
      {
        name: 'copy-unbundled-src-assets',
        apply: 'build',
        closeBundle(error?: Error): void {
          if (error) {
            return;
          }
          const distDir = path.resolve(__dirname, 'dist');
          const srcAssets = path.resolve(__dirname, 'src/assets');
          const distAssets = path.resolve(distDir, 'src/assets');
          if (fs.existsSync(distDir) && fs.existsSync(srcAssets)) {
            fs.cpSync(srcAssets, distAssets, {recursive: true, force: true});
          }
        },
      },
    ],
    resolve: {
      alias: {
        '@': path.resolve(__dirname, '.'),
      },
    },
    optimizeDeps: {
      exclude: ['@ffmpeg/ffmpeg', '@ffmpeg/util'],
    },
    server: {
      // HMR is disabled in AI Studio via DISABLE_HMR env var.
      // Do not modify—file watching is disabled to prevent flickering during agent edits.
      hmr: process.env.DISABLE_HMR !== 'true',
      // Disable file watching when DISABLE_HMR is true to save CPU during agent edits.
      watch: process.env.DISABLE_HMR === 'true' ? null : {},
    },
  };
});
`}),t=[`src/assets/images/game_tactical_arena_1795269900712.jpg`,`src/assets/images/game_coastal_highway_1795269900686.jpg`,`src/assets/images/game_voxel_valley_1795269899720.jpg`,`src/assets/images/game_stadium_floodlights_1795269900819.jpg`];function n(e){return e.startsWith(`android/`)?`android`:e.startsWith(`.github/`)||e.startsWith(`scripts/`)||e===`BUILD_APK_ON_MOBILE.md`||e===`capacitor.config.json`?`build`:`react`}var r=new TextEncoder,i=Object.entries(e).map(([e,t])=>{let i=e.replace(/^\/+/,``);return{path:i,category:n(i),content:t,sizeBytes:r.encode(t).byteLength}}).sort((e,t)=>{let n={android:0,react:1,build:2};return n[e.category]===n[t.category]?e.path.localeCompare(t.path):n[e.category]-n[t.category]});export{t as ASSET_IMAGE_PATHS,i as PROJECT_SOURCE_FILES};
package com.clipkaro.app;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.PowerManager;
import android.provider.Settings;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.activity.OnBackPressedCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.webkit.WebViewAssetLoader;

public class MainActivity extends AppCompatActivity {

    public static final String EXTRA_REQUEST_PROJECTION_GAME = "request_projection_game";

    private static final String PREFS_NAME = "clipkaro_prefs";
    private static final String KEY_PERMISSION_DONE = "permission_screen_done";

    private WebView webView;
    private ValueCallback<Uri[]> filePathCallback;

    private String pendingLaunchPackage = null;
    private String pendingLaunchPlayStore = null;
    private String pendingLaunchGameName = "BGMI";

    private final ActivityResultLauncher<Intent> fileChooserLauncher =
        registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result -> {
            if (filePathCallback == null) return;
            Uri[] results = WebChromeClient.FileChooserParams.parseResult(
                result.getResultCode(),
                result.getData()
            );
            filePathCallback.onReceiveValue(results);
            filePathCallback = null;
        });

    private final ActivityResultLauncher<String> micPermissionLauncher =
        registerForActivityResult(new ActivityResultContracts.RequestPermission(), granted -> {
            if (Boolean.TRUE.equals(granted)) {
                notifyPermissionsUpdated();
            } else {
                openAppDetailsSettings();
            }
        });

    private final ActivityResultLauncher<Intent> settingsDeepLinkLauncher =
        registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result -> {
            notifyPermissionsUpdated();
        });

    private final ActivityResultLauncher<Intent> overlayPermissionLauncher =
        registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result -> {
            notifyPermissionsUpdated();
        });

    private final ActivityResultLauncher<Intent> mediaProjectionLauncher =
        registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result -> {
            int code = result.getResultCode();
            Intent data = result.getData();
            startFloatingClipService(
                code == Activity.RESULT_OK ? code : Activity.RESULT_CANCELED,
                code == Activity.RESULT_OK ? data : null,
                pendingLaunchGameName
            );
            String pkg = pendingLaunchPackage;
            String store = pendingLaunchPlayStore;
            pendingLaunchPackage = null;
            pendingLaunchPlayStore = null;
            if (pkg != null && !pkg.isEmpty()) {
                launchInstalledPackageOrPlayStore(pkg, store);
            }
        });

    @SuppressLint({"SetJavaScriptEnabled", "JavascriptInterface"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        webView = new WebView(this);
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);

        final WebViewAssetLoader.AssetsPathHandler assetsHandler =
            new WebViewAssetLoader.AssetsPathHandler(this);

        final WebViewAssetLoader assetLoader = new WebViewAssetLoader.Builder()
            .addPathHandler("/", path -> {
                String cleanPath = path.startsWith("/") ? path.substring(1) : path;
                if (cleanPath.isEmpty()) {
                    cleanPath = "index.html";
                }
                WebResourceResponse response = assetsHandler.handle("public/" + cleanPath);
                if (response != null && response.getData() != null) {
                    return response;
                }
                return assetsHandler.handle(cleanPath);
            })
            .build();

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return assetLoader.shouldInterceptRequest(request.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                String scheme = uri.getScheme();
                if ("intent".equalsIgnoreCase(scheme) || "market".equalsIgnoreCase(scheme)) {
                    try {
                        Intent intent = Intent.parseUri(uri.toString(), Intent.URI_INTENT_SCHEME);
                        if (intent.resolveActivity(getPackageManager()) != null) {
                            startActivity(intent);
                        } else {
                            String fallback = intent.getStringExtra("browser_fallback_url");
                            if (fallback != null) {
                                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(fallback)));
                            }
                        }
                        return true;
                    } catch (Exception ignored) {
                        return true;
                    }
                }
                return false;
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onPermissionRequest(final PermissionRequest request) {
                runOnUiThread(() -> request.grant(request.getResources()));
            }

            @Override
            public boolean onShowFileChooser(
                WebView webView,
                ValueCallback<Uri[]> filePathCallback,
                FileChooserParams fileChooserParams
            ) {
                if (MainActivity.this.filePathCallback != null) {
                    MainActivity.this.filePathCallback.onReceiveValue(null);
                }
                MainActivity.this.filePathCallback = filePathCallback;
                Intent intent = fileChooserParams.createIntent();
                fileChooserLauncher.launch(intent);
                return true;
            }
        });

        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                if (webView != null && webView.canGoBack()) {
                    webView.goBack();
                } else {
                    setEnabled(false);
                    getOnBackPressedDispatcher().onBackPressed();
                }
            }
        });

        webView.addJavascriptInterface(new ClipKaroAndroidBridge(), "Android");
        webView.loadUrl("https://appassets.androidplatform.net/index.html");
        handleProjectionPromptIntent(getIntent());
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleProjectionPromptIntent(intent);
    }

    private void handleProjectionPromptIntent(Intent intent) {
        if (intent != null && intent.hasExtra(EXTRA_REQUEST_PROJECTION_GAME)) {
            String game = intent.getStringExtra(EXTRA_REQUEST_PROJECTION_GAME);
            pendingLaunchGameName = (game != null && !game.isEmpty()) ? game : "BGMI";
            pendingLaunchPackage = null;
            pendingLaunchPlayStore = null;
            requestMediaProjectionCapture();
        }
    }

    private void requestMediaProjectionCapture() {
        MediaProjectionManager mpm =
            (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);
        if (mpm != null) {
            mediaProjectionLauncher.launch(mpm.createScreenCaptureIntent());
        } else {
            startFloatingClipService(Activity.RESULT_CANCELED, null, pendingLaunchGameName);
            if (pendingLaunchPackage != null && !pendingLaunchPackage.isEmpty()) {
                launchInstalledPackageOrPlayStore(pendingLaunchPackage, pendingLaunchPlayStore);
            }
        }
    }

    private void startFloatingClipService(int resultCode, Intent resultData, String gameName) {
        Intent serviceIntent = new Intent(this, FloatingClipService.class);
        serviceIntent.setAction(FloatingClipService.ACTION_START);
        serviceIntent.putExtra(FloatingClipService.EXTRA_GAME_NAME, gameName != null ? gameName : "BGMI");
        if (resultCode == Activity.RESULT_OK && resultData != null) {
            serviceIntent.putExtra(FloatingClipService.EXTRA_RESULT_CODE, resultCode);
            serviceIntent.putExtra(FloatingClipService.EXTRA_RESULT_DATA, resultData);
        }
        ContextCompat.startForegroundService(this, serviceIntent);
    }

    private boolean launchInstalledPackageOrPlayStore(String packageName, String playStoreUrl) {
        PackageManager pm = getPackageManager();
        Intent launchIntent = pm.getLaunchIntentForPackage(packageName);
        if (launchIntent != null) {
            launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(launchIntent);
            return true;
        }
        try {
            Intent marketIntent = new Intent(
                Intent.ACTION_VIEW,
                Uri.parse("market://details?id=" + packageName)
            );
            marketIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(marketIntent);
        } catch (Exception e) {
            if (playStoreUrl != null && !playStoreUrl.isEmpty()) {
                Intent webIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(playStoreUrl));
                webIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(webIntent);
            }
        }
        return false;
    }

    private void openAppDetailsSettings() {
        Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
        intent.setData(Uri.parse("package:" + getPackageName()));
        runOnUiThread(() -> settingsDeepLinkLauncher.launch(intent));
    }

    private void openOverlaySettingsDeepLink() {
        Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION);
        intent.setData(Uri.parse("package:" + getPackageName()));
        runOnUiThread(() -> overlayPermissionLauncher.launch(intent));
    }

    @SuppressLint("BatteryLife")
    private void openBatteryOptimizationDeepLink() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Intent intent = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS);
            intent.setData(Uri.parse("package:" + getPackageName()));
            runOnUiThread(() -> {
                try {
                    settingsDeepLinkLauncher.launch(intent);
                } catch (Exception e) {
                    openAppDetailsSettings();
                }
            });
        } else {
            notifyPermissionsUpdated();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        notifyPermissionsUpdated();
    }

    private void notifyPermissionsUpdated() {
        if (webView != null) {
            Runnable emit = () -> {
                if (webView != null) {
                    webView.evaluateJavascript(
                        "window.dispatchEvent(new CustomEvent('clipkaro-permissions-updated'))",
                        null
                    );
                }
            };
            webView.post(emit);
            webView.postDelayed(emit, 250);
        }
    }

    private boolean checkOverlayGranted() {
        return Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(this);
    }

    private boolean checkStorageGranted() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            return ContextCompat.checkSelfPermission(this, Manifest.permission.READ_MEDIA_VIDEO)
                == PackageManager.PERMISSION_GRANTED
                && ContextCompat.checkSelfPermission(this, Manifest.permission.READ_MEDIA_IMAGES)
                == PackageManager.PERMISSION_GRANTED;
        }
        return ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE)
            == PackageManager.PERMISSION_GRANTED;
    }

    private boolean checkMicrophoneGranted() {
        return ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            == PackageManager.PERMISSION_GRANTED;
    }

    private boolean checkBatteryOptimizationIgnored() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
            return pm == null || pm.isIgnoringBatteryOptimizations(getPackageName());
        }
        return true;
    }

    public class ClipKaroAndroidBridge {
        @JavascriptInterface
        public boolean launchApp(String packageName, String playStoreUrl) {
            return launchInstalledPackageOrPlayStore(packageName, playStoreUrl);
        }

        @JavascriptInterface
        public String startFloatingAndLaunchGame(String packageName, String playStoreUrl, String gameName) {
            if (!checkOverlayGranted()) {
                openOverlaySettingsDeepLink();
                return "overlay_required";
            }

            pendingLaunchPackage = packageName;
            pendingLaunchPlayStore = playStoreUrl;
            pendingLaunchGameName = (gameName != null && !gameName.trim().isEmpty()) ? gameName.trim() : "BGMI";
            runOnUiThread(() -> requestMediaProjectionCapture());
            return "started";
        }

        @JavascriptInterface
        public void stopFloatingService() {
            Intent stopIntent = new Intent(MainActivity.this, FloatingClipService.class);
            stopIntent.setAction(FloatingClipService.ACTION_STOP);
            startService(stopIntent);
        }

        @JavascriptInterface
        public boolean canDrawOverlays() {
            return checkOverlayGranted();
        }

        @JavascriptInterface
        public void requestOverlayPermission() {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(MainActivity.this)) {
                openOverlaySettingsDeepLink();
            } else {
                notifyPermissionsUpdated();
            }
        }

        @JavascriptInterface
        public boolean hasStoragePermission() {
            return checkStorageGranted();
        }

        @JavascriptInterface
        public void requestStoragePermission() {
            if (!checkStorageGranted()) {
                openAppDetailsSettings();
            } else {
                notifyPermissionsUpdated();
            }
        }

        @JavascriptInterface
        public boolean hasMicrophonePermission() {
            return checkMicrophoneGranted();
        }

        @JavascriptInterface
        public void requestMicrophonePermission() {
            if (!checkMicrophoneGranted()) {
                runOnUiThread(() -> micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO));
            } else {
                notifyPermissionsUpdated();
            }
        }

        @JavascriptInterface
        public void openMicrophoneSettings() {
            if (!checkMicrophoneGranted()) {
                openAppDetailsSettings();
            } else {
                notifyPermissionsUpdated();
            }
        }

        @JavascriptInterface
        public boolean hasBatteryPermission() {
            return checkBatteryOptimizationIgnored();
        }

        @JavascriptInterface
        public void requestBatteryPermission() {
            if (!checkBatteryOptimizationIgnored()) {
                openBatteryOptimizationDeepLink();
            } else {
                notifyPermissionsUpdated();
            }
        }

        @JavascriptInterface
        public boolean isPermissionSetupDone() {
            SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
            return prefs.getBoolean(KEY_PERMISSION_DONE, false);
        }

        @JavascriptInterface
        public void setPermissionSetupDone(boolean done) {
            SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
            prefs.edit().putBoolean(KEY_PERMISSION_DONE, done).apply();
        }

        @JavascriptInterface
        public String getPermissionStatusJson() {
            return "{"
                + "\"overlay\":" + checkOverlayGranted() + ","
                + "\"storage\":" + checkStorageGranted() + ","
                + "\"microphone\":" + checkMicrophoneGranted() + ","
                + "\"battery\":" + checkBatteryOptimizationIgnored() + ","
                + "\"setupDone\":" + isPermissionSetupDone()
                + "}";
        }
    }
}

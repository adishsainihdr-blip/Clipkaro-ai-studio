package com.clipkaro.app;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AppOpsManager;
import android.app.usage.UsageEvents;
import android.app.usage.UsageStatsManager;
import android.content.BroadcastReceiver;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Color;
import android.media.MediaScannerConnection;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.PowerManager;
import android.provider.MediaStore;
import android.provider.Settings;
import android.util.Base64;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import androidx.webkit.WebViewAssetLoader;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    public static final String EXTRA_REQUEST_PROJECTION_GAME = "request_projection_game";
    public static volatile boolean isActivityInForeground = false;

    private static final String PREFS_NAME = "clipkaro_prefs";
    private static final String KEY_PERMISSION_DONE = "permission_screen_done";
    private static final String CHROME_MOBILE_UA =
        "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36";

    private FrameLayout rootContainer;
    private WebView webView;
    private ValueCallback<Uri[]> filePathCallback;

    // Native In-App WebView overlay for "Open Inside" (YouTube / Instagram / Facebook)
    private LinearLayout inAppOverlay;
    private WebView inAppWebView;
    private String inAppCurrentUrl = "";
    private String inAppFallbackPkg = "";
    private String inAppPlatformLabel = "";
    private boolean inAppFallbackTriggered = false;

    private String pendingLaunchPackage = null;
    private String pendingLaunchPlayStore = null;
    private String pendingLaunchGameName = "BGMI";
    private int pendingDurationAfterProjection = 0;
    private boolean pendingFullAfterProjection = false;
    private boolean isWelcomeProjectionRequest = false;

    private final BroadcastReceiver nativeClipSavedReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            notifyNativeClipsUpdated();
        }
    };

    private final ActivityResultLauncher<Intent> fileChooserLauncher =
        registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result -> {
            if (filePathCallback == null) return;
            Uri[] results = WebChromeClient.FileChooserParams.parseResult(
                result.getResultCode(),
                result.getData()
            );
            filePathCallback.onReceiveValue(results);
            filePathCallback = null;
        });

    private final ActivityResultLauncher<String> micPermissionLauncher =
        registerForActivityResult(new ActivityResultContracts.RequestPermission(), granted -> {
            if (Boolean.TRUE.equals(granted)) {
                notifyPermissionsUpdated();
            } else {
                openAppDetailsSettings();
            }
        });

    private final ActivityResultLauncher<Intent> settingsDeepLinkLauncher =
        registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result -> {
            notifyPermissionsUpdated();
        });

    private final ActivityResultLauncher<Intent> overlayPermissionLauncher =
        registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result -> {
            notifyPermissionsUpdated();
        });

    private final ActivityResultLauncher<Intent> mediaProjectionLauncher =
        registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result -> {
            int code = result.getResultCode();
            Intent data = result.getData();
            if (code == Activity.RESULT_OK && data != null) {
                FloatingClipService.cacheProjectionToken(code, data);
            }

            boolean fromWelcome = isWelcomeProjectionRequest;
            isWelcomeProjectionRequest = false;

            if (fromWelcome) {
                if (code == Activity.RESULT_OK && data != null) {
                    Intent prep = new Intent(this, FloatingClipService.class);
                    prep.setAction(FloatingClipService.ACTION_PREPARE_PROJECTION);
                    prep.putExtra(FloatingClipService.EXTRA_RESULT_CODE, code);
                    prep.putExtra(FloatingClipService.EXTRA_RESULT_DATA, data);
                    ContextCompat.startForegroundService(this, prep);
                }
                notifyPermissionsUpdated();
                return;
            }

            String pkg = pendingLaunchPackage;
            String store = pendingLaunchPlayStore;
            String gameName = pendingLaunchGameName;
            pendingLaunchPackage = null;
            pendingLaunchPlayStore = null;

            startFloatingClipService(
                code == Activity.RESULT_OK ? code : Activity.RESULT_CANCELED,
                code == Activity.RESULT_OK ? data : null,
                gameName,
                pkg
            );

            if (pkg != null && !pkg.isEmpty()) {
                if (!isPackageCurrentlyForeground(pkg)) {
                    launchInstalledPackageOrPlayStore(pkg, store);
                }
                moveTaskToBack(true);
            } else {
                moveTaskToBack(true);
            }
        });

    @SuppressLint({"SetJavaScriptEnabled", "JavascriptInterface"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        rootContainer = new FrameLayout(this);
        webView = new WebView(this);
        rootContainer.addView(
            webView,
            new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        );
        setContentView(rootContainer);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setJavaScriptCanOpenWindowsAutomatically(true);
        settings.setUserAgentString(CHROME_MOBILE_UA);

        CookieManager.getInstance().setAcceptCookie(true);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true);
        }

        final WebViewAssetLoader.AssetsPathHandler assetsHandler =
            new WebViewAssetLoader.AssetsPathHandler(this);

        final WebViewAssetLoader assetLoader = new WebViewAssetLoader.Builder()
            .addPathHandler("/", path -> {
                String cleanPath = path.startsWith("/") ? path.substring(1) : path;
                if (cleanPath.isEmpty()) {
                    cleanPath = "index.html";
                }
                WebResourceResponse response = assetsHandler.handle("public/" + cleanPath);
                if (response != null && response.getData() != null) {
                    return response;
                }
                return assetsHandler.handle(cleanPath);
            })
            .build();

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                Uri url = request.getUrl();
                if (url != null && "/native-clip".equals(url.getPath())) {
                    String uriParam = url.getQueryParameter("uri");
                    if (uriParam != null && !uriParam.isEmpty()) {
                        try {
                            Uri targetUri = Uri.parse(uriParam);
                            InputStream stream = "file".equalsIgnoreCase(targetUri.getScheme()) && targetUri.getPath() != null
                                ? new FileInputStream(new File(targetUri.getPath()))
                                : getContentResolver().openInputStream(targetUri);
                            if (stream != null) {
                                Map<String, String> headers = new HashMap<>();
                                headers.put("Access-Control-Allow-Origin", "*");
                                return new WebResourceResponse("video/mp4", null, 200, "OK", headers, stream);
                            }
                        } catch (Exception ignored) {
                        }
                    }
                    return new WebResourceResponse(
                        "text/plain",
                        "UTF-8",
                        404,
                        "Not Found",
                        new HashMap<>(),
                        new ByteArrayInputStream(new byte[0])
                    );
                }
                return assetLoader.shouldInterceptRequest(url);
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                String scheme = uri.getScheme();
                if ("intent".equalsIgnoreCase(scheme) || "market".equalsIgnoreCase(scheme)) {
                    try {
                        Intent intent = Intent.parseUri(uri.toString(), Intent.URI_INTENT_SCHEME);
                        if (intent.resolveActivity(getPackageManager()) != null) {
                            startActivity(intent);
                        } else {
                            String fallback = intent.getStringExtra("browser_fallback_url");
                            if (fallback != null) {
                                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(fallback)));
                            }
                        }
                        return true;
                    } catch (Exception ignored) {
                        return true;
                    }
                }
                return false;
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onPermissionRequest(final PermissionRequest request) {
                runOnUiThread(() -> request.grant(request.getResources()));
            }

            @Override
            public boolean onShowFileChooser(
                WebView webView,
                ValueCallback<Uri[]> filePathCallback,
                FileChooserParams fileChooserParams
            ) {
                if (MainActivity.this.filePathCallback != null) {
                    MainActivity.this.filePathCallback.onReceiveValue(null);
                }
                MainActivity.this.filePathCallback = filePathCallback;
                Intent intent = fileChooserParams.createIntent();
                fileChooserLauncher.launch(intent);
                return true;
            }
        });

        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                if (inAppOverlay != null) {
                    if (inAppWebView != null && inAppWebView.canGoBack()) {
                        inAppWebView.goBack();
                    } else {
                        closeInAppWebViewOverlay();
                    }
                    return;
                }
                if (webView != null && webView.canGoBack()) {
                    webView.goBack();
                } else {
                    setEnabled(false);
                    getOnBackPressedDispatcher().onBackPressed();
                }
            }
        });

        webView.addJavascriptInterface(new ClipKaroAndroidBridge(), "Android");
        webView.loadUrl("https://appassets.androidplatform.net/index.html");
        handleProjectionPromptIntent(getIntent());

        IntentFilter filter = new IntentFilter(FloatingClipService.ACTION_NATIVE_CLIP_SAVED);
        ContextCompat.registerReceiver(this, nativeClipSavedReceiver, filter, ContextCompat.RECEIVER_NOT_EXPORTED);
    }

    @Override
    protected void onDestroy() {
        isActivityInForeground = false;
        closeInAppWebViewOverlay();
        try {
            unregisterReceiver(nativeClipSavedReceiver);
        } catch (IllegalArgumentException ignored) {
        }
        super.onDestroy();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleProjectionPromptIntent(intent);
    }

    private void handleProjectionPromptIntent(Intent intent) {
        if (intent != null && intent.hasExtra(EXTRA_REQUEST_PROJECTION_GAME)) {
            String game = intent.getStringExtra(EXTRA_REQUEST_PROJECTION_GAME);
            String pkg = intent.getStringExtra(FloatingClipService.EXTRA_TARGET_PACKAGE);
            pendingLaunchGameName = (game != null && !game.isEmpty()) ? game : "BGMI";
            pendingDurationAfterProjection = intent.getIntExtra(FloatingClipService.EXTRA_PENDING_DURATION, 0);
            pendingFullAfterProjection = intent.getBooleanExtra(FloatingClipService.EXTRA_PENDING_FULL, false);
            pendingLaunchPackage = (pkg != null && !pkg.isEmpty()) ? pkg : null;
            pendingLaunchPlayStore = null;
            isWelcomeProjectionRequest = false;
            if (FloatingClipService.hasCachedProjection()) {
                startFloatingClipService(
                    FloatingClipService.cachedProjectionResultCode,
                    FloatingClipService.cachedProjectionResultData,
                    pendingLaunchGameName,
                    pendingLaunchPackage
                );
                moveTaskToBack(true);
            } else {
                requestMediaProjectionCapture();
            }
        }
    }

    private void requestMediaProjectionCapture() {
        MediaProjectionManager mpm =
            (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);
        if (mpm != null) {
            mediaProjectionLauncher.launch(mpm.createScreenCaptureIntent());
        } else {
            startFloatingClipService(Activity.RESULT_CANCELED, null, pendingLaunchGameName, pendingLaunchPackage);
            if (pendingLaunchPackage != null && !pendingLaunchPackage.isEmpty()) {
                launchInstalledPackageOrPlayStore(pendingLaunchPackage, pendingLaunchPlayStore);
            }
        }
    }

    private void startFloatingClipService(int resultCode, Intent resultData, String gameName, String targetPackage) {
        Intent serviceIntent = new Intent(this, FloatingClipService.class);
        serviceIntent.setAction(FloatingClipService.ACTION_START);
        serviceIntent.putExtra(FloatingClipService.EXTRA_GAME_NAME, gameName != null ? gameName : "BGMI");
        if (targetPackage != null && !targetPackage.trim().isEmpty()) {
            serviceIntent.putExtra(FloatingClipService.EXTRA_TARGET_PACKAGE, targetPackage.trim());
        }
        if (pendingDurationAfterProjection > 0) {
            serviceIntent.putExtra(FloatingClipService.EXTRA_PENDING_DURATION, pendingDurationAfterProjection);
            pendingDurationAfterProjection = 0;
        }
        if (pendingFullAfterProjection) {
            serviceIntent.putExtra(FloatingClipService.EXTRA_PENDING_FULL, true);
            pendingFullAfterProjection = false;
        }
        if (resultCode == Activity.RESULT_OK && resultData != null) {
            serviceIntent.putExtra(FloatingClipService.EXTRA_RESULT_CODE, resultCode);
            serviceIntent.putExtra(FloatingClipService.EXTRA_RESULT_DATA, resultData);
        }
        ContextCompat.startForegroundService(this, serviceIntent);
    }

    private boolean isPackageCurrentlyForeground(String packageName) {
        if (packageName == null || packageName.isEmpty() || Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP_MR1) {
            return false;
        }
        try {
            UsageStatsManager usm = (UsageStatsManager) getSystemService(Context.USAGE_STATS_SERVICE);
            if (usm == null) return false;
            long now = System.currentTimeMillis();
            UsageEvents events = usm.queryEvents(now - 10_000L, now);
            UsageEvents.Event ev = new UsageEvents.Event();
            long latestTs = 0L;
            String latestPkg = null;
            while (events.hasNextEvent()) {
                events.getNextEvent(ev);
                int type = ev.getEventType();
                boolean isResumed = (type == UsageEvents.Event.MOVE_TO_FOREGROUND)
                    || (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q
                        && type == UsageEvents.Event.ACTIVITY_RESUMED);
                if (isResumed && ev.getTimeStamp() >= latestTs && ev.getPackageName() != null) {
                    latestTs = ev.getTimeStamp();
                    latestPkg = ev.getPackageName();
                }
            }
            return packageName.equals(latestPkg);
        } catch (Exception ignored) {
            return false;
        }
    }

    private boolean launchInstalledPackageOrPlayStore(String packageName, String playStoreUrl) {
        if (isPackageCurrentlyForeground(packageName)) {
            moveTaskToBack(true);
            return true;
        }
        PackageManager pm = getPackageManager();
        Intent launchIntent = pm.getLaunchIntentForPackage(packageName);
        if (launchIntent != null) {
            launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
            startActivity(launchIntent);
            return true;
        }
        try {
            Intent marketIntent = new Intent(
                Intent.ACTION_VIEW,
                Uri.parse("market://details?id=" + packageName)
            );
            marketIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(marketIntent);
        } catch (Exception e) {
            if (playStoreUrl != null && !playStoreUrl.isEmpty()) {
                Intent webIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(playStoreUrl));
                webIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(webIntent);
            }
        }
        return false;
    }

    private void openNativeAppOrBrowserFallback(String packageName, String targetUrl) {
        if (packageName != null && !packageName.trim().isEmpty()) {
            try {
                Intent appIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(targetUrl));
                appIntent.setPackage(packageName.trim());
                appIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                if (appIntent.resolveActivity(getPackageManager()) != null) {
                    startActivity(appIntent);
                    return;
                }
                Intent launcher = getPackageManager().getLaunchIntentForPackage(packageName.trim());
                if (launcher != null) {
                    launcher.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(launcher);
                    return;
                }
            } catch (Exception ignored) {
            }
        }
        try {
            Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(targetUrl));
            browserIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(browserIntent);
        } catch (Exception ignored) {
            Toast.makeText(this, "Could not open link", Toast.LENGTH_SHORT).show();
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private void showInAppWebViewOverlay(String url, String platformLabel, String fallbackPackage) {
        closeInAppWebViewOverlay();
        inAppCurrentUrl = url;
        inAppFallbackPkg = fallbackPackage != null ? fallbackPackage : "";
        inAppPlatformLabel = (platformLabel != null && !platformLabel.isEmpty()) ? platformLabel : "Viewer";
        inAppFallbackTriggered = false;

        int pad = Math.round(12 * getResources().getDisplayMetrics().density);

        inAppOverlay = new LinearLayout(this);
        inAppOverlay.setOrientation(LinearLayout.VERTICAL);
        inAppOverlay.setBackgroundColor(Color.parseColor("#0B0E14"));

        // Top Header Bar
        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(pad, pad, pad, pad);
        header.setBackgroundColor(Color.parseColor("#121722"));

        TextView titleTv = new TextView(this);
        titleTv.setText(inAppPlatformLabel + " · Inside ClipKaro");
        titleTv.setTextColor(Color.WHITE);
        titleTv.setTextSize(14);
        header.addView(titleTv, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        Button openAppBtn = new Button(this);
        openAppBtn.setText("Open in App");
        openAppBtn.setAllCaps(false);
        openAppBtn.setTextSize(12);
        openAppBtn.setTextColor(Color.WHITE);
        openAppBtn.setBackgroundColor(Color.parseColor("#E11D48"));
        LinearLayout.LayoutParams appLp = new LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
        );
        appLp.rightMargin = pad / 2;
        openAppBtn.setOnClickListener(v -> {
            String curUrl = (inAppWebView != null && inAppWebView.getUrl() != null)
                ? inAppWebView.getUrl()
                : inAppCurrentUrl;
            closeInAppWebViewOverlay();
            openNativeAppOrBrowserFallback(inAppFallbackPkg, curUrl);
        });
        header.addView(openAppBtn, appLp);

        Button closeBtn = new Button(this);
        closeBtn.setText("Close");
        closeBtn.setAllCaps(false);
        closeBtn.setTextSize(12);
        closeBtn.setTextColor(Color.WHITE);
        closeBtn.setBackgroundColor(Color.parseColor("#334155"));
        closeBtn.setOnClickListener(v -> closeInAppWebViewOverlay());
        header.addView(closeBtn);

        inAppOverlay.addView(header, new LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ));

        inAppWebView = new WebView(this);
        WebSettings ws = inAppWebView.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setDomStorageEnabled(true);
        ws.setDatabaseEnabled(true);
        ws.setMediaPlaybackRequiresUserGesture(false);
        ws.setJavaScriptCanOpenWindowsAutomatically(true);
        ws.setLoadWithOverviewMode(true);
        ws.setUseWideViewPort(true);
        ws.setUserAgentString(CHROME_MOBILE_UA);

        CookieManager.getInstance().setAcceptCookie(true);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            CookieManager.getInstance().setAcceptThirdPartyCookies(inAppWebView, true);
        }

        inAppWebView.setWebChromeClient(new WebChromeClient());
        inAppWebView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                String scheme = uri.getScheme();
                if (!"http".equalsIgnoreCase(scheme) && !"https".equalsIgnoreCase(scheme)) {
                    try {
                        Intent intent = "intent".equalsIgnoreCase(scheme)
                            ? Intent.parseUri(uri.toString(), Intent.URI_INTENT_SCHEME)
                            : new Intent(Intent.ACTION_VIEW, uri);
                        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        if (intent.resolveActivity(getPackageManager()) != null) {
                            startActivity(intent);
                            return true;
                        }
                    } catch (Exception ignored) {
                    }
                    triggerInAppFallback(url);
                    return true;
                }
                return false;
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                if (request.isForMainFrame()) {
                    triggerInAppFallback(request.getUrl().toString());
                }
            }

            @Override
            public void onReceivedHttpError(
                WebView view,
                WebResourceRequest request,
                WebResourceResponse errorResponse
            ) {
                if (request.isForMainFrame() && errorResponse.getStatusCode() >= 400) {
                    triggerInAppFallback(request.getUrl().toString());
                }
            }

            @Override
            public void onPageFinished(WebView view, String finishedUrl) {
                // Guard against blank blocked pages (X-Frame-Options / CSP / failed hydration)
                view.postDelayed(() -> {
                    if (inAppWebView == null || inAppFallbackTriggered) return;
                    inAppWebView.evaluateJavascript(
                        "(function(){var t=(document.body&&document.body.innerText||'').trim();var v=document.querySelector('video,iframe');return t.length===0&&!v?'BLANK':'OK';})()",
                        value -> {
                            if (value != null && value.contains("BLANK")) {
                                triggerInAppFallback(finishedUrl != null ? finishedUrl : inAppCurrentUrl);
                            }
                        }
                    );
                }, 2600L);
            }
        });

        inAppOverlay.addView(inAppWebView, new LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f
        ));

        rootContainer.addView(inAppOverlay, new FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
        ));
        inAppWebView.loadUrl(url);
    }

    private void triggerInAppFallback(String targetUrl) {
        if (inAppFallbackTriggered) return;
        inAppFallbackTriggered = true;
        String pkg = inAppFallbackPkg;
        String label = inAppPlatformLabel;
        closeInAppWebViewOverlay();
        Toast.makeText(
            this,
            "Opening " + label + " in app/browser…",
            Toast.LENGTH_SHORT
        ).show();
        openNativeAppOrBrowserFallback(pkg, targetUrl != null ? targetUrl : inAppCurrentUrl);
    }

    private void closeInAppWebViewOverlay() {
        if (inAppWebView != null) {
            try {
                inAppWebView.stopLoading();
                inAppWebView.destroy();
            } catch (Exception ignored) {
            }
            inAppWebView = null;
        }
        if (inAppOverlay != null && rootContainer != null) {
            rootContainer.removeView(inAppOverlay);
            inAppOverlay = null;
        }
    }

    private void openAppDetailsSettings() {
        Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
        intent.setData(Uri.parse("package:" + getPackageName()));
        runOnUiThread(() -> settingsDeepLinkLauncher.launch(intent));
    }

    private void openOverlaySettingsDeepLink() {
        Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION);
        intent.setData(Uri.parse("package:" + getPackageName()));
        runOnUiThread(() -> overlayPermissionLauncher.launch(intent));
    }

    @SuppressLint("BatteryLife")
    private void openBatteryOptimizationDeepLink() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Intent intent = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS);
            intent.setData(Uri.parse("package:" + getPackageName()));
            runOnUiThread(() -> {
                try {
                    settingsDeepLinkLauncher.launch(intent);
                } catch (Exception e) {
                    openAppDetailsSettings();
                }
            });
        } else {
            notifyPermissionsUpdated();
        }
    }

    private void openUsageAccessDeepLink() {
        runOnUiThread(() -> {
            try {
                Intent intent = new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS);
                intent.setData(Uri.parse("package:" + getPackageName()));
                settingsDeepLinkLauncher.launch(intent);
            } catch (Exception e) {
                try {
                    settingsDeepLinkLauncher.launch(new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS));
                } catch (Exception ignored) {
                    openAppDetailsSettings();
                }
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        isActivityInForeground = true;
        Intent i = new Intent(this, FloatingClipService.class);
        i.setAction(FloatingClipService.ACTION_CLIPKARO_RESUMED);
        try {
            startService(i);
        } catch (Exception ignored) {
        }
        notifyPermissionsUpdated();
        notifyNativeClipsUpdated();
    }

    @Override
    protected void onPause() {
        isActivityInForeground = false;
        super.onPause();
    }

    private void notifyPermissionsUpdated() {
        if (webView != null) {
            Runnable emit = () -> {
                if (webView != null) {
                    webView.evaluateJavascript(
                        "window.dispatchEvent(new CustomEvent('clipkaro-permissions-updated'))",
                        null
                    );
                }
            };
            webView.post(emit);
            webView.postDelayed(emit, 250);
        }
    }

    private void notifyNativeClipsUpdated() {
        if (webView != null) {
            webView.post(() -> {
                if (webView != null) {
                    webView.evaluateJavascript(
                        "window.dispatchEvent(new CustomEvent('clipkaro-native-clips-updated'))",
                        null
                    );
                }
            });
        }
    }

    private boolean checkOverlayGranted() {
        return Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(this);
    }

    private boolean checkStorageGranted() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            return ContextCompat.checkSelfPermission(this, Manifest.permission.READ_MEDIA_VIDEO)
                == PackageManager.PERMISSION_GRANTED
                && ContextCompat.checkSelfPermission(this, Manifest.permission.READ_MEDIA_IMAGES)
                == PackageManager.PERMISSION_GRANTED;
        }
        return ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE)
            == PackageManager.PERMISSION_GRANTED;
    }

    private boolean checkMicrophoneGranted() {
        return ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            == PackageManager.PERMISSION_GRANTED;
    }

    private boolean checkBatteryOptimizationIgnored() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
            return pm == null || pm.isIgnoringBatteryOptimizations(getPackageName());
        }
        return true;
    }

    private boolean checkUsageAccessGranted() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP) return true;
        try {
            AppOpsManager appOps = (AppOpsManager) getSystemService(Context.APP_OPS_SERVICE);
            if (appOps == null) return false;
            int mode = Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q
                ? appOps.unsafeCheckOpNoThrow(
                    AppOpsManager.OPSTR_GET_USAGE_STATS,
                    android.os.Process.myUid(),
                    getPackageName()
                )
                : appOps.checkOpNoThrow(
                    AppOpsManager.OPSTR_GET_USAGE_STATS,
                    android.os.Process.myUid(),
                    getPackageName()
                );
            return mode == AppOpsManager.MODE_ALLOWED;
        } catch (Exception ignored) {
            return false;
        }
    }

    public class ClipKaroAndroidBridge {
        @JavascriptInterface
        public boolean launchApp(String packageName, String playStoreUrl) {
            return launchInstalledPackageOrPlayStore(packageName, playStoreUrl);
        }

        @JavascriptInterface
        public void openUrlInsideWebView(String url, String platformLabel, String fallbackPackage) {
            if (url == null || url.trim().isEmpty()) return;
            runOnUiThread(() -> showInAppWebViewOverlay(url.trim(), platformLabel, fallbackPackage));
        }

        @JavascriptInterface
        public String startFloatingAndLaunchGame(String packageName, String playStoreUrl, String gameName) {
            if (!checkOverlayGranted()) {
                openOverlaySettingsDeepLink();
                return "overlay_required";
            }

            String targetTitle = (gameName != null && !gameName.trim().isEmpty()) ? gameName.trim() : "BGMI";
            String cleanPkg = packageName != null ? packageName.trim() : "";

            // Reuse cached MediaProjection token without asking the system dialog again!
            if (FloatingClipService.hasCachedProjection()) {
                startFloatingClipService(
                    FloatingClipService.cachedProjectionResultCode,
                    FloatingClipService.cachedProjectionResultData,
                    targetTitle,
                    cleanPkg
                );
                if (!cleanPkg.isEmpty()) {
                    launchInstalledPackageOrPlayStore(cleanPkg, playStoreUrl);
                }
                return "started";
            }

            pendingLaunchPackage = cleanPkg;
            pendingLaunchPlayStore = playStoreUrl;
            pendingLaunchGameName = targetTitle;
            isWelcomeProjectionRequest = false;
            runOnUiThread(() -> requestMediaProjectionCapture());
            return "started";
        }

        @JavascriptInterface
        public void stopFloatingService() {
            Intent stopIntent = new Intent(MainActivity.this, FloatingClipService.class);
            stopIntent.setAction(FloatingClipService.ACTION_STOP);
            startService(stopIntent);
        }

        @JavascriptInterface
        public boolean hasScreenCapturePermission() {
            return FloatingClipService.hasCachedProjection();
        }

        @JavascriptInterface
        public void requestScreenCapturePermission() {
            if (FloatingClipService.hasCachedProjection()) {
                notifyPermissionsUpdated();
                return;
            }
            pendingLaunchPackage = null;
            pendingLaunchPlayStore = null;
            pendingLaunchGameName = "BGMI";
            isWelcomeProjectionRequest = true;
            runOnUiThread(() -> requestMediaProjectionCapture());
        }

        @JavascriptInterface
        public boolean hasUsageAccessPermission() {
            return checkUsageAccessGranted();
        }

        @JavascriptInterface
        public void requestUsageAccessPermission() {
            if (!checkUsageAccessGranted()) {
                openUsageAccessDeepLink();
            } else {
                notifyPermissionsUpdated();
            }
        }

        @JavascriptInterface
        public boolean canDrawOverlays() {
            return checkOverlayGranted();
        }

        @JavascriptInterface
        public void requestOverlayPermission() {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(MainActivity.this)) {
                openOverlaySettingsDeepLink();
            } else {
                notifyPermissionsUpdated();
            }
        }

        @JavascriptInterface
        public boolean hasStoragePermission() {
            return checkStorageGranted();
        }

        @JavascriptInterface
        public void requestStoragePermission() {
            if (!checkStorageGranted()) {
                openAppDetailsSettings();
            } else {
                notifyPermissionsUpdated();
            }
        }

        @JavascriptInterface
        public boolean hasMicrophonePermission() {
            return checkMicrophoneGranted();
        }

        @JavascriptInterface
        public void requestMicrophonePermission() {
            if (!checkMicrophoneGranted()) {
                runOnUiThread(() -> micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO));
            } else {
                notifyPermissionsUpdated();
            }
        }

        @JavascriptInterface
        public void openMicrophoneSettings() {
            if (!checkMicrophoneGranted()) {
                openAppDetailsSettings();
            } else {
                notifyPermissionsUpdated();
            }
        }

        @JavascriptInterface
        public boolean hasBatteryPermission() {
            return checkBatteryOptimizationIgnored();
        }

        @JavascriptInterface
        public void requestBatteryPermission() {
            if (!checkBatteryOptimizationIgnored()) {
                openBatteryOptimizationDeepLink();
            } else {
                notifyPermissionsUpdated();
            }
        }

        @JavascriptInterface
        public boolean isPermissionSetupDone() {
            SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
            return prefs.getBoolean(KEY_PERMISSION_DONE, false);
        }

        @JavascriptInterface
        public void setPermissionSetupDone(boolean done) {
            SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
            prefs.edit().putBoolean(KEY_PERMISSION_DONE, done).apply();
        }

        @JavascriptInterface
        public String getPermissionStatusJson() {
            return "{"
                + "\"overlay\":" + checkOverlayGranted() + ","
                + "\"storage\":" + checkStorageGranted() + ","
                + "\"microphone\":" + checkMicrophoneGranted() + ","
                + "\"battery\":" + checkBatteryOptimizationIgnored() + ","
                + "\"screenCapture\":" + FloatingClipService.hasCachedProjection() + ","
                + "\"usageAccess\":" + checkUsageAccessGranted() + ","
                + "\"setupDone\":" + isPermissionSetupDone()
                + "}";
        }

        @JavascriptInterface
        public String listNativeClipKaroVideosJson() {
            JSONArray result = new JSONArray();
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    String[] projection = new String[]{
                        MediaStore.Video.Media._ID,
                        MediaStore.Video.Media.DISPLAY_NAME,
                        MediaStore.Video.Media.DURATION,
                        MediaStore.Video.Media.DATE_ADDED
                    };
                    String selection = MediaStore.Video.Media.RELATIVE_PATH + " LIKE ?";
                    String[] selectionArgs = new String[]{"%ClipKaro%"};
                    String sortOrder = MediaStore.Video.Media.DATE_ADDED + " DESC";
                    try (Cursor cursor = getContentResolver().query(
                        MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
                        projection,
                        selection,
                        selectionArgs,
                        sortOrder
                    )) {
                        if (cursor != null) {
                            int idCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media._ID);
                            int nameCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME);
                            int durCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DURATION);
                            int dateCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DATE_ADDED);
                            int count = 0;
                            while (cursor.moveToNext() && count < 40) {
                                long id = cursor.getLong(idCol);
                                String name = cursor.getString(nameCol);
                                long durMs = cursor.getLong(durCol);
                                long dateSec = cursor.getLong(dateCol);
                                Uri contentUri = Uri.withAppendedPath(
                                    MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
                                    String.valueOf(id)
                                );
                                JSONObject obj = new JSONObject();
                                obj.put("uri", contentUri.toString());
                                obj.put("fileName", name != null ? name : ("Clip_" + id + ".mp4"));
                                obj.put("durationSec", Math.max(1, Math.round(durMs / 1000.0)));
                                obj.put("createdAtMs", dateSec * 1000L);
                                result.put(obj);
                                count++;
                            }
                        }
                    }
                } else {
                    File dir = new File(
                        Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES),
                        "ClipKaro"
                    );
                    File[] files = dir.exists() ? dir.listFiles() : null;
                    if (files != null) {
                        for (File f : files) {
                            if (f.isFile() && f.getName().endsWith(".mp4")) {
                                JSONObject obj = new JSONObject();
                                obj.put("uri", Uri.fromFile(f).toString());
                                obj.put("fileName", f.getName());
                                obj.put("durationSec", 10);
                                obj.put("createdAtMs", f.lastModified());
                                result.put(obj);
                            }
                        }
                    }
                }
            } catch (Exception ignored) {
            }
            return result.toString();
        }

        @JavascriptInterface
        public boolean saveVideoFileToClipKaroFolder(String fileName, String base64Video) {
            if (base64Video == null || base64Video.isEmpty()) return false;
            try {
                byte[] bytes = Base64.decode(base64Video, Base64.DEFAULT);
                String safeName = (fileName != null && !fileName.trim().isEmpty())
                    ? fileName.replaceAll("[^A-Za-z0-9._-]+", "_")
                    : ("ClipKaro_Edited_" + System.currentTimeMillis() + ".mp4");
                if (!safeName.endsWith(".mp4") && !safeName.endsWith(".webm")) {
                    safeName += ".mp4";
                }
                String mime = safeName.endsWith(".webm") ? "video/webm" : "video/mp4";

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    ContentResolver resolver = getContentResolver();
                    ContentValues values = new ContentValues();
                    values.put(MediaStore.Video.Media.DISPLAY_NAME, safeName);
                    values.put(MediaStore.Video.Media.MIME_TYPE, mime);
                    values.put(
                        MediaStore.Video.Media.RELATIVE_PATH,
                        Environment.DIRECTORY_MOVIES + "/ClipKaro"
                    );
                    values.put(MediaStore.Video.Media.IS_PENDING, 1);

                    Uri uri = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values);
                    if (uri == null) return false;
                    try (OutputStream out = resolver.openOutputStream(uri)) {
                        if (out == null) return false;
                        out.write(bytes);
                    }
                    values.clear();
                    values.put(MediaStore.Video.Media.IS_PENDING, 0);
                    resolver.update(uri, values, null, null);
                    return true;
                } else {
                    File moviesDir = new File(
                        Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES),
                        "ClipKaro"
                    );
                    if (!moviesDir.exists()) {
                        //noinspection ResultOfMethodCallIgnored
                        moviesDir.mkdirs();
                    }
                    File dest = new File(moviesDir, safeName);
                    try (FileOutputStream fos = new FileOutputStream(dest)) {
                        fos.write(bytes);
                    }
                    MediaScannerConnection.scanFile(
                        MainActivity.this,
                        new String[]{dest.getAbsolutePath()},
                        new String[]{mime},
                        null
                    );
                    return true;
                }
            } catch (Exception ignored) {
                return false;
            }
        }

        @JavascriptInterface
        public boolean shareVideoToPlatform(
            String targetPlatform,
            String fileName,
            String base64Video,
            String nativeUriStr,
            String captionText
        ) {
            try {
                Uri shareUri = null;
                if (nativeUriStr != null && !nativeUriStr.trim().isEmpty()) {
                    Uri parsed = Uri.parse(nativeUriStr.trim());
                    if ("content".equalsIgnoreCase(parsed.getScheme())) {
                        shareUri = parsed;
                    } else if ("file".equalsIgnoreCase(parsed.getScheme()) && parsed.getPath() != null) {
                        File f = new File(parsed.getPath());
                        if (f.exists()) {
                            shareUri = FileProvider.getUriForFile(
                                MainActivity.this,
                                getPackageName() + ".fileprovider",
                                f
                            );
                        }
                    }
                }

                if (shareUri == null && base64Video != null && !base64Video.isEmpty()) {
                    File shareDir = new File(getCacheDir(), "shared_clips");
                    if (!shareDir.exists()) {
                        //noinspection ResultOfMethodCallIgnored
                        shareDir.mkdirs();
                    }
                    String safeName = (fileName != null && !fileName.trim().isEmpty())
                        ? fileName.replaceAll("[^A-Za-z0-9._-]+", "_")
                        : ("ClipKaro_Share_" + System.currentTimeMillis() + ".mp4");
                    if (!safeName.endsWith(".mp4") && !safeName.endsWith(".webm")) {
                        safeName += ".mp4";
                    }
                    File outFile = new File(shareDir, safeName);
                    byte[] bytes = Base64.decode(base64Video, Base64.DEFAULT);
                    try (FileOutputStream fos = new FileOutputStream(outFile)) {
                        fos.write(bytes);
                    }
                    shareUri = FileProvider.getUriForFile(
                        MainActivity.this,
                        getPackageName() + ".fileprovider",
                        outFile
                    );
                }

                if (shareUri == null) return false;

                String pkg = null;
                if ("youtube".equalsIgnoreCase(targetPlatform)) {
                    pkg = "com.google.android.youtube";
                } else if ("instagram".equalsIgnoreCase(targetPlatform)) {
                    pkg = "com.instagram.android";
                } else if ("whatsapp".equalsIgnoreCase(targetPlatform)) {
                    pkg = "com.whatsapp";
                }

                String shareText = (captionText != null && !captionText.trim().isEmpty())
                    ? captionText.trim()
                    : "BGMI Highlight #BGMI #ClipKaro";

                Intent shareIntent = new Intent(Intent.ACTION_SEND);
                shareIntent.setType("video/*");
                shareIntent.putExtra(Intent.EXTRA_STREAM, shareUri);
                shareIntent.putExtra(Intent.EXTRA_TEXT, shareText);
                shareIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);

                if (pkg != null) {
                    shareIntent.setPackage(pkg);
                    if (shareIntent.resolveActivity(getPackageManager()) != null) {
                        Intent finalTargeted = shareIntent;
                        runOnUiThread(() -> startActivity(finalTargeted));
                        return true;
                    }
                    shareIntent.setPackage(null);
                }

                Intent chooser = Intent.createChooser(shareIntent, "Share ClipKaro Highlight");
                chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                runOnUiThread(() -> startActivity(chooser));
                return true;
            } catch (Exception ignored) {
                return false;
            }
        }
    }
}

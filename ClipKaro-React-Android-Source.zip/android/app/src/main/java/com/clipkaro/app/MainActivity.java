package com.clipkaro.app;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.activity.OnBackPressedCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.webkit.WebViewAssetLoader;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private static final String PREFS_NAME = "clipkaro_prefs";
    private static final String KEY_PERMISSION_DONE = "permission_screen_done";

    private WebView webView;
    private ValueCallback<Uri[]> filePathCallback;

    private final ActivityResultLauncher<Intent> fileChooserLauncher =
        registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result -> {
            if (filePathCallback == null) return;
            Uri[] results = WebChromeClient.FileChooserParams.parseResult(
                result.getResultCode(),
                result.getData()
            );
            filePathCallback.onReceiveValue(results);
            filePathCallback = null;
        });

    private final ActivityResultLauncher<String[]> permissionsLauncher =
        registerForActivityResult(new ActivityResultContracts.RequestMultiplePermissions(), granted -> {
            notifyPermissionsUpdated();
        });

    private final ActivityResultLauncher<Intent> overlayPermissionLauncher =
        registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result -> {
            notifyPermissionsUpdated();
        });

    @SuppressLint({"SetJavaScriptEnabled", "JavascriptInterface"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        webView = new WebView(this);
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);

        final WebViewAssetLoader.AssetsPathHandler assetsHandler =
            new WebViewAssetLoader.AssetsPathHandler(this);

        final WebViewAssetLoader assetLoader = new WebViewAssetLoader.Builder()
            .addPathHandler("/", path -> {
                String cleanPath = path.startsWith("/") ? path.substring(1) : path;
                if (cleanPath.isEmpty()) {
                    cleanPath = "index.html";
                }
                WebResourceResponse response = assetsHandler.handle("public/" + cleanPath);
                if (response != null && response.getData() != null) {
                    return response;
                }
                return assetsHandler.handle(cleanPath);
            })
            .build();

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return assetLoader.shouldInterceptRequest(request.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                String scheme = uri.getScheme();
                if ("intent".equalsIgnoreCase(scheme) || "market".equalsIgnoreCase(scheme)) {
                    try {
                        Intent intent = Intent.parseUri(uri.toString(), Intent.URI_INTENT_SCHEME);
                        if (intent.resolveActivity(getPackageManager()) != null) {
                            startActivity(intent);
                        } else {
                            String fallback = intent.getStringExtra("browser_fallback_url");
                            if (fallback != null) {
                                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(fallback)));
                            }
                        }
                        return true;
                    } catch (Exception ignored) {
                        return true;
                    }
                }
                return false;
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onPermissionRequest(final PermissionRequest request) {
                runOnUiThread(() -> request.grant(request.getResources()));
            }

            @Override
            public boolean onShowFileChooser(
                WebView webView,
                ValueCallback<Uri[]> filePathCallback,
                FileChooserParams fileChooserParams
            ) {
                if (MainActivity.this.filePathCallback != null) {
                    MainActivity.this.filePathCallback.onReceiveValue(null);
                }
                MainActivity.this.filePathCallback = filePathCallback;
                Intent intent = fileChooserParams.createIntent();
                fileChooserLauncher.launch(intent);
                return true;
            }
        });

        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                if (webView != null && webView.canGoBack()) {
                    webView.goBack();
                } else {
                    setEnabled(false);
                    getOnBackPressedDispatcher().onBackPressed();
                }
            }
        });

        webView.addJavascriptInterface(new ClipKaroAndroidBridge(), "Android");
        webView.loadUrl("https://appassets.androidplatform.net/index.html");
    }

    @Override
    protected void onResume() {
        super.onResume();
        notifyPermissionsUpdated();
    }

    private void notifyPermissionsUpdated() {
        if (webView != null) {
            webView.post(() ->
                webView.evaluateJavascript(
                    "window.dispatchEvent(new CustomEvent('clipkaro-permissions-updated'))",
                    null
                )
            );
        }
    }

    private boolean checkOverlayGranted() {
        return Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(this);
    }

    private boolean checkStorageGranted() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            return ContextCompat.checkSelfPermission(this, Manifest.permission.READ_MEDIA_VIDEO)
                == PackageManager.PERMISSION_GRANTED
                && ContextCompat.checkSelfPermission(this, Manifest.permission.READ_MEDIA_IMAGES)
                == PackageManager.PERMISSION_GRANTED;
        }
        return ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE)
            == PackageManager.PERMISSION_GRANTED;
    }

    private boolean checkMicrophoneGranted() {
        return ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            == PackageManager.PERMISSION_GRANTED;
    }

    public class ClipKaroAndroidBridge {
        @JavascriptInterface
        public boolean launchApp(String packageName, String playStoreUrl) {
            PackageManager pm = getPackageManager();
            Intent launchIntent = pm.getLaunchIntentForPackage(packageName);
            if (launchIntent != null) {
                launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(launchIntent);
                return true;
            }
            try {
                Intent marketIntent = new Intent(
                    Intent.ACTION_VIEW,
                    Uri.parse("market://details?id=" + packageName)
                );
                marketIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(marketIntent);
            } catch (Exception e) {
                if (playStoreUrl != null && !playStoreUrl.isEmpty()) {
                    Intent webIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(playStoreUrl));
                    webIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(webIntent);
                }
            }
            return false;
        }

        @JavascriptInterface
        public boolean canDrawOverlays() {
            return checkOverlayGranted();
        }

        @JavascriptInterface
        public void requestOverlayPermission() {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(MainActivity.this)) {
                Intent intent = new Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName())
                );
                runOnUiThread(() -> overlayPermissionLauncher.launch(intent));
            } else {
                notifyPermissionsUpdated();
            }
        }

        @JavascriptInterface
        public boolean hasStoragePermission() {
            return checkStorageGranted();
        }

        @JavascriptInterface
        public void requestStoragePermission() {
            List<String> needed = new ArrayList<>();
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                if (ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.READ_MEDIA_VIDEO)
                    != PackageManager.PERMISSION_GRANTED) {
                    needed.add(Manifest.permission.READ_MEDIA_VIDEO);
                }
                if (ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.READ_MEDIA_IMAGES)
                    != PackageManager.PERMISSION_GRANTED) {
                    needed.add(Manifest.permission.READ_MEDIA_IMAGES);
                }
            } else {
                if (ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.READ_EXTERNAL_STORAGE)
                    != PackageManager.PERMISSION_GRANTED) {
                    needed.add(Manifest.permission.READ_EXTERNAL_STORAGE);
                }
            }
            if (!needed.isEmpty()) {
                runOnUiThread(() -> permissionsLauncher.launch(needed.toArray(new String[0])));
            } else {
                notifyPermissionsUpdated();
            }
        }

        @JavascriptInterface
        public boolean hasMicrophonePermission() {
            return checkMicrophoneGranted();
        }

        @JavascriptInterface
        public void requestMicrophonePermission() {
            if (!checkMicrophoneGranted()) {
                runOnUiThread(() -> permissionsLauncher.launch(new String[]{ Manifest.permission.RECORD_AUDIO }));
            } else {
                notifyPermissionsUpdated();
            }
        }

        @JavascriptInterface
        public boolean isPermissionSetupDone() {
            SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
            return prefs.getBoolean(KEY_PERMISSION_DONE, false);
        }

        @JavascriptInterface
        public void setPermissionSetupDone(boolean done) {
            SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
            prefs.edit().putBoolean(KEY_PERMISSION_DONE, done).apply();
        }

        @JavascriptInterface
        public String getPermissionStatusJson() {
            return "{"
                + "\"overlay\":" + checkOverlayGranted() + ","
                + "\"storage\":" + checkStorageGranted() + ","
                + "\"microphone\":" + checkMicrophoneGranted() + ","
                + "\"setupDone\":" + isPermissionSetupDone()
                + "}";
        }
    }
}

package com.clipkaro.app;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ServiceInfo;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioPlaybackCaptureConfiguration;
import android.media.AudioRecord;
import android.media.MediaCodec;
import android.media.MediaCodecInfo;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.media.MediaMuxer;
import android.media.MediaRecorder;
import android.media.MediaScannerConnection;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.provider.MediaStore;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.Surface;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;
import androidx.core.content.ContextCompat;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

public class FloatingClipService extends Service {

    public static final String ACTION_START = "com.clipkaro.app.action.START_FLOATING";
    public static final String ACTION_STOP = "com.clipkaro.app.action.STOP_FLOATING";
    public static final String ACTION_QUICK_CLIP_10 = "com.clipkaro.app.action.QUICK_CLIP_10";
    public static final String ACTION_QUICK_CLIP_30 = "com.clipkaro.app.action.QUICK_CLIP_30";
    public static final String ACTION_TOGGLE_FULL = "com.clipkaro.app.action.TOGGLE_FULL";
    public static final String ACTION_STOP_RECORDING = "com.clipkaro.app.action.STOP_RECORDING";
    public static final String ACTION_NATIVE_CLIP_SAVED = "com.clipkaro.app.NATIVE_CLIP_SAVED";

    public static final String EXTRA_RESULT_CODE = "result_code";
    public static final String EXTRA_RESULT_DATA = "result_data";
    public static final String EXTRA_GAME_NAME = "game_name";
    public static final String EXTRA_PENDING_DURATION = "pending_duration";
    public static final String EXTRA_PENDING_FULL = "pending_full";
    public static final String EXTRA_SAVED_FILE_NAME = "saved_file_name";
    public static final String EXTRA_SAVED_URI = "saved_uri";

    public static final String AUDIO_MODE_GAME = "game";
    public static final String AUDIO_MODE_MIC = "mic";
    public static final String AUDIO_MODE_BOTH = "both";

    private static final String PREFS_NAME = "clipkaro_prefs";
    private static final String KEY_AUDIO_MODE = "floating_audio_mode";
    private static final String KEY_AUTO_CONTINUOUS = "floating_auto_continuous";
    private static final String KEY_AUTO_HIGHLIGHT = "floating_auto_highlight";

    private static final String CHANNEL_ID = "clipkaro_floating_channel";
    private static final int NOTIFICATION_ID = 7001;

    private static final int HIGHLIGHT_SEGMENT_DURATION_MS = 5000;
    private static final int MAX_HIGHLIGHT_SEGMENTS = 4;
    private static final long HIGHLIGHT_COOLDOWN_MS = 18_000L;
    private static final int VIDEO_BITRATE = 4_000_000;
    private static final int VIDEO_FPS = 30;
    private static final int AUDIO_SAMPLE_RATE = 44100;
    private static final int AUDIO_BITRATE = 128_000;

    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final ExecutorService exportExecutor = Executors.newSingleThreadExecutor();
    private final Object muxerLock = new Object();

    private WindowManager windowManager;
    private FrameLayout bubbleView;
    private ImageView bubbleIdleIcon;
    private LinearLayout bubbleRecordingBox;
    private View bubbleRedDot;
    private TextView bubbleTimerTv;

    private LinearLayout menuView;
    private WindowManager.LayoutParams bubbleParams;
    private WindowManager.LayoutParams menuParams;
    private boolean isMenuVisible = false;

    private TextView menuStatusView;
    private Button fullRecordBtn;
    private Button stopRecBtn;
    private Button audioGameBtn;
    private Button audioMicBtn;
    private Button audioBothBtn;
    private Button autoContinuousBtn;
    private Button autoHighlightBtn;

    private String activeGameName = "BGMI";
    private String selectedAudioMode = AUDIO_MODE_BOTH;
    private boolean autoContinuousEnabled = true;
    private boolean autoHighlightEnabled = true;

    private int projectionResultCode = Activity.RESULT_CANCELED;
    private Intent projectionResultData = null;

    // MediaProjection & Encoding State
    private MediaProjection mediaProjection;
    private VirtualDisplay virtualDisplay;
    private Surface encoderSurface;
    private MediaCodec videoEncoder;
    private MediaCodec audioEncoder;
    private AudioRecord gameAudioRecord;
    private AudioRecord micAudioRecord;

    private final AtomicBoolean isCapturing = new AtomicBoolean(false);
    private final AtomicBoolean isRecordingTimed = new AtomicBoolean(false);
    private final AtomicBoolean isRecordingFull = new AtomicBoolean(false);
    private final AtomicBoolean audioLoopRunning = new AtomicBoolean(false);

    private Thread videoThread;
    private Thread audioThread;

    private MediaFormat latestVideoFormat;
    private MediaFormat latestAudioFormat;

    // Active Timed Clip Recording (Supports Auto Continuous Clips loop)
    private File timedTempFile;
    private MediaMuxer timedMuxer;
    private int timedVideoTrack = -1;
    private int timedAudioTrack = -1;
    private boolean timedMuxerStarted = false;
    private boolean timedWaitingForKeyframe = false;
    private int activeTimedDurationSec = 10;
    private int currentClipSequence = 1;
    private long timedStartMs = 0L;

    // Active Full Gameplay Continuous Recording
    private File fullTempFile;
    private MediaMuxer fullMuxer;
    private int fullVideoTrack = -1;
    private int fullAudioTrack = -1;
    private boolean fullMuxerStarted = false;
    private boolean fullWaitingForKeyframe = false;
    private long fullStartMs = 0L;

    // Auto Highlight Rolling 15s Ring + Kill / Headshot / Knock Spike State
    private File highlightBufferDir;
    private final List<File> completedHighlightSegments = new ArrayList<>();
    private File currentHighlightSegmentFile;
    private MediaMuxer highlightMuxer;
    private int hlVideoTrack = -1;
    private int hlAudioTrack = -1;
    private boolean hlMuxerStarted = false;
    private long currentHlSegmentStartUs = -1L;
    private int hlSegmentIndex = 0;
    private long captureStartedAtMs = 0L;
    private long lastAudioCombatPeakMs = 0L;
    private long lastAutoHighlightSavedMs = 0L;
    private double avgPFrameBytes = 14000.0;
    private int highlightSequence = 1;

    private int pendingDurationAfterProjection = 0;
    private boolean pendingFullAfterProjection = false;

    private final Runnable uiTickerRunnable = new Runnable() {
        private boolean dotBright = true;

        @Override
        public void run() {
            if (!isRecordingTimed.get() && !isRecordingFull.get()) {
                updateBubbleVisuals(false, 0L, false);
                return;
            }

            long now = System.currentTimeMillis();
            if (isRecordingTimed.get()) {
                long elapsedMs = Math.max(0L, now - timedStartMs);
                long elapsedSec = elapsedMs / 1000L;

                if (elapsedSec >= activeTimedDurationSec) {
                    onTimedClipDurationReached();
                    elapsedSec = 0L;
                }
                dotBright = !dotBright;
                updateBubbleVisuals(true, elapsedSec, dotBright);
            } else if (isRecordingFull.get()) {
                long elapsedSec = Math.max(0L, (now - fullStartMs) / 1000L);
                dotBright = !dotBright;
                updateBubbleVisuals(true, elapsedSec, dotBright);
            }

            updateNotificationOnly();
            if (isMenuVisible) {
                updateMenuStatusText();
            }
            mainHandler.postDelayed(this, 500);
        }
    };

    @Override
    public void onCreate() {
        super.onCreate();
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        selectedAudioMode = prefs.getString(KEY_AUDIO_MODE, AUDIO_MODE_BOTH);
        autoContinuousEnabled = prefs.getBoolean(KEY_AUTO_CONTINUOUS, true);
        autoHighlightEnabled = prefs.getBoolean(KEY_AUTO_HIGHLIGHT, true);
        highlightBufferDir = new File(getCacheDir(), "clipkaro_hl_buffer");
        if (!highlightBufferDir.exists()) {
            //noinspection ResultOfMethodCallIgnored
            highlightBufferDir.mkdirs();
        }
        createNotificationChannel();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent != null ? intent.getAction() : ACTION_START;

        if (ACTION_STOP.equals(action)) {
            stopEverythingAndSelf();
            return START_NOT_STICKY;
        }

        if (intent != null) {
            String game = intent.getStringExtra(EXTRA_GAME_NAME);
            if (game != null && !game.trim().isEmpty()) {
                activeGameName = game.trim();
            }
            if (intent.hasExtra(EXTRA_RESULT_CODE) && intent.hasExtra(EXTRA_RESULT_DATA)) {
                int code = intent.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED);
                Intent data = getParcelableIntentExtra(intent, EXTRA_RESULT_DATA);
                if (code == Activity.RESULT_OK && data != null) {
                    projectionResultCode = code;
                    projectionResultData = data;
                }
            }
            if (intent.hasExtra(EXTRA_PENDING_DURATION)) {
                pendingDurationAfterProjection = intent.getIntExtra(EXTRA_PENDING_DURATION, 0);
            }
            if (intent.hasExtra(EXTRA_PENDING_FULL)) {
                pendingFullAfterProjection = intent.getBooleanExtra(EXTRA_PENDING_FULL, false);
            }
        }

        startForegroundWithType(projectionResultData != null);
        ensureOverlayBubbleShown();

        if (projectionResultData != null && !isCapturing.get()) {
            startCapturePipeline();
        }

        if (ACTION_QUICK_CLIP_10.equals(action)) {
            onClipDurationTapped(10);
        } else if (ACTION_QUICK_CLIP_30.equals(action)) {
            onClipDurationTapped(30);
        } else if (ACTION_TOGGLE_FULL.equals(action)) {
            onToggleFullGameplay();
        } else if (ACTION_STOP_RECORDING.equals(action)) {
            stopActiveRecordingOnly();
        } else if (pendingFullAfterProjection && isCapturing.get()) {
            pendingFullAfterProjection = false;
            pendingDurationAfterProjection = 0;
            startFullGameplayRecording();
        } else if (pendingDurationAfterProjection > 0 && isCapturing.get()) {
            int dur = pendingDurationAfterProjection;
            pendingDurationAfterProjection = 0;
            startTimedClipRecording(dur, true);
        }

        updateMenuStatusText();
        return START_STICKY;
    }

    @SuppressWarnings("deprecation")
    private Intent getParcelableIntentExtra(Intent source, String key) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            return source.getParcelableExtra(key, Intent.class);
        }
        return source.getParcelableExtra(key);
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID,
                "ClipKaro Floating CLIP",
                NotificationManager.IMPORTANCE_LOW
            );
            channel.setDescription("Floating CLIP controls & notification recording options");
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null) {
                nm.createNotificationChannel(channel);
            }
        }
    }

    private Notification buildServiceNotification() {
        Intent openIntent = new Intent(this, MainActivity.class);
        openIntent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
        int piFlags = PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE;
        PendingIntent contentIntent = PendingIntent.getActivity(this, 0, openIntent, piFlags);

        PendingIntent stopServicePending = PendingIntent.getService(
            this, 1, new Intent(this, FloatingClipService.class).setAction(ACTION_STOP), piFlags
        );
        PendingIntent clip10Pending = PendingIntent.getService(
            this, 2, new Intent(this, FloatingClipService.class).setAction(ACTION_QUICK_CLIP_10), piFlags
        );
        PendingIntent clip30Pending = PendingIntent.getService(
            this, 3, new Intent(this, FloatingClipService.class).setAction(ACTION_QUICK_CLIP_30), piFlags
        );
        PendingIntent fullPending = PendingIntent.getService(
            this, 4, new Intent(this, FloatingClipService.class).setAction(ACTION_TOGGLE_FULL), piFlags
        );
        PendingIntent stopRecPending = PendingIntent.getService(
            this, 5, new Intent(this, FloatingClipService.class).setAction(ACTION_STOP_RECORDING), piFlags
        );

        boolean recordingNow = isRecordingTimed.get() || isRecordingFull.get();
        String title;
        String subtitle;
        if (isRecordingTimed.get()) {
            long sec = Math.max(0L, (System.currentTimeMillis() - timedStartMs) / 1000L);
            title = String.format(
                Locale.US,
                "REC %02d:%02d / %02d:%02d · Clip #%d",
                sec / 60, sec % 60, activeTimedDurationSec / 60, activeTimedDurationSec % 60, currentClipSequence
            );
            subtitle = activeGameName + " · " + getAudioModeLabel() + (autoContinuousEnabled ? " · Auto Loop ON" : "");
        } else if (isRecordingFull.get()) {
            long sec = Math.max(0L, (System.currentTimeMillis() - fullStartMs) / 1000L);
            title = String.format(Locale.US, "REC Full Gameplay %02d:%02d", sec / 60, sec % 60);
            subtitle = activeGameName + " · " + getAudioModeLabel() + " · Saving to Movies/ClipKaro";
        } else {
            title = "ClipKaro Floating CLIP Ready";
            subtitle = activeGameName + " · Audio: " + getAudioModeLabel() + " · Record from Notification or Bubble";
        }

        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(title)
            .setContentText(subtitle)
            .setSmallIcon(R.drawable.ic_clip_scissors)
            .setContentIntent(contentIntent)
            .setOnlyAlertOnce(true)
            .setOngoing(true);

        if (recordingNow) {
            builder.addAction(0, "Stop Recording", stopRecPending);
            builder.addAction(0, "Full Gameplay", fullPending);
            builder.addAction(0, "Close", stopServicePending);
        } else {
            builder.addAction(0, "10s Clip", clip10Pending);
            builder.addAction(0, "30s Clip", clip30Pending);
            builder.addAction(0, "Full Record", fullPending);
        }

        return builder.build();
    }

    private void updateNotificationOnly() {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (nm != null) {
            nm.notify(NOTIFICATION_ID, buildServiceNotification());
        }
    }

    private void startForegroundWithType(boolean hasMediaProjection) {
        Notification notification = buildServiceNotification();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            int fgsType;
            if (hasMediaProjection) {
                fgsType = ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION;
                if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
                    == PackageManager.PERMISSION_GRANTED) {
                    fgsType |= ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE;
                }
            } else {
                fgsType = ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE;
            }
            startForeground(NOTIFICATION_ID, notification, fgsType);
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q && hasMediaProjection) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            );
        } else {
            startForeground(NOTIFICATION_ID, notification);
        }
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    @SuppressLint("ClickableViewAccessibility")
    private void ensureOverlayBubbleShown() {
        if (bubbleView != null || windowManager == null) {
            return;
        }

        int overlayType = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
            ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            : WindowManager.LayoutParams.TYPE_PHONE;

        // 48dp small floating CLIP button with 50% transparency
        int bubbleSize = dp(48);
        bubbleParams = new WindowManager.LayoutParams(
            bubbleSize,
            bubbleSize,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        );
        bubbleParams.gravity = Gravity.TOP | Gravity.START;
        bubbleParams.x = dp(16);
        bubbleParams.y = dp(160);

        bubbleView = new FrameLayout(this);
        bubbleView.setAlpha(0.5f); // 50% transparent
        applyBubbleBackground(false);
        bubbleView.setElevation(dp(8));

        bubbleIdleIcon = new ImageView(this);
        bubbleIdleIcon.setImageResource(R.drawable.ic_clip_scissors);
        FrameLayout.LayoutParams iconLp = new FrameLayout.LayoutParams(dp(22), dp(22));
        iconLp.gravity = Gravity.CENTER;
        bubbleView.addView(bubbleIdleIcon, iconLp);

        // Recording state UI inside the 48dp bubble: RED dot + live timer
        bubbleRecordingBox = new LinearLayout(this);
        bubbleRecordingBox.setOrientation(LinearLayout.VERTICAL);
        bubbleRecordingBox.setGravity(Gravity.CENTER);
        bubbleRecordingBox.setVisibility(View.GONE);

        bubbleRedDot = new View(this);
        GradientDrawable dotBg = new GradientDrawable();
        dotBg.setShape(GradientDrawable.OVAL);
        dotBg.setColor(Color.parseColor("#FF1E2D"));
        bubbleRedDot.setBackground(dotBg);
        LinearLayout.LayoutParams dotLp = new LinearLayout.LayoutParams(dp(8), dp(8));
        dotLp.bottomMargin = dp(2);
        bubbleRecordingBox.addView(bubbleRedDot, dotLp);

        bubbleTimerTv = new TextView(this);
        bubbleTimerTv.setTextColor(Color.WHITE);
        bubbleTimerTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 9);
        bubbleTimerTv.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        bubbleTimerTv.setGravity(Gravity.CENTER);
        bubbleTimerTv.setText("00:00");
        bubbleRecordingBox.addView(bubbleTimerTv);

        FrameLayout.LayoutParams recLp = new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT,
            FrameLayout.LayoutParams.WRAP_CONTENT
        );
        recLp.gravity = Gravity.CENTER;
        bubbleView.addView(bubbleRecordingBox, recLp);

        bubbleView.setOnTouchListener(new View.OnTouchListener() {
            private int initialX;
            private int initialY;
            private float downRawX;
            private float downRawY;
            private boolean isDragging;

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                DisplayMetrics dm = getResources().getDisplayMetrics();
                switch (event.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        initialX = bubbleParams.x;
                        initialY = bubbleParams.y;
                        downRawX = event.getRawX();
                        downRawY = event.getRawY();
                        isDragging = false;
                        return true;

                    case MotionEvent.ACTION_MOVE:
                        float dx = event.getRawX() - downRawX;
                        float dy = event.getRawY() - downRawY;
                        if (Math.hypot(dx, dy) > dp(6)) {
                            isDragging = true;
                        }
                        if (isDragging) {
                            int maxX = Math.max(0, dm.widthPixels - bubbleSize);
                            int maxY = Math.max(0, dm.heightPixels - bubbleSize);
                            bubbleParams.x = Math.max(0, Math.min(maxX, Math.round(initialX + dx)));
                            bubbleParams.y = Math.max(dp(24), Math.min(maxY, Math.round(initialY + dy)));
                            windowManager.updateViewLayout(bubbleView, bubbleParams);
                            if (isMenuVisible && menuView != null) {
                                positionMenuNearBubble();
                                windowManager.updateViewLayout(menuView, menuParams);
                            }
                        }
                        return true;

                    case MotionEvent.ACTION_UP:
                        if (!isDragging) {
                            toggleFloatingMenu();
                        }
                        return true;

                    default:
                        return false;
                }
            }
        });

        windowManager.addView(bubbleView, bubbleParams);
    }

    private void applyBubbleBackground(boolean recording) {
        if (bubbleView == null) return;
        GradientDrawable bg = new GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            recording
                ? new int[]{Color.parseColor("#1E293B"), Color.parseColor("#0F172A")}
                : new int[]{Color.parseColor("#F43F5E"), Color.parseColor("#BE123C")}
        );
        bg.setShape(GradientDrawable.OVAL);
        bg.setStroke(dp(2), Color.parseColor(recording ? "#FF1E2D" : "#FFFFFF"));
        bubbleView.setBackground(bg);
        bubbleView.setAlpha(0.5f);
    }

    private void updateBubbleVisuals(boolean recording, long elapsedSec, boolean dotBright) {
        if (bubbleView == null) return;
        applyBubbleBackground(recording);
        if (recording) {
            if (bubbleIdleIcon != null) bubbleIdleIcon.setVisibility(View.GONE);
            if (bubbleRecordingBox != null) bubbleRecordingBox.setVisibility(View.VISIBLE);
            if (bubbleRedDot != null) bubbleRedDot.setAlpha(dotBright ? 1.0f : 0.35f);
            if (bubbleTimerTv != null) {
                bubbleTimerTv.setText(String.format(Locale.US, "%02d:%02d", elapsedSec / 60, elapsedSec % 60));
            }
        } else {
            if (bubbleIdleIcon != null) bubbleIdleIcon.setVisibility(View.VISIBLE);
            if (bubbleRecordingBox != null) bubbleRecordingBox.setVisibility(View.GONE);
        }
    }

    private void positionMenuNearBubble() {
        if (menuParams == null || bubbleParams == null) return;
        DisplayMetrics dm = getResources().getDisplayMetrics();
        int menuWidth = dp(264);
        int targetX = bubbleParams.x + dp(56);
        if (targetX + menuWidth > dm.widthPixels - dp(10)) {
            targetX = Math.max(dp(10), bubbleParams.x - menuWidth - dp(8));
        }
        int targetY = Math.max(dp(28), Math.min(dm.heightPixels - dp(390), bubbleParams.y));
        menuParams.x = targetX;
        menuParams.y = targetY;
    }

    private void toggleFloatingMenu() {
        if (isMenuVisible) {
            hideFloatingMenu();
        } else {
            showFloatingMenu();
        }
    }

    private void showFloatingMenu() {
        if (windowManager == null) return;
        if (menuView == null) {
            buildFloatingMenu();
        }
        positionMenuNearBubble();
        updateMenuStatusText();
        if (!isMenuVisible) {
            windowManager.addView(menuView, menuParams);
            isMenuVisible = true;
        }
    }

    private void hideFloatingMenu() {
        if (isMenuVisible && menuView != null && windowManager != null) {
            try {
                windowManager.removeView(menuView);
            } catch (IllegalArgumentException ignored) {
            }
            isMenuVisible = false;
        }
    }

    private void buildFloatingMenu() {
        int overlayType = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
            ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            : WindowManager.LayoutParams.TYPE_PHONE;

        menuParams = new WindowManager.LayoutParams(
            dp(264),
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        );
        menuParams.gravity = Gravity.TOP | Gravity.START;

        menuView = new LinearLayout(this);
        menuView.setOrientation(LinearLayout.VERTICAL);
        menuView.setPadding(dp(12), dp(12), dp(12), dp(12));

        GradientDrawable cardBg = new GradientDrawable();
        cardBg.setColor(Color.parseColor("#F50F172A"));
        cardBg.setCornerRadius(dp(14));
        cardBg.setStroke(dp(1), Color.parseColor("#334155"));
        menuView.setBackground(cardBg);
        menuView.setElevation(dp(12));

        // Header Row
        LinearLayout headerRow = new LinearLayout(this);
        headerRow.setOrientation(LinearLayout.HORIZONTAL);
        headerRow.setGravity(Gravity.CENTER_VERTICAL);

        TextView titleTv = new TextView(this);
        titleTv.setText("ClipKaro CLIP");
        titleTv.setTextColor(Color.WHITE);
        titleTv.setTextSize(14);
        titleTv.setTypeface(Typeface.DEFAULT_BOLD);
        headerRow.addView(titleTv, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

        TextView closeTv = new TextView(this);
        closeTv.setText("Hide");
        closeTv.setTextColor(Color.parseColor("#94A3B8"));
        closeTv.setTextSize(12);
        closeTv.setPadding(dp(8), dp(2), dp(4), dp(2));
        closeTv.setOnClickListener(v -> hideFloatingMenu());
        headerRow.addView(closeTv);
        menuView.addView(headerRow);

        menuStatusView = new TextView(this);
        menuStatusView.setTextColor(Color.parseColor("#CBD5E1"));
        menuStatusView.setTextSize(11);
        menuStatusView.setPadding(0, dp(3), 0, dp(8));
        menuView.addView(menuStatusView);

        // Audio Choice Header
        TextView audioLabel = new TextView(this);
        audioLabel.setText("Audio Source");
        audioLabel.setTextColor(Color.parseColor("#94A3B8"));
        audioLabel.setTextSize(10);
        audioLabel.setTypeface(Typeface.DEFAULT_BOLD);
        audioLabel.setPadding(0, 0, 0, dp(4));
        menuView.addView(audioLabel);

        // Audio Choice Selector: Game/Video Only / Mic Only / Game+Mic Both
        LinearLayout audioRow = new LinearLayout(this);
        audioRow.setOrientation(LinearLayout.HORIZONTAL);
        audioGameBtn = createCompactToggleBtn("Game/Video");
        audioMicBtn = createCompactToggleBtn("Mic Only");
        audioBothBtn = createCompactToggleBtn("Game+Mic");

        LinearLayout.LayoutParams aLp1 = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        aLp1.rightMargin = dp(4);
        LinearLayout.LayoutParams aLp2 = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        aLp2.rightMargin = dp(4);
        LinearLayout.LayoutParams aLp3 = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.15f);

        audioGameBtn.setOnClickListener(v -> setAudioMode(AUDIO_MODE_GAME));
        audioMicBtn.setOnClickListener(v -> setAudioMode(AUDIO_MODE_MIC));
        audioBothBtn.setOnClickListener(v -> setAudioMode(AUDIO_MODE_BOTH));

        audioRow.addView(audioGameBtn, aLp1);
        audioRow.addView(audioMicBtn, aLp2);
        audioRow.addView(audioBothBtn, aLp3);
        menuView.addView(audioRow);

        // Auto Continuous Clips Toggle
        autoContinuousBtn = createMenuButton("Auto Continuous Clips: ON", "#1E293B", "#6EE7B7");
        LinearLayout.LayoutParams autoLp = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        );
        autoLp.topMargin = dp(8);
        autoLp.bottomMargin = dp(4);
        autoContinuousBtn.setOnClickListener(v -> toggleAutoContinuous());
        menuView.addView(autoContinuousBtn, autoLp);

        // Auto Highlight (15s on BGMI Kill / Headshot / Knock) Toggle
        autoHighlightBtn = createMenuButton("Auto Highlight 15s: ON", "#1E293B", "#FDE68A");
        LinearLayout.LayoutParams hlLp = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        );
        hlLp.bottomMargin = dp(6);
        autoHighlightBtn.setOnClickListener(v -> toggleAutoHighlight());
        menuView.addView(autoHighlightBtn, hlLp);

        // Clip Duration Grid (10s - 60s)
        GridLayout grid = new GridLayout(this);
        grid.setColumnCount(2);
        int[] durations = new int[]{10, 20, 30, 40, 50, 60};
        for (int sec : durations) {
            Button btn = createMenuButton(sec + "s Clip", "#1E293B", "#F8FAFC");
            GridLayout.LayoutParams gp = new GridLayout.LayoutParams();
            gp.width = 0;
            gp.columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f);
            gp.setMargins(dp(3), dp(3), dp(3), dp(3));
            btn.setOnClickListener(v -> onClipDurationTapped(sec));
            grid.addView(btn, gp);
        }
        menuView.addView(grid);

        // Record Full Video / Gameplay Button
        fullRecordBtn = createMenuButton("Record Full Video / Gameplay", "#E11D48", "#FFFFFF");
        LinearLayout.LayoutParams fullLp = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        );
        fullLp.topMargin = dp(8);
        fullRecordBtn.setOnClickListener(v -> onToggleFullGameplay());
        menuView.addView(fullRecordBtn, fullLp);

        // Stop Recording / Stop Floating Service Buttons
        stopRecBtn = createMenuButton("Stop Recording", "#7F1D1D", "#FECACA");
        LinearLayout.LayoutParams stopRecLp = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        );
        stopRecLp.topMargin = dp(6);
        stopRecBtn.setOnClickListener(v -> {
            hideFloatingMenu();
            stopActiveRecordingOnly();
        });
        menuView.addView(stopRecBtn, stopRecLp);

        Button closeBubbleBtn = createMenuButton("Close Floating Bubble", "#334155", "#CBD5E1");
        LinearLayout.LayoutParams closeLp = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        );
        closeLp.topMargin = dp(6);
        closeBubbleBtn.setOnClickListener(v -> stopEverythingAndSelf());
        menuView.addView(closeBubbleBtn, closeLp);
    }

    private Button createCompactToggleBtn(String label) {
        Button btn = new Button(this);
        btn.setText(label);
        btn.setAllCaps(false);
        btn.setTextSize(10);
        btn.setTypeface(Typeface.DEFAULT_BOLD);
        btn.setPadding(dp(4), dp(6), dp(4), dp(6));
        btn.setMinHeight(0);
        btn.setMinimumHeight(dp(30));
        return btn;
    }

    private void styleToggleButton(Button btn, boolean active) {
        if (btn == null) return;
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.parseColor(active ? "#E11D48" : "#1E293B"));
        bg.setCornerRadius(dp(6));
        if (!active) {
            bg.setStroke(dp(1), Color.parseColor("#334155"));
        }
        btn.setBackground(bg);
        btn.setTextColor(Color.parseColor(active ? "#FFFFFF" : "#CBD5E1"));
    }

    private Button createMenuButton(String label, String bgHex, String textHex) {
        Button btn = new Button(this);
        btn.setText(label);
        btn.setAllCaps(false);
        btn.setTextSize(12);
        btn.setTypeface(Typeface.DEFAULT_BOLD);
        btn.setTextColor(Color.parseColor(textHex));
        btn.setPadding(dp(8), dp(7), dp(8), dp(7));
        btn.setMinHeight(0);
        btn.setMinimumHeight(dp(34));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.parseColor(bgHex));
        bg.setCornerRadius(dp(8));
        btn.setBackground(bg);
        return btn;
    }

    private void setAudioMode(String mode) {
        selectedAudioMode = mode;
        getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
            .edit()
            .putString(KEY_AUDIO_MODE, mode)
            .apply();
        updateMenuStatusText();
        updateNotificationOnly();

        if (isCapturing.get()) {
            restartAudioPipelineForMode();
        }
        showToast("Audio set to: " + getAudioModeLabel());
    }

    private void toggleAutoContinuous() {
        autoContinuousEnabled = !autoContinuousEnabled;
        getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
            .edit()
            .putBoolean(KEY_AUTO_CONTINUOUS, autoContinuousEnabled)
            .apply();
        updateMenuStatusText();
        updateNotificationOnly();
    }

    private void toggleAutoHighlight() {
        autoHighlightEnabled = !autoHighlightEnabled;
        getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
            .edit()
            .putBoolean(KEY_AUTO_HIGHLIGHT, autoHighlightEnabled)
            .apply();
        updateMenuStatusText();
        showToast(
            autoHighlightEnabled
                ? "Auto Highlight ON: Saves 15s on Kill / Headshot / Knock"
                : "Auto Highlight OFF"
        );
    }

    private String getAudioModeLabel() {
        if (AUDIO_MODE_GAME.equals(selectedAudioMode)) return "Game/Video Only";
        if (AUDIO_MODE_MIC.equals(selectedAudioMode)) return "Mic Only";
        return "Game+Mic Both";
    }

    private void updateMenuStatusText() {
        mainHandler.post(() -> {
            styleToggleButton(audioGameBtn, AUDIO_MODE_GAME.equals(selectedAudioMode));
            styleToggleButton(audioMicBtn, AUDIO_MODE_MIC.equals(selectedAudioMode));
            styleToggleButton(audioBothBtn, AUDIO_MODE_BOTH.equals(selectedAudioMode));

            if (autoContinuousBtn != null) {
                autoContinuousBtn.setText(
                    autoContinuousEnabled
                        ? "Auto Continuous Clips: ON"
                        : "Auto Continuous Clips: OFF"
                );
                autoContinuousBtn.setTextColor(
                    Color.parseColor(autoContinuousEnabled ? "#6EE7B7" : "#94A3B8")
                );
            }

            if (autoHighlightBtn != null) {
                autoHighlightBtn.setText(
                    autoHighlightEnabled
                        ? "Auto Highlight (15s Kill/Headshot): ON"
                        : "Auto Highlight (15s Kill/Headshot): OFF"
                );
                autoHighlightBtn.setTextColor(
                    Color.parseColor(autoHighlightEnabled ? "#FDE68A" : "#94A3B8")
                );
            }

            if (menuStatusView != null) {
                if (isRecordingTimed.get()) {
                    long sec = Math.max(0L, (System.currentTimeMillis() - timedStartMs) / 1000L);
                    menuStatusView.setText(
                        String.format(
                            Locale.US,
                            "REC %02d:%02d / %02d:%02d · Clip #%d (%s)",
                            sec / 60, sec % 60, activeTimedDurationSec / 60, activeTimedDurationSec % 60,
                            currentClipSequence, getAudioModeLabel()
                        )
                    );
                    menuStatusView.setTextColor(Color.parseColor("#FDA4AF"));
                } else if (isRecordingFull.get()) {
                    long sec = Math.max(0L, (System.currentTimeMillis() - fullStartMs) / 1000L);
                    menuStatusView.setText(
                        String.format(Locale.US, "REC Full Video %02d:%02d · %s", sec / 60, sec % 60, getAudioModeLabel())
                    );
                    menuStatusView.setTextColor(Color.parseColor("#FDA4AF"));
                } else if (isCapturing.get()) {
                    menuStatusView.setText(activeGameName + " · Tap duration to record immediately");
                    menuStatusView.setTextColor(Color.parseColor("#6EE7B7"));
                } else {
                    menuStatusView.setText(activeGameName + " · Tap any option to capture screen");
                    menuStatusView.setTextColor(Color.parseColor("#FDE68A"));
                }
            }

            boolean recordingAny = isRecordingTimed.get() || isRecordingFull.get();
            if (fullRecordBtn != null) {
                fullRecordBtn.setText(
                    isRecordingFull.get() ? "Stop & Save Full Video" : "Record Full Video / Gameplay"
                );
            }
            if (stopRecBtn != null) {
                stopRecBtn.setVisibility(recordingAny ? View.VISIBLE : View.GONE);
            }
        });
    }

    private void onClipDurationTapped(int seconds) {
        hideFloatingMenu();
        if (!isCapturing.get()) {
            pendingDurationAfterProjection = seconds;
            pendingFullAfterProjection = false;
            promptMainForScreenCapture(seconds, false);
            return;
        }
        startTimedClipRecording(seconds, true);
    }

    private void onToggleFullGameplay() {
        hideFloatingMenu();
        if (!isCapturing.get()) {
            pendingFullAfterProjection = true;
            pendingDurationAfterProjection = 0;
            promptMainForScreenCapture(0, true);
            return;
        }
        if (isRecordingFull.get()) {
            stopActiveRecordingOnly();
        } else {
            startFullGameplayRecording();
        }
    }

    private void promptMainForScreenCapture(int durationSec, boolean isFull) {
        Intent intent = new Intent(this, MainActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        intent.putExtra(MainActivity.EXTRA_REQUEST_PROJECTION_GAME, activeGameName);
        if (durationSec > 0) {
            intent.putExtra(EXTRA_PENDING_DURATION, durationSec);
        }
        if (isFull) {
            intent.putExtra(EXTRA_PENDING_FULL, true);
        }
        startActivity(intent);
        showToast("Allow screen capture to start recording " + activeGameName);
    }

    private void startCapturePipeline() {
        if (projectionResultData == null || isCapturing.get()) {
            return;
        }

        MediaProjectionManager mpm =
            (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);
        if (mpm == null) return;

        mediaProjection = mpm.getMediaProjection(projectionResultCode, projectionResultData);
        if (mediaProjection == null) return;

        mediaProjection.registerCallback(new MediaProjection.Callback() {
            @Override
            public void onStop() {
                mainHandler.post(() -> {
                    stopCapturePipeline();
                    updateBubbleVisuals(false, 0L, false);
                    updateMenuStatusText();
                    updateNotificationOnly();
                });
            }
        }, mainHandler);

        DisplayMetrics dm = getResources().getDisplayMetrics();
        int rawW = Math.max(720, dm.widthPixels);
        int rawH = Math.max(720, dm.heightPixels);
        int maxDim = Math.max(rawW, rawH);
        double scale = maxDim > 1280 ? (1280.0 / maxDim) : 1.0;
        int encW = Math.max(320, ((int) Math.round(rawW * scale) / 16) * 16);
        int encH = Math.max(320, ((int) Math.round(rawH * scale) / 16) * 16);

        try {
            MediaFormat videoFormat = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, encW, encH);
            videoFormat.setInteger(
                MediaFormat.KEY_COLOR_FORMAT,
                MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface
            );
            videoFormat.setInteger(MediaFormat.KEY_BIT_RATE, VIDEO_BITRATE);
            videoFormat.setInteger(MediaFormat.KEY_FRAME_RATE, VIDEO_FPS);
            videoFormat.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1);

            videoEncoder = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC);
            videoEncoder.configure(videoFormat, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE);
            encoderSurface = videoEncoder.createInputSurface();
            videoEncoder.start();

            virtualDisplay = mediaProjection.createVirtualDisplay(
                "ClipKaroCapture",
                encW,
                encH,
                dm.densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                encoderSurface,
                null,
                null
            );

            isCapturing.set(true);
            captureStartedAtMs = System.currentTimeMillis();
            videoThread = new Thread(this::runVideoDrainLoop, "ClipKaroVideoDrain");
            videoThread.start();

            startAudioPipeline();
            updateMenuStatusText();
            updateNotificationOnly();
        } catch (Exception e) {
            stopCapturePipeline();
            showToast("Screen capture setup failed: " + e.getMessage());
        }
    }

    @SuppressLint("MissingPermission")
    private void startAudioPipeline() {
        stopAudioPipelineOnly();
        if (!isCapturing.get()) return;

        try {
            int minBuf = AudioRecord.getMinBufferSize(
                AUDIO_SAMPLE_RATE,
                AudioFormat.CHANNEL_IN_STEREO,
                AudioFormat.ENCODING_PCM_16BIT
            );
            int bufSize = Math.max(minBuf * 2, 8192);

            AudioFormat audioFormat = new AudioFormat.Builder()
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setSampleRate(AUDIO_SAMPLE_RATE)
                .setChannelMask(AudioFormat.CHANNEL_IN_STEREO)
                .build();

            boolean wantGame = AUDIO_MODE_GAME.equals(selectedAudioMode) || AUDIO_MODE_BOTH.equals(selectedAudioMode);
            boolean wantMic = AUDIO_MODE_MIC.equals(selectedAudioMode) || AUDIO_MODE_BOTH.equals(selectedAudioMode);
            boolean micPermGranted = ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
                == PackageManager.PERMISSION_GRANTED;

            if (wantGame && Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q && mediaProjection != null) {
                AudioPlaybackCaptureConfiguration config =
                    new AudioPlaybackCaptureConfiguration.Builder(mediaProjection)
                        .addMatchingUsage(AudioAttributes.USAGE_GAME)
                        .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
                        .build();
                AudioRecord rec = new AudioRecord.Builder()
                    .setAudioPlaybackCaptureConfig(config)
                    .setAudioFormat(audioFormat)
                    .setBufferSizeInBytes(bufSize)
                    .build();
                if (rec.getState() == AudioRecord.STATE_INITIALIZED) {
                    gameAudioRecord = rec;
                } else {
                    rec.release();
                }
            }

            if (wantMic && micPermGranted) {
                AudioRecord rec = new AudioRecord.Builder()
                    .setAudioSource(MediaRecorder.AudioSource.MIC)
                    .setAudioFormat(audioFormat)
                    .setBufferSizeInBytes(bufSize)
                    .build();
                if (rec.getState() == AudioRecord.STATE_INITIALIZED) {
                    micAudioRecord = rec;
                } else {
                    rec.release();
                }
            }

            // Fallback to mic on Android < 10 if Game Only selected without AudioPlaybackCapture support
            if (gameAudioRecord == null && micAudioRecord == null && micPermGranted) {
                AudioRecord rec = new AudioRecord.Builder()
                    .setAudioSource(MediaRecorder.AudioSource.MIC)
                    .setAudioFormat(audioFormat)
                    .setBufferSizeInBytes(bufSize)
                    .build();
                if (rec.getState() == AudioRecord.STATE_INITIALIZED) {
                    micAudioRecord = rec;
                } else {
                    rec.release();
                }
            }

            if (gameAudioRecord != null || micAudioRecord != null) {
                MediaFormat encFormat = MediaFormat.createAudioFormat(
                    MediaFormat.MIMETYPE_AUDIO_AAC,
                    AUDIO_SAMPLE_RATE,
                    2
                );
                encFormat.setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC);
                encFormat.setInteger(MediaFormat.KEY_BIT_RATE, AUDIO_BITRATE);
                encFormat.setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, bufSize);

                audioEncoder = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC);
                audioEncoder.configure(encFormat, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE);
                audioEncoder.start();

                if (gameAudioRecord != null) gameAudioRecord.startRecording();
                if (micAudioRecord != null) micAudioRecord.startRecording();

                audioLoopRunning.set(true);
                audioThread = new Thread(this::runAudioCaptureLoop, "ClipKaroAudioLoop");
                audioThread.start();
            }
        } catch (Exception ignored) {
            stopAudioPipelineOnly();
        }
    }

    private void restartAudioPipelineForMode() {
        exportExecutor.execute(() -> {
            startAudioPipeline();
        });
    }

    private void stopAudioPipelineOnly() {
        audioLoopRunning.set(false);
        if (audioThread != null) {
            try {
                audioThread.join(350);
            } catch (InterruptedException ignored) {
            }
            audioThread = null;
        }
        if (gameAudioRecord != null) {
            try {
                gameAudioRecord.stop();
            } catch (Exception ignored) {
            }
            try {
                gameAudioRecord.release();
            } catch (Exception ignored) {
            }
            gameAudioRecord = null;
        }
        if (micAudioRecord != null) {
            try {
                micAudioRecord.stop();
            } catch (Exception ignored) {
            }
            try {
                micAudioRecord.release();
            } catch (Exception ignored) {
            }
            micAudioRecord = null;
        }
        if (audioEncoder != null) {
            try {
                audioEncoder.stop();
            } catch (Exception ignored) {
            }
            try {
                audioEncoder.release();
            } catch (Exception ignored) {
            }
            audioEncoder = null;
        }
    }

    private void startTimedClipRecording(int durationSec, boolean resetSequence) {
        if (isRecordingFull.get()) {
            finishFullGameplayRecording(true);
        }
        synchronized (muxerLock) {
            if (isRecordingTimed.get()) {
                closeTimedMuxerAndEnqueueSaveLocked(false);
            }
            activeTimedDurationSec = Math.max(5, durationSec);
            if (resetSequence) {
                currentClipSequence = 1;
            }
            openNewTimedMuxerLocked();
            isRecordingTimed.set(true);
        }

        requestSyncFrame();
        mainHandler.removeCallbacks(uiTickerRunnable);
        mainHandler.post(uiTickerRunnable);
        updateBubbleVisuals(true, 0L, true);
        updateNotificationOnly();
        showToast(
            String.format(
                Locale.US,
                "Recording %ds clip (#%d · %s)",
                activeTimedDurationSec, currentClipSequence, getAudioModeLabel()
            )
        );
    }

    private void openNewTimedMuxerLocked() {
        String safeGame = activeGameName.replaceAll("[^A-Za-z0-9_]+", "_");
        timedTempFile = new File(
            getCacheDir(),
            String.format(
                Locale.US,
                "ClipKaro_%s_%ds_Clip%d_%d.mp4",
                safeGame, activeTimedDurationSec, currentClipSequence, System.currentTimeMillis()
            )
        );
        try {
            timedMuxer = new MediaMuxer(timedTempFile.getAbsolutePath(), MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);
            timedMuxerStarted = false;
            timedWaitingForKeyframe = true;
            timedVideoTrack = -1;
            timedAudioTrack = -1;
            timedStartMs = System.currentTimeMillis();
        } catch (IOException e) {
            timedMuxer = null;
            isRecordingTimed.set(false);
        }
    }

    private void closeTimedMuxerAndEnqueueSaveLocked(boolean saveToGallery) {
        if (timedMuxer != null) {
            try {
                if (timedMuxerStarted) timedMuxer.stop();
            } catch (Exception ignored) {
            }
            try {
                timedMuxer.release();
            } catch (Exception ignored) {
            }
            timedMuxer = null;
            timedMuxerStarted = false;
        }
        File finishedFile = timedTempFile;
        int clipNum = currentClipSequence;
        int durSec = activeTimedDurationSec;
        timedTempFile = null;

        if (finishedFile != null && finishedFile.exists()) {
            if (saveToGallery && finishedFile.length() > 2048) {
                exportExecutor.execute(() -> saveClipFileAndBroadcast(finishedFile, "Saved Clip #" + clipNum + " (" + durSec + "s)"));
            } else {
                //noinspection ResultOfMethodCallIgnored
                finishedFile.delete();
            }
        }
    }

    private void onTimedClipDurationReached() {
        if (!isRecordingTimed.get()) return;
        synchronized (muxerLock) {
            closeTimedMuxerAndEnqueueSaveLocked(true);
            if (autoContinuousEnabled) {
                currentClipSequence += 1;
                openNewTimedMuxerLocked();
                requestSyncFrame();
            } else {
                isRecordingTimed.set(false);
            }
        }
        if (!isRecordingTimed.get()) {
            updateBubbleVisuals(false, 0L, false);
            updateNotificationOnly();
            updateMenuStatusText();
        }
    }

    private void startFullGameplayRecording() {
        if (isRecordingTimed.get()) {
            synchronized (muxerLock) {
                isRecordingTimed.set(false);
                closeTimedMuxerAndEnqueueSaveLocked(true);
            }
        }
        synchronized (muxerLock) {
            if (isRecordingFull.get()) return;
            String safeGame = activeGameName.replaceAll("[^A-Za-z0-9_]+", "_");
            fullTempFile = new File(
                getCacheDir(),
                "ClipKaro_Full_" + safeGame + "_" + System.currentTimeMillis() + ".mp4"
            );
            try {
                fullMuxer = new MediaMuxer(fullTempFile.getAbsolutePath(), MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);
                fullMuxerStarted = false;
                fullWaitingForKeyframe = true;
                fullVideoTrack = -1;
                fullAudioTrack = -1;
                fullStartMs = System.currentTimeMillis();
                isRecordingFull.set(true);
                requestSyncFrame();
            } catch (IOException e) {
                fullMuxer = null;
                isRecordingFull.set(false);
            }
        }
        mainHandler.removeCallbacks(uiTickerRunnable);
        mainHandler.post(uiTickerRunnable);
        updateBubbleVisuals(true, 0L, true);
        updateNotificationOnly();
        showToast("Recording full " + activeGameName + " gameplay (" + getAudioModeLabel() + ")…");
    }

    private void finishFullGameplayRecording(boolean saveFile) {
        File finishedFile;
        synchronized (muxerLock) {
            if (!isRecordingFull.get()) return;
            isRecordingFull.set(false);
            if (fullMuxer != null) {
                try {
                    if (fullMuxerStarted) fullMuxer.stop();
                } catch (Exception ignored) {
                }
                try {
                    fullMuxer.release();
                } catch (Exception ignored) {
                }
                fullMuxer = null;
                fullMuxerStarted = false;
            }
            finishedFile = fullTempFile;
            fullTempFile = null;
        }

        if (finishedFile != null && finishedFile.exists()) {
            if (saveFile && finishedFile.length() > 2048) {
                exportExecutor.execute(() -> saveClipFileAndBroadcast(finishedFile, "Saved Full " + activeGameName + " gameplay"));
            } else {
                //noinspection ResultOfMethodCallIgnored
                finishedFile.delete();
            }
        }
    }

    private void stopActiveRecordingOnly() {
        boolean wasTimed = isRecordingTimed.get();
        boolean wasFull = isRecordingFull.get();
        if (wasTimed) {
            synchronized (muxerLock) {
                isRecordingTimed.set(false);
                closeTimedMuxerAndEnqueueSaveLocked(true);
            }
        }
        if (wasFull) {
            finishFullGameplayRecording(true);
        }
        mainHandler.removeCallbacks(uiTickerRunnable);
        updateBubbleVisuals(false, 0L, false);
        updateMenuStatusText();
        updateNotificationOnly();
        if (wasTimed || wasFull) {
            showToast("Recording stopped — saving to Movies/ClipKaro & My Clips");
        }
    }

    private void requestSyncFrame() {
        if (videoEncoder != null) {
            try {
                Bundle sync = new Bundle();
                sync.putInt(MediaCodec.PARAMETER_KEY_REQUEST_SYNC_FRAME, 0);
                videoEncoder.setParameters(sync);
            } catch (Exception ignored) {
            }
        }
    }

    private void saveClipFileAndBroadcast(File tempFile, String toastLabel) {
        try {
            Uri savedUri = saveMp4ToMoviesGallery(tempFile, tempFile.getName());
            showToast(toastLabel + " → Movies/ClipKaro");
            Intent savedBroadcast = new Intent(ACTION_NATIVE_CLIP_SAVED);
            savedBroadcast.setPackage(getPackageName());
            savedBroadcast.putExtra(EXTRA_SAVED_FILE_NAME, tempFile.getName());
            if (savedUri != null) {
                savedBroadcast.putExtra(EXTRA_SAVED_URI, savedUri.toString());
            }
            sendBroadcast(savedBroadcast);
        } catch (IOException e) {
            showToast("Save failed: " + e.getMessage());
        } finally {
            //noinspection ResultOfMethodCallIgnored
            tempFile.delete();
        }
    }

    private void openNextHighlightSegmentLocked(long firstPtsUs) {
        closeCurrentHighlightSegmentLocked(true);
        if (latestVideoFormat == null || highlightBufferDir == null) return;
        try {
            File nextFile = new File(highlightBufferDir, "hl_" + (hlSegmentIndex++) + ".mp4");
            MediaMuxer muxer = new MediaMuxer(nextFile.getAbsolutePath(), MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);
            hlVideoTrack = muxer.addTrack(latestVideoFormat);
            hlAudioTrack = latestAudioFormat != null ? muxer.addTrack(latestAudioFormat) : -1;
            muxer.start();
            currentHighlightSegmentFile = nextFile;
            highlightMuxer = muxer;
            hlMuxerStarted = true;
            currentHlSegmentStartUs = firstPtsUs;
        } catch (IOException ignored) {
            highlightMuxer = null;
            hlMuxerStarted = false;
        }
    }

    private void closeCurrentHighlightSegmentLocked(boolean keepFile) {
        if (highlightMuxer != null) {
            try {
                if (hlMuxerStarted) highlightMuxer.stop();
            } catch (Exception ignored) {
            }
            try {
                highlightMuxer.release();
            } catch (Exception ignored) {
            }
            highlightMuxer = null;
            hlMuxerStarted = false;
        }
        if (currentHighlightSegmentFile != null) {
            if (keepFile && currentHighlightSegmentFile.exists() && currentHighlightSegmentFile.length() > 1024) {
                completedHighlightSegments.add(currentHighlightSegmentFile);
                while (completedHighlightSegments.size() > MAX_HIGHLIGHT_SEGMENTS) {
                    File oldest = completedHighlightSegments.remove(0);
                    //noinspection ResultOfMethodCallIgnored
                    oldest.delete();
                }
            } else {
                //noinspection ResultOfMethodCallIgnored
                currentHighlightSegmentFile.delete();
            }
            currentHighlightSegmentFile = null;
        }
        currentHlSegmentStartUs = -1L;
    }

    private void maybeTriggerAutoHighlight(String eventLabel) {
        if (!autoHighlightEnabled || !isCapturing.get()) return;
        long now = System.currentTimeMillis();
        if (now - captureStartedAtMs < 7000L) return;
        if (now - lastAutoHighlightSavedMs < HIGHLIGHT_COOLDOWN_MS) return;
        lastAutoHighlightSavedMs = now;
        exportExecutor.execute(() -> exportAutoHighlight15s(eventLabel));
    }

    private void exportAutoHighlight15s(String eventLabel) {
        try {
            requestSyncFrame();
            try {
                Thread.sleep(250);
            } catch (InterruptedException ignored) {
            }
            List<File> sourceFiles;
            synchronized (muxerLock) {
                closeCurrentHighlightSegmentLocked(true);
                int count = completedHighlightSegments.size();
                if (count == 0) return;
                int start = Math.max(0, count - 3);
                sourceFiles = new ArrayList<>(completedHighlightSegments.subList(start, count));
            }
            if (sourceFiles.isEmpty()) return;

            String safeGame = activeGameName.replaceAll("[^A-Za-z0-9_]+", "_");
            String fileName = String.format(
                Locale.US,
                "ClipKaro_AutoHighlight_%s_%s_15s_%d_%d.mp4",
                safeGame, eventLabel, highlightSequence++, System.currentTimeMillis()
            );
            File tempOut = new File(getCacheDir(), fileName);
            stitchHighlightSegments(sourceFiles, tempOut);
            if (tempOut.exists() && tempOut.length() > 2048) {
                saveClipFileAndBroadcast(tempOut, "Auto Highlight (" + eventLabel + " · 15s)");
            } else {
                //noinspection ResultOfMethodCallIgnored
                tempOut.delete();
            }
        } catch (Exception ignored) {
        }
    }

    private void stitchHighlightSegments(List<File> segments, File outFile) throws IOException {
        MediaMuxer outMuxer = new MediaMuxer(outFile.getAbsolutePath(), MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);
        int outVideoTrack = -1;
        int outAudioTrack = -1;
        boolean muxerStarted = false;
        long totalVideoOffsetUs = 0L;
        long totalAudioOffsetUs = 0L;
        ByteBuffer buffer = ByteBuffer.allocate(1024 * 1024);
        MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();

        try {
            for (File seg : segments) {
                MediaExtractor extractor = new MediaExtractor();
                try {
                    extractor.setDataSource(seg.getAbsolutePath());
                    int srcVideo = -1;
                    int srcAudio = -1;
                    MediaFormat vFmt = null;
                    MediaFormat aFmt = null;
                    for (int i = 0; i < extractor.getTrackCount(); i++) {
                        MediaFormat fmt = extractor.getTrackFormat(i);
                        String mime = fmt.getString(MediaFormat.KEY_MIME);
                        if (mime != null && mime.startsWith("video/") && srcVideo < 0) {
                            srcVideo = i;
                            vFmt = fmt;
                        } else if (mime != null && mime.startsWith("audio/") && srcAudio < 0) {
                            srcAudio = i;
                            aFmt = fmt;
                        }
                    }
                    if (!muxerStarted) {
                        if (vFmt != null) outVideoTrack = outMuxer.addTrack(vFmt);
                        if (aFmt != null) outAudioTrack = outMuxer.addTrack(aFmt);
                        if (outVideoTrack >= 0 || outAudioTrack >= 0) {
                            outMuxer.start();
                            muxerStarted = true;
                        }
                    }
                    if (!muxerStarted) continue;

                    long segMaxVideoUs = 0L;
                    long segFirstVideoUs = -1L;
                    if (srcVideo >= 0 && outVideoTrack >= 0) {
                        extractor.selectTrack(srcVideo);
                        while (true) {
                            int size = extractor.readSampleData(buffer, 0);
                            if (size < 0) break;
                            long sampleTime = extractor.getSampleTime();
                            if (segFirstVideoUs < 0) segFirstVideoUs = sampleTime;
                            long relUs = Math.max(0L, sampleTime - segFirstVideoUs);
                            info.offset = 0;
                            info.size = size;
                            info.presentationTimeUs = totalVideoOffsetUs + relUs;
                            //noinspection WrongConstant
                            info.flags = extractor.getSampleFlags();
                            outMuxer.writeSampleData(outVideoTrack, buffer, info);
                            segMaxVideoUs = Math.max(segMaxVideoUs, relUs);
                            extractor.advance();
                        }
                        extractor.unselectTrack(srcVideo);
                    }

                    long segMaxAudioUs = 0L;
                    long segFirstAudioUs = -1L;
                    if (srcAudio >= 0 && outAudioTrack >= 0) {
                        extractor.selectTrack(srcAudio);
                        while (true) {
                            int size = extractor.readSampleData(buffer, 0);
                            if (size < 0) break;
                            long sampleTime = extractor.getSampleTime();
                            if (segFirstAudioUs < 0) segFirstAudioUs = sampleTime;
                            long relUs = Math.max(0L, sampleTime - segFirstAudioUs);
                            info.offset = 0;
                            info.size = size;
                            info.presentationTimeUs = totalAudioOffsetUs + relUs;
                            //noinspection WrongConstant
                            info.flags = extractor.getSampleFlags();
                            outMuxer.writeSampleData(outAudioTrack, buffer, info);
                            segMaxAudioUs = Math.max(segMaxAudioUs, relUs);
                            extractor.advance();
                        }
                        extractor.unselectTrack(srcAudio);
                    }

                    totalVideoOffsetUs += segMaxVideoUs + 33_333L;
                    totalAudioOffsetUs += Math.max(segMaxAudioUs, segMaxVideoUs) + 23_220L;
                } finally {
                    extractor.release();
                }
            }
        } finally {
            try {
                if (muxerStarted) outMuxer.stop();
            } catch (Exception ignored) {
            }
            outMuxer.release();
        }
    }

    private void runVideoDrainLoop() {
        MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
        while (isCapturing.get()) {
            try {
                int outIndex = videoEncoder.dequeueOutputBuffer(info, 10_000);
                if (outIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    synchronized (muxerLock) {
                        latestVideoFormat = videoEncoder.getOutputFormat();
                    }
                } else if (outIndex >= 0) {
                    ByteBuffer outBuf = videoEncoder.getOutputBuffer(outIndex);
                    if (outBuf != null && (info.flags & MediaCodec.BUFFER_FLAG_CODEC_CONFIG) == 0 && info.size > 0) {
                        boolean isKeyFrame = (info.flags & MediaCodec.BUFFER_FLAG_KEY_FRAME) != 0;
                        if (!isKeyFrame) {
                            avgPFrameBytes = avgPFrameBytes * 0.95 + info.size * 0.05;
                            long nowMs = System.currentTimeMillis();
                            if (autoHighlightEnabled
                                && (nowMs - lastAudioCombatPeakMs) <= 2200L
                                && info.size > avgPFrameBytes * 2.15) {
                                maybeTriggerAutoHighlight("Headshot");
                            }
                        }

                        synchronized (muxerLock) {
                            if (autoHighlightEnabled) {
                                if (currentHlSegmentStartUs > 0
                                    && (info.presentationTimeUs - currentHlSegmentStartUs) >= HIGHLIGHT_SEGMENT_DURATION_MS * 1000L
                                    && isKeyFrame) {
                                    openNextHighlightSegmentLocked(info.presentationTimeUs);
                                } else if (!hlMuxerStarted && isKeyFrame) {
                                    openNextHighlightSegmentLocked(info.presentationTimeUs);
                                }
                                if (hlMuxerStarted && highlightMuxer != null && hlVideoTrack >= 0) {
                                    outBuf.position(info.offset);
                                    outBuf.limit(info.offset + info.size);
                                    highlightMuxer.writeSampleData(hlVideoTrack, outBuf, info);
                                }
                            }

                            if (isRecordingTimed.get() && timedMuxer != null) {
                                if (!timedMuxerStarted && isKeyFrame && latestVideoFormat != null) {
                                    timedVideoTrack = timedMuxer.addTrack(latestVideoFormat);
                                    timedAudioTrack = latestAudioFormat != null ? timedMuxer.addTrack(latestAudioFormat) : -1;
                                    timedMuxer.start();
                                    timedMuxerStarted = true;
                                    timedWaitingForKeyframe = false;
                                }
                                if (timedMuxerStarted && !timedWaitingForKeyframe && timedVideoTrack >= 0) {
                                    outBuf.position(info.offset);
                                    outBuf.limit(info.offset + info.size);
                                    timedMuxer.writeSampleData(timedVideoTrack, outBuf, info);
                                }
                            }

                            if (isRecordingFull.get() && fullMuxer != null) {
                                if (!fullMuxerStarted && isKeyFrame && latestVideoFormat != null) {
                                    fullVideoTrack = fullMuxer.addTrack(latestVideoFormat);
                                    fullAudioTrack = latestAudioFormat != null ? fullMuxer.addTrack(latestAudioFormat) : -1;
                                    fullMuxer.start();
                                    fullMuxerStarted = true;
                                    fullWaitingForKeyframe = false;
                                }
                                if (fullMuxerStarted && !fullWaitingForKeyframe && fullVideoTrack >= 0) {
                                    outBuf.position(info.offset);
                                    outBuf.limit(info.offset + info.size);
                                    fullMuxer.writeSampleData(fullVideoTrack, outBuf, info);
                                }
                            }
                        }
                    }
                    videoEncoder.releaseOutputBuffer(outIndex, false);
                }
            } catch (Exception e) {
                if (!isCapturing.get()) break;
            }
        }
    }

    private void runAudioCaptureLoop() {
        final int frameBytes = 4096;
        byte[] gamePcm = new byte[frameBytes];
        byte[] micPcm = new byte[frameBytes];
        byte[] mixedPcm = new byte[frameBytes];
        MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
        long startNano = System.nanoTime();

        while (isCapturing.get() && audioLoopRunning.get() && audioEncoder != null) {
            try {
                int readGame = (gameAudioRecord != null) ? gameAudioRecord.read(gamePcm, 0, frameBytes) : 0;
                int readMic = (micAudioRecord != null) ? micAudioRecord.read(micPcm, 0, frameBytes) : 0;
                int bytesToEncode = Math.max(readGame, readMic);

                if (bytesToEncode > 0) {
                    byte[] payload;
                    if (readGame > 0 && readMic > 0) {
                        // Mix 16-bit PCM game audio + microphone voice cleanly
                        int minLen = Math.min(readGame, readMic);
                        for (int i = 0; i + 1 < bytesToEncode; i += 2) {
                            int g = (i < minLen || i + 1 < readGame)
                                ? (short) ((gamePcm[i] & 0xff) | (gamePcm[i + 1] << 8))
                                : 0;
                            int m = (i + 1 < readMic)
                                ? (short) ((micPcm[i] & 0xff) | (micPcm[i + 1] << 8))
                                : 0;
                            int sum = Math.max(-32768, Math.min(32767, g + m));
                            mixedPcm[i] = (byte) (sum & 0xff);
                            mixedPcm[i + 1] = (byte) ((sum >> 8) & 0xff);
                        }
                        payload = mixedPcm;
                    } else if (readGame > 0) {
                        payload = gamePcm;
                    } else {
                        payload = micPcm;
                    }

                    // Measure gunfire / knock / kill sound impact peak for Auto Highlight (15s)
                    if (autoHighlightEnabled) {
                        int peak = 0;
                        for (int i = 0; i + 1 < bytesToEncode; i += 8) {
                            int sample = Math.abs((short) ((payload[i] & 0xff) | (payload[i + 1] << 8)));
                            if (sample > peak) peak = sample;
                        }
                        if (peak > 22000) {
                            lastAudioCombatPeakMs = System.currentTimeMillis();
                        }
                    }

                    int inIndex = audioEncoder.dequeueInputBuffer(5000);
                    if (inIndex >= 0) {
                        ByteBuffer inBuf = audioEncoder.getInputBuffer(inIndex);
                        if (inBuf != null) {
                            inBuf.clear();
                            int count = Math.min(bytesToEncode, inBuf.capacity());
                            inBuf.put(payload, 0, count);
                            long ptsUs = (System.nanoTime() - startNano) / 1000L;
                            audioEncoder.queueInputBuffer(inIndex, 0, count, ptsUs, 0);
                        }
                    }
                }

                int outIndex = audioEncoder.dequeueOutputBuffer(info, 0);
                while (outIndex >= 0 || outIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    if (outIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                        synchronized (muxerLock) {
                            latestAudioFormat = audioEncoder.getOutputFormat();
                        }
                    } else if (outIndex >= 0) {
                        ByteBuffer outBuf = audioEncoder.getOutputBuffer(outIndex);
                        if (outBuf != null && (info.flags & MediaCodec.BUFFER_FLAG_CODEC_CONFIG) == 0 && info.size > 0) {
                            synchronized (muxerLock) {
                                if (autoHighlightEnabled && hlMuxerStarted && highlightMuxer != null && hlAudioTrack >= 0) {
                                    outBuf.position(info.offset);
                                    outBuf.limit(info.offset + info.size);
                                    highlightMuxer.writeSampleData(hlAudioTrack, outBuf, info);
                                }
                                if (isRecordingTimed.get() && timedMuxerStarted && timedMuxer != null && timedAudioTrack >= 0) {
                                    outBuf.position(info.offset);
                                    outBuf.limit(info.offset + info.size);
                                    timedMuxer.writeSampleData(timedAudioTrack, outBuf, info);
                                }
                                if (isRecordingFull.get() && fullMuxerStarted && fullMuxer != null && fullAudioTrack >= 0) {
                                    outBuf.position(info.offset);
                                    outBuf.limit(info.offset + info.size);
                                    fullMuxer.writeSampleData(fullAudioTrack, outBuf, info);
                                }
                            }
                        }
                        audioEncoder.releaseOutputBuffer(outIndex, false);
                    }
                    outIndex = audioEncoder.dequeueOutputBuffer(info, 0);
                }
            } catch (Exception e) {
                if (!audioLoopRunning.get() || !isCapturing.get()) break;
            }
        }
    }

    @Nullable
    private Uri saveMp4ToMoviesGallery(File sourceFile, String displayName) throws IOException {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            ContentResolver resolver = getContentResolver();
            ContentValues values = new ContentValues();
            values.put(MediaStore.Video.Media.DISPLAY_NAME, displayName);
            values.put(MediaStore.Video.Media.MIME_TYPE, "video/mp4");
            values.put(
                MediaStore.Video.Media.RELATIVE_PATH,
                Environment.DIRECTORY_MOVIES + "/ClipKaro"
            );
            values.put(MediaStore.Video.Media.IS_PENDING, 1);

            Uri uri = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values);
            if (uri == null) {
                throw new IOException("MediaStore insert failed");
            }

            try (OutputStream out = resolver.openOutputStream(uri);
                 FileInputStream in = new FileInputStream(sourceFile)) {
                if (out == null) throw new IOException("Output stream unavailable");
                byte[] buf = new byte[16384];
                int n;
                while ((n = in.read(buf)) != -1) {
                    out.write(buf, 0, n);
                }
            }

            values.clear();
            values.put(MediaStore.Video.Media.IS_PENDING, 0);
            resolver.update(uri, values, null, null);
            return uri;
        } else {
            File moviesDir = new File(
                Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES),
                "ClipKaro"
            );
            if (!moviesDir.exists()) {
                //noinspection ResultOfMethodCallIgnored
                moviesDir.mkdirs();
            }
            File dest = new File(moviesDir, displayName);
            try (FileInputStream in = new FileInputStream(sourceFile);
                 OutputStream out = new java.io.FileOutputStream(dest)) {
                byte[] buf = new byte[16384];
                int n;
                while ((n = in.read(buf)) != -1) {
                    out.write(buf, 0, n);
                }
            }
            MediaScannerConnection.scanFile(
                this,
                new String[]{dest.getAbsolutePath()},
                new String[]{"video/mp4"},
                null
            );
            return Uri.fromFile(dest);
        }
    }

    private void stopCapturePipeline() {
        stopActiveRecordingOnly();
        isCapturing.set(false);
        stopAudioPipelineOnly();
        synchronized (muxerLock) {
            closeCurrentHighlightSegmentLocked(false);
            for (File seg : completedHighlightSegments) {
                //noinspection ResultOfMethodCallIgnored
                seg.delete();
            }
            completedHighlightSegments.clear();
        }

        if (virtualDisplay != null) {
            virtualDisplay.release();
            virtualDisplay = null;
        }
        if (encoderSurface != null) {
            encoderSurface.release();
            encoderSurface = null;
        }
        if (videoEncoder != null) {
            try {
                videoEncoder.stop();
            } catch (Exception ignored) {
            }
            try {
                videoEncoder.release();
            } catch (Exception ignored) {
            }
            videoEncoder = null;
        }
        if (mediaProjection != null) {
            mediaProjection.stop();
            mediaProjection = null;
        }
    }

    private void stopEverythingAndSelf() {
        mainHandler.removeCallbacks(uiTickerRunnable);
        hideFloatingMenu();
        if (bubbleView != null && windowManager != null) {
            try {
                windowManager.removeView(bubbleView);
            } catch (IllegalArgumentException ignored) {
            }
            bubbleView = null;
        }
        stopCapturePipeline();
        stopForeground(STOP_FOREGROUND_REMOVE);
        stopSelf();
    }

    private void showToast(String message) {
        mainHandler.post(() -> Toast.makeText(getApplicationContext(), message, Toast.LENGTH_SHORT).show());
    }

    @Override
    public void onDestroy() {
        mainHandler.removeCallbacks(uiTickerRunnable);
        hideFloatingMenu();
        if (bubbleView != null && windowManager != null) {
            try {
                windowManager.removeView(bubbleView);
            } catch (IllegalArgumentException ignored) {
            }
            bubbleView = null;
        }
        stopCapturePipeline();
        exportExecutor.shutdownNow();
        super.onDestroy();
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}

package com.clipkaro.app;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.app.usage.UsageEvents;
import android.app.usage.UsageStatsManager;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ServiceInfo;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioPlaybackCaptureConfiguration;
import android.media.AudioRecord;
import android.media.MediaCodec;
import android.media.MediaCodecInfo;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.media.MediaMuxer;
import android.media.MediaRecorder;
import android.media.MediaScannerConnection;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.provider.MediaStore;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.HapticFeedbackConstants;
import android.view.MotionEvent;
import android.view.Surface;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;
import androidx.core.content.ContextCompat;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

public class FloatingClipService extends Service {

    public static final String ACTION_START = "com.clipkaro.app.action.START_FLOATING";
    public static final String ACTION_PREPARE_PROJECTION = "com.clipkaro.app.action.PREPARE_PROJECTION";
    public static final String ACTION_HIDE_BUBBLE = "com.clipkaro.app.action.HIDE_BUBBLE";
    public static final String ACTION_CLIPKARO_RESUMED = "com.clipkaro.app.action.CLIPKARO_RESUMED";
    public static final String ACTION_CLIPKARO_BACKGROUND = "com.clipkaro.app.action.CLIPKARO_BACKGROUND";
    public static final String ACTION_STOP = "com.clipkaro.app.action.STOP_FLOATING";
    public static final String ACTION_QUICK_CLIP_10 = "com.clipkaro.app.action.QUICK_CLIP_10";
    public static final String ACTION_QUICK_CLIP_30 = "com.clipkaro.app.action.QUICK_CLIP_30";
    public static final String ACTION_TOGGLE_FULL = "com.clipkaro.app.action.TOGGLE_FULL";
    public static final String ACTION_STOP_RECORDING = "com.clipkaro.app.action.STOP_RECORDING";
    public static final String ACTION_PAUSE_RECORDING = "com.clipkaro.app.action.PAUSE_RECORDING";
    public static final String ACTION_RESUME_RECORDING = "com.clipkaro.app.action.RESUME_RECORDING";
    public static final String ACTION_NATIVE_CLIP_SAVED = "com.clipkaro.app.NATIVE_CLIP_SAVED";

    public static final String EXTRA_RESULT_CODE = "result_code";
    public static final String EXTRA_RESULT_DATA = "result_data";
    public static final String EXTRA_GAME_NAME = "game_name";
    public static final String EXTRA_TARGET_PACKAGE = "target_package";
    public static final String EXTRA_PENDING_DURATION = "pending_duration";
    public static final String EXTRA_PENDING_FULL = "pending_full";
    public static final String EXTRA_SAVED_FILE_NAME = "saved_file_name";
    public static final String EXTRA_SAVED_URI = "saved_uri";

    // Process-lifetime MediaProjection cache (asked once in Welcome screen, cleared only on phone restart or revoke)
    public static int cachedProjectionResultCode = Activity.RESULT_CANCELED;
    public static Intent cachedProjectionResultData = null;
    public static MediaProjection cachedMediaProjection = null;

    public static boolean hasCachedProjection() {
        return cachedMediaProjection != null
            || (cachedProjectionResultCode == Activity.RESULT_OK && cachedProjectionResultData != null);
    }

    public static void cacheProjectionToken(int resultCode, @Nullable Intent data) {
        if (resultCode == Activity.RESULT_OK && data != null) {
            cachedProjectionResultCode = resultCode;
            cachedProjectionResultData = (Intent) data.clone();
        }
    }

    public static final String AUDIO_MODE_GAME = "game";
    public static final String AUDIO_MODE_MIC = "mic";
    public static final String AUDIO_MODE_BOTH = "both";

    private static final String PREFS_NAME = "clipkaro_prefs";
    private static final String KEY_AUDIO_MODE = "floating_audio_mode";
    private static final String KEY_AUTO_CONTINUOUS = "floating_auto_continuous";
    private static final String KEY_AUTO_HIGHLIGHT = "floating_auto_highlight";

    private static final String CHANNEL_ID = "clipkaro_floating_channel";
    private static final String ALERT_CHANNEL_ID = "clipkaro_status_alerts";
    private static final int NOTIFICATION_ID = 7001;
    private static final int STATUS_NOTIFICATION_ID = 7002;

    private static final int HIGHLIGHT_SEGMENT_DURATION_MS = 5000;
    private static final int MAX_HIGHLIGHT_SEGMENTS = 4;
    private static final long HIGHLIGHT_COOLDOWN_MS = 18_000L;
    private static final int VIDEO_BITRATE = 4_000_000;
    private static final int VIDEO_FPS = 30;
    private static final int AUDIO_SAMPLE_RATE = 44100;
    private static final int AUDIO_BITRATE = 128_000;

    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final ExecutorService exportExecutor = Executors.newSingleThreadExecutor();
    private final Object muxerLock = new Object();

    private WindowManager windowManager;
    private FrameLayout bubbleView;
    private LinearLayout bubbleIdleBox;
    private LinearLayout bubbleRecordingBox;
    private View bubbleRedDot;
    private TextView bubbleTimerTv;

    private FrameLayout menuView;
    private LinearLayout idleMenuContainer;
    private LinearLayout recordingMenuContainer;
    private WindowManager.LayoutParams bubbleParams;
    private WindowManager.LayoutParams menuParams;
    private boolean isMenuVisible = false;

    // 500ms Long-press popup menu (Hide Button / Stop Recording + Hide / Stop)
    private LinearLayout longPressMenuView;
    private WindowManager.LayoutParams longPressMenuParams;
    private boolean isLongPressMenuVisible = false;

    // Target foreground app monitoring (> 3 seconds auto-hide / auto-stop)
    private String targetPackageName = "";
    private boolean bubbleSuppressed = true;
    private long targetLaunchGraceUntilMs = 0L;
    private long outOfTargetSinceMs = 0L;
    private String lastKnownForegroundPackage = null;

    private TextView recMenuTimerTv;
    private View recMenuRedDot;
    private TextView recMenuSubTv;
    private Button pauseRecBtn;
    private Button resumeRecBtn;
    private Button stopRecBigBtn;
    private Button idleStopBtn;
    private Button audioCycleBtn;
    private Button autoContinuousBtn;
    private Button autoHighlightBtn;

    // Top 2-second notification popup overlay
    private LinearLayout topBannerView;
    private View topBannerDot;
    private TextView topBannerTitleTv;
    private TextView topBannerSubTv;
    private final Runnable hideTopBannerRunnable = this::hideTopNotificationPopup;

    private String activeGameName = "BGMI";
    private String selectedAudioMode = AUDIO_MODE_BOTH;
    private boolean autoContinuousEnabled = true;
    private boolean autoHighlightEnabled = true;

    private int projectionResultCode = Activity.RESULT_CANCELED;
    private Intent projectionResultData = null;

    // MediaProjection & Encoding State
    private MediaProjection mediaProjection;
    private VirtualDisplay virtualDisplay;
    private Surface encoderSurface;
    private MediaCodec videoEncoder;
    private MediaCodec audioEncoder;
    private AudioRecord gameAudioRecord;
    private AudioRecord micAudioRecord;

    private final AtomicBoolean isCapturing = new AtomicBoolean(false);
    private final AtomicBoolean isRecordingTimed = new AtomicBoolean(false);
    private final AtomicBoolean isRecordingFull = new AtomicBoolean(false);
    private final AtomicBoolean isRecordingPaused = new AtomicBoolean(false);
    private final AtomicBoolean audioLoopRunning = new AtomicBoolean(false);

    private Thread videoThread;
    private Thread audioThread;

    private MediaFormat latestVideoFormat;
    private MediaFormat latestAudioFormat;

    // Pause timing & monotonic PTS tracking for Pause/Resume
    private long pauseStartedMs = 0L;
    private long totalPausedMs = 0L;
    private long lastRawVideoPtsUs = 0L;
    private long pausedVideoPtsOffsetUs = 0L;
    private boolean videoJustResumed = false;
    private long lastRawAudioPtsUs = 0L;
    private long pausedAudioPtsOffsetUs = 0L;
    private boolean audioJustResumed = false;

    // Active Timed Clip Recording (Continuous until STOP)
    private File timedTempFile;
    private MediaMuxer timedMuxer;
    private int timedVideoTrack = -1;
    private int timedAudioTrack = -1;
    private boolean timedMuxerStarted = false;
    private boolean timedWaitingForKeyframe = false;
    private int activeTimedDurationSec = 10;
    private int currentClipSequence = 1;
    private long timedStartMs = 0L;

    // Active Full Gameplay Continuous Recording
    private File fullTempFile;
    private MediaMuxer fullMuxer;
    private int fullVideoTrack = -1;
    private int fullAudioTrack = -1;
    private boolean fullMuxerStarted = false;
    private boolean fullWaitingForKeyframe = false;
    private long fullStartMs = 0L;

    // Auto Highlight Rolling 15s Ring + Kill / Headshot / Knock Spike State
    private File highlightBufferDir;
    private final List<File> completedHighlightSegments = new ArrayList<>();
    private File currentHighlightSegmentFile;
    private MediaMuxer highlightMuxer;
    private int hlVideoTrack = -1;
    private int hlAudioTrack = -1;
    private boolean hlMuxerStarted = false;
    private long currentHlSegmentStartUs = -1L;
    private int hlSegmentIndex = 0;
    private long captureStartedAtMs = 0L;
    private long lastAudioCombatPeakMs = 0L;
    private long lastAutoHighlightSavedMs = 0L;
    private double avgPFrameBytes = 14000.0;
    private int highlightSequence = 1;

    private int pendingDurationAfterProjection = 0;
    private boolean pendingFullAfterProjection = false;

    private long getCurrentActiveElapsedSec() {
        long now = isRecordingPaused.get() ? pauseStartedMs : System.currentTimeMillis();
        if (isRecordingTimed.get()) {
            return Math.max(0L, (now - timedStartMs - totalPausedMs) / 1000L);
        }
        if (isRecordingFull.get()) {
            return Math.max(0L, (now - fullStartMs - totalPausedMs) / 1000L);
        }
        return 0L;
    }

    private final Runnable uiTickerRunnable = new Runnable() {
        private boolean dotBright = true;

        @Override
        public void run() {
            if (!isRecordingTimed.get() && !isRecordingFull.get()) {
                updateBubbleVisuals(false, 0L, false);
                return;
            }

            if (isRecordingPaused.get()) {
                long pausedSec = getCurrentActiveElapsedSec();
                updateBubbleVisuals(true, pausedSec, true);
                updateExpandedRecordingTimer(pausedSec, true);
                updateNotificationOnly();
                mainHandler.postDelayed(this, 500);
                return;
            }

            long elapsedSec = getCurrentActiveElapsedSec();
            if (isRecordingTimed.get() && elapsedSec >= activeTimedDurationSec) {
                onTimedClipDurationReached();
                elapsedSec = 0L;
            }

            dotBright = !dotBright;
            updateBubbleVisuals(true, elapsedSec, dotBright);
            updateExpandedRecordingTimer(elapsedSec, dotBright);
            updateNotificationOnly();
            if (isMenuVisible) {
                updateMenuStatusText();
            }
            mainHandler.postDelayed(this, 500);
        }
    };

    private final Runnable foregroundMonitorRunnable = new Runnable() {
        @Override
        public void run() {
            if (bubbleSuppressed || bubbleView == null) {
                return;
            }
            checkTargetForegroundState();
            if (!bubbleSuppressed && bubbleView != null) {
                mainHandler.postDelayed(this, 1000L);
            }
        }
    };

    @Override
    public void onCreate() {
        super.onCreate();
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        selectedAudioMode = prefs.getString(KEY_AUDIO_MODE, AUDIO_MODE_BOTH);
        autoContinuousEnabled = prefs.getBoolean(KEY_AUTO_CONTINUOUS, true);
        autoHighlightEnabled = prefs.getBoolean(KEY_AUTO_HIGHLIGHT, true);
        highlightBufferDir = new File(getCacheDir(), "clipkaro_hl_buffer");
        if (!highlightBufferDir.exists()) {
            //noinspection ResultOfMethodCallIgnored
            highlightBufferDir.mkdirs();
        }
        createNotificationChannel();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent != null ? intent.getAction() : ACTION_START;

        if (ACTION_STOP.equals(action)) {
            stopEverythingAndSelf();
            return START_NOT_STICKY;
        }

        if (ACTION_HIDE_BUBBLE.equals(action)) {
            hideFloatingBubbleOnly();
            return START_STICKY;
        }

        if (ACTION_CLIPKARO_BACKGROUND.equals(action)) {
            if (!bubbleSuppressed && targetPackageName != null && !targetPackageName.isEmpty()) {
                lastKnownForegroundPackage = targetPackageName;
                outOfTargetSinceMs = 0L;
                targetLaunchGraceUntilMs = System.currentTimeMillis() + 3000L;
            }
            return START_STICKY;
        }

        if (ACTION_CLIPKARO_RESUMED.equals(action)) {
            lastKnownForegroundPackage = getPackageName();
            return START_STICKY;
        }

        if (intent != null) {
            String game = intent.getStringExtra(EXTRA_GAME_NAME);
            if (game != null && !game.trim().isEmpty()) {
                activeGameName = game.trim();
            }
            String pkg = intent.getStringExtra(EXTRA_TARGET_PACKAGE);
            if (pkg != null && !pkg.trim().isEmpty()) {
                targetPackageName = pkg.trim();
            }
            if (intent.hasExtra(EXTRA_RESULT_CODE) && intent.hasExtra(EXTRA_RESULT_DATA)) {
                int code = intent.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED);
                Intent data = getParcelableIntentExtra(intent, EXTRA_RESULT_DATA);
                if (code == Activity.RESULT_OK && data != null) {
                    projectionResultCode = code;
                    projectionResultData = data;
                    cacheProjectionToken(code, data);
                }
            }
            if (intent.hasExtra(EXTRA_PENDING_DURATION)) {
                pendingDurationAfterProjection = intent.getIntExtra(EXTRA_PENDING_DURATION, 0);
            }
            if (intent.hasExtra(EXTRA_PENDING_FULL)) {
                pendingFullAfterProjection = intent.getBooleanExtra(EXTRA_PENDING_FULL, false);
            }
        }

        if (projectionResultData == null && cachedProjectionResultData != null) {
            projectionResultCode = cachedProjectionResultCode;
            projectionResultData = cachedProjectionResultData;
        }

        boolean hasProj = hasCachedProjection() || projectionResultData != null;
        startForegroundWithType(hasProj);

        // One-time MediaProjection warmup from Welcome Permission Screen (do NOT show bubble over ClipKaro itself)
        if (ACTION_PREPARE_PROJECTION.equals(action)) {
            bubbleSuppressed = true;
            hideFloatingBubbleOnly();
            ensureMediaProjectionInitialized();
            updateNotificationOnly();
            return START_STICKY;
        }

        // Only show floating bubble when a target app is explicitly opened from ClipKaro
        if (ACTION_START.equals(action)) {
            if (targetPackageName == null || targetPackageName.isEmpty()) {
                bubbleSuppressed = true;
                hideFloatingBubbleOnly();
                updateNotificationOnly();
                return START_STICKY;
            }
            bubbleSuppressed = false;
            outOfTargetSinceMs = 0L;
            lastKnownForegroundPackage = targetPackageName;
            targetLaunchGraceUntilMs = System.currentTimeMillis() + 3500L;
            ensureOverlayBubbleShown();
            startForegroundMonitor();
        } else if (!bubbleSuppressed) {
            ensureOverlayBubbleShown();
            startForegroundMonitor();
        }

        if (hasProj && !isCapturing.get() && !bubbleSuppressed) {
            startCapturePipeline();
        }

        if (ACTION_QUICK_CLIP_10.equals(action)) {
            onClipDurationTapped(10);
        } else if (ACTION_QUICK_CLIP_30.equals(action)) {
            onClipDurationTapped(30);
        } else if (ACTION_TOGGLE_FULL.equals(action)) {
            onToggleFullGameplay();
        } else if (ACTION_PAUSE_RECORDING.equals(action)) {
            pauseActiveRecording();
        } else if (ACTION_RESUME_RECORDING.equals(action)) {
            resumeActiveRecording();
        } else if (ACTION_STOP_RECORDING.equals(action)) {
            stopActiveRecordingOnly();
        } else if (pendingFullAfterProjection && isCapturing.get()) {
            pendingFullAfterProjection = false;
            pendingDurationAfterProjection = 0;
            startFullGameplayRecording();
        } else if (pendingDurationAfterProjection > 0 && isCapturing.get()) {
            int dur = pendingDurationAfterProjection;
            pendingDurationAfterProjection = 0;
            startTimedClipRecording(dur, true);
        }

        updateMenuStatusText();
        return START_STICKY;
    }

    @SuppressWarnings("deprecation")
    private Intent getParcelableIntentExtra(Intent source, String key) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            return source.getParcelableExtra(key, Intent.class);
        }
        return source.getParcelableExtra(key);
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm == null) return;

            NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID,
                "ClipKaro Floating CLIP",
                NotificationManager.IMPORTANCE_LOW
            );
            channel.setDescription("Floating CLIP controls & notification recording options");
            nm.createNotificationChannel(channel);

            NotificationChannel alertChannel = new NotificationChannel(
                ALERT_CHANNEL_ID,
                "ClipKaro Recording Alerts",
                NotificationManager.IMPORTANCE_HIGH
            );
            alertChannel.setDescription("Alerts when clipping starts, pauses, resumes, or saves");
            nm.createNotificationChannel(alertChannel);
        }
    }

    private Notification buildServiceNotification() {
        Intent openIntent = new Intent(this, MainActivity.class);
        openIntent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
        int piFlags = PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE;
        PendingIntent contentIntent = PendingIntent.getActivity(this, 0, openIntent, piFlags);

        PendingIntent stopServicePending = PendingIntent.getService(
            this, 1, new Intent(this, FloatingClipService.class).setAction(ACTION_STOP), piFlags
        );
        PendingIntent clip10Pending = PendingIntent.getService(
            this, 2, new Intent(this, FloatingClipService.class).setAction(ACTION_QUICK_CLIP_10), piFlags
        );
        PendingIntent clip30Pending = PendingIntent.getService(
            this, 3, new Intent(this, FloatingClipService.class).setAction(ACTION_QUICK_CLIP_30), piFlags
        );
        PendingIntent fullPending = PendingIntent.getService(
            this, 4, new Intent(this, FloatingClipService.class).setAction(ACTION_TOGGLE_FULL), piFlags
        );
        PendingIntent stopRecPending = PendingIntent.getService(
            this, 5, new Intent(this, FloatingClipService.class).setAction(ACTION_STOP_RECORDING), piFlags
        );
        PendingIntent pausePending = PendingIntent.getService(
            this, 6, new Intent(this, FloatingClipService.class).setAction(ACTION_PAUSE_RECORDING), piFlags
        );
        PendingIntent resumePending = PendingIntent.getService(
            this, 7, new Intent(this, FloatingClipService.class).setAction(ACTION_RESUME_RECORDING), piFlags
        );

        boolean recordingNow = isRecordingTimed.get() || isRecordingFull.get();
        boolean pausedNow = isRecordingPaused.get();
        String title;
        String subtitle;
        if (isRecordingTimed.get()) {
            long sec = getCurrentActiveElapsedSec();
            title = pausedNow
                ? String.format(Locale.US, "Recording Paused (%02d:%02d · %d sec Clip)", sec / 60, sec % 60, activeTimedDurationSec)
                : String.format(Locale.US, "Clipping Started - %d sec Clip · %02d:%02d", activeTimedDurationSec, sec / 60, sec % 60);
            subtitle = "● " + activeTimedDurationSec + " sec Clip · Tap CLIP button to Stop (Clip #" + currentClipSequence + ")";
        } else if (isRecordingFull.get()) {
            long sec = getCurrentActiveElapsedSec();
            title = pausedNow
                ? String.format(Locale.US, "Recording Paused (%02d:%02d · Full Video)", sec / 60, sec % 60)
                : String.format(Locale.US, "Clipping Started - Full Video · %02d:%02d", sec / 60, sec % 60);
            subtitle = "● Full Video · Tap CLIP button to Stop";
        } else {
            title = "ClipKaro Floating CLIP Ready";
            subtitle = activeGameName + " · Audio: " + getAudioModeLabel() + " · Record from Notification or Bubble";
        }

        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(title)
            .setContentText(subtitle)
            .setSmallIcon(R.drawable.ic_clip_scissors)
            .setContentIntent(contentIntent)
            .setOnlyAlertOnce(true)
            .setOngoing(true);

        if (recordingNow) {
            if (pausedNow) {
                builder.addAction(0, "Resume", resumePending);
            } else {
                builder.addAction(0, "Pause", pausePending);
            }
            builder.addAction(0, "Stop", stopRecPending);
            builder.addAction(0, "Close", stopServicePending);
        } else {
            builder.addAction(0, "10s Clip", clip10Pending);
            builder.addAction(0, "30s Clip", clip30Pending);
            builder.addAction(0, "Full Record", fullPending);
        }

        return builder.build();
    }

    private void updateNotificationOnly() {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (nm != null) {
            nm.notify(NOTIFICATION_ID, buildServiceNotification());
        }
    }

    private void postStatusNotification(String title, String body, boolean withRedDot, boolean showTopPopup) {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (nm != null) {
            Intent openIntent = new Intent(this, MainActivity.class);
            openIntent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
            PendingIntent pi = PendingIntent.getActivity(
                this, 20, openIntent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
            );
            NotificationCompat.Builder b = new NotificationCompat.Builder(this, ALERT_CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_clip_scissors)
                .setContentTitle(title)
                .setContentText(body)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setAutoCancel(true)
                .setContentIntent(pi);
            nm.notify(STATUS_NOTIFICATION_ID, b.build());
        }
        updateNotificationOnly();
        if (showTopPopup) {
            showTopNotificationPopup(title, body, withRedDot);
        }
        showToast(title);
    }

    private void showTopNotificationPopup(String title, String subtitle, boolean showRedDot) {
        mainHandler.post(() -> {
            if (windowManager == null) return;
            hideTopNotificationPopup();

            int overlayType = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;

            WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                overlayType,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                    | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                    | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT
            );
            lp.gravity = Gravity.TOP | Gravity.CENTER_HORIZONTAL;
            lp.y = dp(26);

            topBannerView = new LinearLayout(this);
            topBannerView.setOrientation(LinearLayout.HORIZONTAL);
            topBannerView.setGravity(Gravity.CENTER_VERTICAL);
            topBannerView.setPadding(dp(12), dp(8), dp(14), dp(8));

            GradientDrawable bg = new GradientDrawable();
            bg.setColor(Color.parseColor("#E60B0E14"));
            bg.setCornerRadius(dp(20));
            bg.setStroke(dp(1), Color.parseColor(showRedDot ? "#EF4444" : "#34D399"));
            topBannerView.setBackground(bg);
            topBannerView.setElevation(dp(12));

            topBannerDot = new View(this);
            GradientDrawable dBg = new GradientDrawable();
            dBg.setShape(GradientDrawable.OVAL);
            dBg.setColor(Color.parseColor(showRedDot ? "#FF1E2D" : "#22C55E"));
            topBannerDot.setBackground(dBg);
            LinearLayout.LayoutParams dLp = new LinearLayout.LayoutParams(dp(9), dp(9));
            dLp.rightMargin = dp(8);
            topBannerView.addView(topBannerDot, dLp);

            LinearLayout textCol = new LinearLayout(this);
            textCol.setOrientation(LinearLayout.VERTICAL);

            topBannerTitleTv = new TextView(this);
            topBannerTitleTv.setText(title);
            topBannerTitleTv.setTextColor(Color.WHITE);
            topBannerTitleTv.setTextSize(12);
            topBannerTitleTv.setTypeface(Typeface.DEFAULT_BOLD);
            textCol.addView(topBannerTitleTv);

            topBannerSubTv = new TextView(this);
            topBannerSubTv.setText(subtitle);
            topBannerSubTv.setTextColor(Color.parseColor("#CBD5E1"));
            topBannerSubTv.setTextSize(10);
            textCol.addView(topBannerSubTv);

            topBannerView.addView(textCol);

            try {
                windowManager.addView(topBannerView, lp);
                mainHandler.removeCallbacks(hideTopBannerRunnable);
                mainHandler.postDelayed(hideTopBannerRunnable, 2000L);
            } catch (Exception ignored) {
                topBannerView = null;
            }
        });
    }

    private void hideTopNotificationPopup() {
        mainHandler.removeCallbacks(hideTopBannerRunnable);
        if (topBannerView != null && windowManager != null) {
            try {
                windowManager.removeView(topBannerView);
            } catch (IllegalArgumentException ignored) {
            }
            topBannerView = null;
        }
    }

    private void startForegroundWithType(boolean hasMediaProjection) {
        Notification notification = buildServiceNotification();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            int fgsType;
            if (hasMediaProjection) {
                fgsType = ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION;
                if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
                    == PackageManager.PERMISSION_GRANTED) {
                    fgsType |= ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE;
                }
            } else {
                fgsType = ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE;
            }
            startForeground(NOTIFICATION_ID, notification, fgsType);
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q && hasMediaProjection) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            );
        } else {
            startForeground(NOTIFICATION_ID, notification);
        }
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    @SuppressLint("ClickableViewAccessibility")
    private void ensureOverlayBubbleShown() {
        if (bubbleView != null || windowManager == null) {
            return;
        }

        int overlayType = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
            ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            : WindowManager.LayoutParams.TYPE_PHONE;

        // SMALL MODE: 32dp small circle with 60% transparency (alpha = 0.40)
        int bubbleSize = dp(32);
        bubbleParams = new WindowManager.LayoutParams(
            bubbleSize,
            bubbleSize,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        );
        bubbleParams.gravity = Gravity.TOP | Gravity.START;
        bubbleParams.x = dp(14);
        bubbleParams.y = dp(160);

        bubbleView = new FrameLayout(this);
        bubbleView.setAlpha(0.40f); // 60% transparent
        applyBubbleBackground(false);
        bubbleView.setElevation(dp(6));

        // Idle UI inside 32dp circle: Scissors + CLIP micro label
        bubbleIdleBox = new LinearLayout(this);
        bubbleIdleBox.setOrientation(LinearLayout.VERTICAL);
        bubbleIdleBox.setGravity(Gravity.CENTER);

        ImageView scissorsIv = new ImageView(this);
        scissorsIv.setImageResource(R.drawable.ic_clip_scissors);
        LinearLayout.LayoutParams iconLp = new LinearLayout.LayoutParams(dp(13), dp(13));
        bubbleIdleBox.addView(scissorsIv, iconLp);

        TextView clipLabelTv = new TextView(this);
        clipLabelTv.setText("CLIP");
        clipLabelTv.setTextColor(Color.WHITE);
        clipLabelTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 6);
        clipLabelTv.setTypeface(Typeface.DEFAULT_BOLD);
        clipLabelTv.setIncludeFontPadding(false);
        clipLabelTv.setGravity(Gravity.CENTER);
        bubbleIdleBox.addView(clipLabelTv);

        FrameLayout.LayoutParams idleLp = new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT,
            FrameLayout.LayoutParams.WRAP_CONTENT
        );
        idleLp.gravity = Gravity.CENTER;
        bubbleView.addView(bubbleIdleBox, idleLp);

        // Recording state UI inside the 32dp circle: RED dot + timer (00:12)
        bubbleRecordingBox = new LinearLayout(this);
        bubbleRecordingBox.setOrientation(LinearLayout.VERTICAL);
        bubbleRecordingBox.setGravity(Gravity.CENTER);
        bubbleRecordingBox.setVisibility(View.GONE);

        bubbleRedDot = new View(this);
        GradientDrawable dotBg = new GradientDrawable();
        dotBg.setShape(GradientDrawable.OVAL);
        dotBg.setColor(Color.parseColor("#FF1E2D"));
        bubbleRedDot.setBackground(dotBg);
        LinearLayout.LayoutParams dotLp = new LinearLayout.LayoutParams(dp(6), dp(6));
        dotLp.bottomMargin = dp(1);
        bubbleRecordingBox.addView(bubbleRedDot, dotLp);

        bubbleTimerTv = new TextView(this);
        bubbleTimerTv.setTextColor(Color.WHITE);
        bubbleTimerTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 7);
        bubbleTimerTv.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        bubbleTimerTv.setIncludeFontPadding(false);
        bubbleTimerTv.setGravity(Gravity.CENTER);
        bubbleTimerTv.setText("00:00");
        bubbleRecordingBox.addView(bubbleTimerTv);

        FrameLayout.LayoutParams recLp = new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT,
            FrameLayout.LayoutParams.WRAP_CONTENT
        );
        recLp.gravity = Gravity.CENTER;
        bubbleView.addView(bubbleRecordingBox, recLp);

        bubbleView.setOnTouchListener(new View.OnTouchListener() {
            private int initialX;
            private int initialY;
            private float downRawX;
            private float downRawY;
            private boolean isDragging;
            private boolean longPressTriggered;
            private final Runnable longPressRunnable = () -> {
                if (!isDragging) {
                    longPressTriggered = true;
                    bubbleView.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
                    showLongPressPopupMenu();
                }
            };

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                DisplayMetrics dm = getResources().getDisplayMetrics();
                switch (event.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        initialX = bubbleParams.x;
                        initialY = bubbleParams.y;
                        downRawX = event.getRawX();
                        downRawY = event.getRawY();
                        isDragging = false;
                        longPressTriggered = false;
                        mainHandler.removeCallbacks(longPressRunnable);
                        mainHandler.postDelayed(longPressRunnable, 500L);
                        return true;

                    case MotionEvent.ACTION_MOVE:
                        float dx = event.getRawX() - downRawX;
                        float dy = event.getRawY() - downRawY;
                        if (Math.hypot(dx, dy) > dp(6)) {
                            isDragging = true;
                            mainHandler.removeCallbacks(longPressRunnable);
                        }
                        if (isDragging) {
                            int maxX = Math.max(0, dm.widthPixels - bubbleSize);
                            int maxY = Math.max(0, dm.heightPixels - bubbleSize);
                            bubbleParams.x = Math.max(0, Math.min(maxX, Math.round(initialX + dx)));
                            bubbleParams.y = Math.max(dp(20), Math.min(maxY, Math.round(initialY + dy)));
                            windowManager.updateViewLayout(bubbleView, bubbleParams);
                        }
                        return true;

                    case MotionEvent.ACTION_UP:
                        mainHandler.removeCallbacks(longPressRunnable);
                        if (!isDragging && !longPressTriggered) {
                            showFloatingMenu();
                        }
                        return true;

                    case MotionEvent.ACTION_CANCEL:
                        mainHandler.removeCallbacks(longPressRunnable);
                        return true;

                    default:
                        return false;
                }
            }
        });

        windowManager.addView(bubbleView, bubbleParams);
    }

    @SuppressLint("ClickableViewAccessibility")
    private void showLongPressPopupMenu() {
        if (windowManager == null || bubbleParams == null) return;
        hideLongPressPopupMenu();
        hideFloatingMenu();

        int overlayType = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
            ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            : WindowManager.LayoutParams.TYPE_PHONE;

        int menuW = dp(188);
        DisplayMetrics dm = getResources().getDisplayMetrics();
        longPressMenuParams = new WindowManager.LayoutParams(
            menuW,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                | WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH
                | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        );
        longPressMenuParams.gravity = Gravity.TOP | Gravity.START;
        int maxX = Math.max(dp(8), dm.widthPixels - menuW - dp(8));
        int desiredX = bubbleParams.x + dp(38);
        if (desiredX > maxX) {
            desiredX = Math.max(dp(8), bubbleParams.x - menuW - dp(6));
        }
        longPressMenuParams.x = Math.max(dp(8), Math.min(maxX, desiredX));
        longPressMenuParams.y = Math.max(dp(24), Math.min(dm.heightPixels - dp(160), bubbleParams.y));

        longPressMenuView = new LinearLayout(this);
        longPressMenuView.setOrientation(LinearLayout.VERTICAL);
        longPressMenuView.setPadding(dp(10), dp(10), dp(10), dp(10));
        longPressMenuView.setElevation(dp(16));

        GradientDrawable cardBg = new GradientDrawable();
        cardBg.setColor(Color.parseColor("#EE0B0E14"));
        cardBg.setCornerRadius(dp(14));
        cardBg.setStroke(dp(1), Color.parseColor("#475569"));
        longPressMenuView.setBackground(cardBg);

        longPressMenuView.setOnTouchListener((v, ev) -> {
            if (ev.getAction() == MotionEvent.ACTION_OUTSIDE) {
                hideLongPressPopupMenu();
                return true;
            }
            return false;
        });

        TextView header = new TextView(this);
        header.setText("CLIP Options");
        header.setTextColor(Color.parseColor("#94A3B8"));
        header.setTextSize(10);
        header.setTypeface(Typeface.DEFAULT_BOLD);
        header.setPadding(dp(4), 0, dp(4), dp(6));
        longPressMenuView.addView(header);

        Button hideBtn = createCircularGridButton("Hide Button", "#1E293B", "#F8FAFC");
        LinearLayout.LayoutParams hLp = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, dp(34)
        );
        hLp.bottomMargin = dp(6);
        hideBtn.setOnClickListener(v -> {
            hideLongPressPopupMenu();
            hideFloatingBubbleOnly();
            showToast("Floating CLIP hidden");
        });
        longPressMenuView.addView(hideBtn, hLp);

        Button stopAndHideBtn = createCircularGridButton("Stop Recording + Hide", "#B45309", "#FFFFFF");
        LinearLayout.LayoutParams shLp = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, dp(34)
        );
        shLp.bottomMargin = dp(6);
        stopAndHideBtn.setOnClickListener(v -> {
            hideLongPressPopupMenu();
            stopActiveRecordingOnly();
            hideFloatingBubbleOnly();
        });
        longPressMenuView.addView(stopAndHideBtn, shLp);

        Button stopServiceBtn = createCircularGridButton("Stop", "#DC2626", "#FFFFFF");
        LinearLayout.LayoutParams sLp = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, dp(34)
        );
        stopServiceBtn.setOnClickListener(v -> {
            hideLongPressPopupMenu();
            stopEverythingAndSelf();
        });
        longPressMenuView.addView(stopServiceBtn, sLp);

        try {
            windowManager.addView(longPressMenuView, longPressMenuParams);
            isLongPressMenuVisible = true;
        } catch (Exception ignored) {
            longPressMenuView = null;
            isLongPressMenuVisible = false;
        }
    }

    private void hideLongPressPopupMenu() {
        if (isLongPressMenuVisible && longPressMenuView != null && windowManager != null) {
            try {
                windowManager.removeView(longPressMenuView);
            } catch (IllegalArgumentException ignored) {
            }
            longPressMenuView = null;
            isLongPressMenuVisible = false;
        }
    }

    private void startForegroundMonitor() {
        mainHandler.removeCallbacks(foregroundMonitorRunnable);
        mainHandler.postDelayed(foregroundMonitorRunnable, 1200L);
    }

    private void stopForegroundMonitor() {
        mainHandler.removeCallbacks(foregroundMonitorRunnable);
        outOfTargetSinceMs = 0L;
    }

    private boolean isTransientSystemPackage(String pkg) {
        return "com.android.permissioncontroller".equals(pkg)
            || "com.google.android.permissioncontroller".equals(pkg)
            || "com.google.android.packageinstaller".equals(pkg);
    }

    private void checkTargetForegroundState() {
        if (bubbleSuppressed || targetPackageName == null || targetPackageName.isEmpty()) {
            return;
        }
        long now = System.currentTimeMillis();
        if (now < targetLaunchGraceUntilMs) {
            outOfTargetSinceMs = 0L;
            return;
        }

        // Update latest foreground package from UsageStatsManager when available
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP_MR1) {
            try {
                UsageStatsManager usm = (UsageStatsManager) getSystemService(Context.USAGE_STATS_SERVICE);
                if (usm != null) {
                    UsageEvents events = usm.queryEvents(now - 15_000L, now);
                    UsageEvents.Event ev = new UsageEvents.Event();
                    long latestTs = 0L;
                    String latestPkg = null;
                    while (events.hasNextEvent()) {
                        events.getNextEvent(ev);
                        int type = ev.getEventType();
                        boolean isResumed = (type == UsageEvents.Event.MOVE_TO_FOREGROUND)
                            || (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q
                                && type == UsageEvents.Event.ACTIVITY_RESUMED);
                        if (isResumed && ev.getTimeStamp() >= latestTs && ev.getPackageName() != null) {
                            latestTs = ev.getTimeStamp();
                            latestPkg = ev.getPackageName();
                        }
                    }
                    if (latestPkg != null) {
                        lastKnownForegroundPackage = latestPkg;
                    }
                }
            } catch (Exception ignored) {
            }
        }

        boolean clipKaroFront = MainActivity.isActivityInForeground;
        boolean notInTarget = clipKaroFront
            || (lastKnownForegroundPackage != null
                && !lastKnownForegroundPackage.equals(targetPackageName)
                && !isTransientSystemPackage(lastKnownForegroundPackage));

        if (notInTarget) {
            if (outOfTargetSinceMs == 0L) {
                outOfTargetSinceMs = now;
            } else if (now - outOfTargetSinceMs > 3000L) {
                boolean wasRecording = isRecordingTimed.get() || isRecordingFull.get();
                if (wasRecording) {
                    stopActiveRecordingOnlyWithMessage(
                        "Game closed, Clipping Saved",
                        activeGameName + " closed · Saved to Movies/ClipKaro & My Clips"
                    );
                }
                hideFloatingBubbleOnly();
            }
        } else {
            outOfTargetSinceMs = 0L;
        }
    }

    private void hideFloatingBubbleOnly() {
        bubbleSuppressed = true;
        stopForegroundMonitor();
        hideLongPressPopupMenu();
        hideFloatingMenu();
        if (bubbleView != null && windowManager != null) {
            try {
                windowManager.removeView(bubbleView);
            } catch (IllegalArgumentException ignored) {
            }
            bubbleView = null;
        }
        // Stop capture encoders while preserving cachedMediaProjection for instant reuse on next game open
        stopCapturePipelineKeepProjection();
        updateNotificationOnly();
    }

    private void applyBubbleBackground(boolean recording) {
        if (bubbleView == null) return;
        boolean pausedNow = recording && isRecordingPaused.get();
        GradientDrawable bg = new GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            recording
                ? new int[]{Color.parseColor("#1E293B"), Color.parseColor("#0F172A")}
                : new int[]{Color.parseColor("#F43F5E"), Color.parseColor("#BE123C")}
        );
        bg.setShape(GradientDrawable.OVAL);
        bg.setStroke(dp(1), Color.parseColor(pausedNow ? "#FACC15" : (recording ? "#FF1E2D" : "#FFFFFF")));
        bubbleView.setBackground(bg);
        bubbleView.setAlpha(0.40f); // Keep 60% transparent
    }

    private void updateBubbleVisuals(boolean recording, long elapsedSec, boolean dotBright) {
        if (bubbleView == null) return;
        applyBubbleBackground(recording);
        if (recording) {
            if (bubbleIdleBox != null) bubbleIdleBox.setVisibility(View.GONE);
            if (bubbleRecordingBox != null) bubbleRecordingBox.setVisibility(View.VISIBLE);
            if (bubbleRedDot != null) {
                GradientDrawable dBg = new GradientDrawable();
                dBg.setShape(GradientDrawable.OVAL);
                dBg.setColor(Color.parseColor(isRecordingPaused.get() ? "#FACC15" : "#FF1E2D"));
                bubbleRedDot.setBackground(dBg);
                bubbleRedDot.setAlpha(isRecordingPaused.get() ? 1.0f : (dotBright ? 1.0f : 0.30f));
            }
            if (bubbleTimerTv != null) {
                bubbleTimerTv.setText(String.format(Locale.US, "%02d:%02d", elapsedSec / 60, elapsedSec % 60));
            }
        } else {
            if (bubbleIdleBox != null) bubbleIdleBox.setVisibility(View.VISIBLE);
            if (bubbleRecordingBox != null) bubbleRecordingBox.setVisibility(View.GONE);
        }
    }

    private void updateExpandedRecordingTimer(long elapsedSec, boolean dotBright) {
        boolean pausedNow = isRecordingPaused.get();
        if (recMenuRedDot != null) {
            GradientDrawable dBg = new GradientDrawable();
            dBg.setShape(GradientDrawable.OVAL);
            dBg.setColor(Color.parseColor(pausedNow ? "#FACC15" : "#FF1E2D"));
            recMenuRedDot.setBackground(dBg);
            recMenuRedDot.setAlpha(pausedNow ? 1.0f : (dotBright ? 1.0f : 0.30f));
        }
        if (recMenuTimerTv != null) {
            recMenuTimerTv.setText(String.format(Locale.US, "%02d:%02d", elapsedSec / 60, elapsedSec % 60));
        }
        if (recMenuSubTv != null) {
            String base = isRecordingTimed.get()
                ? (activeTimedDurationSec + " sec · Clip #" + currentClipSequence)
                : (activeGameName + " · Full Video");
            recMenuSubTv.setText(pausedNow ? "PAUSED · " + base : base);
            recMenuSubTv.setTextColor(Color.parseColor(pausedNow ? "#FDE047" : "#CBD5E1"));
        }
        if (pauseRecBtn != null) {
            pauseRecBtn.setEnabled(!pausedNow);
            pauseRecBtn.setAlpha(pausedNow ? 0.45f : 1.0f);
        }
        if (resumeRecBtn != null) {
            resumeRecBtn.setEnabled(pausedNow);
            resumeRecBtn.setAlpha(pausedNow ? 1.0f : 0.45f);
        }
    }

    private void positionMenuNearBubble(int menuSizeDp) {
        if (menuParams == null || bubbleParams == null) return;
        DisplayMetrics dm = getResources().getDisplayMetrics();
        int menuPx = dp(menuSizeDp);
        menuParams.width = menuPx;
        menuParams.height = menuPx;

        // Expand around small bubble center and clamp cleanly inside screen
        int bubbleCenterX = bubbleParams.x + dp(16);
        int bubbleCenterY = bubbleParams.y + dp(16);
        int targetX = bubbleCenterX - (menuPx / 2);
        int targetY = bubbleCenterY - (menuPx / 2);

        int maxX = Math.max(dp(8), dm.widthPixels - menuPx - dp(8));
        int maxY = Math.max(dp(20), dm.heightPixels - menuPx - dp(16));
        menuParams.x = Math.max(dp(8), Math.min(maxX, targetX));
        menuParams.y = Math.max(dp(20), Math.min(maxY, targetY));
    }

    private void showFloatingMenu() {
        if (windowManager == null) return;
        if (menuView == null) {
            buildFloatingMenu();
        }
        boolean recordingAny = isRecordingTimed.get() || isRecordingFull.get();
        int targetSizeDp = recordingAny ? 210 : 232;
        if (idleMenuContainer != null) {
            idleMenuContainer.setVisibility(recordingAny ? View.GONE : View.VISIBLE);
        }
        if (recordingMenuContainer != null) {
            recordingMenuContainer.setVisibility(recordingAny ? View.VISIBLE : View.GONE);
        }
        applyMenuBackground(recordingAny);
        positionMenuNearBubble(targetSizeDp);
        if (recordingAny) {
            updateExpandedRecordingTimer(getCurrentActiveElapsedSec(), true);
        }
        updateMenuStatusText();

        if (bubbleView != null) {
            bubbleView.setVisibility(View.GONE);
        }
        if (!isMenuVisible) {
            windowManager.addView(menuView, menuParams);
            isMenuVisible = true;
        } else {
            windowManager.updateViewLayout(menuView, menuParams);
        }
    }

    private void hideFloatingMenu() {
        if (isMenuVisible && menuView != null && windowManager != null) {
            try {
                windowManager.removeView(menuView);
            } catch (IllegalArgumentException ignored) {
            }
            isMenuVisible = false;
        }
        if (bubbleView != null && !bubbleSuppressed) {
            bubbleView.setVisibility(View.VISIBLE);
        }
    }

    private void applyMenuBackground(boolean recordingMode) {
        if (menuView == null) return;
        GradientDrawable circleBg = new GradientDrawable();
        circleBg.setShape(GradientDrawable.OVAL);
        circleBg.setColor(Color.parseColor("#D90B0E14")); // Semi-transparent dark background
        circleBg.setStroke(dp(2), Color.parseColor(recordingMode ? "#EF4444" : "#475569"));
        menuView.setBackground(circleBg);
    }

    @SuppressLint("ClickableViewAccessibility")
    private void buildFloatingMenu() {
        int overlayType = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
            ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            : WindowManager.LayoutParams.TYPE_PHONE;

        menuParams = new WindowManager.LayoutParams(
            dp(232),
            dp(232),
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                | WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH
                | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        );
        menuParams.gravity = Gravity.TOP | Gravity.START;

        menuView = new FrameLayout(this);
        menuView.setElevation(dp(14));
        applyMenuBackground(false);

        // Auto-collapse back to small 32dp button when user taps outside expanded menu
        menuView.setOnTouchListener((v, event) -> {
            if (event.getAction() == MotionEvent.ACTION_OUTSIDE) {
                hideFloatingMenu();
                return true;
            }
            return false;
        });

        // 1) IDLE EXPANDED CIRCLE MENU (232dp semi-transparent dark circle)
        idleMenuContainer = new LinearLayout(this);
        idleMenuContainer.setOrientation(LinearLayout.VERTICAL);
        idleMenuContainer.setGravity(Gravity.CENTER_HORIZONTAL);
        idleMenuContainer.setPadding(dp(16), dp(14), dp(16), dp(12));

        // Top Row: CLIP title + CLOSE (X) button
        LinearLayout topRow = new LinearLayout(this);
        topRow.setOrientation(LinearLayout.HORIZONTAL);
        topRow.setGravity(Gravity.CENTER);
        topRow.setPadding(dp(20), 0, dp(20), dp(4));

        TextView titleTv = new TextView(this);
        titleTv.setText("CLIP");
        titleTv.setTextColor(Color.WHITE);
        titleTv.setTextSize(12);
        titleTv.setTypeface(Typeface.DEFAULT_BOLD);
        topRow.addView(titleTv, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

        Button closeXBtn = createCircleIconBtn("X", "#334155", "#F8FAFC", 24);
        closeXBtn.setOnClickListener(v -> hideFloatingMenu());
        topRow.addView(closeXBtn);
        idleMenuContainer.addView(topRow, new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ));

        // Compact Toggle Row: Audio Cycler + Auto Loop + Auto Highlight (keeps all features accessible)
        LinearLayout toggleRow = new LinearLayout(this);
        toggleRow.setOrientation(LinearLayout.HORIZONTAL);
        toggleRow.setGravity(Gravity.CENTER);
        toggleRow.setPadding(dp(14), 0, dp(14), dp(5));

        audioCycleBtn = createCompactToggleBtn("Game+Mic");
        autoContinuousBtn = createCompactToggleBtn("Loop:ON");
        autoHighlightBtn = createCompactToggleBtn("15sHL:ON");

        LinearLayout.LayoutParams tLp1 = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.2f);
        tLp1.rightMargin = dp(3);
        LinearLayout.LayoutParams tLp2 = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        tLp2.rightMargin = dp(3);
        LinearLayout.LayoutParams tLp3 = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);

        audioCycleBtn.setOnClickListener(v -> cycleAudioMode());
        autoContinuousBtn.setOnClickListener(v -> toggleAutoContinuous());
        autoHighlightBtn.setOnClickListener(v -> toggleAutoHighlight());

        toggleRow.addView(audioCycleBtn, tLp1);
        toggleRow.addView(autoContinuousBtn, tLp2);
        toggleRow.addView(autoHighlightBtn, tLp3);
        idleMenuContainer.addView(toggleRow, new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ));

        // Row 1: 10 sec / 20 sec / 30 sec
        LinearLayout row1 = new LinearLayout(this);
        row1.setOrientation(LinearLayout.HORIZONTAL);
        row1.setGravity(Gravity.CENTER);
        for (int sec : new int[]{10, 20, 30}) {
            Button btn = createCircularGridButton(sec + " sec", "#1E293B", "#FFFFFF");
            LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(0, dp(32), 1f);
            bp.setMargins(dp(2), dp(2), dp(2), dp(2));
            btn.setOnClickListener(v -> onClipDurationTapped(sec));
            row1.addView(btn, bp);
        }
        idleMenuContainer.addView(row1, new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ));

        // Row 2: 40 sec / 50 sec / 60 sec
        LinearLayout row2 = new LinearLayout(this);
        row2.setOrientation(LinearLayout.HORIZONTAL);
        row2.setGravity(Gravity.CENTER);
        for (int sec : new int[]{40, 50, 60}) {
            Button btn = createCircularGridButton(sec + " sec", "#1E293B", "#FFFFFF");
            LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(0, dp(32), 1f);
            bp.setMargins(dp(2), dp(2), dp(2), dp(2));
            btn.setOnClickListener(v -> onClipDurationTapped(sec));
            row2.addView(btn, bp);
        }
        idleMenuContainer.addView(row2, new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ));

        // Row 3: Full Video
        Button fullBtn = createCircularGridButton("Full Video", "#0F766E", "#FFFFFF");
        LinearLayout.LayoutParams fullLp = new LinearLayout.LayoutParams(dp(156), dp(30));
        fullLp.topMargin = dp(4);
        fullBtn.setOnClickListener(v -> onToggleFullGameplay());
        idleMenuContainer.addView(fullBtn, fullLp);

        // Bottom Row: STOP (RED) button
        idleStopBtn = createCircularGridButton("STOP", "#DC2626", "#FFFFFF");
        LinearLayout.LayoutParams idleStopLp = new LinearLayout.LayoutParams(dp(106), dp(30));
        idleStopLp.topMargin = dp(5);
        idleStopBtn.setOnClickListener(v -> {
            hideFloatingMenu();
            if (isRecordingTimed.get() || isRecordingFull.get()) {
                stopActiveRecordingOnly();
            } else {
                showToast("Ready — tap duration to start recording");
            }
        });
        idleMenuContainer.addView(idleStopBtn, idleStopLp);

        menuView.addView(idleMenuContainer, new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.MATCH_PARENT
        ));

        // 2) RECORDING BIG CONTROLS CIRCLE MENU (210dp semi-transparent dark circle: STOP RED, PAUSE YELLOW, RESUME GREEN, CLOSE X)
        recordingMenuContainer = new LinearLayout(this);
        recordingMenuContainer.setOrientation(LinearLayout.VERTICAL);
        recordingMenuContainer.setGravity(Gravity.CENTER);
        recordingMenuContainer.setPadding(dp(14), dp(14), dp(14), dp(14));
        recordingMenuContainer.setVisibility(View.GONE);

        // Top close (X) row inside circle
        LinearLayout recTopRow = new LinearLayout(this);
        recTopRow.setOrientation(LinearLayout.HORIZONTAL);
        recTopRow.setGravity(Gravity.CENTER);

        recMenuRedDot = new View(this);
        GradientDrawable rDotBg = new GradientDrawable();
        rDotBg.setShape(GradientDrawable.OVAL);
        rDotBg.setColor(Color.parseColor("#FF1E2D"));
        recMenuRedDot.setBackground(rDotBg);
        LinearLayout.LayoutParams rDotLp = new LinearLayout.LayoutParams(dp(10), dp(10));
        rDotLp.rightMargin = dp(6);
        recTopRow.addView(recMenuRedDot, rDotLp);

        recMenuTimerTv = new TextView(this);
        recMenuTimerTv.setText("00:00");
        recMenuTimerTv.setTextColor(Color.WHITE);
        recMenuTimerTv.setTextSize(17);
        recMenuTimerTv.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        recTopRow.addView(recMenuTimerTv);

        Button recCloseX = createCircleIconBtn("X", "#334155", "#FFFFFF", 24);
        LinearLayout.LayoutParams rxLp = new LinearLayout.LayoutParams(dp(24), dp(24));
        rxLp.leftMargin = dp(10);
        recCloseX.setOnClickListener(v -> hideFloatingMenu());
        recTopRow.addView(recCloseX, rxLp);
        recordingMenuContainer.addView(recTopRow);

        recMenuSubTv = new TextView(this);
        recMenuSubTv.setText("Recording...");
        recMenuSubTv.setTextColor(Color.parseColor("#CBD5E1"));
        recMenuSubTv.setTextSize(10);
        recMenuSubTv.setGravity(Gravity.CENTER);
        recMenuSubTv.setPadding(0, dp(3), 0, dp(8));
        recordingMenuContainer.addView(recMenuSubTv);

        // Middle Row: PAUSE (YELLOW) + RESUME (GREEN)
        LinearLayout pauseResumeRow = new LinearLayout(this);
        pauseResumeRow.setOrientation(LinearLayout.HORIZONTAL);
        pauseResumeRow.setGravity(Gravity.CENTER);

        pauseRecBtn = createCircularGridButton("PAUSE", "#EAB308", "#0B0E14");
        LinearLayout.LayoutParams pLp = new LinearLayout.LayoutParams(dp(78), dp(34));
        pLp.rightMargin = dp(6);
        pauseRecBtn.setOnClickListener(v -> pauseActiveRecording());
        pauseResumeRow.addView(pauseRecBtn, pLp);

        resumeRecBtn = createCircularGridButton("RESUME", "#16A34A", "#FFFFFF");
        LinearLayout.LayoutParams rLp = new LinearLayout.LayoutParams(dp(78), dp(34));
        resumeRecBtn.setOnClickListener(v -> resumeActiveRecording());
        pauseResumeRow.addView(resumeRecBtn, rLp);

        recordingMenuContainer.addView(pauseResumeRow);

        // Bottom: BIG RED STOP button
        stopRecBigBtn = createCircularGridButton("STOP", "#DC2626", "#FFFFFF");
        stopRecBigBtn.setTextSize(13);
        LinearLayout.LayoutParams stopBigLp = new LinearLayout.LayoutParams(dp(120), dp(40));
        stopBigLp.topMargin = dp(8);
        stopRecBigBtn.setOnClickListener(v -> {
            hideFloatingMenu();
            stopActiveRecordingOnly();
        });
        recordingMenuContainer.addView(stopRecBigBtn, stopBigLp);

        menuView.addView(recordingMenuContainer, new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.MATCH_PARENT
        ));
    }

    private Button createCircleIconBtn(String label, String bgHex, String textHex, int sizeDp) {
        Button btn = new Button(this);
        btn.setText(label);
        btn.setAllCaps(false);
        btn.setTextSize(11);
        btn.setTypeface(Typeface.DEFAULT_BOLD);
        btn.setTextColor(Color.parseColor(textHex));
        btn.setPadding(0, 0, 0, 0);
        btn.setMinWidth(0);
        btn.setMinHeight(0);
        btn.setMinimumWidth(dp(sizeDp));
        btn.setMinimumHeight(dp(sizeDp));
        GradientDrawable bg = new GradientDrawable();
        bg.setShape(GradientDrawable.OVAL);
        bg.setColor(Color.parseColor(bgHex));
        bg.setStroke(dp(1), Color.parseColor("#64748B"));
        btn.setBackground(bg);
        btn.setLayoutParams(new LinearLayout.LayoutParams(dp(sizeDp), dp(sizeDp)));
        return btn;
    }

    private Button createCircularGridButton(String label, String bgHex, String textHex) {
        Button btn = new Button(this);
        btn.setText(label);
        btn.setAllCaps(false);
        btn.setTextSize(10);
        btn.setTypeface(Typeface.DEFAULT_BOLD);
        btn.setTextColor(Color.parseColor(textHex));
        btn.setPadding(dp(4), dp(2), dp(4), dp(2));
        btn.setMinHeight(0);
        btn.setMinWidth(0);
        btn.setMinimumHeight(dp(28));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.parseColor(bgHex));
        bg.setCornerRadius(dp(16));
        bg.setStroke(dp(1), Color.parseColor("#475569"));
        btn.setBackground(bg);
        return btn;
    }

    private Button createCompactToggleBtn(String label) {
        Button btn = new Button(this);
        btn.setText(label);
        btn.setAllCaps(false);
        btn.setTextSize(8);
        btn.setTypeface(Typeface.DEFAULT_BOLD);
        btn.setPadding(dp(3), dp(2), dp(3), dp(2));
        btn.setMinHeight(0);
        btn.setMinWidth(0);
        btn.setMinimumHeight(dp(22));
        return btn;
    }

    private void styleMiniToggle(Button btn, boolean highlighted, String activeBgHex) {
        if (btn == null) return;
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.parseColor(highlighted ? activeBgHex : "#1E293B"));
        bg.setCornerRadius(dp(10));
        bg.setStroke(dp(1), Color.parseColor("#475569"));
        btn.setBackground(bg);
        btn.setTextColor(Color.parseColor(highlighted ? "#FFFFFF" : "#94A3B8"));
    }

    private void cycleAudioMode() {
        String next;
        if (AUDIO_MODE_BOTH.equals(selectedAudioMode)) {
            next = AUDIO_MODE_GAME;
        } else if (AUDIO_MODE_GAME.equals(selectedAudioMode)) {
            next = AUDIO_MODE_MIC;
        } else {
            next = AUDIO_MODE_BOTH;
        }
        setAudioMode(next);
    }

    private void setAudioMode(String mode) {
        selectedAudioMode = mode;
        getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
            .edit()
            .putString(KEY_AUDIO_MODE, mode)
            .apply();
        updateMenuStatusText();
        updateNotificationOnly();

        if (isCapturing.get()) {
            restartAudioPipelineForMode();
        }
        showToast("Audio set to: " + getAudioModeLabel());
    }

    private void toggleAutoContinuous() {
        autoContinuousEnabled = !autoContinuousEnabled;
        getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
            .edit()
            .putBoolean(KEY_AUTO_CONTINUOUS, autoContinuousEnabled)
            .apply();
        updateMenuStatusText();
        updateNotificationOnly();
    }

    private void toggleAutoHighlight() {
        autoHighlightEnabled = !autoHighlightEnabled;
        getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
            .edit()
            .putBoolean(KEY_AUTO_HIGHLIGHT, autoHighlightEnabled)
            .apply();
        updateMenuStatusText();
        showToast(
            autoHighlightEnabled
                ? "Auto Highlight ON: Saves 15s on Kill / Headshot / Knock"
                : "Auto Highlight OFF"
        );
    }

    private String getAudioModeLabel() {
        if (AUDIO_MODE_GAME.equals(selectedAudioMode)) return "Game/Video Only";
        if (AUDIO_MODE_MIC.equals(selectedAudioMode)) return "Mic Only";
        return "Game+Mic Both";
    }

    private void updateMenuStatusText() {
        mainHandler.post(() -> {
            if (audioCycleBtn != null) {
                String shortAudio = AUDIO_MODE_GAME.equals(selectedAudioMode)
                    ? "Game"
                    : AUDIO_MODE_MIC.equals(selectedAudioMode)
                        ? "Mic"
                        : "Game+Mic";
                audioCycleBtn.setText(shortAudio);
                styleMiniToggle(audioCycleBtn, true, "#E11D48");
            }
            if (autoContinuousBtn != null) {
                autoContinuousBtn.setText(autoContinuousEnabled ? "Loop:ON" : "Loop:OFF");
                styleMiniToggle(autoContinuousBtn, autoContinuousEnabled, "#065F46");
            }
            if (autoHighlightBtn != null) {
                autoHighlightBtn.setText(autoHighlightEnabled ? "15sHL:ON" : "15sHL:OFF");
                styleMiniToggle(autoHighlightBtn, autoHighlightEnabled, "#92400E");
            }
        });
    }

    private void onClipDurationTapped(int seconds) {
        hideFloatingMenu();
        if (!isCapturing.get()) {
            if (hasCachedProjection()) {
                startCapturePipeline();
            }
            if (!isCapturing.get()) {
                pendingDurationAfterProjection = seconds;
                pendingFullAfterProjection = false;
                promptMainForScreenCapture(seconds, false);
                return;
            }
        }
        startTimedClipRecording(seconds, true);
    }

    private void onToggleFullGameplay() {
        hideFloatingMenu();
        if (!isCapturing.get()) {
            if (hasCachedProjection()) {
                startCapturePipeline();
            }
            if (!isCapturing.get()) {
                pendingFullAfterProjection = true;
                pendingDurationAfterProjection = 0;
                promptMainForScreenCapture(0, true);
                return;
            }
        }
        if (isRecordingFull.get()) {
            stopActiveRecordingOnly();
        } else {
            startFullGameplayRecording();
        }
    }

    private void promptMainForScreenCapture(int durationSec, boolean isFull) {
        Intent intent = new Intent(this, MainActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        intent.putExtra(MainActivity.EXTRA_REQUEST_PROJECTION_GAME, activeGameName);
        if (targetPackageName != null && !targetPackageName.isEmpty()) {
            intent.putExtra(EXTRA_TARGET_PACKAGE, targetPackageName);
        }
        if (durationSec > 0) {
            intent.putExtra(EXTRA_PENDING_DURATION, durationSec);
        }
        if (isFull) {
            intent.putExtra(EXTRA_PENDING_FULL, true);
        }
        startActivity(intent);
        showToast("Allow screen capture once to start recording " + activeGameName);
    }

    private void ensureMediaProjectionInitialized() {
        if (cachedMediaProjection != null) {
            mediaProjection = cachedMediaProjection;
            return;
        }
        Intent tokenData = projectionResultData != null ? projectionResultData : cachedProjectionResultData;
        int tokenCode = projectionResultData != null ? projectionResultCode : cachedProjectionResultCode;
        if (tokenCode != Activity.RESULT_OK || tokenData == null) return;

        MediaProjectionManager mpm =
            (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);
        if (mpm == null) return;

        try {
            mediaProjection = mpm.getMediaProjection(tokenCode, tokenData);
        } catch (SecurityException e) {
            // Single-use token already consumed or revoked
            mediaProjection = null;
            cachedMediaProjection = null;
            cachedProjectionResultData = null;
            cachedProjectionResultCode = Activity.RESULT_CANCELED;
            return;
        }
        if (mediaProjection == null) return;

        cachedMediaProjection = mediaProjection;
        mediaProjection.registerCallback(new MediaProjection.Callback() {
            @Override
            public void onStop() {
                mainHandler.post(() -> {
                    cachedMediaProjection = null;
                    cachedProjectionResultData = null;
                    cachedProjectionResultCode = Activity.RESULT_CANCELED;
                    projectionResultData = null;
                    projectionResultCode = Activity.RESULT_CANCELED;
                    stopCapturePipeline();
                    updateBubbleVisuals(false, 0L, false);
                    updateMenuStatusText();
                    updateNotificationOnly();
                });
            }
        }, mainHandler);
    }

    private void startCapturePipeline() {
        if (isCapturing.get()) {
            return;
        }
        ensureMediaProjectionInitialized();
        if (mediaProjection == null) {
            return;
        }

        DisplayMetrics dm = getResources().getDisplayMetrics();
        int rawW = Math.max(720, dm.widthPixels);
        int rawH = Math.max(720, dm.heightPixels);
        int maxDim = Math.max(rawW, rawH);
        double scale = maxDim > 1280 ? (1280.0 / maxDim) : 1.0;
        int encW = Math.max(320, ((int) Math.round(rawW * scale) / 16) * 16);
        int encH = Math.max(320, ((int) Math.round(rawH * scale) / 16) * 16);

        try {
            MediaFormat videoFormat = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, encW, encH);
            videoFormat.setInteger(
                MediaFormat.KEY_COLOR_FORMAT,
                MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface
            );
            videoFormat.setInteger(MediaFormat.KEY_BIT_RATE, VIDEO_BITRATE);
            videoFormat.setInteger(MediaFormat.KEY_FRAME_RATE, VIDEO_FPS);
            videoFormat.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1);

            videoEncoder = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC);
            videoEncoder.configure(videoFormat, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE);
            encoderSurface = videoEncoder.createInputSurface();
            videoEncoder.start();

            virtualDisplay = mediaProjection.createVirtualDisplay(
                "ClipKaroCapture",
                encW,
                encH,
                dm.densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                encoderSurface,
                null,
                null
            );

            isCapturing.set(true);
            captureStartedAtMs = System.currentTimeMillis();
            videoThread = new Thread(this::runVideoDrainLoop, "ClipKaroVideoDrain");
            videoThread.start();

            startAudioPipeline();
            updateMenuStatusText();
            updateNotificationOnly();
        } catch (Exception e) {
            stopCapturePipeline();
            showToast("Screen capture setup failed: " + e.getMessage());
        }
    }

    @SuppressLint("MissingPermission")
    private void startAudioPipeline() {
        stopAudioPipelineOnly();
        if (!isCapturing.get()) return;

        try {
            int minBuf = AudioRecord.getMinBufferSize(
                AUDIO_SAMPLE_RATE,
                AudioFormat.CHANNEL_IN_STEREO,
                AudioFormat.ENCODING_PCM_16BIT
            );
            int bufSize = Math.max(minBuf * 2, 8192);

            AudioFormat audioFormat = new AudioFormat.Builder()
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setSampleRate(AUDIO_SAMPLE_RATE)
                .setChannelMask(AudioFormat.CHANNEL_IN_STEREO)
                .build();

            boolean wantGame = AUDIO_MODE_GAME.equals(selectedAudioMode) || AUDIO_MODE_BOTH.equals(selectedAudioMode);
            boolean wantMic = AUDIO_MODE_MIC.equals(selectedAudioMode) || AUDIO_MODE_BOTH.equals(selectedAudioMode);
            boolean micPermGranted = ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
                == PackageManager.PERMISSION_GRANTED;

            if (wantGame && Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q && mediaProjection != null) {
                AudioPlaybackCaptureConfiguration config =
                    new AudioPlaybackCaptureConfiguration.Builder(mediaProjection)
                        .addMatchingUsage(AudioAttributes.USAGE_GAME)
                        .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
                        .build();
                AudioRecord rec = new AudioRecord.Builder()
                    .setAudioPlaybackCaptureConfig(config)
                    .setAudioFormat(audioFormat)
                    .setBufferSizeInBytes(bufSize)
                    .build();
                if (rec.getState() == AudioRecord.STATE_INITIALIZED) {
                    gameAudioRecord = rec;
                } else {
                    rec.release();
                }
            }

            if (wantMic && micPermGranted) {
                AudioRecord rec = new AudioRecord.Builder()
                    .setAudioSource(MediaRecorder.AudioSource.MIC)
                    .setAudioFormat(audioFormat)
                    .setBufferSizeInBytes(bufSize)
                    .build();
                if (rec.getState() == AudioRecord.STATE_INITIALIZED) {
                    micAudioRecord = rec;
                } else {
                    rec.release();
                }
            }

            // Fallback to mic on Android < 10 if Game Only selected without AudioPlaybackCapture support
            if (gameAudioRecord == null && micAudioRecord == null && micPermGranted) {
                AudioRecord rec = new AudioRecord.Builder()
                    .setAudioSource(MediaRecorder.AudioSource.MIC)
                    .setAudioFormat(audioFormat)
                    .setBufferSizeInBytes(bufSize)
                    .build();
                if (rec.getState() == AudioRecord.STATE_INITIALIZED) {
                    micAudioRecord = rec;
                } else {
                    rec.release();
                }
            }

            if (gameAudioRecord != null || micAudioRecord != null) {
                MediaFormat encFormat = MediaFormat.createAudioFormat(
                    MediaFormat.MIMETYPE_AUDIO_AAC,
                    AUDIO_SAMPLE_RATE,
                    2
                );
                encFormat.setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC);
                encFormat.setInteger(MediaFormat.KEY_BIT_RATE, AUDIO_BITRATE);
                encFormat.setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, bufSize);

                audioEncoder = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC);
                audioEncoder.configure(encFormat, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE);
                audioEncoder.start();

                if (gameAudioRecord != null) gameAudioRecord.startRecording();
                if (micAudioRecord != null) micAudioRecord.startRecording();

                audioLoopRunning.set(true);
                audioThread = new Thread(this::runAudioCaptureLoop, "ClipKaroAudioLoop");
                audioThread.start();
            }
        } catch (Exception ignored) {
            stopAudioPipelineOnly();
        }
    }

    private void restartAudioPipelineForMode() {
        exportExecutor.execute(() -> {
            startAudioPipeline();
        });
    }

    private void stopAudioPipelineOnly() {
        audioLoopRunning.set(false);
        if (audioThread != null) {
            try {
                audioThread.join(350);
            } catch (InterruptedException ignored) {
            }
            audioThread = null;
        }
        if (gameAudioRecord != null) {
            try {
                gameAudioRecord.stop();
            } catch (Exception ignored) {
            }
            try {
                gameAudioRecord.release();
            } catch (Exception ignored) {
            }
            gameAudioRecord = null;
        }
        if (micAudioRecord != null) {
            try {
                micAudioRecord.stop();
            } catch (Exception ignored) {
            }
            try {
                micAudioRecord.release();
            } catch (Exception ignored) {
            }
            micAudioRecord = null;
        }
        if (audioEncoder != null) {
            try {
                audioEncoder.stop();
            } catch (Exception ignored) {
            }
            try {
                audioEncoder.release();
            } catch (Exception ignored) {
            }
            audioEncoder = null;
        }
    }

    private void resetPauseTracking() {
        isRecordingPaused.set(false);
        pauseStartedMs = 0L;
        totalPausedMs = 0L;
        pausedVideoPtsOffsetUs = 0L;
        videoJustResumed = false;
        pausedAudioPtsOffsetUs = 0L;
        audioJustResumed = false;
    }

    private void startTimedClipRecording(int durationSec, boolean resetSequence) {
        if (isRecordingFull.get()) {
            finishFullGameplayRecording(true);
        }
        synchronized (muxerLock) {
            if (isRecordingTimed.get()) {
                closeTimedMuxerAndEnqueueSaveLocked(false);
            }
            resetPauseTracking();
            activeTimedDurationSec = Math.max(5, durationSec);
            if (resetSequence) {
                currentClipSequence = 1;
            }
            openNewTimedMuxerLocked();
            isRecordingTimed.set(true);
        }

        requestSyncFrame();
        mainHandler.removeCallbacks(uiTickerRunnable);
        mainHandler.post(uiTickerRunnable);
        updateBubbleVisuals(true, 0L, true);
        postStatusNotification(
            "Clipping Started - " + activeTimedDurationSec + " sec Clip",
            "● " + activeTimedDurationSec + " sec Clip · Tap CLIP button to Stop",
            true,
            true
        );
    }

    private void openNewTimedMuxerLocked() {
        String safeGame = activeGameName.replaceAll("[^A-Za-z0-9_]+", "_");
        timedTempFile = new File(
            getCacheDir(),
            String.format(
                Locale.US,
                "ClipKaro_%s_%ds_Clip%d_%d.mp4",
                safeGame, activeTimedDurationSec, currentClipSequence, System.currentTimeMillis()
            )
        );
        try {
            timedMuxer = new MediaMuxer(timedTempFile.getAbsolutePath(), MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);
            timedMuxerStarted = false;
            timedWaitingForKeyframe = true;
            timedVideoTrack = -1;
            timedAudioTrack = -1;
            timedStartMs = System.currentTimeMillis();
        } catch (IOException e) {
            timedMuxer = null;
            isRecordingTimed.set(false);
        }
    }

    private void closeTimedMuxerAndEnqueueSaveLocked(boolean saveToGallery) {
        if (timedMuxer != null) {
            try {
                if (timedMuxerStarted) timedMuxer.stop();
            } catch (Exception ignored) {
            }
            try {
                timedMuxer.release();
            } catch (Exception ignored) {
            }
            timedMuxer = null;
            timedMuxerStarted = false;
        }
        File finishedFile = timedTempFile;
        int clipNum = currentClipSequence;
        int durSec = activeTimedDurationSec;
        timedTempFile = null;

        if (finishedFile != null && finishedFile.exists()) {
            if (saveToGallery && finishedFile.length() > 2048) {
                exportExecutor.execute(() -> saveClipFileAndBroadcast(finishedFile, "Saved Clip #" + clipNum + " (" + durSec + "s)"));
            } else {
                //noinspection ResultOfMethodCallIgnored
                finishedFile.delete();
            }
        }
    }

    private void onTimedClipDurationReached() {
        if (!isRecordingTimed.get()) return;
        // Recording should NEVER stop automatically: save finished clip and immediately start next clip until STOP
        synchronized (muxerLock) {
            closeTimedMuxerAndEnqueueSaveLocked(true);
            currentClipSequence += 1;
            totalPausedMs = 0L;
            pausedVideoPtsOffsetUs = 0L;
            pausedAudioPtsOffsetUs = 0L;
            openNewTimedMuxerLocked();
            requestSyncFrame();
        }
    }

    private void startFullGameplayRecording() {
        if (isRecordingTimed.get()) {
            synchronized (muxerLock) {
                isRecordingTimed.set(false);
                closeTimedMuxerAndEnqueueSaveLocked(true);
            }
        }
        synchronized (muxerLock) {
            if (isRecordingFull.get()) return;
            resetPauseTracking();
            String safeGame = activeGameName.replaceAll("[^A-Za-z0-9_]+", "_");
            fullTempFile = new File(
                getCacheDir(),
                "ClipKaro_Full_" + safeGame + "_" + System.currentTimeMillis() + ".mp4"
            );
            try {
                fullMuxer = new MediaMuxer(fullTempFile.getAbsolutePath(), MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);
                fullMuxerStarted = false;
                fullWaitingForKeyframe = true;
                fullVideoTrack = -1;
                fullAudioTrack = -1;
                fullStartMs = System.currentTimeMillis();
                isRecordingFull.set(true);
                requestSyncFrame();
            } catch (IOException e) {
                fullMuxer = null;
                isRecordingFull.set(false);
            }
        }
        mainHandler.removeCallbacks(uiTickerRunnable);
        mainHandler.post(uiTickerRunnable);
        updateBubbleVisuals(true, 0L, true);
        postStatusNotification(
            "Clipping Started - Full Video",
            "● Full Video · Tap CLIP button to Stop",
            true,
            true
        );
    }

    private void finishFullGameplayRecording(boolean saveFile) {
        File finishedFile;
        synchronized (muxerLock) {
            if (!isRecordingFull.get()) return;
            isRecordingFull.set(false);
            if (fullMuxer != null) {
                try {
                    if (fullMuxerStarted) fullMuxer.stop();
                } catch (Exception ignored) {
                }
                try {
                    fullMuxer.release();
                } catch (Exception ignored) {
                }
                fullMuxer = null;
                fullMuxerStarted = false;
            }
            finishedFile = fullTempFile;
            fullTempFile = null;
        }

        if (finishedFile != null && finishedFile.exists()) {
            if (saveFile && finishedFile.length() > 2048) {
                exportExecutor.execute(() -> saveClipFileAndBroadcast(finishedFile, "Saved Full " + activeGameName + " gameplay"));
            } else {
                //noinspection ResultOfMethodCallIgnored
                finishedFile.delete();
            }
        }
    }

    private void pauseActiveRecording() {
        if ((!isRecordingTimed.get() && !isRecordingFull.get()) || isRecordingPaused.get()) {
            return;
        }
        pauseStartedMs = System.currentTimeMillis();
        isRecordingPaused.set(true);
        long frozenSec = getCurrentActiveElapsedSec();
        updateBubbleVisuals(true, frozenSec, true);
        updateExpandedRecordingTimer(frozenSec, true);
        postStatusNotification(
            "Recording Paused",
            String.format(Locale.US, "Paused at %02d:%02d · Tap Resume to continue", frozenSec / 60, frozenSec % 60),
            false,
            true
        );
    }

    private void resumeActiveRecording() {
        if ((!isRecordingTimed.get() && !isRecordingFull.get()) || !isRecordingPaused.get()) {
            return;
        }
        if (pauseStartedMs > 0L) {
            totalPausedMs += Math.max(0L, System.currentTimeMillis() - pauseStartedMs);
        }
        pauseStartedMs = 0L;
        videoJustResumed = true;
        audioJustResumed = true;
        isRecordingPaused.set(false);
        requestSyncFrame();
        long currentSec = getCurrentActiveElapsedSec();
        updateBubbleVisuals(true, currentSec, true);
        updateExpandedRecordingTimer(currentSec, true);
        postStatusNotification(
            "Recording Resumed",
            "● Continuing from " + String.format(Locale.US, "%02d:%02d", currentSec / 60, currentSec % 60),
            true,
            true
        );
    }

    private void stopActiveRecordingOnly() {
        stopActiveRecordingOnlyWithMessage(
            "Clipping Saved - My Clips me save ho gayi",
            "Saved to Movies/ClipKaro & My Clips"
        );
    }

    private void stopActiveRecordingOnlyWithMessage(String notifyTitle, String notifyBody) {
        boolean wasTimed = isRecordingTimed.get();
        boolean wasFull = isRecordingFull.get();
        resetPauseTracking();
        if (wasTimed) {
            synchronized (muxerLock) {
                isRecordingTimed.set(false);
                closeTimedMuxerAndEnqueueSaveLocked(true);
            }
        }
        if (wasFull) {
            finishFullGameplayRecording(true);
        }
        mainHandler.removeCallbacks(uiTickerRunnable);
        updateBubbleVisuals(false, 0L, false);
        updateMenuStatusText();
        updateNotificationOnly();
        if (wasTimed || wasFull) {
            postStatusNotification(
                notifyTitle,
                notifyBody,
                false,
                true
            );
        }
    }

    private void requestSyncFrame() {
        if (videoEncoder != null) {
            try {
                Bundle sync = new Bundle();
                sync.putInt(MediaCodec.PARAMETER_KEY_REQUEST_SYNC_FRAME, 0);
                videoEncoder.setParameters(sync);
            } catch (Exception ignored) {
            }
        }
    }

    private void saveClipFileAndBroadcast(File tempFile, String toastLabel) {
        try {
            Uri savedUri = saveMp4ToMoviesGallery(tempFile, tempFile.getName());
            showToast(toastLabel + " → Movies/ClipKaro");
            Intent savedBroadcast = new Intent(ACTION_NATIVE_CLIP_SAVED);
            savedBroadcast.setPackage(getPackageName());
            savedBroadcast.putExtra(EXTRA_SAVED_FILE_NAME, tempFile.getName());
            if (savedUri != null) {
                savedBroadcast.putExtra(EXTRA_SAVED_URI, savedUri.toString());
            }
            sendBroadcast(savedBroadcast);
        } catch (IOException e) {
            showToast("Save failed: " + e.getMessage());
        } finally {
            //noinspection ResultOfMethodCallIgnored
            tempFile.delete();
        }
    }

    private void openNextHighlightSegmentLocked(long firstPtsUs) {
        closeCurrentHighlightSegmentLocked(true);
        if (latestVideoFormat == null || highlightBufferDir == null) return;
        try {
            File nextFile = new File(highlightBufferDir, "hl_" + (hlSegmentIndex++) + ".mp4");
            MediaMuxer muxer = new MediaMuxer(nextFile.getAbsolutePath(), MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);
            hlVideoTrack = muxer.addTrack(latestVideoFormat);
            hlAudioTrack = latestAudioFormat != null ? muxer.addTrack(latestAudioFormat) : -1;
            muxer.start();
            currentHighlightSegmentFile = nextFile;
            highlightMuxer = muxer;
            hlMuxerStarted = true;
            currentHlSegmentStartUs = firstPtsUs;
        } catch (IOException ignored) {
            highlightMuxer = null;
            hlMuxerStarted = false;
        }
    }

    private void closeCurrentHighlightSegmentLocked(boolean keepFile) {
        if (highlightMuxer != null) {
            try {
                if (hlMuxerStarted) highlightMuxer.stop();
            } catch (Exception ignored) {
            }
            try {
                highlightMuxer.release();
            } catch (Exception ignored) {
            }
            highlightMuxer = null;
            hlMuxerStarted = false;
        }
        if (currentHighlightSegmentFile != null) {
            if (keepFile && currentHighlightSegmentFile.exists() && currentHighlightSegmentFile.length() > 1024) {
                completedHighlightSegments.add(currentHighlightSegmentFile);
                while (completedHighlightSegments.size() > MAX_HIGHLIGHT_SEGMENTS) {
                    File oldest = completedHighlightSegments.remove(0);
                    //noinspection ResultOfMethodCallIgnored
                    oldest.delete();
                }
            } else {
                //noinspection ResultOfMethodCallIgnored
                currentHighlightSegmentFile.delete();
            }
            currentHighlightSegmentFile = null;
        }
        currentHlSegmentStartUs = -1L;
    }

    private void maybeTriggerAutoHighlight(String eventLabel) {
        if (!autoHighlightEnabled || !isCapturing.get()) return;
        long now = System.currentTimeMillis();
        if (now - captureStartedAtMs < 7000L) return;
        if (now - lastAutoHighlightSavedMs < HIGHLIGHT_COOLDOWN_MS) return;
        lastAutoHighlightSavedMs = now;
        exportExecutor.execute(() -> exportAutoHighlight15s(eventLabel));
    }

    private void exportAutoHighlight15s(String eventLabel) {
        try {
            requestSyncFrame();
            try {
                Thread.sleep(250);
            } catch (InterruptedException ignored) {
            }
            List<File> sourceFiles;
            synchronized (muxerLock) {
                closeCurrentHighlightSegmentLocked(true);
                int count = completedHighlightSegments.size();
                if (count == 0) return;
                int start = Math.max(0, count - 3);
                sourceFiles = new ArrayList<>(completedHighlightSegments.subList(start, count));
            }
            if (sourceFiles.isEmpty()) return;

            String safeGame = activeGameName.replaceAll("[^A-Za-z0-9_]+", "_");
            String fileName = String.format(
                Locale.US,
                "ClipKaro_AutoHighlight_%s_%s_15s_%d_%d.mp4",
                safeGame, eventLabel, highlightSequence++, System.currentTimeMillis()
            );
            File tempOut = new File(getCacheDir(), fileName);
            stitchHighlightSegments(sourceFiles, tempOut);
            if (tempOut.exists() && tempOut.length() > 2048) {
                saveClipFileAndBroadcast(tempOut, "Auto Highlight (" + eventLabel + " · 15s)");
            } else {
                //noinspection ResultOfMethodCallIgnored
                tempOut.delete();
            }
        } catch (Exception ignored) {
        }
    }

    private void stitchHighlightSegments(List<File> segments, File outFile) throws IOException {
        MediaMuxer outMuxer = new MediaMuxer(outFile.getAbsolutePath(), MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);
        int outVideoTrack = -1;
        int outAudioTrack = -1;
        boolean muxerStarted = false;
        long totalVideoOffsetUs = 0L;
        long totalAudioOffsetUs = 0L;
        ByteBuffer buffer = ByteBuffer.allocate(1024 * 1024);
        MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();

        try {
            for (File seg : segments) {
                MediaExtractor extractor = new MediaExtractor();
                try {
                    extractor.setDataSource(seg.getAbsolutePath());
                    int srcVideo = -1;
                    int srcAudio = -1;
                    MediaFormat vFmt = null;
                    MediaFormat aFmt = null;
                    for (int i = 0; i < extractor.getTrackCount(); i++) {
                        MediaFormat fmt = extractor.getTrackFormat(i);
                        String mime = fmt.getString(MediaFormat.KEY_MIME);
                        if (mime != null && mime.startsWith("video/") && srcVideo < 0) {
                            srcVideo = i;
                            vFmt = fmt;
                        } else if (mime != null && mime.startsWith("audio/") && srcAudio < 0) {
                            srcAudio = i;
                            aFmt = fmt;
                        }
                    }
                    if (!muxerStarted) {
                        if (vFmt != null) outVideoTrack = outMuxer.addTrack(vFmt);
                        if (aFmt != null) outAudioTrack = outMuxer.addTrack(aFmt);
                        if (outVideoTrack >= 0 || outAudioTrack >= 0) {
                            outMuxer.start();
                            muxerStarted = true;
                        }
                    }
                    if (!muxerStarted) continue;

                    long segMaxVideoUs = 0L;
                    long segFirstVideoUs = -1L;
                    if (srcVideo >= 0 && outVideoTrack >= 0) {
                        extractor.selectTrack(srcVideo);
                        while (true) {
                            int size = extractor.readSampleData(buffer, 0);
                            if (size < 0) break;
                            long sampleTime = extractor.getSampleTime();
                            if (segFirstVideoUs < 0) segFirstVideoUs = sampleTime;
                            long relUs = Math.max(0L, sampleTime - segFirstVideoUs);
                            info.offset = 0;
                            info.size = size;
                            info.presentationTimeUs = totalVideoOffsetUs + relUs;
                            //noinspection WrongConstant
                            info.flags = extractor.getSampleFlags();
                            outMuxer.writeSampleData(outVideoTrack, buffer, info);
                            segMaxVideoUs = Math.max(segMaxVideoUs, relUs);
                            extractor.advance();
                        }
                        extractor.unselectTrack(srcVideo);
                    }

                    long segMaxAudioUs = 0L;
                    long segFirstAudioUs = -1L;
                    if (srcAudio >= 0 && outAudioTrack >= 0) {
                        extractor.selectTrack(srcAudio);
                        while (true) {
                            int size = extractor.readSampleData(buffer, 0);
                            if (size < 0) break;
                            long sampleTime = extractor.getSampleTime();
                            if (segFirstAudioUs < 0) segFirstAudioUs = sampleTime;
                            long relUs = Math.max(0L, sampleTime - segFirstAudioUs);
                            info.offset = 0;
                            info.size = size;
                            info.presentationTimeUs = totalAudioOffsetUs + relUs;
                            //noinspection WrongConstant
                            info.flags = extractor.getSampleFlags();
                            outMuxer.writeSampleData(outAudioTrack, buffer, info);
                            segMaxAudioUs = Math.max(segMaxAudioUs, relUs);
                            extractor.advance();
                        }
                        extractor.unselectTrack(srcAudio);
                    }

                    totalVideoOffsetUs += segMaxVideoUs + 33_333L;
                    totalAudioOffsetUs += Math.max(segMaxAudioUs, segMaxVideoUs) + 23_220L;
                } finally {
                    extractor.release();
                }
            }
        } finally {
            try {
                if (muxerStarted) outMuxer.stop();
            } catch (Exception ignored) {
            }
            outMuxer.release();
        }
    }

    private void runVideoDrainLoop() {
        MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
        while (isCapturing.get()) {
            try {
                int outIndex = videoEncoder.dequeueOutputBuffer(info, 10_000);
                if (outIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    synchronized (muxerLock) {
                        latestVideoFormat = videoEncoder.getOutputFormat();
                    }
                } else if (outIndex >= 0) {
                    ByteBuffer outBuf = videoEncoder.getOutputBuffer(outIndex);
                    if (outBuf != null && (info.flags & MediaCodec.BUFFER_FLAG_CODEC_CONFIG) == 0 && info.size > 0) {
                        boolean isKeyFrame = (info.flags & MediaCodec.BUFFER_FLAG_KEY_FRAME) != 0;
                        if (!isKeyFrame) {
                            avgPFrameBytes = avgPFrameBytes * 0.95 + info.size * 0.05;
                            long nowMs = System.currentTimeMillis();
                            if (autoHighlightEnabled
                                && (nowMs - lastAudioCombatPeakMs) <= 2200L
                                && info.size > avgPFrameBytes * 2.15) {
                                maybeTriggerAutoHighlight("Headshot");
                            }
                        }

                        synchronized (muxerLock) {
                            if (autoHighlightEnabled) {
                                if (currentHlSegmentStartUs > 0
                                    && (info.presentationTimeUs - currentHlSegmentStartUs) >= HIGHLIGHT_SEGMENT_DURATION_MS * 1000L
                                    && isKeyFrame) {
                                    openNextHighlightSegmentLocked(info.presentationTimeUs);
                                } else if (!hlMuxerStarted && isKeyFrame) {
                                    openNextHighlightSegmentLocked(info.presentationTimeUs);
                                }
                                if (hlMuxerStarted && highlightMuxer != null && hlVideoTrack >= 0) {
                                    outBuf.position(info.offset);
                                    outBuf.limit(info.offset + info.size);
                                    highlightMuxer.writeSampleData(hlVideoTrack, outBuf, info);
                                }
                            }

                            if (!isRecordingPaused.get()) {
                                if (videoJustResumed && lastRawVideoPtsUs > 0L) {
                                    pausedVideoPtsOffsetUs += Math.max(0L, info.presentationTimeUs - lastRawVideoPtsUs - 33_333L);
                                    videoJustResumed = false;
                                }
                                lastRawVideoPtsUs = info.presentationTimeUs;
                                MediaCodec.BufferInfo adjInfo = new MediaCodec.BufferInfo();
                                adjInfo.set(
                                    info.offset,
                                    info.size,
                                    Math.max(0L, info.presentationTimeUs - pausedVideoPtsOffsetUs),
                                    info.flags
                                );

                                if (isRecordingTimed.get() && timedMuxer != null) {
                                    if (!timedMuxerStarted && isKeyFrame && latestVideoFormat != null) {
                                        timedVideoTrack = timedMuxer.addTrack(latestVideoFormat);
                                        timedAudioTrack = latestAudioFormat != null ? timedMuxer.addTrack(latestAudioFormat) : -1;
                                        timedMuxer.start();
                                        timedMuxerStarted = true;
                                        timedWaitingForKeyframe = false;
                                    }
                                    if (timedMuxerStarted && !timedWaitingForKeyframe && timedVideoTrack >= 0) {
                                        outBuf.position(adjInfo.offset);
                                        outBuf.limit(adjInfo.offset + adjInfo.size);
                                        timedMuxer.writeSampleData(timedVideoTrack, outBuf, adjInfo);
                                    }
                                }

                                if (isRecordingFull.get() && fullMuxer != null) {
                                    if (!fullMuxerStarted && isKeyFrame && latestVideoFormat != null) {
                                        fullVideoTrack = fullMuxer.addTrack(latestVideoFormat);
                                        fullAudioTrack = latestAudioFormat != null ? fullMuxer.addTrack(latestAudioFormat) : -1;
                                        fullMuxer.start();
                                        fullMuxerStarted = true;
                                        fullWaitingForKeyframe = false;
                                    }
                                    if (fullMuxerStarted && !fullWaitingForKeyframe && fullVideoTrack >= 0) {
                                        outBuf.position(adjInfo.offset);
                                        outBuf.limit(adjInfo.offset + adjInfo.size);
                                        fullMuxer.writeSampleData(fullVideoTrack, outBuf, adjInfo);
                                    }
                                }
                            }
                        }
                    }
                    videoEncoder.releaseOutputBuffer(outIndex, false);
                }
            } catch (Exception e) {
                if (!isCapturing.get()) break;
            }
        }
    }

    private void runAudioCaptureLoop() {
        final int frameBytes = 4096;
        byte[] gamePcm = new byte[frameBytes];
        byte[] micPcm = new byte[frameBytes];
        byte[] mixedPcm = new byte[frameBytes];
        MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
        long startNano = System.nanoTime();

        while (isCapturing.get() && audioLoopRunning.get() && audioEncoder != null) {
            try {
                int readGame = (gameAudioRecord != null) ? gameAudioRecord.read(gamePcm, 0, frameBytes) : 0;
                int readMic = (micAudioRecord != null) ? micAudioRecord.read(micPcm, 0, frameBytes) : 0;
                int bytesToEncode = Math.max(readGame, readMic);

                if (bytesToEncode > 0) {
                    byte[] payload;
                    if (readGame > 0 && readMic > 0) {
                        // Mix 16-bit PCM game audio + microphone voice cleanly
                        int minLen = Math.min(readGame, readMic);
                        for (int i = 0; i + 1 < bytesToEncode; i += 2) {
                            int g = (i < minLen || i + 1 < readGame)
                                ? (short) ((gamePcm[i] & 0xff) | (gamePcm[i + 1] << 8))
                                : 0;
                            int m = (i + 1 < readMic)
                                ? (short) ((micPcm[i] & 0xff) | (micPcm[i + 1] << 8))
                                : 0;
                            int sum = Math.max(-32768, Math.min(32767, g + m));
                            mixedPcm[i] = (byte) (sum & 0xff);
                            mixedPcm[i + 1] = (byte) ((sum >> 8) & 0xff);
                        }
                        payload = mixedPcm;
                    } else if (readGame > 0) {
                        payload = gamePcm;
                    } else {
                        payload = micPcm;
                    }

                    // Measure gunfire / knock / kill sound impact peak for Auto Highlight (15s)
                    if (autoHighlightEnabled) {
                        int peak = 0;
                        for (int i = 0; i + 1 < bytesToEncode; i += 8) {
                            int sample = Math.abs((short) ((payload[i] & 0xff) | (payload[i + 1] << 8)));
                            if (sample > peak) peak = sample;
                        }
                        if (peak > 22000) {
                            lastAudioCombatPeakMs = System.currentTimeMillis();
                        }
                    }

                    int inIndex = audioEncoder.dequeueInputBuffer(5000);
                    if (inIndex >= 0) {
                        ByteBuffer inBuf = audioEncoder.getInputBuffer(inIndex);
                        if (inBuf != null) {
                            inBuf.clear();
                            int count = Math.min(bytesToEncode, inBuf.capacity());
                            inBuf.put(payload, 0, count);
                            long ptsUs = (System.nanoTime() - startNano) / 1000L;
                            audioEncoder.queueInputBuffer(inIndex, 0, count, ptsUs, 0);
                        }
                    }
                }

                int outIndex = audioEncoder.dequeueOutputBuffer(info, 0);
                while (outIndex >= 0 || outIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    if (outIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                        synchronized (muxerLock) {
                            latestAudioFormat = audioEncoder.getOutputFormat();
                        }
                    } else if (outIndex >= 0) {
                        ByteBuffer outBuf = audioEncoder.getOutputBuffer(outIndex);
                        if (outBuf != null && (info.flags & MediaCodec.BUFFER_FLAG_CODEC_CONFIG) == 0 && info.size > 0) {
                            synchronized (muxerLock) {
                                if (autoHighlightEnabled && hlMuxerStarted && highlightMuxer != null && hlAudioTrack >= 0) {
                                    outBuf.position(info.offset);
                                    outBuf.limit(info.offset + info.size);
                                    highlightMuxer.writeSampleData(hlAudioTrack, outBuf, info);
                                }
                                if (!isRecordingPaused.get()) {
                                    if (audioJustResumed && lastRawAudioPtsUs > 0L) {
                                        pausedAudioPtsOffsetUs += Math.max(0L, info.presentationTimeUs - lastRawAudioPtsUs - 23_220L);
                                        audioJustResumed = false;
                                    }
                                    lastRawAudioPtsUs = info.presentationTimeUs;
                                    MediaCodec.BufferInfo adjAudio = new MediaCodec.BufferInfo();
                                    adjAudio.set(
                                        info.offset,
                                        info.size,
                                        Math.max(0L, info.presentationTimeUs - pausedAudioPtsOffsetUs),
                                        info.flags
                                    );
                                    if (isRecordingTimed.get() && timedMuxerStarted && timedMuxer != null && timedAudioTrack >= 0) {
                                        outBuf.position(adjAudio.offset);
                                        outBuf.limit(adjAudio.offset + adjAudio.size);
                                        timedMuxer.writeSampleData(timedAudioTrack, outBuf, adjAudio);
                                    }
                                    if (isRecordingFull.get() && fullMuxerStarted && fullMuxer != null && fullAudioTrack >= 0) {
                                        outBuf.position(adjAudio.offset);
                                        outBuf.limit(adjAudio.offset + adjAudio.size);
                                        fullMuxer.writeSampleData(fullAudioTrack, outBuf, adjAudio);
                                    }
                                }
                            }
                        }
                        audioEncoder.releaseOutputBuffer(outIndex, false);
                    }
                    outIndex = audioEncoder.dequeueOutputBuffer(info, 0);
                }
            } catch (Exception e) {
                if (!audioLoopRunning.get() || !isCapturing.get()) break;
            }
        }
    }

    @Nullable
    private Uri saveMp4ToMoviesGallery(File sourceFile, String displayName) throws IOException {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            ContentResolver resolver = getContentResolver();
            ContentValues values = new ContentValues();
            values.put(MediaStore.Video.Media.DISPLAY_NAME, displayName);
            values.put(MediaStore.Video.Media.MIME_TYPE, "video/mp4");
            values.put(
                MediaStore.Video.Media.RELATIVE_PATH,
                Environment.DIRECTORY_MOVIES + "/ClipKaro"
            );
            values.put(MediaStore.Video.Media.IS_PENDING, 1);

            Uri uri = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values);
            if (uri == null) {
                throw new IOException("MediaStore insert failed");
            }

            try (OutputStream out = resolver.openOutputStream(uri);
                 FileInputStream in = new FileInputStream(sourceFile)) {
                if (out == null) throw new IOException("Output stream unavailable");
                byte[] buf = new byte[16384];
                int n;
                while ((n = in.read(buf)) != -1) {
                    out.write(buf, 0, n);
                }
            }

            values.clear();
            values.put(MediaStore.Video.Media.IS_PENDING, 0);
            resolver.update(uri, values, null, null);
            return uri;
        } else {
            File moviesDir = new File(
                Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES),
                "ClipKaro"
            );
            if (!moviesDir.exists()) {
                //noinspection ResultOfMethodCallIgnored
                moviesDir.mkdirs();
            }
            File dest = new File(moviesDir, displayName);
            try (FileInputStream in = new FileInputStream(sourceFile);
                 OutputStream out = new java.io.FileOutputStream(dest)) {
                byte[] buf = new byte[16384];
                int n;
                while ((n = in.read(buf)) != -1) {
                    out.write(buf, 0, n);
                }
            }
            MediaScannerConnection.scanFile(
                this,
                new String[]{dest.getAbsolutePath()},
                new String[]{"video/mp4"},
                null
            );
            return Uri.fromFile(dest);
        }
    }

    private void stopCapturePipelineKeepProjection() {
        stopActiveRecordingOnly();
        isCapturing.set(false);
        stopAudioPipelineOnly();
        synchronized (muxerLock) {
            closeCurrentHighlightSegmentLocked(false);
            for (File seg : completedHighlightSegments) {
                //noinspection ResultOfMethodCallIgnored
                seg.delete();
            }
            completedHighlightSegments.clear();
        }

        if (virtualDisplay != null) {
            virtualDisplay.release();
            virtualDisplay = null;
        }
        if (encoderSurface != null) {
            encoderSurface.release();
            encoderSurface = null;
        }
        if (videoEncoder != null) {
            try {
                videoEncoder.stop();
            } catch (Exception ignored) {
            }
            try {
                videoEncoder.release();
            } catch (Exception ignored) {
            }
            videoEncoder = null;
        }
    }

    private void stopCapturePipeline() {
        stopCapturePipelineKeepProjection();
        if (mediaProjection != null) {
            try {
                mediaProjection.stop();
            } catch (Exception ignored) {
            }
            mediaProjection = null;
        }
        cachedMediaProjection = null;
    }

    private void stopEverythingAndSelf() {
        bubbleSuppressed = true;
        stopForegroundMonitor();
        mainHandler.removeCallbacks(uiTickerRunnable);
        hideTopNotificationPopup();
        hideLongPressPopupMenu();
        hideFloatingMenu();
        if (bubbleView != null && windowManager != null) {
            try {
                windowManager.removeView(bubbleView);
            } catch (IllegalArgumentException ignored) {
            }
            bubbleView = null;
        }
        stopCapturePipeline();
        stopForeground(STOP_FOREGROUND_REMOVE);
        stopSelf();
    }

    private void showToast(String message) {
        mainHandler.post(() -> Toast.makeText(getApplicationContext(), message, Toast.LENGTH_SHORT).show());
    }

    @Override
    public void onDestroy() {
        stopForegroundMonitor();
        mainHandler.removeCallbacks(uiTickerRunnable);
        hideTopNotificationPopup();
        hideLongPressPopupMenu();
        hideFloatingMenu();
        if (bubbleView != null && windowManager != null) {
            try {
                windowManager.removeView(bubbleView);
            } catch (IllegalArgumentException ignored) {
            }
            bubbleView = null;
        }
        stopCapturePipeline();
        exportExecutor.shutdownNow();
        super.onDestroy();
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}

package com.clipkaro.app;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ServiceInfo;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioPlaybackCaptureConfiguration;
import android.media.AudioRecord;
import android.media.MediaCodec;
import android.media.MediaCodecInfo;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.media.MediaMuxer;
import android.media.MediaRecorder;
import android.media.MediaScannerConnection;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.provider.MediaStore;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.Surface;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;
import androidx.core.content.ContextCompat;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

public class FloatingClipService extends Service {

    public static final String ACTION_START = "com.clipkaro.app.action.START_FLOATING";
    public static final String ACTION_STOP = "com.clipkaro.app.action.STOP_FLOATING";
    public static final String EXTRA_RESULT_CODE = "result_code";
    public static final String EXTRA_RESULT_DATA = "result_data";
    public static final String EXTRA_GAME_NAME = "game_name";

    private static final String CHANNEL_ID = "clipkaro_floating_channel";
    private static final int NOTIFICATION_ID = 7001;

    private static final int SEGMENT_DURATION_MS = 5000;
    private static final int MAX_BUFFER_SEGMENTS = 14; // ~70s rolling gameplay buffer
    private static final int VIDEO_BITRATE = 4_000_000;
    private static final int VIDEO_FPS = 30;
    private static final int AUDIO_SAMPLE_RATE = 44100;
    private static final int AUDIO_BITRATE = 128_000;

    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final ExecutorService exportExecutor = Executors.newSingleThreadExecutor();
    private final Object muxerLock = new Object();

    private WindowManager windowManager;
    private FrameLayout bubbleView;
    private LinearLayout menuView;
    private WindowManager.LayoutParams bubbleParams;
    private WindowManager.LayoutParams menuParams;
    private boolean isMenuVisible = false;

    private TextView menuStatusView;
    private Button fullRecordBtn;

    private String activeGameName = "BGMI";
    private int projectionResultCode = Activity.RESULT_CANCELED;
    private Intent projectionResultData = null;

    // MediaProjection & Encoding State
    private MediaProjection mediaProjection;
    private VirtualDisplay virtualDisplay;
    private Surface encoderSurface;
    private MediaCodec videoEncoder;
    private MediaCodec audioEncoder;
    private AudioRecord audioRecord;

    private final AtomicBoolean isCapturing = new AtomicBoolean(false);
    private final AtomicBoolean isRecordingFull = new AtomicBoolean(false);
    private final AtomicBoolean splitSegmentRequested = new AtomicBoolean(false);

    private Thread videoThread;
    private Thread audioThread;

    private File bufferDir;
    private final List<File> completedSegments = new ArrayList<>();
    private File currentSegmentFile;
    private MediaMuxer segmentMuxer;
    private int segVideoTrack = -1;
    private int segAudioTrack = -1;
    private boolean segMuxerStarted = false;
    private long currentSegmentStartUs = -1L;

    private MediaFormat latestVideoFormat;
    private MediaFormat latestAudioFormat;

    // Optional Full Gameplay Continuous Output
    private File fullTempFile;
    private MediaMuxer fullMuxer;
    private int fullVideoTrack = -1;
    private int fullAudioTrack = -1;
    private boolean fullMuxerStarted = false;
    private boolean fullWaitingForKeyframe = false;
    private long fullStartMs = 0L;

    private int segmentIndex = 0;

    @Override
    public void onCreate() {
        super.onCreate();
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        bufferDir = new File(getCacheDir(), "clipkaro_buffer");
        if (!bufferDir.exists()) {
            //noinspection ResultOfMethodCallIgnored
            bufferDir.mkdirs();
        }
        createNotificationChannel();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            stopEverythingAndSelf();
            return START_NOT_STICKY;
        }

        if (intent != null) {
            String game = intent.getStringExtra(EXTRA_GAME_NAME);
            if (game != null && !game.trim().isEmpty()) {
                activeGameName = game.trim();
            }
            if (intent.hasExtra(EXTRA_RESULT_CODE) && intent.hasExtra(EXTRA_RESULT_DATA)) {
                int code = intent.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED);
                Intent data = getParcelableIntentExtra(intent, EXTRA_RESULT_DATA);
                if (code == Activity.RESULT_OK && data != null) {
                    projectionResultCode = code;
                    projectionResultData = data;
                }
            }
        }

        startForegroundWithType(projectionResultData != null);
        ensureOverlayBubbleShown();
        updateMenuStatusText();

        if (projectionResultData != null && !isCapturing.get()) {
            startRollingCapture();
        }

        return START_STICKY;
    }

    @SuppressWarnings("deprecation")
    private Intent getParcelableIntentExtra(Intent source, String key) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            return source.getParcelableExtra(key, Intent.class);
        }
        return source.getParcelableExtra(key);
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID,
                "ClipKaro Floating CLIP",
                NotificationManager.IMPORTANCE_LOW
            );
            channel.setDescription("Keeps ClipKaro floating CLIP bubble active over games");
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null) {
                nm.createNotificationChannel(channel);
            }
        }
    }

    private void startForegroundWithType(boolean hasMediaProjection) {
        Intent openIntent = new Intent(this, MainActivity.class);
        openIntent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
        int piFlags = PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE;
        PendingIntent contentIntent = PendingIntent.getActivity(this, 0, openIntent, piFlags);

        Intent stopIntent = new Intent(this, FloatingClipService.class);
        stopIntent.setAction(ACTION_STOP);
        PendingIntent stopPending = PendingIntent.getService(this, 1, stopIntent, piFlags);

        String subtitle = hasMediaProjection
            ? "Buffering HD gameplay + game sound for " + activeGameName
            : "Tap floating CLIP bubble to clip or record " + activeGameName;

        Notification notification = new NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("ClipKaro Floating CLIP Active")
            .setContentText(subtitle)
            .setSmallIcon(R.drawable.ic_clip_scissors)
            .setContentIntent(contentIntent)
            .addAction(0, "Stop", stopPending)
            .setOngoing(true)
            .build();

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            int fgsType;
            if (hasMediaProjection) {
                fgsType = ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION;
                if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
                    == PackageManager.PERMISSION_GRANTED) {
                    fgsType |= ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE;
                }
            } else {
                fgsType = ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE;
            }
            startForeground(NOTIFICATION_ID, notification, fgsType);
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q && hasMediaProjection) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            );
        } else {
            startForeground(NOTIFICATION_ID, notification);
        }
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    @SuppressLint("ClickableViewAccessibility")
    private void ensureOverlayBubbleShown() {
        if (bubbleView != null || windowManager == null) {
            return;
        }

        int overlayType = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
            ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            : WindowManager.LayoutParams.TYPE_PHONE;

        int bubbleSize = dp(60);
        bubbleParams = new WindowManager.LayoutParams(
            bubbleSize,
            bubbleSize,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        );
        bubbleParams.gravity = Gravity.TOP | Gravity.START;
        bubbleParams.x = dp(18);
        bubbleParams.y = dp(160);

        bubbleView = new FrameLayout(this);
        GradientDrawable bg = new GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            new int[]{Color.parseColor("#F43F5E"), Color.parseColor("#BE123C")}
        );
        bg.setShape(GradientDrawable.OVAL);
        bg.setStroke(dp(2), Color.parseColor("#FFFFFF"));
        bubbleView.setBackground(bg);
        bubbleView.setElevation(dp(10));

        ImageView icon = new ImageView(this);
        icon.setImageResource(R.drawable.ic_clip_scissors);
        FrameLayout.LayoutParams iconLp = new FrameLayout.LayoutParams(dp(28), dp(28));
        iconLp.gravity = Gravity.CENTER;
        bubbleView.addView(icon, iconLp);

        bubbleView.setOnTouchListener(new View.OnTouchListener() {
            private int initialX;
            private int initialY;
            private float downRawX;
            private float downRawY;
            private boolean isDragging;

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                DisplayMetrics dm = getResources().getDisplayMetrics();
                switch (event.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        initialX = bubbleParams.x;
                        initialY = bubbleParams.y;
                        downRawX = event.getRawX();
                        downRawY = event.getRawY();
                        isDragging = false;
                        return true;

                    case MotionEvent.ACTION_MOVE:
                        float dx = event.getRawX() - downRawX;
                        float dy = event.getRawY() - downRawY;
                        if (Math.hypot(dx, dy) > dp(8)) {
                            isDragging = true;
                        }
                        if (isDragging) {
                            int maxX = Math.max(0, dm.widthPixels - bubbleSize);
                            int maxY = Math.max(0, dm.heightPixels - bubbleSize);
                            bubbleParams.x = Math.max(0, Math.min(maxX, Math.round(initialX + dx)));
                            bubbleParams.y = Math.max(dp(24), Math.min(maxY, Math.round(initialY + dy)));
                            windowManager.updateViewLayout(bubbleView, bubbleParams);
                            if (isMenuVisible && menuView != null) {
                                positionMenuNearBubble();
                                windowManager.updateViewLayout(menuView, menuParams);
                            }
                        }
                        return true;

                    case MotionEvent.ACTION_UP:
                        if (!isDragging) {
                            toggleFloatingMenu();
                        }
                        return true;

                    default:
                        return false;
                }
            }
        });

        windowManager.addView(bubbleView, bubbleParams);
    }

    private void positionMenuNearBubble() {
        if (menuParams == null || bubbleParams == null) return;
        DisplayMetrics dm = getResources().getDisplayMetrics();
        int menuWidth = dp(248);
        int targetX = bubbleParams.x + dp(68);
        if (targetX + menuWidth > dm.widthPixels - dp(12)) {
            targetX = Math.max(dp(12), bubbleParams.x - menuWidth - dp(8));
        }
        int targetY = Math.max(dp(36), Math.min(dm.heightPixels - dp(320), bubbleParams.y));
        menuParams.x = targetX;
        menuParams.y = targetY;
    }

    private void toggleFloatingMenu() {
        if (isMenuVisible) {
            hideFloatingMenu();
        } else {
            showFloatingMenu();
        }
    }

    private void showFloatingMenu() {
        if (windowManager == null) return;
        if (menuView == null) {
            buildFloatingMenu();
        }
        positionMenuNearBubble();
        updateMenuStatusText();
        if (!isMenuVisible) {
            windowManager.addView(menuView, menuParams);
            isMenuVisible = true;
        }
    }

    private void hideFloatingMenu() {
        if (isMenuVisible && menuView != null && windowManager != null) {
            try {
                windowManager.removeView(menuView);
            } catch (IllegalArgumentException ignored) {
            }
            isMenuVisible = false;
        }
    }

    private void buildFloatingMenu() {
        int overlayType = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
            ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            : WindowManager.LayoutParams.TYPE_PHONE;

        menuParams = new WindowManager.LayoutParams(
            dp(248),
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        );
        menuParams.gravity = Gravity.TOP | Gravity.START;

        menuView = new LinearLayout(this);
        menuView.setOrientation(LinearLayout.VERTICAL);
        menuView.setPadding(dp(12), dp(12), dp(12), dp(12));

        GradientDrawable cardBg = new GradientDrawable();
        cardBg.setColor(Color.parseColor("#F20F172A"));
        cardBg.setCornerRadius(dp(14));
        cardBg.setStroke(dp(1), Color.parseColor("#334155"));
        menuView.setBackground(cardBg);
        menuView.setElevation(dp(12));

        // Title Row
        LinearLayout headerRow = new LinearLayout(this);
        headerRow.setOrientation(LinearLayout.HORIZONTAL);
        headerRow.setGravity(Gravity.CENTER_VERTICAL);

        TextView titleTv = new TextView(this);
        titleTv.setText("ClipKaro CLIP");
        titleTv.setTextColor(Color.WHITE);
        titleTv.setTextSize(14);
        titleTv.setTypeface(Typeface.DEFAULT_BOLD);
        LinearLayout.LayoutParams titleLp = new LinearLayout.LayoutParams(
            0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f
        );
        headerRow.addView(titleTv, titleLp);

        TextView closeTv = new TextView(this);
        closeTv.setText("Hide");
        closeTv.setTextColor(Color.parseColor("#94A3B8"));
        closeTv.setTextSize(12);
        closeTv.setPadding(dp(8), dp(2), dp(4), dp(2));
        closeTv.setOnClickListener(v -> hideFloatingMenu());
        headerRow.addView(closeTv);
        menuView.addView(headerRow);

        menuStatusView = new TextView(this);
        menuStatusView.setTextColor(Color.parseColor("#CBD5E1"));
        menuStatusView.setTextSize(11);
        menuStatusView.setPadding(0, dp(3), 0, dp(10));
        menuView.addView(menuStatusView);

        // Clip Duration Grid (10s - 60s)
        GridLayout grid = new GridLayout(this);
        grid.setColumnCount(2);
        int[] durations = new int[]{10, 20, 30, 40, 50, 60};
        for (int sec : durations) {
            Button btn = createMenuButton(sec + "s Clip", "#1E293B", "#F8FAFC");
            GridLayout.LayoutParams gp = new GridLayout.LayoutParams();
            gp.width = 0;
            gp.columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f);
            gp.setMargins(dp(3), dp(3), dp(3), dp(3));
            btn.setOnClickListener(v -> onClipDurationTapped(sec));
            grid.addView(btn, gp);
        }
        menuView.addView(grid);

        // Record Full Gameplay Button
        fullRecordBtn = createMenuButton("Record Full Gameplay", "#E11D48", "#FFFFFF");
        LinearLayout.LayoutParams fullLp = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        );
        fullLp.topMargin = dp(8);
        fullRecordBtn.setOnClickListener(v -> onToggleFullGameplay());
        menuView.addView(fullRecordBtn, fullLp);

        // Stop Button
        Button stopBtn = createMenuButton("Stop", "#334155", "#FCA5A5");
        LinearLayout.LayoutParams stopLp = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        );
        stopLp.topMargin = dp(6);
        stopBtn.setOnClickListener(v -> stopEverythingAndSelf());
        menuView.addView(stopBtn, stopLp);
    }

    private Button createMenuButton(String label, String bgHex, String textHex) {
        Button btn = new Button(this);
        btn.setText(label);
        btn.setAllCaps(false);
        btn.setTextSize(12);
        btn.setTypeface(Typeface.DEFAULT_BOLD);
        btn.setTextColor(Color.parseColor(textHex));
        btn.setPadding(dp(8), dp(8), dp(8), dp(8));
        btn.setMinHeight(0);
        btn.setMinimumHeight(dp(36));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.parseColor(bgHex));
        bg.setCornerRadius(dp(8));
        btn.setBackground(bg);
        return btn;
    }

    private void updateMenuStatusText() {
        mainHandler.post(() -> {
            if (menuStatusView != null) {
                if (isRecordingFull.get()) {
                    long elapsedSec = Math.max(0L, (System.currentTimeMillis() - fullStartMs) / 1000L);
                    menuStatusView.setText(
                        String.format(Locale.US, "%s · Recording Full Gameplay (%ds)", activeGameName, elapsedSec)
                    );
                    menuStatusView.setTextColor(Color.parseColor("#FDA4AF"));
                } else if (isCapturing.get()) {
                    menuStatusView.setText(activeGameName + " · HD Buffer + Game Sound Ready");
                    menuStatusView.setTextColor(Color.parseColor("#6EE7B7"));
                } else {
                    menuStatusView.setText(activeGameName + " · Tap any option to enable Screen Capture");
                    menuStatusView.setTextColor(Color.parseColor("#FDE68A"));
                }
            }
            if (fullRecordBtn != null) {
                fullRecordBtn.setText(
                    isRecordingFull.get() ? "Stop & Save Full Gameplay" : "Record Full Gameplay"
                );
            }
        });
    }

    private void onClipDurationTapped(int seconds) {
        if (!isCapturing.get()) {
            promptMainForScreenCapture();
            return;
        }
        hideFloatingMenu();
        showToast("Saving last " + seconds + "s " + activeGameName + " clip…");
        exportExecutor.execute(() -> exportLastSecondsClip(seconds));
    }

    private void onToggleFullGameplay() {
        if (!isCapturing.get()) {
            promptMainForScreenCapture();
            return;
        }
        if (isRecordingFull.get()) {
            hideFloatingMenu();
            showToast("Saving full " + activeGameName + " gameplay…");
            exportExecutor.execute(this::finishFullGameplayRecording);
        } else {
            startFullGameplayRecording();
            hideFloatingMenu();
            showToast("Recording full " + activeGameName + " gameplay in HD…");
        }
        updateMenuStatusText();
    }

    private void promptMainForScreenCapture() {
        Intent intent = new Intent(this, MainActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        intent.putExtra(MainActivity.EXTRA_REQUEST_PROJECTION_GAME, activeGameName);
        startActivity(intent);
        showToast("Allow screen capture in ClipKaro to clip " + activeGameName);
    }

    private void startRollingCapture() {
        if (projectionResultData == null || isCapturing.get()) {
            return;
        }

        MediaProjectionManager mpm =
            (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);
        if (mpm == null) return;

        mediaProjection = mpm.getMediaProjection(projectionResultCode, projectionResultData);
        if (mediaProjection == null) return;

        mediaProjection.registerCallback(new MediaProjection.Callback() {
            @Override
            public void onStop() {
                mainHandler.post(() -> {
                    stopCapturePipeline();
                    updateMenuStatusText();
                });
            }
        }, mainHandler);

        DisplayMetrics dm = getResources().getDisplayMetrics();
        int rawW = Math.max(720, dm.widthPixels);
        int rawH = Math.max(720, dm.heightPixels);
        int maxDim = Math.max(rawW, rawH);
        double scale = maxDim > 1280 ? (1280.0 / maxDim) : 1.0;
        int encW = Math.max(320, ((int) Math.round(rawW * scale) / 16) * 16);
        int encH = Math.max(320, ((int) Math.round(rawH * scale) / 16) * 16);

        try {
            MediaFormat videoFormat = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, encW, encH);
            videoFormat.setInteger(
                MediaFormat.KEY_COLOR_FORMAT,
                MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface
            );
            videoFormat.setInteger(MediaFormat.KEY_BIT_RATE, VIDEO_BITRATE);
            videoFormat.setInteger(MediaFormat.KEY_FRAME_RATE, VIDEO_FPS);
            videoFormat.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1);

            videoEncoder = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC);
            videoEncoder.configure(videoFormat, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE);
            encoderSurface = videoEncoder.createInputSurface();
            videoEncoder.start();

            virtualDisplay = mediaProjection.createVirtualDisplay(
                "ClipKaroCapture",
                encW,
                encH,
                dm.densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                encoderSurface,
                null,
                null
            );

            setupAudioCapture();
            isCapturing.set(true);

            videoThread = new Thread(this::runVideoDrainLoop, "ClipKaroVideoDrain");
            videoThread.start();
            if (audioRecord != null && audioEncoder != null) {
                audioThread = new Thread(this::runAudioCaptureLoop, "ClipKaroAudioLoop");
                audioThread.start();
            }

            updateMenuStatusText();
        } catch (Exception e) {
            stopCapturePipeline();
            showToast("Screen capture setup failed: " + e.getMessage());
        }
    }

    @SuppressLint("MissingPermission")
    private void setupAudioCapture() {
        try {
            int minBuf = AudioRecord.getMinBufferSize(
                AUDIO_SAMPLE_RATE,
                AudioFormat.CHANNEL_IN_STEREO,
                AudioFormat.ENCODING_PCM_16BIT
            );
            int bufSize = Math.max(minBuf * 2, 8192);

            AudioFormat audioFormat = new AudioFormat.Builder()
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setSampleRate(AUDIO_SAMPLE_RATE)
                .setChannelMask(AudioFormat.CHANNEL_IN_STEREO)
                .build();

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q && mediaProjection != null) {
                AudioPlaybackCaptureConfiguration config =
                    new AudioPlaybackCaptureConfiguration.Builder(mediaProjection)
                        .addMatchingUsage(AudioAttributes.USAGE_GAME)
                        .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
                        .build();
                audioRecord = new AudioRecord.Builder()
                    .setAudioPlaybackCaptureConfig(config)
                    .setAudioFormat(audioFormat)
                    .setBufferSizeInBytes(bufSize)
                    .build();
            } else if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
                == PackageManager.PERMISSION_GRANTED) {
                audioRecord = new AudioRecord.Builder()
                    .setAudioSource(MediaRecorder.AudioSource.MIC)
                    .setAudioFormat(audioFormat)
                    .setBufferSizeInBytes(bufSize)
                    .build();
            }

            if (audioRecord != null && audioRecord.getState() == AudioRecord.STATE_INITIALIZED) {
                MediaFormat encFormat = MediaFormat.createAudioFormat(
                    MediaFormat.MIMETYPE_AUDIO_AAC,
                    AUDIO_SAMPLE_RATE,
                    2
                );
                encFormat.setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC);
                encFormat.setInteger(MediaFormat.KEY_BIT_RATE, AUDIO_BITRATE);
                encFormat.setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, bufSize);

                audioEncoder = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC);
                audioEncoder.configure(encFormat, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE);
                audioEncoder.start();
                audioRecord.startRecording();
            } else {
                if (audioRecord != null) {
                    audioRecord.release();
                    audioRecord = null;
                }
            }
        } catch (Exception ignored) {
            if (audioRecord != null) {
                try {
                    audioRecord.release();
                } catch (Exception ignored2) {
                }
                audioRecord = null;
            }
            if (audioEncoder != null) {
                try {
                    audioEncoder.release();
                } catch (Exception ignored2) {
                }
                audioEncoder = null;
            }
        }
    }

    private void openNextSegmentMuxerLocked(long firstPtsUs) {
        closeCurrentSegmentLocked(true);
        if (latestVideoFormat == null) return;

        try {
            File nextFile = new File(bufferDir, "seg_" + (segmentIndex++) + ".mp4");
            MediaMuxer muxer = new MediaMuxer(nextFile.getAbsolutePath(), MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);
            segVideoTrack = muxer.addTrack(latestVideoFormat);
            segAudioTrack = latestAudioFormat != null ? muxer.addTrack(latestAudioFormat) : -1;
            muxer.start();

            currentSegmentFile = nextFile;
            segmentMuxer = muxer;
            segMuxerStarted = true;
            currentSegmentStartUs = firstPtsUs;
        } catch (IOException ignored) {
            segmentMuxer = null;
            segMuxerStarted = false;
        }
    }

    private void closeCurrentSegmentLocked(boolean keepFile) {
        if (segmentMuxer != null) {
            try {
                if (segMuxerStarted) {
                    segmentMuxer.stop();
                }
            } catch (Exception ignored) {
            }
            try {
                segmentMuxer.release();
            } catch (Exception ignored) {
            }
            segmentMuxer = null;
            segMuxerStarted = false;
        }
        if (currentSegmentFile != null) {
            if (keepFile && currentSegmentFile.exists() && currentSegmentFile.length() > 1024) {
                completedSegments.add(currentSegmentFile);
                while (completedSegments.size() > MAX_BUFFER_SEGMENTS) {
                    File oldest = completedSegments.remove(0);
                    //noinspection ResultOfMethodCallIgnored
                    oldest.delete();
                }
            } else {
                //noinspection ResultOfMethodCallIgnored
                currentSegmentFile.delete();
            }
            currentSegmentFile = null;
        }
        currentSegmentStartUs = -1L;
    }

    private void runVideoDrainLoop() {
        MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
        while (isCapturing.get()) {
            try {
                int outIndex = videoEncoder.dequeueOutputBuffer(info, 10_000);
                if (outIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    synchronized (muxerLock) {
                        latestVideoFormat = videoEncoder.getOutputFormat();
                    }
                } else if (outIndex >= 0) {
                    ByteBuffer outBuf = videoEncoder.getOutputBuffer(outIndex);
                    if (outBuf != null && (info.flags & MediaCodec.BUFFER_FLAG_CODEC_CONFIG) == 0 && info.size > 0) {
                        boolean isKeyFrame = (info.flags & MediaCodec.BUFFER_FLAG_KEY_FRAME) != 0;
                        synchronized (muxerLock) {
                            if (currentSegmentStartUs > 0
                                && (info.presentationTimeUs - currentSegmentStartUs) >= SEGMENT_DURATION_MS * 1000L
                                && isKeyFrame) {
                                openNextSegmentMuxerLocked(info.presentationTimeUs);
                            } else if (!segMuxerStarted && isKeyFrame) {
                                openNextSegmentMuxerLocked(info.presentationTimeUs);
                            } else if (splitSegmentRequested.get() && isKeyFrame) {
                                splitSegmentRequested.set(false);
                                openNextSegmentMuxerLocked(info.presentationTimeUs);
                            }

                            if (segMuxerStarted && segmentMuxer != null && segVideoTrack >= 0) {
                                outBuf.position(info.offset);
                                outBuf.limit(info.offset + info.size);
                                segmentMuxer.writeSampleData(segVideoTrack, outBuf, info);
                            }

                            if (isRecordingFull.get() && fullMuxer != null) {
                                if (!fullMuxerStarted && isKeyFrame && latestVideoFormat != null) {
                                    fullVideoTrack = fullMuxer.addTrack(latestVideoFormat);
                                    fullAudioTrack = latestAudioFormat != null ? fullMuxer.addTrack(latestAudioFormat) : -1;
                                    fullMuxer.start();
                                    fullMuxerStarted = true;
                                    fullWaitingForKeyframe = false;
                                }
                                if (fullMuxerStarted && !fullWaitingForKeyframe && fullVideoTrack >= 0) {
                                    outBuf.position(info.offset);
                                    outBuf.limit(info.offset + info.size);
                                    fullMuxer.writeSampleData(fullVideoTrack, outBuf, info);
                                }
                            }
                        }
                    }
                    videoEncoder.releaseOutputBuffer(outIndex, false);
                }
            } catch (Exception e) {
                if (!isCapturing.get()) break;
            }
        }
    }

    private void runAudioCaptureLoop() {
        byte[] pcmBuffer = new byte[4096];
        MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
        long startNano = System.nanoTime();

        while (isCapturing.get() && audioRecord != null && audioEncoder != null) {
            try {
                int readBytes = audioRecord.read(pcmBuffer, 0, pcmBuffer.length);
                if (readBytes > 0) {
                    int inIndex = audioEncoder.dequeueInputBuffer(5000);
                    if (inIndex >= 0) {
                        ByteBuffer inBuf = audioEncoder.getInputBuffer(inIndex);
                        if (inBuf != null) {
                            inBuf.clear();
                            inBuf.put(pcmBuffer, 0, Math.min(readBytes, inBuf.capacity()));
                            long ptsUs = (System.nanoTime() - startNano) / 1000L;
                            audioEncoder.queueInputBuffer(inIndex, 0, readBytes, ptsUs, 0);
                        }
                    }
                }

                int outIndex = audioEncoder.dequeueOutputBuffer(info, 0);
                while (outIndex >= 0 || outIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    if (outIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                        synchronized (muxerLock) {
                            latestAudioFormat = audioEncoder.getOutputFormat();
                        }
                    } else if (outIndex >= 0) {
                        ByteBuffer outBuf = audioEncoder.getOutputBuffer(outIndex);
                        if (outBuf != null && (info.flags & MediaCodec.BUFFER_FLAG_CODEC_CONFIG) == 0 && info.size > 0) {
                            synchronized (muxerLock) {
                                if (segMuxerStarted && segmentMuxer != null && segAudioTrack >= 0) {
                                    outBuf.position(info.offset);
                                    outBuf.limit(info.offset + info.size);
                                    segmentMuxer.writeSampleData(segAudioTrack, outBuf, info);
                                }
                                if (isRecordingFull.get() && fullMuxerStarted && fullMuxer != null && fullAudioTrack >= 0) {
                                    outBuf.position(info.offset);
                                    outBuf.limit(info.offset + info.size);
                                    fullMuxer.writeSampleData(fullAudioTrack, outBuf, info);
                                }
                            }
                        }
                        audioEncoder.releaseOutputBuffer(outIndex, false);
                    }
                    outIndex = audioEncoder.dequeueOutputBuffer(info, 0);
                }
            } catch (Exception e) {
                if (!isCapturing.get()) break;
            }
        }
    }

    private void exportLastSecondsClip(int targetSeconds) {
        try {
            if (videoEncoder != null) {
                Bundle sync = new Bundle();
                sync.putInt(MediaCodec.PARAMETER_KEY_REQUEST_SYNC_FRAME, 0);
                videoEncoder.setParameters(sync);
            }
            splitSegmentRequested.set(true);
            try {
                Thread.sleep(350);
            } catch (InterruptedException ignored) {
            }

            List<File> sourceFiles;
            synchronized (muxerLock) {
                closeCurrentSegmentLocked(true);
                int neededCount = Math.max(1, (int) Math.ceil(targetSeconds / (SEGMENT_DURATION_MS / 1000.0)));
                int startIdx = Math.max(0, completedSegments.size() - neededCount);
                sourceFiles = new ArrayList<>(completedSegments.subList(startIdx, completedSegments.size()));
            }

            if (sourceFiles.isEmpty()) {
                showToast("Buffering gameplay — wait a few seconds and tap Clip again.");
                return;
            }

            String safeGame = activeGameName.replaceAll("[^A-Za-z0-9_]+", "_");
            String fileName = String.format(
                Locale.US,
                "ClipKaro_%s_%ds_%d.mp4",
                safeGame,
                targetSeconds,
                System.currentTimeMillis()
            );
            File tempOut = new File(getCacheDir(), fileName);
            stitchMp4Segments(sourceFiles, tempOut, targetSeconds * 1_000_000L);

            if (tempOut.exists() && tempOut.length() > 1024) {
                saveMp4ToMoviesGallery(tempOut, fileName);
                //noinspection ResultOfMethodCallIgnored
                tempOut.delete();
                showToast("Saved " + targetSeconds + "s " + activeGameName + " clip to Movies/ClipKaro");
            } else {
                showToast("Unable to save clip yet — play for a few seconds first.");
            }
        } catch (Exception e) {
            showToast("Clip export failed: " + e.getMessage());
        }
    }

    private void stitchMp4Segments(List<File> segments, File outFile, long maxDurationUs) throws IOException {
        MediaMuxer outMuxer = new MediaMuxer(outFile.getAbsolutePath(), MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);
        int outVideoTrack = -1;
        int outAudioTrack = -1;
        boolean muxerStarted = false;

        long totalVideoOffsetUs = 0L;
        long totalAudioOffsetUs = 0L;
        ByteBuffer buffer = ByteBuffer.allocate(1024 * 1024);
        MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();

        // Keep segments whose combined tail fits target duration cleanly
        List<File> chosen = new ArrayList<>(segments);
        Collections.reverse(chosen);
        List<File> orderedTail = new ArrayList<>();
        long approxUs = 0L;
        for (File seg : chosen) {
            orderedTail.add(0, seg);
            approxUs += SEGMENT_DURATION_MS * 1000L;
            if (approxUs >= maxDurationUs) break;
        }

        try {
            for (File seg : orderedTail) {
                MediaExtractor extractor = new MediaExtractor();
                try {
                    extractor.setDataSource(seg.getAbsolutePath());
                    int srcVideo = -1;
                    int srcAudio = -1;
                    MediaFormat vFmt = null;
                    MediaFormat aFmt = null;

                    for (int i = 0; i < extractor.getTrackCount(); i++) {
                        MediaFormat fmt = extractor.getTrackFormat(i);
                        String mime = fmt.getString(MediaFormat.KEY_MIME);
                        if (mime != null && mime.startsWith("video/") && srcVideo < 0) {
                            srcVideo = i;
                            vFmt = fmt;
                        } else if (mime != null && mime.startsWith("audio/") && srcAudio < 0) {
                            srcAudio = i;
                            aFmt = fmt;
                        }
                    }

                    if (!muxerStarted) {
                        if (vFmt != null) outVideoTrack = outMuxer.addTrack(vFmt);
                        if (aFmt != null) outAudioTrack = outMuxer.addTrack(aFmt);
                        if (outVideoTrack >= 0 || outAudioTrack >= 0) {
                            outMuxer.start();
                            muxerStarted = true;
                        }
                    }

                    if (!muxerStarted) continue;

                    long segMaxVideoUs = 0L;
                    long segFirstVideoUs = -1L;
                    if (srcVideo >= 0 && outVideoTrack >= 0) {
                        extractor.selectTrack(srcVideo);
                        while (true) {
                            int size = extractor.readSampleData(buffer, 0);
                            if (size < 0) break;
                            long sampleTime = extractor.getSampleTime();
                            if (segFirstVideoUs < 0) segFirstVideoUs = sampleTime;
                            long relUs = Math.max(0L, sampleTime - segFirstVideoUs);
                            info.offset = 0;
                            info.size = size;
                            info.presentationTimeUs = totalVideoOffsetUs + relUs;
                            //noinspection WrongConstant
                            info.flags = extractor.getSampleFlags();
                            outMuxer.writeSampleData(outVideoTrack, buffer, info);
                            segMaxVideoUs = Math.max(segMaxVideoUs, relUs);
                            extractor.advance();
                        }
                        extractor.unselectTrack(srcVideo);
                    }

                    long segMaxAudioUs = 0L;
                    long segFirstAudioUs = -1L;
                    if (srcAudio >= 0 && outAudioTrack >= 0) {
                        extractor.selectTrack(srcAudio);
                        while (true) {
                            int size = extractor.readSampleData(buffer, 0);
                            if (size < 0) break;
                            long sampleTime = extractor.getSampleTime();
                            if (segFirstAudioUs < 0) segFirstAudioUs = sampleTime;
                            long relUs = Math.max(0L, sampleTime - segFirstAudioUs);
                            info.offset = 0;
                            info.size = size;
                            info.presentationTimeUs = totalAudioOffsetUs + relUs;
                            //noinspection WrongConstant
                            info.flags = extractor.getSampleFlags();
                            outMuxer.writeSampleData(outAudioTrack, buffer, info);
                            segMaxAudioUs = Math.max(segMaxAudioUs, relUs);
                            extractor.advance();
                        }
                        extractor.unselectTrack(srcAudio);
                    }

                    totalVideoOffsetUs += segMaxVideoUs + 33_333L;
                    totalAudioOffsetUs += Math.max(segMaxAudioUs, segMaxVideoUs) + 23_220L;
                } finally {
                    extractor.release();
                }
            }
        } finally {
            try {
                if (muxerStarted) outMuxer.stop();
            } catch (Exception ignored) {
            }
            outMuxer.release();
        }
    }

    private void startFullGameplayRecording() {
        synchronized (muxerLock) {
            if (isRecordingFull.get()) return;
            String safeGame = activeGameName.replaceAll("[^A-Za-z0-9_]+", "_");
            fullTempFile = new File(
                getCacheDir(),
                "ClipKaro_Full_" + safeGame + "_" + System.currentTimeMillis() + ".mp4"
            );
            try {
                fullMuxer = new MediaMuxer(fullTempFile.getAbsolutePath(), MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);
                fullMuxerStarted = false;
                fullWaitingForKeyframe = true;
                fullVideoTrack = -1;
                fullAudioTrack = -1;
                fullStartMs = System.currentTimeMillis();
                isRecordingFull.set(true);

                if (videoEncoder != null) {
                    Bundle sync = new Bundle();
                    sync.putInt(MediaCodec.PARAMETER_KEY_REQUEST_SYNC_FRAME, 0);
                    videoEncoder.setParameters(sync);
                }
            } catch (IOException e) {
                fullMuxer = null;
                isRecordingFull.set(false);
            }
        }
    }

    private void finishFullGameplayRecording() {
        File finishedFile;
        synchronized (muxerLock) {
            if (!isRecordingFull.get()) return;
            isRecordingFull.set(false);
            if (fullMuxer != null) {
                try {
                    if (fullMuxerStarted) fullMuxer.stop();
                } catch (Exception ignored) {
                }
                try {
                    fullMuxer.release();
                } catch (Exception ignored) {
                }
                fullMuxer = null;
                fullMuxerStarted = false;
            }
            finishedFile = fullTempFile;
            fullTempFile = null;
        }

        if (finishedFile != null && finishedFile.exists() && finishedFile.length() > 1024) {
            try {
                saveMp4ToMoviesGallery(finishedFile, finishedFile.getName());
                showToast("Saved full " + activeGameName + " gameplay to Movies/ClipKaro");
            } catch (IOException e) {
                showToast("Failed to save gameplay: " + e.getMessage());
            } finally {
                //noinspection ResultOfMethodCallIgnored
                finishedFile.delete();
            }
        }
        updateMenuStatusText();
    }

    private void saveMp4ToMoviesGallery(File sourceFile, String displayName) throws IOException {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            ContentResolver resolver = getContentResolver();
            ContentValues values = new ContentValues();
            values.put(MediaStore.Video.Media.DISPLAY_NAME, displayName);
            values.put(MediaStore.Video.Media.MIME_TYPE, "video/mp4");
            values.put(
                MediaStore.Video.Media.RELATIVE_PATH,
                Environment.DIRECTORY_MOVIES + "/ClipKaro"
            );
            values.put(MediaStore.Video.Media.IS_PENDING, 1);

            Uri uri = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values);
            if (uri == null) {
                throw new IOException("MediaStore insert failed");
            }

            try (OutputStream out = resolver.openOutputStream(uri);
                 FileInputStream in = new FileInputStream(sourceFile)) {
                if (out == null) throw new IOException("Output stream unavailable");
                byte[] buf = new byte[16384];
                int n;
                while ((n = in.read(buf)) != -1) {
                    out.write(buf, 0, n);
                }
            }

            values.clear();
            values.put(MediaStore.Video.Media.IS_PENDING, 0);
            resolver.update(uri, values, null, null);
        } else {
            File moviesDir = new File(
                Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES),
                "ClipKaro"
            );
            if (!moviesDir.exists()) {
                //noinspection ResultOfMethodCallIgnored
                moviesDir.mkdirs();
            }
            File dest = new File(moviesDir, displayName);
            try (FileInputStream in = new FileInputStream(sourceFile);
                 OutputStream out = new java.io.FileOutputStream(dest)) {
                byte[] buf = new byte[16384];
                int n;
                while ((n = in.read(buf)) != -1) {
                    out.write(buf, 0, n);
                }
            }
            MediaScannerConnection.scanFile(
                this,
                new String[]{dest.getAbsolutePath()},
                new String[]{"video/mp4"},
                null
            );
        }
    }

    private void stopCapturePipeline() {
        isCapturing.set(false);
        if (isRecordingFull.get()) {
            finishFullGameplayRecording();
        }
        synchronized (muxerLock) {
            closeCurrentSegmentLocked(false);
            for (File seg : completedSegments) {
                //noinspection ResultOfMethodCallIgnored
                seg.delete();
            }
            completedSegments.clear();
        }
        if (virtualDisplay != null) {
            virtualDisplay.release();
            virtualDisplay = null;
        }
        if (encoderSurface != null) {
            encoderSurface.release();
            encoderSurface = null;
        }
        if (videoEncoder != null) {
            try {
                videoEncoder.stop();
            } catch (Exception ignored) {
            }
            try {
                videoEncoder.release();
            } catch (Exception ignored) {
            }
            videoEncoder = null;
        }
        if (audioRecord != null) {
            try {
                audioRecord.stop();
            } catch (Exception ignored) {
            }
            try {
                audioRecord.release();
            } catch (Exception ignored) {
            }
            audioRecord = null;
        }
        if (audioEncoder != null) {
            try {
                audioEncoder.stop();
            } catch (Exception ignored) {
            }
            try {
                audioEncoder.release();
            } catch (Exception ignored) {
            }
            audioEncoder = null;
        }
        if (mediaProjection != null) {
            mediaProjection.stop();
            mediaProjection = null;
        }
    }

    private void stopEverythingAndSelf() {
        hideFloatingMenu();
        if (bubbleView != null && windowManager != null) {
            try {
                windowManager.removeView(bubbleView);
            } catch (IllegalArgumentException ignored) {
            }
            bubbleView = null;
        }
        stopCapturePipeline();
        stopForeground(STOP_FOREGROUND_REMOVE);
        stopSelf();
    }

    private void showToast(String message) {
        mainHandler.post(() -> Toast.makeText(getApplicationContext(), message, Toast.LENGTH_SHORT).show());
    }

    @Override
    public void onDestroy() {
        hideFloatingMenu();
        if (bubbleView != null && windowManager != null) {
            try {
                windowManager.removeView(bubbleView);
            } catch (IllegalArgumentException ignored) {
            }
            bubbleView = null;
        }
        stopCapturePipeline();
        exportExecutor.shutdownNow();
        super.onDestroy();
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}

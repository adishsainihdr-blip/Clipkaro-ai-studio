# Build ClipKaro APK on Mobile (No Laptop Required)

You can compile `ClipKaro` into an installable Android `.apk` using only your smartphone in two ways:

---

## Method 1: Cloud Build via GitHub Browser (Easiest, Recommended)

This uses the included `.github/workflows/build-android-apk.yml` file to compile the APK on GitHub's cloud servers for free in ~2 minutes.

1. **Download & extract the project code on your phone**:
   - Tap **Download React + Android Code** inside ClipKaro to open the Project Files exporter.
   - Tap **Download Source + Android ZIP (Recommended)** to get `ClipKaro-React-Android-Source.zip` (~3.8 MB, fast on mobile — `npm install` auto-installs FFmpeg WASM), OR download `ClipKaro-complete-code.zip` if you want the offline FFmpeg WASM already bundled. You can also download or copy any React/Android file individually inside the exporter.
   - Open your phone's **Files** app (or **ZArchiver**) and extract the ZIP into a folder named `ClipKaro`.
2. **Create a GitHub repository in your mobile browser**:
   - Open Chrome on your phone and go to `https://github.com/new`.
   - Name the repository `ClipKaro`, keep it Public or Private, and tap **Create repository**.
3. **Upload the extracted files**:
   - On the empty repository page, tap **uploading an existing file**.
   - Select the files and folders from your extracted `ClipKaro` folder (including `.github`, `android`, `scripts`, `public`, `src`, `package.json`, `index.html`, `vite.config.ts`, `tsconfig.json`, `capacitor.config.json`, `metadata.json`).
   - Tap **Commit changes**.
4. **Run the APK build**:
   - Tap the **Actions** tab at the top of your GitHub repository.
   - Tap **Build ClipKaro Android APK** -> **Run workflow** (if it hasn't started automatically on push).
5. **Download & Install the APK**:
   - Once the workflow turns green (~2 minutes), scroll down to **Artifacts** and tap **ClipKaro-Debug-APK** to download the ZIP containing `app-debug.apk`.
   - Unzip it on your phone, tap `app-debug.apk`, allow **Install unknown apps** if prompted, and install **ClipKaro**.

---

## Method 2: Offline On-Device Build with Termux (Android)

If you want to build the APK directly on your Android phone offline:

1. Install **Termux** (from F-Droid) on your Android device.
2. Run these commands inside Termux:
   ```bash
   pkg update && pkg upgrade -y
   pkg install -y nodejs-lts openjdk-17 gradle unzip wget
   ```
3. Copy or extract `ClipKaro-complete-code.zip` into `~/ClipKaro`:
   ```bash
   mkdir -p ~/ClipKaro
   cd ~/ClipKaro
   unzip /sdcard/Download/ClipKaro-complete-code.zip -d .
   ```
4. Build the web bundle and sync it to Android assets:
   ```bash
   npm install
   npm run build
   mkdir -p android/app/src/main/assets/public
   cp -r dist/* android/app/src/main/assets/public/
   ```
5. Install Android SDK Command-Line Tools (`platform-tools`, `platforms;android-35`, `build-tools;35.0.0`) via `sdkmanager`, set `ANDROID_HOME`, then compile the APK:
   ```bash
   cd ~/ClipKaro/android
   gradle assembleDebug
   ```
6. Copy the built APK to your Downloads folder and tap it to install:
   ```bash
   cp app/build/outputs/apk/debug/app-debug.apk /sdcard/Download/ClipKaro.apk
   ```

---

## Permissions Included in `AndroidManifest.xml`
- **Record Audio**: `RECORD_AUDIO`, `MODIFY_AUDIO_SETTINGS`, `FOREGROUND_SERVICE_MICROPHONE`
- **Record Screen**: `FOREGROUND_SERVICE`, `FOREGROUND_SERVICE_MEDIA_PROJECTION`
- **Display Over Other Apps**: `SYSTEM_ALERT_WINDOW`
- **Storage**: `READ_MEDIA_VIDEO`, `READ_MEDIA_AUDIO`, `READ_MEDIA_IMAGES`, `READ_EXTERNAL_STORAGE`, `WRITE_EXTERNAL_STORAGE`
- **Installed Game Launching**: Package `<queries>` for `com.pubg.imobile` (BGMI), `com.dts.freefiremax` (Free Fire MAX), `com.rockstargames.gtav` (GTA V), `com.mojang.minecraftpe` (Minecraft), `com.riotgames.valorant` (Valorant), and `com.activision.callofduty.shooter` (Call of Duty Mobile).
